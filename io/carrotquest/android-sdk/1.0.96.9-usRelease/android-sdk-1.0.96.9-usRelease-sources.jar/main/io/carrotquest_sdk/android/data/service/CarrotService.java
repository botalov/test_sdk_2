package io.carrotquest_sdk.android.data.service;


import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import android.text.TextUtils;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import io.carrotquest_sdk.android.core.util.huawei.HuaweiUtilsKt;
import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.models.Settings;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.models.UserConversations;
import io.carrotquest_sdk.android.lib.models.UserProperty;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse;
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse;
import io.carrotquest_sdk.android.lib.network.responses.connect.RealtimeService;
import io.carrotquest_sdk.android.lib.network.responses.conversation.ConversationResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse;
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse;
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse;
import io.carrotquest_sdk.android.lib.utils.AndroidUtils;
import io.carrotquest_sdk.android.lib.utils.FreedomUtilsKt;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;
import io.carrotquest_sdk.android.lib.wss.Channel;
import io.carrotquest_sdk.android.lib.wss.ChannelEnum;
import io.carrotquest_sdk.android.lib.wss.IWssService;
import io.carrotquest_sdk.android.lib.wss.jwt.ClearRtsConnectDataIfNeedUseCaseKt;
import io.carrotquest_sdk.android.lib.wss.jwt.IsActualJwtTokenUseCaseKt;
import io.carrotquest_sdk.android.lib.wss.jwt.JwtTokenRefreshService;
import io.carrotquest_sdk.android.lib.wss.jwt.JwtWssService;
import io.carrotquest_sdk.android.lib.wss.jwt.RefreshJwtTokenUseCaseKt;
import io.carrotquest_sdk.android.lib.wss.response.WssResponse;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.core.main.CarrotSDK;
import io.carrotquest_sdk.android.core.main.ThemeSdk;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.core.util.UserAgent;
import io.carrotquest_sdk.android.core.util.files.download_files.DownloadManager;
import io.carrotquest_sdk.android.core.utm.UtmUtil;
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationTypingResponse;
import io.carrotquest_sdk.android.data.network.wss_responses.IRtsMessage;
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage;
import io.carrotquest_sdk.android.data.network.wss_responses.RtsMessageFactory;
import io.carrotquest_sdk.android.data.repositories.SettingsRepository;
import io.carrotquest_sdk.android.data.repositories.old.UserRepository;
import io.carrotquest_sdk.android.domain.entities.SettingsEntity;
import io.carrotquest_sdk.android.domain.entities.UserEntity;
import io.carrotquest_sdk.android.domain.use_cases.conversations.FindPopUpConversationsUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.popup.IncomingPopUpUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.rts.GetRtsHostUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.rts.SaveRtsHostUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.triggers.LoadTriggersUseCase;
import io.carrotquest_sdk.android.domain.use_cases.user.LoadUserUseCaseKt;
import io.carrotquest_sdk.android.presentation.constans.StatusOperators;
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushTapReceiver;
import io.carrotquest_sdk.android.presentation.mvp.utils.ViewUtilsKt;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.PublishSubject;
import okhttp3.ResponseBody;
import retrofit2.HttpException;

public class CarrotService implements ICarrotService {
    private static final String TAG = "CarrotService";

    @Inject
    UserRepository userRepository;
    @Inject
    Gson gson;

    private static CarrotService instance;
    public static CarrotService getInstance() {
        if(instance == null) {
            instance = new CarrotService();
        }
        return instance;
    }

    /**
     * Идентификатор аппа
     */
    private String appId;

    /**
     * Инициализирован ли сервис
     */
    private boolean isInitService = false;
    /**
     * Находится ли сервис в процессе инициализации
     */
    private boolean isInitServiceProcess = false;

    private Disposable disposableInit;

    /**
     * Общая библиотека для работы с API
     */
    public CarrotLib carrotLib;

    /**
     * Для работы с RTS
     */
    private IWssService wssService;

    /**
     * Для отписки от события авторизации
     */
    private  Disposable dAuth;

    /**
     * Для организации очереди запросов
     */
    private BehaviorSubject<Boolean> commandsBehaviorSubject;
    private CompositeDisposable allDisposables = new CompositeDisposable();

    private BehaviorSubject<Boolean> isInitBehaviorSubject;
    private boolean isUseEuServers = false;


    private Disposable disposableSendPush;
    private Disposable disposableAuth;

    public CarrotService(Context context, String appId, boolean useEuServers) {
        this.appId = appId;
        this.isUseEuServers = useEuServers;
        CarrotInternal.getLibComponent().inject(this);

        this.commandsBehaviorSubject = BehaviorSubject.create();
        this.isInitBehaviorSubject = BehaviorSubject.create();
        carrotLib = new CarrotLib(context, userRepository, isUseEuServers);
    }

    public CarrotService() {
        this.appId = CarrotSDK.getAppId();
        this.isUseEuServers = CarrotSDK.isUseEuApi();
        CarrotInternal.getLibComponent().inject(this);

        this.commandsBehaviorSubject = BehaviorSubject.create();
        this.isInitBehaviorSubject = BehaviorSubject.create();
        carrotLib = new CarrotLib(CarrotInternal.getLibComponent().getContextSdk(), userRepository, isUseEuServers);
    }

    private Observable<ConnectResponse> connectObservable = null;
    private int tryConnect = 0;


    /**
     * Инициализация сервисов (вызов setup())
     *
     * @param apiKey Ключ
     * @param callback Колюек сигнализирующий об успешности коннекта
     */
    @Override
    public void init(@NonNull String apiKey, CarrotSDK.Callback<Boolean> callback, boolean startSession) {
        Log.i("TEST_INIT_IN","init start");
        boolean needWssConnect = true;
        if(userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }

        try {
            userRepository.saveToken("");
        }catch (Exception exSaveToken) {
            Log.e(TAG, "save token error: " + exSaveToken);
        }

        if (!isInitService && !isInitServiceProcess) {
            Log.i("TEST_INIT_IN","XXX");
            isInitServiceProcess = true;

            String referrer = "";
            try {
                referrer = UtmUtil.INSTANCE.getReferrer(CarrotLib.getLibComponents().getContext());
            } catch (Exception e) {
                Log.e(TAG, e);
            }

            //TODO FREEDOM удалить потом
            SharedPreferencesLib.saveString(CarrotInternal.getLibComponent().getContextSdk(), "X_APP_ID_KEY", appId);

            if(carrotLib == null) {
                carrotLib = new CarrotLib(CarrotInternal.getLibComponent().getContextSdk(), userRepository, isUseEuServers);
            }
            String sdkVersion = CarrotSDK.getVersion();
            if(sdkVersion == null) {
                sdkVersion = "";
            }


            if(connectObservable != null) {
                connectObservable = null;
            }

            Log.i("TEST_INIT_IN","tryConnect: " + tryConnect);
            if(tryConnect > 3) {
                if(callback != null) {
                    callback.onFailure(new Exception("Too many attempts"));
                }
                return;
            }

            tryConnect++;

            try {
                ClearRtsConnectDataIfNeedUseCaseKt.clearRtsDataIfNeed(CarrotInternal.getLibComponent().getContextSdk(), appId);
                boolean tokenIsActual = IsActualJwtTokenUseCaseKt.isActualJwtToken(CarrotInternal.getLibComponent().getContextSdk());
                Log.i("TEST_INIT_IN","tokenIsActual: " + tokenIsActual);
                if (tokenIsActual) {
                    tryConnect = 0;
                    connectObservable = carrotLib.connect(apiKey,
                            "sdk " + sdkVersion,
                            "usersdkandroid",
                            referrer,
                            startSession);
                } else {
                    BehaviorSubject<String> b = BehaviorSubject.create();
                    Disposable dd = b
                            .subscribeOn(Schedulers.io())
                            .take(1)
                            .subscribe(token -> {
                                Log.i("TEST_INIT_IN","token: " + token);
                                if (userRepository == null) {
                                    userRepository = CarrotInternal.getLibComponent().getUserRepository();
                                }

                                User user = userRepository.getUser();
                                user.setToken(token);
                                userRepository.saveUser(user);

                                isInitServiceProcess = false;
                                Log.i("TEST_INIT_IN","start init");
                                init(apiKey, callback, startSession);
                            }, throwable -> {
                                Log.e(TAG, "refresh token error: " + throwable.toString());
                            });
                    RefreshJwtTokenUseCaseKt.refreshJwtToken(b);

                    return;
                }

            } catch(Exception connectEx){
                Log.e(TAG, "connectObservable getStackTrace: " + Arrays.toString(connectEx.getStackTrace()));
            }


            if(connectObservable == null) {
                if(callback != null) {
                    callback.onFailure(new Exception("connect is null"));
                }
                return;
            }

            disposableInit = connectObservable
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .filter(connectResponse -> {
                        return (connectResponse != null && connectResponse.getData() != null && connectResponse.getData().getApp() != null && !connectResponse.getData().getApp().isBlocked())
                                || (connectResponse != null && connectResponse.getMeta().getStatus() != 200);
                    })
                    .doOnNext(connectResponse -> {
                        Settings settings = connectResponse.getData().getApp().getSettings();
                        if (CarrotSDK.getTheme() == ThemeSdk.FROM_WEB) {
                            if ("dark".equals(settings.getTheme())) {
                                CarrotSDK.setTheme(ThemeSdk.DARK);
                            } else {
                                CarrotSDK.setTheme(ThemeSdk.LIGHT);
                            }
                        }

                        User user = connectResponse.getData().getUser();

                        ArrayList<Admin> admins = new ArrayList<>(connectResponse.getData().getApp().getAdmins());
                        SettingsEntity entity = new SettingsEntity(
                                user.getId(),
                                settings.isShowVK(),
                                settings.getTextLinkVK(),

                                settings.isShowViber(),
                                settings.getTextLinkViber(),

                                settings.isShowFB(),
                                settings.getTextLinkFB(),

                                settings.isShowTelegram(),
                                settings.getTextLinkTelegram(),

                                settings.isShowInstagram(),
                                settings.getTextLinkInstagram(),

                                settings.isShowWhatsapp(),
                                settings.getTextLinkWhatsapp(),

                                settings.getAppColor(),
                                settings.getWelcomeMessage(),
                                settings.getMessengerAvatar(),
                                settings.isShowPoweredBy(),
                                connectResponse.getSourceData(),

                                //connectResponse.getData().getApp().getName(),
                                connectResponse.getData().getApp().getSettings() == null ? connectResponse.getData().getApp().getName() : connectResponse.getData().getApp().getSettings().getMessengerName(),
                                connectResponse.getData().getApp().getId(),
                                connectResponse.getData().getApp().getSettings().isShowKbLinkInWelcomeMessage(),
                                "online".equals(connectResponse.getData().getApp().getStatusOperators()) ? StatusOperators.ONLINE : StatusOperators.OFFLINE,

                                settings.getOnlineMessage(),
                                settings.getOfflineMessage(),
                                admins,
                                settings.getTheme(),
                                settings.getLocale()

                        );

                        SettingsRepository.Companion.getInstance().saveSettings(entity);

                        UserEntity userEntity = new UserEntity(
                                user.getId(),
                                user.getToken(),
                                user.hasConversations,
                                user.isBanned(),
                                user.getConversationsUnread()
                        );

                        RealtimeService realtimeService = connectResponse.getData().getRealtimeServices();
                        Map<Integer, String> hosts = realtimeService.getHosts();
                        if(!hosts.isEmpty()) {
                            for(Integer key : hosts.keySet()) {
                                String rtsHost = hosts.get(key);
                                if(rtsHost != null && !rtsHost.isEmpty()) {
                                    SaveRtsHostUseCaseKt.saveRtsHost(CarrotInternal.getLibComponent().getContextSdk(), rtsHost);
                                    break;
                                }
                            }
                        }


//                        if(startSession) {
                        downloadPopUps(userEntity);
//                        }

                        io.carrotquest_sdk.android.data.repositories.UserRepository.Companion.getInstance().saveUser(userEntity);
                        UtmUtil.INSTANCE.sendSavedUtm(CarrotLib.getLibComponents().getContext());

                        //TODO FREEDOM удалить потом
                        if (FreedomUtilsKt.isFreedom(appId)) {
                            FreedomUtilsKt.saveDashlyTokenFlag();
                        }

                        loadTriggers();
                    })
                    .doOnError(t -> {
                        Log.d(TAG, t.toString());
                        if (callback != null) {
                            callback.onFailure(t);
                        }
                    })
                    .subscribeWith(createInitObserver(callback, needWssConnect));

            carrotLib.getWssService();

            initBroadcast(CarrotLib.getLibComponents().getContext());
        } else {
            if (callback != null) {
                callback.onResponse(true);
            }
        }
    }

    private void loadTriggers() {
        LoadTriggersUseCase loadTriggersUseCase = new LoadTriggersUseCase();
        loadTriggersUseCase.call()
                .take(1)
                .subscribeOn(Schedulers.io())
                //.onErrorReturnItem(false)
                .subscribe();
    }

    private void initBroadcast(Context context) {
        PushTapReceiver messageReceiver = new PushTapReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction("carrotquest.sdk.tap.push");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.registerReceiver(messageReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            context.registerReceiver(messageReceiver, filter);
        }
    }

    private void downloadPopUps(UserEntity userEntity) {
        String neededShowPopUpConversationId = SharedPreferencesLib
                .getString(CarrotInternal.getLibComponent().getContextSdk(),"need_show_popup_conv_id");
            Disposable d = FindPopUpConversationsUseCaseKt.findLastUnreadPopup(Observable.just(userEntity))
                    .take(1)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .delay(2, TimeUnit.SECONDS)
                    .onErrorReturnItem(new ArrayList<>())
                    .subscribe(popUpsList -> {
                        if (popUpsList != null && !popUpsList.isEmpty()) {
                            for(PopUpMessage p : popUpsList) {
                                IncomingPopUpUseCaseKt.saveNewPopUp(Observable.just(p))
                                        .take(1)
                                        .subscribe();
                            }
                        }
                    }, throwable -> Log.e(TAG, throwable.toString()));
    }

    /**
     * Деинициализация сервисов (разлогирование, остановка RTS, etc.)
     */
    @Override
    public void deInit() {
        String deviceId = AndroidUtils.getInstallId(CarrotInternal.getLibComponent().getContextSdk());
        if(userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }

        unsubscribePush(userRepository.getUser().getId(), deviceId);

        allDisposables.clear();
        isInitService = false;
        isInitServiceProcess = false;
        if(wssService != null) {
            wssService.deInit();
            wssService = null;
        }

        deInitDisposables();

        this.commandsBehaviorSubject = BehaviorSubject.create();

        carrotLib.clearSession();
        userRepository.saveUser(new User());
        //settingsRepository.saveSettings((Settings) null);
        //conversationsRepository.saveConversations(new UserConversations());


    }

    /**
     * @return Ининциализированы ли сервисы
     */
    @Override
    public boolean isInit() {
        return isInitService;
    }

    @Override
    public void authUser(String id, String userAuthKey) {
        authUser(id, userAuthKey, null);
    }


    @Override
    public void authUser(String id, String userAuthKey, DisposableObserver<User> userDisposableObserver) {
        dAuth = commandsBehaviorSubject
                .onErrorReturnItem(false)
                .subscribe(isInit -> {
                    auth(id, userAuthKey, isInitService, userDisposableObserver);
                    if (dAuth != null && !dAuth.isDisposed()) {
                        dAuth.dispose();
                    }
                },
                error -> Log.e(TAG, error));
    }

    @Override
    public void hashedAuth(String id, String hash, DisposableObserver<User> userDisposableObserver) {
        dAuth = commandsBehaviorSubject
                .onErrorReturnItem(false)
                .subscribe(isInit -> {
                            hashedAuth(id, hash, isInitService, userDisposableObserver);
                            if (dAuth != null && !dAuth.isDisposed()) {
                                dAuth.dispose();
                            }
                        },
                        error -> Log.e(TAG, error));
    }

    @Override
    public void setUserProperty(List<UserProperty> userProperty) {
        allDisposables.add(commandsBehaviorSubject.onErrorReturnItem(false).subscribeWith(new DisposableObserver<Boolean>() {
            @Override
            public void onNext(Boolean isInitService) {
                if (isInitService) {
                    setUserPropertySimple(userProperty);
                }
            }

            @Override
            public void onError(Throwable e) {
                Log.e(TAG, e.toString());
            }

            @Override
            public void onComplete() {

            }
        }));
    }

    public void setUserPropertySimple(List<UserProperty> userProperty) {
        if(userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }

        carrotLib.setProperty(userRepository.getUser().getId(), userProperty)
                .take(1)
                .subscribe(new Observer<NetworkResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(NetworkResponse networkResponse) {
                        Log.d(TAG, "onNext setUserProperty");
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e);
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @Override
    public void setUserProperty(List<UserProperty> userProperty, DisposableObserver<Boolean> observer) {
        String prefix = "Set user property: ";
        allDisposables.add(commandsBehaviorSubject.subscribeWith(new DisposableObserver<Boolean>() {
            @Override
            public void onNext(Boolean isInitService) {
                if (isInitService) {
                    carrotLib
                            .setProperty(userRepository.getUser().getId(), userProperty)
                            .subscribe(new Observer<NetworkResponse>() {
                                @Override
                                public void onSubscribe(Disposable d) {
                                    Log.d(TAG, prefix + "onSubscribe");
                                }

                                @Override
                                public void onNext(NetworkResponse networkResponse) {
                                    boolean responseNotEmpty = networkResponse != null;
                                    observer.onNext(responseNotEmpty);
                                }

                                @Override
                                public void onError(Throwable e) {
                                    String errorText = prefix + "error: " + e.toString();
                                    Log.e(TAG, errorText);
                                    observer.onError(e);
                                }

                                @Override
                                public void onComplete() {
                                    Log.d(TAG, prefix + "onComplete");
                                }
                            });
                }
            }

            @Override
            public void onError(Throwable e) {
                Log.e(TAG, e.toString());
            }

            @Override
            public void onComplete() {

            }
        }));
    }

    @Override
    public void trackEvent(String eventName, String eventParams, DisposableObserver<NetworkResponse> observer) {

        allDisposables.add(commandsBehaviorSubject.subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean result) {
                        if (result) {
                            trackEventSimple(eventName, eventParams, observer);
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    public  void trackEventSimple(String eventName, String eventParams, DisposableObserver<NetworkResponse> observer) {
        if(userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }

        carrotLib.trackEvent(userRepository.getUser().getId(), eventName, eventParams)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<NetworkResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(NetworkResponse response) {
                        observer.onNext(response);
                    }

                    @Override
                    public void onError(Throwable e) {
                        observer.onError(e);
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @Override
    public void getConversations(String userId, DisposableObserver<UserConversations> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isInitService) {
                        if (isInitService) {
                            carrotLib
                                    .getConservations(userId)
                                    .subscribeOn(Schedulers.io())
                                    .doOnError(throwable -> {
                                        Log.e(TAG, throwable);
                                    })
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<UserConversations>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {

                                        }

                                        @Override
                                        public void onNext(UserConversations userConversations) {
                                            observer.onNext(userConversations);
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            Log.e(TAG, e.toString());
                                            observer.onError(e);
                                        }

                                        @Override
                                        public void onComplete() {

                                        }
                                    });
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    @Override
    public void getConversations(String userId, String after, DisposableObserver<UserConversations> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isInitService) {
                        if (isInitService) {
                            carrotLib
                                    .getConservations(userId, after)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<UserConversations>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {

                                        }

                                        @Override
                                        public void onNext(UserConversations userConversations) {
                                            observer.onNext(userConversations);
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            Log.e(TAG, e.toString());
                                            observer.onError(e);
                                        }

                                        @Override
                                        public void onComplete() {

                                        }
                                    });
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    @Override
    public void getConversation(String conversationId, Observer<ConversationResponse> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isInitService) {
                        if (isInitService) {
                            carrotLib
                                    .getConservation(conversationId)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<ConversationResponse>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {

                                        }

                                        @Override
                                        public void onNext(ConversationResponse conversation) {
                                            observer.onNext(conversation);
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            Log.e(TAG, e.toString());
                                            observer.onError(e);
                                        }

                                        @Override
                                        public void onComplete() {

                                        }
                                    });
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    @Override
    public void startConversations(String userId, String messageText, DisposableObserver<StartConversationResponse> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isInitService) {
                        if (isInitService) {
                            carrotLib
                                    .startConversation(userId, messageText)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<StartConversationResponse>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {

                                        }

                                        @Override
                                        public void onNext(StartConversationResponse startConversationResponse) {
                                            observer.onNext(startConversationResponse);
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            Log.e(TAG, e.toString());
                                            observer.onError(e);
                                        }

                                        @Override
                                        public void onComplete() {

                                        }
                                    });
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    @Override
    public void startConversations(String userId, File file, DisposableObserver<StartConversationResponse> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isInitService) {
                        if (isInitService) {
                            carrotLib
                                    .startConversation(userId, file)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<StartConversationResponse>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {

                                        }

                                        @Override
                                        public void onNext(StartConversationResponse startConversationResponse) {
                                            observer.onNext(startConversationResponse);
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            Log.e(TAG, e.toString());
                                            observer.onError(e);
                                        }

                                        @Override
                                        public void onComplete() {

                                        }
                                    });
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    @Override
    public void getMessage(String conversationId, String after, DisposableObserver<MessagesResponse> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isInitService) {
                        if (isInitService) {
                            try {
                                if (after.isEmpty()) {
                                    carrotLib
                                            .getMessages(conversationId)
                                            .observeOn(AndroidSchedulers.mainThread())
                                            .subscribe(new Observer<MessagesResponse>() {
                                                @Override
                                                public void onSubscribe(Disposable d) {

                                                }

                                                @Override
                                                public void onNext(MessagesResponse messagesResponse) {
                                                    observer.onNext(messagesResponse);
                                                }

                                                @Override
                                                public void onError(Throwable e) {
                                                    Log.e(TAG, e.toString());
                                                    observer.onError(e);
                                                }

                                                @Override
                                                public void onComplete() {

                                                }
                                            });
                                } else {
                                    carrotLib
                                            .getMessages(conversationId, after)
                                            .observeOn(AndroidSchedulers.mainThread())
                                            .subscribe(new Observer<MessagesResponse>() {
                                                @Override
                                                public void onSubscribe(Disposable d) {

                                                }

                                                @Override
                                                public void onNext(MessagesResponse messagesResponse) {
                                                    observer.onNext(messagesResponse);
                                                }

                                                @Override
                                                public void onError(Throwable e) {
                                                    Log.e(TAG, e.toString());
                                                    observer.onError(e);
                                                }

                                                @Override
                                                public void onComplete() {

                                                }
                                            });
                                }
                            } catch (Exception e) {
                                Log.e(TAG, e.toString());
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    @Override
    public void reply(String conversationId, String messageText, boolean fromUser, String randomId, DisposableObserver<ReplyResponse> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isInitService) {
                        if (isInitService) {
                            carrotLib
                                    .reply(conversationId, messageText, fromUser, randomId)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<ReplyResponse>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {

                                        }

                                        @Override
                                        public void onNext(ReplyResponse replyResponse) {
                                            observer.onNext(replyResponse);
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            Log.e(TAG, e.toString());
                                            observer.onError(e);
                                        }

                                        @Override
                                        public void onComplete() {

                                        }
                                    });
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    @Override
    public void replyFile(String conversationId, File file, String autoAssign, String randomId, DisposableObserver<ReplyFileResponse> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isResult) {
                        carrotLib.replyFile(conversationId, file, autoAssign, randomId)
                                .observeOn(AndroidSchedulers.mainThread())
                                .onErrorReturn(throwable -> {
                                    ReplyFileResponse errorResponse = new ReplyFileResponse();
                                    Meta meta = new Meta();
                                    meta.setStatus(400);
                                    meta.setError(throwable.getMessage());
                                    errorResponse.setMeta(meta);
                                    return errorResponse;
                                })
                                .subscribe(new Observer<ReplyFileResponse>() {
                                    @Override
                                    public void onSubscribe(Disposable d) {

                                    }

                                    @Override
                                    public void onNext(ReplyFileResponse response) {
                                        observer.onNext(response);
                                    }

                                    @Override
                                    public void onError(Throwable e) {
                                        Log.e(TAG, e.toString());
                                        observer.onError(e);
                                    }

                                    @Override
                                    public void onComplete() {

                                    }
                                });
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    @Override
    public void trackClickByPush(String conversationId, DisposableObserver<NetworkResponse> observer) {
        carrotLib.trackInteraction(conversationId, "clicked")
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<NetworkResponse>() {
                    @Override
                    public void onSubscribe(@NonNull Disposable d) {

                    }

                    @Override
                    public void onNext(@NonNull NetworkResponse response) {
                        observer.onNext(response);
                    }

                    @Override
                    public void onError(@NonNull Throwable e) {
                        Log.e(TAG, e.toString());
                        observer.onError(e);
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @Override
    public void markConversationAsRead(String conversationId, DisposableObserver<NetworkResponse> observer) {
        carrotLib.markRead(conversationId)
                .observeOn(AndroidSchedulers.mainThread())
                .doOnError(t -> {
                    Log.e("markReadError", t);
                })
                .subscribe(new Observer<NetworkResponse>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onNext(NetworkResponse emptyResponse) {
                        observer.onNext(emptyResponse);
                        io.carrotquest_sdk.android.data.repositories.ConversationsRepository.Companion.getInstance().removeUnreadConversation(conversationId);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                        observer.onError(e);
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    @Override
    public void voteOperator(String messageId, Integer vote, String comment, DisposableObserver<NetworkResponse> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {

                    @Override
                    public void onNext(Boolean isSuccessful) {
                        if (isSuccessful) {
                            JsonObject bodyMetaDataObject = new JsonObject();
                            bodyMetaDataObject.addProperty("vote", vote);
                            if (!TextUtils.isEmpty(comment)) {
                                bodyMetaDataObject.addProperty("comment", comment);
                            }

                            carrotLib.conversationParts(messageId, bodyMetaDataObject)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<NetworkResponse>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {

                                        }

                                        @Override
                                        public void onNext(NetworkResponse emptyResponse) {
                                            observer.onNext(emptyResponse);
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            Log.e(TAG, e.toString());
                                            observer.onError(e);
                                        }

                                        @Override
                                        public void onComplete() {

                                        }
                                    });
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                }));
    }

    @Override
    public void voteOperator(String messageId, Integer vote, DisposableObserver<NetworkResponse> observer) {
        voteOperator(messageId, vote, "", observer);
    }

    @Override
    public void updateAutoReply(String messageId, boolean replied, DisposableObserver<NetworkResponse> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {

                    @Override
                    public void onNext(Boolean isSuccessful) {
                        if (isSuccessful) {
                            JsonObject bodyMetaDataObject = new JsonObject();
                            bodyMetaDataObject.addProperty("replied", replied);

                            carrotLib.conversationParts(messageId, bodyMetaDataObject)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<NetworkResponse>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {

                                        }

                                        @Override
                                        public void onNext(NetworkResponse emptyResponse) {
                                            observer.onNext(emptyResponse);
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            Log.e(TAG, e.toString());
                                            observer.onError(e);
                                        }

                                        @Override
                                        public void onComplete() {

                                        }
                                    });
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                }));
    }

    @Override
    public void downloadFile(String messageId, String url, long size, Observer<Integer> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isResult) {
                        DownloadManager.startDownload(messageId, url, size, observer);
                    }

                    @Override
                    public void onError(Throwable e) {
                        observer.onError(e);
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    private Disposable typingDisposable;
    private Long startTypingTime = null;
    private Disposable typingDebounceDisposable;

    @Override
    public void setTyping(String conversationId, String messageBody) {
        long currentTime = System.currentTimeMillis();
        long diffTime = currentTime - (startTypingTime == null ? 0L : startTypingTime);

        if(typingDebounceDisposable != null && !typingDebounceDisposable.isDisposed()) {
            typingDebounceDisposable.dispose();
        }

        typingDebounceDisposable = commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .debounce(2, TimeUnit.SECONDS)
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isSuccessful) {
                        if (isSuccessful) {
                            carrotLib.setTyping(conversationId, messageBody)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<NetworkResponse>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {

                                        }

                                        @Override
                                        public void onNext(NetworkResponse emptyResponse) {
                                            typingDebounceDisposable.dispose();
                                            typingDisposable.dispose();
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            Log.e(TAG, e.toString());
                                        }

                                        @Override
                                        public void onComplete() {

                                        }
                                    });
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                });
        allDisposables.add(typingDebounceDisposable);

        if (diffTime < 2000) {
            return;
        }

        if (typingDisposable != null && !typingDisposable.isDisposed()) {
            return;
        }

        startTypingTime = System.currentTimeMillis();

        typingDisposable = commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isSuccessful) {
                        if (isSuccessful) {
                            carrotLib.setTyping(conversationId, messageBody)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(new Observer<NetworkResponse>() {
                                        @Override
                                        public void onSubscribe(Disposable d) {

                                        }

                                        @Override
                                        public void onNext(NetworkResponse emptyResponse) {
                                            typingDebounceDisposable.dispose();
                                            typingDisposable.dispose();
                                        }

                                        @Override
                                        public void onError(Throwable e) {
                                            Log.e(TAG, e.toString());
                                        }

                                        @Override
                                        public void onComplete() {

                                        }
                                    });
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                });
        allDisposables.add(typingDisposable);
    }

    @Override
    public void addInitObserver(Observer<Boolean> initObserver) {
        if(isInitBehaviorSubject != null) {
            isInitBehaviorSubject.subscribe(initObserver);
        }
    }

    @Override
    public String getSaveUserId() {
        return userRepository.getUser().getId();
    }


    @Override
    public void chooseRoutingBot(String conversationId, DisposableObserver<ChooseRoutingBotResponse> observer) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isResult) {
                        carrotLib.chooseRoutingBot(conversationId)
                                .take(1)
                                .subscribe(new Observer<ChooseRoutingBotResponse>() {
                            @Override
                            public void onSubscribe(Disposable d) {

                            }

                            @Override
                            public void onNext(ChooseRoutingBotResponse chooseRoutingBotResponse) {
                                observer.onNext(chooseRoutingBotResponse);
                            }

                            @Override
                            public void onError(Throwable e) {
                                observer.onError(e);
                            }

                            @Override
                            public void onComplete() {

                            }
                        });
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, e.toString());
                        observer.onError(e);
                    }

                    @Override
                    public void onComplete() {

                    }
                }));
    }

    private void initPushesService() {
        try {
            boolean isHuaweiDevice = HuaweiUtilsKt.isHuawei();
            if(isHuaweiDevice) {
                return;
            }

            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                if (!task.isSuccessful()) {
                    return;
                }

                NotificationManagerCompat notificationManager = NotificationManagerCompat.from(CarrotInternal.getLibComponent().getContextSdk());
                if (task.getResult() != null && notificationManager.areNotificationsEnabled()) {
                    String token = task.getResult();
                    String deviceId = AndroidUtils.getInstallId(CarrotInternal.getLibComponent().getContextSdk());
                    if(userRepository == null) {
                        userRepository = CarrotInternal.getLibComponent().getUserRepository();
                    }

                    sendPushToken(userRepository.getUser().getId(), token, deviceId);
                }
            });

        }
        catch (IllegalStateException eIllegalState) {
            Log.d(TAG, eIllegalState.toString());
        }
        catch (Exception e) {
            Log.d(TAG, e.toString());
        }
    }

    public void sendPushToken(String userId, String token, String deviceId) {
        allDisposables.add(commandsBehaviorSubject
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeWith(new DisposableObserver<Boolean>() {
                    @Override
                    public void onNext(Boolean isInitService) {
                        if (isInitService) {
                            String okhttpVersion = carrotLib.getOkHttpVersion();
                            String sUserAgent = UserAgent.Companion.getInstance(CarrotInternal.getLibComponent().getContextSdk()).getUserAgentString(okhttpVersion);

                            String deviceType = ViewUtilsKt.isTablet(CarrotInternal.getLibComponent().getContextSdk()) ? "tablet" : "phone";
                            String device = HuaweiUtilsKt.isHuawei() ? "Huawei [huawei_push] 1.0.0" : "Android";
                            String sdkVersion = CarrotSDK.getVersion();
                            if(sdkVersion == null) {
                                sdkVersion = "";
                            }
                            String browser = "sdk " + sdkVersion;


                            String type = "mobile";

                            if(token == null || token.isEmpty()) {
                                return;
                            }

                            disposableSendPush = carrotLib
                                    .sendPushToken(userId,
                                            token,
                                            deviceId,
                                            type,
                                            deviceType,
                                            device,
                                            browser,
                                            sUserAgent)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(res -> {
                                        Log.d(TAG, res.toString());
                                    }, error-> Log.e(TAG, error));
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        Log.e(TAG, "error happens in sendPushToken: " + e.toString());
                    }

                    @Override
                    public void onComplete() {

                    }
                })
        );
    }

    public void unsubscribePush(String userId, String deviceId) {
        allDisposables.add(carrotLib
                .deletePushToken(userId, deviceId, "mobile")
                .observeOn(AndroidSchedulers.mainThread())
                .take(1)
                .doOnError(e->{
                    Log.e("unsubscribePush",e.toString());
                })
                .subscribe(res -> Log.d(TAG, res.toString()), error-> Log.e(TAG, error)));
    }

    /**
     * Создает новый экземпляр наблюдателя за состоянием инициализации и всего такого
     * @return Обсервер
     */
    private DisposableObserver<ConnectResponse> createInitObserver(CarrotSDK.Callback<Boolean> callback, boolean needWssConnect) {
        return new DisposableObserver<ConnectResponse>() {
            @Override
            public void onNext(ConnectResponse connectResponse) {
                try {
                    try {
                        userRepository.saveUser(connectResponse.getData().getUser());
                    } catch (Exception e) {
                        Log.d("saveUserTag", "error: " + e);
                    }
                    //settingsRepository.saveSettings(connectResponse);
                    initPushesService();

                    initComplete(connectResponse, needWssConnect);
                    try {
                        if(callback != null) {
                            callback.onResponse(TextUtils.isEmpty(connectResponse.getMeta().getError()));
                        }
                    }
                    catch (Exception connectRespEx) {
                        Log.e(TAG, connectRespEx);
                        if(callback != null) {
                            callback.onResponse(false);
                        }
                    }

                } catch (Exception e) {
                    initError(e);
                    if(callback != null) {
                        callback.onResponse(false);
                    }
                }
            }

            @Override
            public void onError(Throwable e) {
                initError(e);
                if(callback != null) {
                    callback.onFailure(e);
                }
            }

            @Override
            public void onComplete() {
                isInitServiceProcess = false;
            }
        };
    }

    private void initComplete(ConnectResponse connectResponse, boolean needWssConnect) {
        userRepository.saveUser(connectResponse.getData().getUser());
        // Если инициализация прошла успешно, то меняем значение флага и вызываем событие
        isInitService = true;
        isInitServiceProcess = false;

        CarrotSDK.getInitObservable().onNext(true);
        commandsBehaviorSubject.onNext(true);

        startRefreshTokenService();
        if(needWssConnect) {
            startWss();
        }

        String userId = connectResponse.getData().getUser().getId();
        LoadUserUseCaseKt
                .loadUserProps(Observable.just(true), userId)
                .take(1)
                .subscribe();
    }

    private void initError(Throwable e) {
        isInitServiceProcess = false;
        isInitService = false;
        CarrotSDK.getInitObservable().onNext(false);

        if (e != null) {
            Log.e(TAG, e.toString());
            e.printStackTrace();
        }
        if (e instanceof HttpException) {
            ResponseBody responseBody = ((HttpException) e).response().errorBody();
            try {
                if (responseBody != null) {
                    try {
                        String errorBody = responseBody.string();
                        Log.e(TAG, errorBody);
                    } catch (IOException ioException) {
                        Log.e(TAG, responseBody.toString());
                    }
                }
            } catch (Exception e1) {
                e1.printStackTrace();
                Log.e(TAG, e1);
            }
        }
    }

    private PublishSubject<ConversationTypingResponse> adminTypingObservable = PublishSubject.create();
    public Observable<ConversationTypingResponse> adminTypingObservable(){
        return adminTypingObservable;
    }

    public void adminTyping(ConversationTypingResponse pair) {
        adminTypingObservable.onNext(pair);
    }

    public void startRefreshTokenService() {
//        allDisposables.add(JwtTokenRefreshService.Companion.getInstance().getUpdateJwtTokenObservable().subscribe(s -> {
//            Log.d("JWT", "getUpdateJwtTokenObservable onNext: " + s);
//            startWss();
//        }, throwable -> {
//            Log.e("JWT", throwable);
//        }));
        JwtTokenRefreshService.Companion.getInstance().start();
    }

    private void startWss() {
        //Запускаем сервис
        if(wssService != null) {
            wssService.deInit();
            wssService = null;
        }

        String host = GetRtsHostUseCaseKt.getRtsHost(CarrotLib.getLibComponents().getContext());
        wssService = new JwtWssService(CarrotLib.getLibComponents().getContext(), host);


        List<Channel> channels = new ArrayList<>();
        List<String> params = new ArrayList<>();
        params.add(userRepository.getUser().getId());
        channels.add(new Channel(ChannelEnum.ping));
        channels.add(new Channel(ChannelEnum.conversation_typing, params));
        channels.add(new Channel(ChannelEnum.conversation, params));
        channels.add(new Channel(ChannelEnum.message_conversation_started, params));
        channels.add(new Channel(ChannelEnum.conversation_read, params));
        channels.add(new Channel(ChannelEnum.conversation_reply, params));
        channels.add(new Channel(ChannelEnum.run_script, params));
        channels.add(new Channel(ChannelEnum.user_ban, params));
        channels.add(new Channel(ChannelEnum.users_removed, params));
        channels.add(new Channel(ChannelEnum.app_online_changed));
        channels.add(new Channel(ChannelEnum.conversation_reply_changed, params));
        channels.add(new Channel(ChannelEnum.chat_bot_conversation_finished, params));
        channels.add(new Channel(ChannelEnum.conversation_parts_batch, params));
        //channels.add(new Channel(ChannelEnum.conversation_assigned, params));

        List<Observer<WssResponse>> observers = new ArrayList<>();
        observers.add(new Observer<WssResponse>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(@NotNull WssResponse response) {
                IRtsMessage rtsMessage = RtsMessageFactory.createResponse(response);
                if (rtsMessage != null) {
                    rtsMessage.process();
                }
            }

            @Override
            public void onError(Throwable e) {
                Log.e(TAG, e.toString());
            }

            @Override
            public void onComplete() {

            }
        });

        wssService.stopSocket(appId);
        wssService.startSocket(appId, channels, observers);
    }


    private void auth(String id, String userAuthKey, boolean isInitService, DisposableObserver<User> getAuthUserObserver) {
        if (isInitService) {
            if (CarrotSDK.getInitObservable() != null) {
                CarrotSDK.getInitObservable().onNext(false);
            }

            if(userRepository == null) {
                userRepository = CarrotInternal.getLibComponent().getUserRepository();
            }

            disposableAuth = carrotLib.auth(id, userAuthKey)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(response -> {
                                if (response.getData() != null && response.getData().getUser() != null) {
                                    User tempUser = response.getData().getUser();
                                    if (TextUtils.isEmpty(tempUser.getToken()) && !TextUtils.isEmpty(response.getData().getAuthToken())) {
                                        tempUser.setToken(response.getData().getAuthToken());
                                    }
                                    userRepository.saveUser(tempUser);

                                    UserEntity userEntity = new UserEntity(
                                            tempUser.getId(),
                                            tempUser.getToken(),
                                            tempUser.hasConversations,
                                            tempUser.isBanned(),
                                            tempUser.getConversationsUnread()
                                    );
                                    io.carrotquest_sdk.android.data.repositories.UserRepository.Companion.getInstance().saveUser(userEntity);
                                }
                                User user = userRepository.getUser();
                                getConversations(user.getId(), new DisposableObserver<UserConversations>() {
                                    @Override
                                    public void onNext(UserConversations userConversations) {
                                        if (getAuthUserObserver != null) {
                                            getAuthUserObserver.onNext(user);
                                        }

                                        startWss();
                                        CarrotSDK.getInitObservable().onNext(response.getMeta() != null && TextUtils.isEmpty(response.getMeta().getError()));
                                    }

                                    @Override
                                    public void onError(Throwable e) {
                                        if (getAuthUserObserver != null) {
                                            getAuthUserObserver.onError(e);
                                        }
                                    }

                                    @Override
                                    public void onComplete() {

                                    }
                                });

                                initPushesService();
                            },
                            e -> {
                                authError(e);
                                if (getAuthUserObserver != null) {
                                    getAuthUserObserver.onError(e);
                                }
                                if (CarrotSDK.getInitObservable() != null) {
                                    CarrotSDK.getInitObservable().onNext(false);
                                }
                            });

        }
    }

    private void hashedAuth(String id, String hash, boolean isInitService, DisposableObserver<User> getAuthUserObserver) {
        if (isInitService) {
            if (CarrotSDK.getInitObservable() != null) {
                CarrotSDK.getInitObservable().onNext(false);
            }

            if(userRepository == null) {
                userRepository = CarrotInternal.getLibComponent().getUserRepository();
            }

            disposableAuth = carrotLib.hashedAuth(id, hash)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(response -> {
                                if (response.getData() != null && response.getData().getUser() != null) {
                                    User tempUser = response.getData().getUser();
                                    if (TextUtils.isEmpty(tempUser.getToken()) && !TextUtils.isEmpty(response.getData().getAuthToken())) {
                                        tempUser.setToken(response.getData().getAuthToken());
                                    }
                                    userRepository.saveUser(tempUser);

                                    UserEntity userEntity = new UserEntity(
                                            tempUser.getId(),
                                            tempUser.getToken(),
                                            tempUser.hasConversations,
                                            tempUser.isBanned(),
                                            tempUser.getConversationsUnread()
                                    );
                                    io.carrotquest_sdk.android.data.repositories.UserRepository.Companion.getInstance().saveUser(userEntity);
                                }
                                User user = userRepository.getUser();
                                getConversations(user.getId(), new DisposableObserver<UserConversations>() {
                                    @Override
                                    public void onNext(UserConversations userConversations) {
                                        if (getAuthUserObserver != null) {
                                            getAuthUserObserver.onNext(user);
                                        }

                                        startWss();
                                        CarrotSDK.getInitObservable().onNext(response.getMeta() != null && TextUtils.isEmpty(response.getMeta().getError()));
                                    }

                                    @Override
                                    public void onError(Throwable e) {
                                        if (getAuthUserObserver != null) {
                                            getAuthUserObserver.onError(e);
                                        }
                                    }

                                    @Override
                                    public void onComplete() {

                                    }
                                });

                                initPushesService();
                            },
                            e -> {
                                authError(e);
                                if (getAuthUserObserver != null) {
                                    getAuthUserObserver.onError(e);
                                }
                                if (CarrotSDK.getInitObservable() != null) {
                                    CarrotSDK.getInitObservable().onNext(false);
                                }
                            });

        }
    }

    private void authError(Throwable e) {
        if (e instanceof HttpException) {
            ResponseBody responseBody = ((HttpException) e).response().errorBody();
            try {
                String body = responseBody != null ? responseBody.string() : "";
                //ErrorResponse response = gson.fromJson(body, ErrorResponse.class);
                //Log.e(TAG, response.errorMessage);
            } catch (NullPointerException npe) {
                npe.printStackTrace();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
        e.printStackTrace();
    }


    private void deInitDisposables() {
        if(disposableInit != null && !disposableInit.isDisposed()) {
            disposableInit.dispose();
        }

        if(disposableSendPush != null && !disposableSendPush.isDisposed()) {
            disposableSendPush.dispose();
        }

        if(disposableAuth != null && !disposableAuth.isDisposed()) {
            disposableAuth.dispose();
        }

        if(allDisposables != null && !allDisposables.isDisposed()) {
            allDisposables.dispose();
            allDisposables = new CompositeDisposable();
        }

        adminTypingObservable.onComplete();
        adminTypingObservable = PublishSubject.create();
    }
}
