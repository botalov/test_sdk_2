package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshData
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshResponse
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject


fun refreshJwtToken(updateJwtTokenSubject: BehaviorSubject<String>) {
    val carrotApi = CarrotLib.getLibComponents().carrotApi

    val needUpdateRefreshToken = needUpdateRefreshToken()
    val d = carrotApi.refresh(needUpdateRefreshToken)
        .subscribeOn(Schedulers.io())
        .take(1)
        .doOnError { e ->
            Log.e("refresh error: ", e)
        }
        .onErrorReturn { e ->
            val meta = Meta()
            meta.status = 999
            meta.error = e.toString()

            val data = RefreshData(access = "", refresh = "")
            return@onErrorReturn RefreshResponse(meta = meta, data = data)
        }
        .subscribe { response ->
            Log.i("JWT_RTS", "refreshJwtToken response ${response.meta.status}")
            if (response.meta.status == 200) {
                val token = response.data.access
                saveJwtToken(token)
                val refreshToken = response.data.refresh
                saveRefreshToken(refreshToken)

                updateJwtTokenSubject.onNext(token)
            }
        }
}

private fun needUpdateRefreshToken(): Boolean {
    return !isActualRefreshToken()
}