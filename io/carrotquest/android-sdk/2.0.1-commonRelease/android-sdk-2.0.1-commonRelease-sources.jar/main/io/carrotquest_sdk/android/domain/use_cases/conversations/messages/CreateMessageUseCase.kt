package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import android.webkit.URLUtil
import com.google.gson.Gson
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.entities.Optional
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversation
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse
import io.reactivex.Observable
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max

fun Observable<SettingsEntity>.createWelcomeMessage() : Observable<Optional<MessageData>> {
    return Observable.defer {
        return@defer this.flatMap {
            val createdTS = (System.currentTimeMillis() / 1000).toString()
            val avatar = if (URLUtil.isValidUrl(it.messengerAvatar)) {
                it.messengerAvatar!!
            } else {
                BuildConfig.BASE_FILES_URL + "/avatars/" + it.messengerAvatar!!
            }
            val message = MessageData()
            message.id = createdTS

            message.body = it.welcomeMessage
            message.conversation = ""
            message.created = createdTS
            message.sentVia = ResponseFields.SDK_ANDROID
            message.direction = ResponseFields.ADMIN_2_USER
            message.isFirst = true
            message.messageFrom = Admin()
            message.messageFrom.id = ""
            message.messageFrom.avatar = avatar
            message.messageFrom.type = "default_admin"
            message.messageFrom.name = it.appName

            message.type = ResponseFields.REPLY_ADMIN
            message.status = MessageStatus.NORMAL.name.lowercase(Locale.getDefault())
            message.hasKBLink = it.showLinkKbAtWelcomeMessage

            message.sourceJsonData = JSONObject(Gson().toJson(message))

            MessagesRepository.getInstance().setData(MessagesResponse())
            if (MessagesRepository.getInstance().getWelcomeMessage() == null) {
                MessagesRepository.getInstance().saveWelcomeMessage(message)
                //MessagesRepository.getInstance().addMessage(message)
            }
            return@flatMap Observable.just(Optional(message))
        }
    }
}

fun <T> Observable<T>.removeWelcomeMessage() : Observable<String> {
    return Observable.defer {
        return@defer this.flatMap {
            val message = MessagesRepository.getInstance().getWelcomeMessage()
            if(message != null) {
                val messageId = message.id ?: ""
                MessagesRepository.getInstance().removeMessage(message)
                MessagesRepository.getInstance().saveWelcomeMessage(null)
                Observable.just(messageId)
            } else {
                Observable.just("")
            }
        }
    }
}


fun <T> Observable<T>.createMessage(text: String, conversationId: String) : Observable<Optional<MessageData>> {
    return createMessage(text, conversationId, isFirst = false, status = MessageStatus.LOADING)
            .doOnNext { message ->
                MessagesRepository.getInstance().addMessage(message.value!!)
            }
}

fun <T> Observable<T>.createMessage(text: String, conversationId: String, isFirst: Boolean, status: MessageStatus) : Observable<Optional<MessageData>> {
    return Observable.defer {
        return@defer this.flatMap {

            return@flatMap Observable.just(true)
                    .getConversation(conversationId)
                    .flatMap { conversationOptional ->
                        val currentTimeStamp = (System.currentTimeMillis() / 1000)
                        val createdTS = when (conversationOptional.value?.lastUpdate == null) {
                            true -> currentTimeStamp.toString()
                            else -> (max(java.lang.Long.parseLong(conversationOptional.value?.lastUpdate!!) /*+ 1*/, currentTimeStamp)).toString()
                        }

                        val message = MessageData()
                        message.id = createdTS
                        message.body = text.replace("\n","<br/>")
                        message.conversation = conversationId
                        message.created = createdTS
                        message.sentVia = ResponseFields.SDK_ANDROID
                        message.direction = ResponseFields.USER_2_ADMIN
                        message.isFirst = isFirst
                        message.randomId = createdTS
                        message.type = ResponseFields.REPLY_USER
                        message.status = if (status != MessageStatus.NORMAL) status.name.lowercase(Locale.getDefault()) else ""

                        message.sourceJsonData = JSONObject(Gson().toJson(message))

                        if (conversationOptional.value != null) {
                            val conversation = conversationOptional.value

                            conversation.message = message
                            conversation.partLast = message
                            conversation.partsCount = conversation.partsCount + 1

                            ConversationsRepository.getInstance().updateConversation(conversationId, conversation)
                        }
                        return@flatMap Observable.just(Optional(message))
                    }
        }
    }
}

fun <T> Observable<T>.saveMessage(message: Optional<MessageData>) : Observable<Optional<MessageData>> {
    return Observable.defer {
        return@defer this.flatMap {
            MessagesRepository.getInstance().addMessage(message.value!!)
            return@flatMap Observable.just(message)
        }
    }
}

fun Observable<Optional<MessageData>>.saveMessage() : Observable<Optional<MessageData>> {
    return Observable.defer {
        return@defer this.flatMap {
            MessagesRepository.getInstance().addMessage(it.value!!)
            return@flatMap Observable.just(it)
        }
    }
}

fun Observable<Optional<MessageData>>.saveMessageWithAttachment() : Observable<Optional<MessageData>> {
    return Observable.defer {
        return@defer this.flatMap {
            MessagesRepository.getInstance().addMessage(it.value!!)
            return@flatMap Observable.just(it)
        }
    }
}


fun <T> Observable<T>.createMessage(attachment: Attachment, conversationId: String, isFirst: Boolean, status: MessageStatus) : Observable<Optional<MessageData>> {
    return Observable.defer {
        return@defer this.flatMap {

            return@flatMap Observable.just(true)
                .getConversation(conversationId)
                //.filter { x -> x.value != null }
                .flatMap { conversationOptional ->
                    val createdTS = (System.currentTimeMillis() / 1000).toString()

                    val messageFrom = Admin()
                    messageFrom.id = when (conversationOptional.value) {
                        null -> conversationId
                        else -> conversationOptional.value.id
                    }
                    messageFrom.avatar = when (conversationOptional.value) {
                        null -> ""
                        else -> conversationOptional.value.partLast?.messageFrom?.avatar
                    }
                    messageFrom.type = when (conversationOptional.value) {
                        null -> ""
                        else -> conversationOptional.value.partLast?.messageFrom?.type
                    }
                    messageFrom.name = when (conversationOptional.value) {
                        null -> ""
                        else -> conversationOptional.value.partLast?.messageFrom?.name
                    }


                    val attachments = ArrayList<Attachment>()
                    attachment.status = "loaded"
                    attachments.add(attachment)
                    val message = MessageData()
                    message.id = createdTS
                    message.body = ""
                    message.conversation = conversationId
                    message.created = createdTS
                    message.randomId = createdTS
                    message.sentVia = ResponseFields.SDK_ANDROID
                    message.direction = ResponseFields.USER_2_ADMIN
                    message.isFirst = isFirst
                    message.type = ResponseFields.REPLY_USER
                    message.status =
                        if (status != MessageStatus.NORMAL) status.name.lowercase(Locale.getDefault()) else ""
                    message.attachments = attachments
                    message.messageFrom = messageFrom

                    message.sourceJsonData = JSONObject(Gson().toJson(message))

                    if (conversationOptional.value != null) {
                        val conversation = conversationOptional.value

                        conversation.message = message
                        conversation.partLast = message
                        conversation.partsCount = conversation.partsCount + 1

                        ConversationsRepository.getInstance()
                            .updateConversation(conversationId, conversation)
                    }
                    return@flatMap Observable.just(Optional(message))
                }
        }
    }
}