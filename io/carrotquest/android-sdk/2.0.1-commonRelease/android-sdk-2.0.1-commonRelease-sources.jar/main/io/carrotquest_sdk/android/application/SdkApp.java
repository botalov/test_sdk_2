package io.carrotquest_sdk.android.application;

import static io.carrotquest_sdk.android.domain.use_cases.conversations.FindPopUpConversationsUseCaseKt.SHOWED_POPUP_IDS;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import androidx.room.Room;
import android.content.Context;
import android.os.Build;

import androidx.multidex.MultiDexApplication;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import io.carrotquest_sdk.android.lib.managers.BackgroundManager;
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.core.main.CarrotSDK;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.data.db.CarrotSdkDB;
import io.carrotquest_sdk.android.data.db.popup.PopUpDbEntity;
import io.carrotquest_sdk.android.data.repositories.PopupRepository;
import io.carrotquest_sdk.android.di.SdkLibComponent;
import io.carrotquest_sdk.android.domain.entities.popup.PopUpMessageEntity;
import io.carrotquest_sdk.android.domain.use_cases.popup.ShowPopUpUseCaseKt;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.plugins.RxJavaPlugins;
import io.reactivex.schedulers.Schedulers;

public class SdkApp extends MultiDexApplication {
    private CarrotSdkDB database;
    private static SdkApp instance;
    private final static FTActivityLifecycleCallbacks mFTActivityLifecycleCallbacks = new FTActivityLifecycleCallbacks();

    public static SdkApp getInstance() {
        if (instance == null) {
            instance = new SdkApp();
            instance.reg();
        }
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        RxJavaPlugins.setErrorHandler(new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {

            }
        });

        instance = this;
        initDataBase(this);
    }

    public CarrotSdkDB getDatabase() {
        return database;
    }

    public void initDataBase(Context context) {
        database = Room.databaseBuilder(context, CarrotSdkDB.class, "carrot_sdk.db").
                allowMainThreadQueries().
                fallbackToDestructiveMigration().
                build();
        initPopUps(context);
    }

    private Disposable popUpsDisposable;
    private void initPopUps(Context context) {
        try {
            Gson gson = new Gson();
            GsonBuilder gb = gson.newBuilder();
            gb.setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
            gson = gb.create();
            Log.d("TEST_GSON", "gson:  " + gson.hashCode());
        }catch (Exception e) {
            Log.e("TEST_GSON", "Error:  " + e.toString());
        }

        BackgroundManager.getInstance().addObserver(isConnect -> {
                    if (isConnect) {
                        popUpsDisposable = PopupRepository
                                .Companion
                                .getAllPopUpsObservable()
                                .delay(1, TimeUnit.SECONDS)
                                .subscribe(popUpModels -> {
                                    //Context context = CarrotInternal.getLibComponent().getContextSdk();
                                    Set<String> exitedSet = SharedPreferencesLib.getStringSet(context, SHOWED_POPUP_IDS);
                                    ArrayList<PopUpDbEntity> needRemove = new ArrayList<>();
                                    for (PopUpDbEntity p : popUpModels) {
                                        if (exitedSet.contains(p.getId())) {
                                            needRemove.add(p);
                                        } else {
                                            exitedSet.add(p.getId());
                                        }
                                    }
                                    SharedPreferencesLib.saveStringSet(context, SHOWED_POPUP_IDS, exitedSet);

                                    popUpModels.removeAll(needRemove);
                                    if (!popUpModels.isEmpty()) {
                                        String neededShowPopUpConversationId = SharedPreferencesLib
                                                .getString(CarrotInternal.getLibComponent().getContextSdk(), "need_show_popup_conv_id");

                                        PopUpDbEntity popUpForShow = findPopUpMessage(neededShowPopUpConversationId, popUpModels);

                                        if (popUpForShow != null) {
                                            SharedPreferencesLib
                                                    .clearPreference(CarrotInternal.getLibComponent().getContextSdk(), "need_show_popup_conv_id");
                                        } else {
                                            popUpForShow = popUpModels.get(popUpModels.size() - 1);
                                        }

                                        PopUpMessageEntity entity = new PopUpMessageEntity(
                                                popUpForShow.getId(),
                                                popUpForShow.getBodyJson(),
                                                popUpForShow.getExpirationTime(),
                                                popUpForShow.getBackgroundColor()
                                        );

                                        ShowPopUpUseCaseKt.showPopup(Observable.just(entity)
                                                        .observeOn(AndroidSchedulers.mainThread()))
                                                .subscribeOn(Schedulers.io())
                                                .observeOn(AndroidSchedulers.mainThread())
                                                .subscribe(new Observer<PopUpMessageEntity>() {
                                                    @Override
                                                    public void onSubscribe(Disposable d) {

                                                    }

                                                    @Override
                                                    public void onNext(PopUpMessageEntity popUpMessageEntity) {
                                                    }

                                                    @Override
                                                    public void onError(Throwable e) {
                                                        Log.e("SHOW_POPUP", "ERROR: " + e.toString());
                                                    }

                                                    @Override
                                                    public void onComplete() {

                                                    }
                                                });
                                    }
                                }, t -> Log.e("", t));
                    } else {
                        if (popUpsDisposable != null) {
                            popUpsDisposable.dispose();
                            popUpsDisposable = null;
                        }
                    }
                },
                e -> android.util.Log.e("TAG", e.toString()),
                () -> {
                    //onComplete

                });
    }

    public Activity getCurrentActivity() {
        Activity activity = mFTActivityLifecycleCallbacks.getCurrentActivity();
        if(activity != null) {
            return activity;
        }

        Context sdkContext = CarrotInternal.getLibComponent().getContextSdk();
        if(sdkContext instanceof Activity) {
            return (Activity)sdkContext;
        }

        return null;
    }

    private PopUpDbEntity findPopUpMessage(String conversationId, ArrayList<PopUpDbEntity> list) {
        if(conversationId == null || conversationId.isEmpty()) {
            return null;
        }

        for (PopUpDbEntity p : list) {
            if(conversationId.equals(p.getId())) {
                return p;
            }
        }

        return null;
    }

    private void reg() {
        try {
            @SuppressLint("PrivateApi") final Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
            final Method method = activityThreadClass.getMethod("currentApplication");
            Application app = (Application) method.invoke(null, (Object[]) null);
            if (app != null) {
                app.registerActivityLifecycleCallbacks(mFTActivityLifecycleCallbacks);

                Disposable d = Observable
                        .just(1)
                        .take(1)
                        .delay(1, TimeUnit.SECONDS)
                                .subscribe(new Consumer<Integer>() {
                                    @Override
                                    public void accept(Integer integer) throws Exception {
                                        SdkLibComponent slib = CarrotInternal.getLibComponent();
                                        if(slib != null) {
                                            Context c = slib.getContextSdk();

                                            if(c instanceof Activity && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                                mFTActivityLifecycleCallbacks.onActivityPostStarted((Activity)c);
                                            }
                                        }
                                    }
                                });

            }
        } catch (final Exception e) {
            Log.e("LIFE STYLE", "REG ERROR: " + e);
        }
    }

    public Disposable subscribeOnCurrentActivity(Consumer<Activity> onNext, Consumer<Throwable> onError) {
        if (mFTActivityLifecycleCallbacks != null) {
            return mFTActivityLifecycleCallbacks.subscribeOnChangeCurrentActivity(onNext, onError);
        }
        return null;
    }
}
