package io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.countries

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.entities.CountryEntity

class CountriesListAdapter(private val dataSet: ArrayList<CountryEntity>): RecyclerView.Adapter<CountriesListAdapter.CountryViewHolder>() {

    class CountryViewHolder( view: View): RecyclerView.ViewHolder(view) {
        val container: ConstraintLayout

        val countryNameTextView: TextView
        val countryFlagTextView: TextView
        val countryCodeTextView: TextView

        init {
            container = view.findViewById(R.id.country_view_container)


            countryNameTextView = view.findViewById(R.id.country_name_text_view)
            countryFlagTextView = view.findViewById(R.id.country_flag_text_view)
            countryCodeTextView = view.findViewById(R.id.country_code_text_view)
        }
    }


    private lateinit var onClickListener: OnClickListener

    fun setOnClickListener(onClickListener: OnClickListener) {
        this.onClickListener = onClickListener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.country_view_holder, parent, false)

        return CountryViewHolder(view)
    }

    override fun getItemCount(): Int {
        return dataSet.size
    }

    override fun onBindViewHolder(viewHolder: CountryViewHolder, position: Int) {
        viewHolder.countryNameTextView.text = dataSet[position].name
        viewHolder.countryFlagTextView.text = (dataSet[position].flag) ?: ""

        val regionCode = dataSet[position].countryCode
        viewHolder.countryCodeTextView.text = if(regionCode > 0) "+$regionCode" else ""

        viewHolder.container.setOnClickListener { _ ->
            onTap(dataSet[position])
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setData(data: List<CountryEntity>) {
        this.dataSet.clear()
        this.dataSet.addAll(data)
        notifyDataSetChanged()
    }

    private fun onTap(country: CountryEntity) {
        this.onClickListener.onClick(country)
    }
}

interface OnClickListener {
    fun onClick(country: CountryEntity)
}
