package io.carrotquest_sdk.android.presentation.mvp.web_view;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.webkit.*;

import io.carrotquest_sdk.android.BuildConfig;

public class CarrotWebViewClient extends WebViewClient {

    private boolean pageInError = false;
    private CarrotWebViewPresenter presenter;
    CarrotWebViewClient(CarrotWebViewPresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        presenter.onPageFinished(pageInError);
    }

    @Override
    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        super.onReceivedError(view, request, error);
        //todo
        //pageInError = true;
        //presenter.onReceivedError();
    }

    @Override
    public void onPageStarted(WebView view, String url, Bitmap favicon) {
        super.onPageStarted(view, url, favicon);
        pageInError = false;
    }

    @Override
    public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
        super.onReceivedHttpError(view, request, errorResponse);
        pageInError = true;
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if(url.contains(BuildConfig.DIALOG_URL)
                || url.contains(BuildConfig.DIALOGS_HISTORY_URL)
                || url.contains(BuildConfig.CALENDLY_URL)
                || url.contains("external-widget/")) {
            return super.shouldOverrideUrlLoading(view, url);
        }
        else {
            presenter.onOpenOutsideUrl(url);
            return true;
        }
    }


    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        WebResourceResponse response = presenter.shouldInterceptRequest(request.getUrl());
        return response == null ? super.shouldInterceptRequest(view, request) : response;
    }

    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
        WebResourceResponse response = presenter.shouldInterceptRequest(Uri.parse(url));
        return response == null ? super.shouldInterceptRequest(view, url) : response;
    }
}
