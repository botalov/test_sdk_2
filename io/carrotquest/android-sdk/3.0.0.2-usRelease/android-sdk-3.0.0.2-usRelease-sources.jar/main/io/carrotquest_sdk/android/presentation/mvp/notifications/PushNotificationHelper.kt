package io.carrotquest_sdk.android.presentation.mvp.notifications

import android.Manifest
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.google.firebase.messaging.RemoteMessage
import com.google.gson.JsonParser
import com.vdurmont.emoji.EmojiParser
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.PushDB
import io.carrotquest_sdk.android.data.db.messages.ReadMessage
import io.carrotquest_sdk.android.data.db.messages.ShowedPush
import io.carrotquest_sdk.android.data.db.pushes.PushInstanceDb
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.SHOWED_POPUP_IDS
import io.carrotquest_sdk.android.lib.managers.BackgroundManager
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.presentation.container.SdkContainerActivity
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.PushStorage
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackDelivered
import io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications.IncomingMessage
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.inject.Inject
import kotlin.random.Random

class PushNotificationHelper private constructor() {

    @Inject
    lateinit var db: CarrotSdkDB

    private val displayedNotificationIds = HashMap<String, MutableList<Int>>()
    private var iconId: Int? = null

    companion object {
        private const val GROUP_KEY_DIALOG = "io.carrotquest.sdk.notify"
        private const val TAG = "PushNotificationHelper"

        @Volatile
        private var instance: PushNotificationHelper? = null

        @JvmStatic
        fun getInstance(): PushNotificationHelper {
            return instance ?: synchronized(this) {
                instance ?: PushNotificationHelper().also { instance = it }
            }
        }
    }

    private val context: Context
        get() = CarrotInternal.getLibComponent().contextSdk

    fun setNotificationIcon(iconId: Int?) {
        SharedPreferencesLib.saveInt(context, "cq_notification_icon_id", iconId ?: 0)
        this.iconId = iconId
    }

    fun postNotification(
        messageId: String,
        title: String?,
        body: String?,
        conversationId: String?,
        sentVia: String?,
        conversationType: String?,
        linkStr: String?,
        isCarrot: Boolean?
    ) {
        CoroutineScope(SdkDispatchers.io).launch {
            // Раньше: Single<ReadMessage> — и onSuccess, и onError(EmptyResultSetException) делали
            // checkAndShowNotify (различия по факту нет). Сохраняем: читаем запись из БД (на io),
            // затем при подходящем conversationId показываем уведомление на main-потоке.
            try {
                SdkApp.getInstance().database.readMessageDao().getById(messageId)
                if (conversationId != null && conversationId != ConversationsRepository.getInstance().getOpenedConversationId()) {
                    withContext(SdkDispatchers.main) {
                        checkAndShowNotify(messageId, title, body, conversationId, linkStr, sentVia, conversationType, isCarrot)
                    }
                }
            } catch (e: Throwable) {
                Log.e("PushNotificationHelper", e)
            }
        }
    }

    private fun getDebugData(remoteMessage: RemoteMessage): String {
        return remoteMessage.data.entries.joinToString("; ") { "${it.key} = ${it.value}" }.plus("; ")
    }

    fun postNotification(pushData: Map<String, String>) {
        try {
            if (pushData.isNotEmpty()) {
                val messageId = pushData[F.ID].toString()
                val title = pushData[F.TITLE]
                val text = pushData[F.BODY]
                val conversationId = pushData[F.CONVERSATION_ID]
                val conversationType = pushData[F.CONVERSATION_TYPE]
                val sentVia = pushData[F.SENT_VIA]
                val bodyJson = pushData[F.BODY_JSON]
                val isCarrot = pushData["is_carrot"]?.toBoolean()

                var linkStr: String? = null
                if (bodyJson != null) {
                    val bJo = JsonParser.parseString(bodyJson)
                    if (!bJo.isJsonNull && bJo.isJsonObject && bJo.asJsonObject.has(F.CLICK_ACTION)) {
                        linkStr = bJo.asJsonObject.get(F.CLICK_ACTION).asString
                    }
                }

                val directionMessage = if (ResponseFields.ADMIN_2_USER == pushData[F.DIRECTION]) {
                    IncomingMessage.DirectionMessage.ADMIN_TO_USER
                } else {
                    IncomingMessage.DirectionMessage.USER_TO_ADMIN
                }

                val messageType = IncomingMessage.MessageType.TEXT

                Room.databaseBuilder(context, PushDB::class.java, "carrot_pushes_sdk.db")
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build()
                    .showedPushDao()
                    .insert(ShowedPush(Random.nextInt(200).toString()))

                val incomingMessage = IncomingMessage(
                    IncomingMessage.IncomingMessageSourceType.PUSH,
                    messageId, conversationId, text, directionMessage, messageType
                )

                NotificationsAllHelper.getInstance().pushMessage(incomingMessage)
                getInstance().postNotification(messageId, title, text, conversationId, sentVia, conversationType, linkStr, isCarrot)
            } else {
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "postNotification: empty push payload")
            }
        } catch (e: Exception) {
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.PUSH, TAG, "postNotification failed", e)
        }
    }

    private fun checkAndShowNotify(
        messageId: String,
        title: String?,
        body: String?,
        conversationId: String?,
        link: String?,
        sentVia: String?,
        conversationType: String?,
        isCarrot: Boolean?
    ) {
        if (!::db.isInitialized) {
            db = SdkApp.getInstance().database
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (statusBarNotification in getStatusBarNotifications()) {
                val convIdN = statusBarNotification.tag
                val channelId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    statusBarNotification.notification.channelId
                } else null

                val titleN = statusBarNotification.notification.extras.getCharSequence(Notification.EXTRA_TITLE)
                val textN = statusBarNotification.notification.extras.getCharSequence(Notification.EXTRA_TEXT)

                val hasFcmNotification = conversationId != null && conversationId == convIdN &&
                        titleN?.toString() == title &&
                        textN?.toString() == body

                if (((Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && channelId == "cq_notification_channel") || channelId == null) &&
                    (convIdN == null || convIdN.contains(messageId) || hasFcmNotification)) {
                    return
                }
            }
        }

        val pushInstanceDb = PushInstanceDb.getDb(context)
        val showedPush = pushInstanceDb.showedPushDao().getById(messageId)

        if (showedPush == null) {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val allTasks = am.getRunningTasks(1)

            if (allTasks.isNullOrEmpty()) {
                pushInstanceDb.showedPushDao().insert(ShowedPush(messageId))
                showNotify(messageId, title, body, conversationId, link, sentVia, conversationType, isCarrot)
            } else {
                for (aTask in allTasks) {
                    val aTaskComponentName = aTask.topActivity

                    if (aTaskComponentName != null && aTaskComponentName.className.contains(SdkContainerActivity::class.java.name)) {
                        val isInBackground = !BackgroundManager.getInstance().lastStateIsForeground()
                        var isNotOpenConversation = !(ConversationsRepository.getInstance().getLastOpenedConversationId() == conversationId ||
                                ConversationsRepository.getInstance().getOpenedConversationId() == conversationId)

                        val conv = if(conversationId != null) {
                            ConversationsRepository.getInstance().getConversationById(conversationId)
                        } else {
                            null
                        }
                        if (conv != null) {
                            isNotOpenConversation = isNotOpenConversation && ConversationsRepository.getInstance().getLastOpenedConversationId() != conv.randomId
                        }

                        if (isInBackground || isNotOpenConversation) {
                            pushInstanceDb.showedPushDao().insert(ShowedPush(messageId))
                            showNotify(messageId, title, body, conversationId, link, sentVia, conversationType, isCarrot)
                            return
                        } else {
                            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG, "push notification suppressed: conversation already open in foreground")
                        }
                    } else {
                        pushInstanceDb.showedPushDao().insert(ShowedPush(messageId))
                        showNotify(messageId, title, body, conversationId, link, sentVia, conversationType, isCarrot)
                        return
                    }
                }
            }
            db.readMessageDao().insert(ReadMessage(messageId))
        }
    }

    private fun getPendingIntentWithSendEvent(intent: Intent): PendingIntent {
        val requestCode = Random.nextInt()
        val flags = when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> PendingIntent.FLAG_MUTABLE
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> PendingIntent.FLAG_UPDATE_CURRENT
            else -> PendingIntent.FLAG_UPDATE_CURRENT
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags)
    }

    private fun showNotify(
        messageId: String,
        title: String?,
        body: String?,
        conversationId: String?,
        link: String?,
        sentVia: String?,
        conversationType: String?,
        isCarrot: Boolean?
    ) {
        val exitedSet = SharedPreferencesLib.getStringSet(context, SHOWED_POPUP_IDS)
        if (!exitedSet.isNullOrEmpty() && exitedSet.contains(conversationId)) {
            return
        }

        val notificationManagerX = NotificationManagerCompat.from(context)
        if (!notificationManagerX.areNotificationsEnabled()) {
            return
        }

        var resultIntent: Intent? = null
        var resultPendingIntent: PendingIntent? = null

        if (!link.isNullOrEmpty()) {
            if (sentVia.equals("message_auto", ignoreCase = true) || sentVia.equals("message_manual", ignoreCase = true) || isCarrot == null || !isCarrot) {
                val intent = Intent(context, PushTapActivity::class.java).apply {
                    putExtra(PushTapReceiver.linkExtraKey, link)
                    putExtra(PushTapReceiver.conversationIdExtraKey, conversationId)
                    putExtra(PushTapReceiver.conversationTypeExtraKey, conversationType)
                    addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                resultPendingIntent = getPendingIntentWithSendEvent(intent)
            } else {
                resultIntent = Intent(Intent.ACTION_VIEW).apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT)
                    }
                    data = Uri.parse(link)
                }
            }
        } else {
            if (sentVia.equals("message_auto", ignoreCase = true) || sentVia.equals("message_manual", ignoreCase = true)) {
                if ((isCarrot == null || isCarrot) && !conversationId.isNullOrEmpty()) {
                    resultIntent = openDialogById(conversationId)
                } else {
                    val intent = Intent(context, PushTapActivity::class.java).apply {
                        putExtra(PushTapReceiver.conversationIdExtraKey, conversationId)
                        putExtra(PushTapReceiver.conversationTypeExtraKey, conversationType)
                        addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    resultPendingIntent = getPendingIntentWithSendEvent(intent)
                }
            } else {
                resultIntent = openDialogById(conversationId ?: "")
            }
        }

        val notifyId = (System.currentTimeMillis() / 1000).toInt()

        if (resultPendingIntent == null && resultIntent != null) {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                PendingIntent.FLAG_MUTABLE
            } else {
                PendingIntent.FLAG_UPDATE_CURRENT
            }
            resultPendingIntent = PendingIntent.getActivity(context, notifyId, resultIntent, flags)
        }

        val savedIcon = SharedPreferencesLib.getInt(context, "cq_notification_icon_id")
        if (savedIcon > 0) {
            iconId = savedIcon
        } else {
            if (iconId == null) {
                iconId = R.drawable.ic_cq_notification
            } else {
                val iconResourceName = context.resources.getResourceName(iconId!!)
                if (iconResourceName == null) {
                    iconId = R.drawable.ic_cq_notification
                }
            }
        }

        initChannels()

        val priority = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            NotificationManager.IMPORTANCE_DEFAULT
        } else {
            @Suppress("DEPRECATION")
            Notification.PRIORITY_DEFAULT
        }

        var parsedBody = EmojiParser.parseToUnicode(body ?: "").trim()
        if (TextUtils.isEmpty(parsedBody)) {
            parsedBody = "..."
        }

        val group = NotificationCompat.Builder(context, "cq_notifications_channel")
            .setLargeIcon(BitmapFactory.decodeResource(context.resources, iconId!!))
            .setSmallIcon(iconId!!)
            .setColor(ContextCompat.getColor(context, R.color.colorCqNotify))
            .setContentTitle(title)
            .setContentText(parsedBody)
            .setGroupSummary(true)
            .setPriority(priority)
            .setGroup(conversationId.toString())
            .setContentIntent(resultPendingIntent)
            .setStyle(NotificationCompat.BigTextStyle().bigText(parsedBody))
            .build()

        val notification = NotificationCompat.Builder(context, "cq_notifications_channel")
            .setLargeIcon(BitmapFactory.decodeResource(context.resources, iconId!!))
            .setSmallIcon(iconId!!)
            .setColor(ContextCompat.getColor(context, R.color.colorCqNotify))
            .setContentTitle(title)
            .setContentText(parsedBody)
            .setPriority(priority)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setGroup(conversationId.toString())
            .setContentIntent(resultPendingIntent)
            .setAutoCancel(true)
            .setStyle(NotificationCompat.BigTextStyle().bigText(parsedBody))
            .build()

        val notifyIds = displayedNotificationIds.getOrPut(conversationId ?: "") { mutableListOf() }
        notifyIds.add(notifyId)

        // 1. Проверяем разрешение для Android 13+ (API 33+) перед показом уведомления
        val hasNotificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        // 2. Показываем уведомление, только если есть разрешение
        if (hasNotificationPermission) {
            if (conversationId != null && conversationId.length >= 9) {
                val groupId = conversationId.substring(conversationId.length - 9, conversationId.length - 1).toIntOrNull() ?: 0
                notificationManagerX.notify(groupId, group)
            }

            notificationManagerX.notify("${conversationId}_${messageId}_$conversationType", notifyId, notification)
        } else {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "notification not posted: POST_NOTIFICATIONS permission denied")
        }

        // 3. Используем этот же флаг для отправки события о прочтении автосообщения
        if (conversationType.equals("sdk_push", ignoreCase = true) &&
            (sentVia.equals("message_auto", ignoreCase = true) || sentVia.equals("message_manual", ignoreCase = true))
        ) {
            if (hasNotificationPermission && conversationId != null) {
                sendEventAboutAutoPushSDK(conversationId)
            }
        }
    }

    private fun openDialogById(conversationId: String): Intent {
        return Intent(context, SdkContainerActivity::class.java).apply {
            putExtra(SdkContainerActivity.CONVERSATION_ID_ARG, conversationId)
            putExtra(SdkContainerActivity.STARTED_FROM_NOTIFICATION, true)
            flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        }
    }

    private fun sendEventAboutAutoPushSDK(conversationId: String) {
        // СРАЗУ сохраняем в локальную базу (SharedPreferences)
        PushStorage.savePushId(context, conversationId)
        // Запускаем Worker
        trackDelivered(context, conversationId)

    }

    private fun initChannels() {
        if (Build.VERSION.SDK_INT < 26) return

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            "cq_notifications_channel",
            "Чаты",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Уведомления чатов"
        }

        notificationManager.createNotificationChannel(channel)
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private fun getStatusBarNotifications(): Array<StatusBarNotification> {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return notificationManager.activeNotifications
    }

    fun clearNotifications(dialogId: String?) {
        if (dialogId.isNullOrEmpty()) return

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        displayedNotificationIds.remove(dialogId)?.forEach { id ->
            notificationManager.cancel(id)
        }

        try {
            val x = if (dialogId.length >= 9) {
                dialogId.substring(dialogId.length - 9, dialogId.length - 1).toInt()
            } else {
                dialogId.toInt()
            }
            notificationManager.cancel(x)
        } catch (e: Exception) {
            Log.e(TAG, e.toString())
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                notificationManager.activeNotifications.forEach { notification ->
                    if (notification.packageName.equals("carrotquest.mobil.inkov.carrotquest", ignoreCase = true) &&
                        notification.tag?.contains(dialogId) == true
                    ) {
                        try {
                            notificationManager.cancel(notification.tag, notification.id)
                        } catch (e: Exception) {
                            Log.e(TAG, e.toString())
                        }
                    }
                }
            } catch (npe: NullPointerException) {
                Log.e(TAG, npe.toString())
            }
        }
    }

    fun clearNotificationsByConversationType(conversationType: String?) {
        if (conversationType.isNullOrEmpty()) return

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            notificationManager.activeNotifications.forEach { notification ->
                if (notification?.tag?.contains(conversationType) == true) {
                    notificationManager.cancel(notification.tag, notification.id)
                }
            }
        }
    }
}