package io.carrotquest_sdk.android.presentation.mvp.notifications;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import io.carrotquest_sdk.android.core.logging.SdkLogCategory;
import io.carrotquest_sdk.android.core.logging.SdkLogLevel;
import io.carrotquest_sdk.android.core.logging.SdkLogger;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.di.SdkLibComponent;

public class SdkFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "SDk Firebase Cloud Messaging Service";

    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG, "push received (" + remoteMessage.getData().size() + " data keys)");
        SdkLibComponent libComponent = CarrotInternal.getLibComponent();
        if (libComponent != null) {
            libComponent.getNotificationHelper().postNotification(remoteMessage.getData());
        } else {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "push dropped: SDK not initialized");
        }
    }
}
