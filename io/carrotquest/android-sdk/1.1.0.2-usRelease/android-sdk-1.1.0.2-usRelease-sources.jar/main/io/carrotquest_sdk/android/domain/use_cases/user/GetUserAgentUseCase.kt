package io.carrotquest_sdk.android.domain.use_cases.user

import android.os.Build
import androidx.core.content.pm.PackageInfoCompat
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.core.util.huawei.isHuawei
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.isDashly

fun getUserAgent(): String {
    val isDashly = isDashly()
    val nameSDK = if(isDashly) {
        "DashlySDK"
    } else {
        "CarrotquestSDK"
    }

    val versionSDK = BuildConfig.VERSION_SDK_NAME
    val os = if(isHuawei()) {
        "Huawei [huawei_push] 1.0.0"
    } else {
        "Android"
    }

    val osVersion = Build.VERSION.RELEASE

    val deviceName = getDeviceName()

    val appName = getAppName()
    val appVersion = getAppVersion()
    val appVersionCode = getAppVersionCode()
    val packageName = getPackageName()

    //<SDKName>/<SDKVersion> (os=<OSName>; osVersion=<OSVersion>; deviceName=<DeviceModel>) <AppName>/<AppVersion> (build=<buildNumber>; bundleID=<bundleID>)
    //CarrotquestSDK/2.14.0-beta15 (os=iOS; osVersion=18.5; deviceName=iPhone12,1(iPhone 11)) UltimateTestSDK/2.14.0 (build=14 bundleID=io.cq.sdk.ultimate-test-app.UltimateTestSDK)
    return "$nameSDK/$versionSDK (os=$os; osVersion=$osVersion; deviceName=$deviceName) $appName/$appVersion (build=$appVersionCode bundleID=$packageName)"
}

private fun getDeviceName(): String {
    val manufacturer = Build.MANUFACTURER
    val model = Build.MODEL
    if (model.startsWith(manufacturer, ignoreCase = true)) {
        return model
    }

    return "$manufacturer $model"
}

private fun getAppName(): String {
    val context = CarrotLib.getLibComponents().context
    val applicationInfo = context.applicationInfo
    return context.packageManager.getApplicationLabel(applicationInfo).toString()
}

private fun getAppVersion(): String {
    val context = CarrotLib.getLibComponents().context
    val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
    val versionName = packageInfo.versionName

    return versionName?:"-"
}

private fun getAppVersionCode(): String {
    val context = CarrotLib.getLibComponents().context
    val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
    val versionCode = PackageInfoCompat.getLongVersionCode(packageInfo)

    return versionCode.toString()
}

private fun getPackageName(): String {
    val context = CarrotLib.getLibComponents().context
    val packageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
    val packageName = packageInfo.packageName

    return packageName
}