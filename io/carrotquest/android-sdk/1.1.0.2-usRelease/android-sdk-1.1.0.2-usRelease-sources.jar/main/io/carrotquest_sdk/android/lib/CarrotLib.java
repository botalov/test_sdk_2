package io.carrotquest_sdk.android.lib;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.MimeTypeMap;

import androidx.fragment.app.FragmentManager;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.inject.Inject;

import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.core.util.huawei.HuaweiUtilsKt;
import io.carrotquest_sdk.android.lib.di.ApiModule;
import io.carrotquest_sdk.android.lib.di.ContextModule;
import io.carrotquest_sdk.android.lib.di.DaggerLibComponent;
import io.carrotquest_sdk.android.lib.di.GsonModule;
import io.carrotquest_sdk.android.lib.di.LibComponent;
import io.carrotquest_sdk.android.lib.di.RepositoryModule;
import io.carrotquest_sdk.android.lib.di.RetrofitModule;
import io.carrotquest_sdk.android.lib.di.WssServiceModule;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.models.UserConversations;
import io.carrotquest_sdk.android.lib.models.UserProperty;
import io.carrotquest_sdk.android.lib.network.responses.PushSubResponse;
import io.carrotquest_sdk.android.lib.network.responses.auth.AuthResponse;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse;
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse;
import io.carrotquest_sdk.android.lib.network.responses.conversation.ConversationResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse;
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshResponse;
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse;
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse;
import io.carrotquest_sdk.android.lib.network.responses.triggers.TriggersResponse;
import io.carrotquest_sdk.android.lib.network.responses.user.UserResponse;
import io.carrotquest_sdk.android.lib.repositories.IUserRepository;
import io.carrotquest_sdk.android.lib.utils.files.FileUtilKt;
import io.carrotquest_sdk.android.lib.utils.files.SaveImageCallback;
import io.carrotquest_sdk.android.lib.full_image_view.view.FullImageViewDialogFragment;
import io.carrotquest_sdk.android.lib.wss.WssService;
import io.reactivex.Observable;
import io.reactivex.exceptions.Exceptions;
import io.reactivex.functions.Consumer;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.http.Field;
import retrofit2.http.Query;

public class CarrotLib implements ICarrotLib {
    private static final String TAG = "CarrotLib";
    private String sessionId = "";
    private static LibComponent libComponent;

    private boolean useEuServers = false;

    @Inject
    CarrotApi carrotApi;

    public CarrotLib(Context context, IUserRepository userRepository, boolean isUseEuServers){
        this.useEuServers = isUseEuServers;

        libComponent = DaggerLibComponent.builder()
                .gsonModule(new GsonModule(context))
                .apiModule(new ApiModule())
                .contextModule(new ContextModule(context))
                .retrofitModule(new RetrofitModule(context, userRepository, useEuServers))
                .repositoryModule(new RepositoryModule(userRepository))
                .wssServiceModule(new WssServiceModule(useEuServers))
                .build();

        if(carrotApi == null) {
            carrotApi = libComponent.getCarrotApi();
        }
    }

    @Override
    public  Observable<ConnectResponse> connect(String apiKey,
                                                String browser,
                                                String tokenType,
                                                String referrer,
                                                boolean startSession) {

        try {
            String deviceType = "phone";
            if (sessionId == null || sessionId.isEmpty()) {
                sessionId = UUID.randomUUID().toString().replaceAll("-", "");
            }

            String osVersion = Build.VERSION.RELEASE; // e.g. myVersion := "1.6"
            int osSdkVersion = Build.VERSION.SDK_INT;

            String os = "Android " + osVersion + " (" + osSdkVersion + ")";

            if(carrotApi == null) {
                carrotApi = libComponent.getCarrotApi();
            }

            if (referrer == null || referrer.isEmpty()) {
                return carrotApi.connect(
                        sessionId,
                        apiKey,
                        startSession,
                        true,
                        false,
                        false,
                        browser,
                        os,
                        getDeviceName(),
                        deviceType,
                        tokenType
                )
                        .doOnError(throwable -> {
                            //Log.e(TAG, "throwable.getCause.getMessage: " + throwable.getCause().getMessage());
                        })
                        .doOnNext(connectResponse -> {
                });
            } else {
                return carrotApi.connect(
                        sessionId,
                        apiKey,
                        true,
                        true,
                        false,
                        false,
                        browser,
                        os,
                        getDeviceName(),
                        deviceType,
                        tokenType,
                        referrer
                );
            }
        }catch (Exception  e) {
            Log.d(TAG, e.toString());
            return Observable.just(null);
        }
    }

    @Override
    public Observable<AuthResponse> auth(String userId, String userAuthKey) {
        try {
            String hash = generateHashHmac(userId, userAuthKey);
            return carrotApi.auth(userId, hash, "sdk_user_android");
        } catch (NoSuchAlgorithmException | InvalidKeyException e) {
            Log.e(TAG, e.toString());
            throw Exceptions.propagate(e);
        }
    }

    @Override
    public Observable<AuthResponse> hashedAuth(String userId, String hash) {
        try {
            return carrotApi.auth(userId, hash, "sdk_user_android");
        } catch (Exception e) {
            Log.e(TAG, e.toString());
            throw Exceptions.propagate(e);
        }
    }

    @Override
    public Observable<RefreshResponse> refresh(Boolean updateRefreshToken) {
        return  carrotApi.refresh(updateRefreshToken);
    }

    @Override
    public  Observable<User> getUser(String userId) {
        return carrotApi.getUser(userId, false);
    }

    @Override
    public  Observable<UserResponse> loadUser(String userId) {
        return carrotApi.loadUser(userId, false);
    }

    @Override
    public Observable<NetworkResponse> setProperty(String userId, UserProperty userProperty) {
        ArrayList<UserProperty> properties = new ArrayList<>();
        properties.add(userProperty);

        return setProperty(userId, properties);
    }

    @Override
    public Observable<NetworkResponse> setProperty(String userId, List<UserProperty> userProperty) {
        String propertyJson;
        if(userProperty == null || userProperty.size() == 0) {
            propertyJson = "[]";
        }
        else {
            JsonArray array = new JsonArray();
            for(UserProperty property : userProperty) {
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("op", property.getOperation());
                jsonObject.addProperty("key", property.getKey());
                jsonObject.addProperty("value", property.getValue());
                array.add(jsonObject);
            }

            propertyJson = array.toString();
        }

        return carrotApi.sendProps(userId, propertyJson);
    }

    @Override
    public Observable<NetworkResponse> trackEvent(String userId, String eventName, String eventParams) {
        return carrotApi.trackEvent(userId, eventName, eventParams);
    }

    @Override
    public Observable<UserConversations> getConservations(String userId) {
        //TODO
//        return carrotApi.getConversations(userId, "sdk")
//                .onErrorReturnItem(new UserConversations());
        return carrotApi.getConversations(userId)
                .onErrorReturnItem(new UserConversations());
    }

    @Override
    public Observable<UserConversations> getConservations(String userId, String after) {
        //TODO
//        return carrotApi.getConversations(userId, after, false, "before", "sdk")
//                .onErrorReturnItem(new UserConversations());
        return carrotApi.getConversations(userId, after, false, "before")
                .onErrorReturnItem(new UserConversations());
    }

    @Override
    public Observable<ConversationResponse> getConservation(String conversationId) {
        return carrotApi.getConversation(conversationId)
                .doOnError(new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.e(TAG, "");
                    }
                })
                .onErrorReturnItem(new ConversationResponse());
    }

    @Override
    public Observable<NetworkResponse> setTyping(String conversationId, String messageBody) {
        return carrotApi.setTyping(conversationId, messageBody, true)
                .onErrorReturnItem(new NetworkResponse("typing error"));
    }

    @Override
    public void clearSession() {
        sessionId = "";
    }

    @Override
    public String getOkHttpVersion() {
       return okhttp3.OkHttp.VERSION;
    }

    @Override
    public Observable<StartConversationResponse> startConversation(String userId, String messageText) {
        return carrotApi.startConversation(userId, messageText);
    }

    @Override
    public Observable<StartConversationResponse> startConversation(String userId, File file) {
        RequestBody boundary = RequestBody.create(MediaType.parse("multipart/form-data"), "*****");
        //RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);


        int index = file.getName().lastIndexOf('.')+1;
        String ext = file.getName().substring(index).toLowerCase();
        String mimetype = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);

        String type = "file";
        // ограинчения по tiff как костыль - чтобы он отображался как файл, а не как картинка
        if(mimetype != null && mimetype.toLowerCase().contains("image") && !mimetype.toLowerCase().contains("tiff")) {
            type = "image";
        }

        RequestBody requestFile = RequestBody.create(file, MediaType.parse(type + "/*"));

        //MultipartBody.Part filePart = MultipartBody.Part.createFormData("file", file.getName(), requestFile);
        MultipartBody.Part filePart = null;
        try {
            filePart = MultipartBody.Part.createFormData("file", URLEncoder.encode(file.getName(), "utf-8"), requestFile);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        RequestBody fileName =  RequestBody.create(MediaType.parse("multipart/form-data"), file.getName());

        return carrotApi.startConversationWithFile(userId, boundary, fileName, filePart);
    }

    @Override
    public Observable<MessagesResponse> getMessages(String conversationId) {
        return carrotApi.getMessages(conversationId)
                .doOnError(new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.d("", throwable.toString());
                    }
                })
                .onErrorReturnItem(new MessagesResponse());
    }

    @Override
    public Observable<MessagesResponse> getMessages(String conversationId, String after) {
        return carrotApi.getMessages(conversationId, after, false, "before")
                .onErrorReturnItem(new MessagesResponse());
    }

    @Override
    public Observable<MessagesResponse> getMessages(String conversationId, String after, Integer count) {
        return carrotApi.getMessages(conversationId, after, count, false, "before")
                .onErrorReturnItem(new MessagesResponse());
    }

    @Override
    public Observable<ReplyResponse> reply(String conversationId, String messageText, boolean fromUser, String randomId){
        return carrotApi.reply(conversationId, messageText, fromUser, randomId)
                .onErrorReturnItem(new ReplyResponse());
    }

    @Override
    public Observable<ReplyFileResponse> replyFile(String conversationId, File file, String autoAssign, String randomId){

        RequestBody boundary = RequestBody.create(MediaType.parse("multipart/form-data"), "*****");


        int index = file.getName().lastIndexOf('.')+1;
        String ext = file.getName().substring(index).toLowerCase();
        String mimetype = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);

        String type = "file";
        // ограинчения по tiff как костыль - чтобы он отображался как файл, а не как картинка
        if(mimetype != null && mimetype.toLowerCase().contains("image") && !mimetype.toLowerCase().contains("tiff")) {
            type = "image";
        }

        RequestBody requestFile = RequestBody.create(file, MediaType.parse(type + "/*"));
        MultipartBody.Part filePart = null;
        try {
            filePart = MultipartBody.Part.createFormData("file", URLEncoder.encode(file.getName(), "utf-8"), requestFile);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        RequestBody randomIdPart = RequestBody.create(MediaType.parse("multipart/form-data"), String.valueOf(randomId));
        RequestBody autoAssignPart = RequestBody.create(MediaType.parse("multipart/form-data"), autoAssign);

        RequestBody fileName =  RequestBody.create(MediaType.parse("multipart/form-data"), file.getName());

        return carrotApi.replyFile(conversationId, boundary, filePart, randomIdPart, autoAssignPart, fileName);
    }

    @Override
    public Observable<NetworkResponse> markRead(String conversationId) {
        return carrotApi.markRead(conversationId)
                .doOnNext(new Consumer<NetworkResponse>() {
                    @Override
                    public void accept(NetworkResponse networkResponse) throws Exception {
                        Log.i("Mark read succ", networkResponse.getMeta().toString());
                    }
                })
                .doOnError(new Consumer<Throwable>() {
            @Override
            public void accept(Throwable throwable) throws Exception {
                Log.e("Mark read error: ", throwable.toString());
            }
        });
               // .onErrorReturnItem(new NetworkResponse("markRead error"));
    }

    @Override
    public Observable<NetworkResponse> conversationParts(String messageId, JsonObject meta_data) {
        return carrotApi.conversationParts(messageId, meta_data);
    }

    @Override
    public Observable<PushSubResponse> sendPushToken(String userId,
                                                     String token,
                                                     String deviceId,
                                                     String type,
                                                     String deviceType,
                                                     String device,
                                                     String browser,
                                                     String userAgent) {
        String osVersion = android.os.Build.VERSION.RELEASE;
        int osSdkVersion = android.os.Build.VERSION.SDK_INT;
        String os = "Android " + osVersion + " (" + osSdkVersion + ")";

        return carrotApi.sendPushToken(userId, token, "mobile", deviceId, device, deviceType, os, browser, userAgent);
    }

    @Override
    public Observable<PushSubResponse> deletePushToken(String userId, String deviceId, String type) {
        return carrotApi.deletePushToken(userId, deviceId, type)
                .doOnNext(new Consumer<PushSubResponse>() {
                    @Override
                    public void accept(PushSubResponse pushSubResponse) throws Exception {
                        Log.i("",pushSubResponse.toString());
                    }
                })
                .doOnError(new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.i("",throwable.toString());
                    }
                })
                .onErrorReturnItem(new PushSubResponse("deletePushToken error"));
    }

    @Override
    public Observable<NetworkResponse> setMetaData(String messageId, String metaData) {
        return carrotApi.setMetaData(messageId, metaData);
    }

    @Override
    public Observable<NetworkResponse> trackInteraction(String conversationId, String type) {
        return carrotApi.trackinteraction(conversationId, type);
    }

    @Override
    public Observable<ChooseRoutingBotResponse> chooseRoutingBot(String conversationId) {
        return carrotApi.chooseRoutingBot(conversationId);
    }

    @Override
    public Observable<NetworkResponse> startRoutingBot(String botId,
                                                String buttonActionId,
                                                String buttonActionText,
                                                String randomId,
                                                String conversationId) {
        return carrotApi.startRoutingBot(botId, buttonActionId, buttonActionText, randomId, conversationId);
    }

    @Override
    public Observable<NetworkResponse> startRoutingBot(String botId,
                                                       String buttonActionId,
                                                       String buttonActionText,
                                                       String randomId) {
        return carrotApi.startRoutingBot(botId, buttonActionId, buttonActionText, randomId);
    }

    public WssService getWssService() {
        return libComponent.getWssService();
    }

    public static String generateHashHmac(String str, String secret) throws NoSuchAlgorithmException, InvalidKeyException {
        Mac sha256_HMAC = Mac.getInstance("HmacSHA256");

        SecretKeySpec secretKey = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
        sha256_HMAC.init(secretKey);

        final byte[] mac_data = sha256_HMAC.doFinal(str.getBytes());
        StringBuilder result = new StringBuilder();
        for (final byte element : mac_data)
        {
            result.append(Integer.toString((element & 0xff) + 0x100, 16).substring(1));
        }
        return result.toString();
    }

    public static void showFullImage(String urlImage, FragmentManager fragmentManager) {
        FullImageViewDialogFragment fullViewImage = FullImageViewDialogFragment.Companion.newInstance(urlImage);
        fullViewImage.show(fragmentManager, "fullViewImage");
    }

    public static void showFullImage(File file, FragmentManager fragmentManager) {
        FullImageViewDialogFragment fullViewImage = FullImageViewDialogFragment.Companion.newInstance(file);
        fullViewImage.show(fragmentManager, "fullViewImage");
    }

    public static void showFullImage(Bitmap bitmap, FragmentManager fragmentManager) {
        FullImageViewDialogFragment fullViewImage = FullImageViewDialogFragment.Companion.newInstance(bitmap);
        fullViewImage.show(fragmentManager, "fullViewImage");
    }

    public static void saveImageToGallery(Drawable image, ContentResolver contetnResolver, SaveImageCallback callback) {
        if(!(image instanceof BitmapDrawable)) {
            callback.fail();
            return;
        }

        Bitmap bitmap = ((BitmapDrawable) image).getBitmap();
        FileUtilKt.saveBitmapImageToGallery(bitmap, contetnResolver, callback);
    }

    public static LibComponent getLibComponents(){
        return libComponent;
    }

    public static boolean isDebug() {
        return BuildConfig.DEBUG;
    }

    /** Returns the consumer friendly device name */
    private String getDeviceName() {
        if (HuaweiUtilsKt.isHuawei()) {
            return "Huawei [huawei_push] 1.0.0";
        } else {
            String manufacturer = Build.MANUFACTURER;
            String model = Build.MODEL;
            if (model.startsWith(manufacturer)) {
                return capitalize(model);
            }

            return capitalize(manufacturer) + " " + model;
        }
    }

    private String capitalize(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        char[] arr = str.toCharArray();
        boolean capitalizeNext = true;

        StringBuilder phrase = new StringBuilder();
        for (char c : arr) {
            if (capitalizeNext && Character.isLetter(c)) {
                phrase.append(Character.toUpperCase(c));
                capitalizeNext = false;
                continue;
            } else if (Character.isWhitespace(c)) {
                capitalizeNext = true;
            }
            phrase.append(c);
        }

        return phrase.toString();
    }

    public void setIsUseEuServers(boolean useEuServers) {
        this.useEuServers = useEuServers;
    }

    public boolean isUseEuServers() {
        return useEuServers;
    }

    @Override
    public Observable<TriggersResponse> getTriggers() {
        return carrotApi.getTriggers();
    }

    @Override
    public Observable<NetworkResponse> sendTrigger(List<String> triggerIds) {
        return  carrotApi.sendTrigger(triggerIds);
    }

    @Override
    public Observable<NetworkResponse> setPresenceCurrentScreen(String presence, String currentScreen)  {
        return  carrotApi.setPresenceCurrentScreen(presence, currentScreen);
    }

    @Override
    public Observable<NetworkResponse> setUserConsentContact(String contacts, String partId, String userId) {
        return  carrotApi.setUserConsentContact(contacts, partId, userId);
    }

    @Override
    public Observable<NetworkResponse> setUserConsentDataProcessing(Boolean dataProcessing, String userId) {
        return  carrotApi.setUserConsentDataProcessing(dataProcessing, userId);
    }
}
