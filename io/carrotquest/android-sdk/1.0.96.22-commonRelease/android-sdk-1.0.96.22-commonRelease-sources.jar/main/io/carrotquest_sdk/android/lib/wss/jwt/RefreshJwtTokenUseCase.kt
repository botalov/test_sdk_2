package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshData
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshResponse
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject


fun refreshJwtToken(updateJwtTokenSubject: BehaviorSubject<String>) {
    Log.i("TEST_INIT_IN", "start refreshJwtToken")
    val carrotApi = CarrotLib.getLibComponents().carrotApi
    Log.i("TEST_INIT_IN", "refreshJwtToken carrotApi = ${carrotApi.hashCode()}")

    val needUpdateRefreshToken = needUpdateRefreshToken()
    Log.i("TEST_INIT_IN", "refreshJwtToken needUpdateRefreshToken = $needUpdateRefreshToken")
    try {
        val d = carrotApi.refresh(needUpdateRefreshToken)
            .subscribeOn(Schedulers.io())
            .take(1)
            .doOnError { e ->
                Log.i("TEST_INIT_IN", "refresh error $e")
                Log.e("refresh error: ", e)
            }
            .onErrorReturn { e ->
                Log.i("TEST_INIT_IN", "onErrorReturn $e")

                val meta = Meta()
                meta.status = 999
                meta.error = e.toString()

                val data = RefreshData(access = "", refresh = "")
                return@onErrorReturn RefreshResponse(meta = meta, data = data)
            }
            .subscribe { response ->
                Log.i("TEST_INIT_IN", "refreshJwtToken response ${response.meta.status}")
                if (response.meta.status == 200) {
                    val token = response.data.access
                    saveJwtToken(token)
                    val refreshToken = response.data.refresh
                    saveRefreshToken(refreshToken)

                    Log.i("TEST_INIT_IN", "onNext")
                    updateJwtTokenSubject.onNext(token)
                }
            }
    }catch (e: Exception) {
        Log.i("TEST_INIT_IN", "EEEEE: $e")
    }
}

private fun needUpdateRefreshToken(): Boolean {
    return !isActualRefreshToken()
}