package io.carrotquest_sdk.android.presentation.mvp.dialog.view

import android.Manifest
import android.animation.Animator
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.content.res.Resources
import android.graphics.Color
import android.graphics.Point
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.TextWatcher
import android.text.style.DynamicDrawableSpan
import android.text.style.ImageSpan
import android.util.Pair
import android.view.Display
import android.view.View
import android.view.ViewStub
import android.view.animation.DecelerateInterpolator
import android.webkit.WebView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.Toolbar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import io.carrotquest_sdk.android.lib.utils.GraphicUtils
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.view.DropDownAnim
import io.carrotquest_sdk.android.data.network.js_interface.DialogJSInterface
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.getDraftMessageUseCase
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.presentation.mvp.base.BaseSdkActivity
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.OperatorStatus
import io.carrotquest_sdk.android.presentation.mvp.dialog.presenter.DialogPresenter
import io.carrotquest_sdk.android.presentation.mvp.file_picker.FilePickerHelper
import io.carrotquest_sdk.android.presentation.mvp.utils.isTablet
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView
import io.carrotquest_sdk.android.presentation.mvp.web_view.ObservableWebView
import io.reactivex.Observer
import io.reactivex.disposables.Disposable


class DialogActivity : BaseSdkActivity(), IDialogView {
    private val tag = "DialogActivity"

    companion object ARGS {
        const val CONVERSATION_ID_ARG = "CONVERSATION_ID_ARG"
        const val STARTED_FROM_NOT_ARG = "STARTED_FROM_NOT_ARG"
    }

    private val presenter = DialogPresenter()
    private var carrotWebView: CarrotWebView? = null

    private var startedFromNotification = false

    private var isInitView = false

    private val documentPick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        presenter.onOpenFile(uri)
    }

    //private val adminsContainer = findViewById<LinearLayout>(R.id.admins_container)
    //private val appBar = findViewById<AppBarLayout>(R.id.app_bar)
    //private val appNameTextView = findViewById<TextView>(R.id.app_name_text_view)
    //private val attachFileImageButton = findViewById<ImageButton>(R.id.attach_file_image_button)
    //private val bottomBar = findViewById<ConstraintLayout>(R.id.bottom_bar)
    //private val bubbleUnreadConversationCountTextView = findViewById<TextView>(R.id.bubble_unread_conversations_count_text_view)
    //private val buttonsBar = findViewById<ConstraintLayout>(R.id.buttons_bar)
    //private val closeImageButton = findViewById<ImageButton>(R.id.close_image_button)
    //private val collapsingToolBar = findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar)
    //private val descriptionTextView = findViewById<TextView>(R.id.description_text_view)
    //private val dialogActRootContainer = findViewById<RootContainerForKeyboard>(R.id.dialog_act_root_container)
    //private val dialogWebViewStub = findViewById<ViewStub>(R.id.dialog_web_view_stub)
    //private val inputMessageEditText = findViewById<EditText>(R.id.input_message_edit_text)
    //private val openDialogsImageButton = findViewById<ImageButton>(R.id.open_dialogs_image_button)
    //private val phonePrefix = findViewById<ConstraintLayout>(R.id.phone_prefix)
    //private val phonePrefixArrow = findViewById<ImageView>(R.id.phone_prefix_arrow)
    //private val phonePrefixFirstSymbol = findViewById<TextView>(R.id.phone_prefix_first_symbol)
    //private val phonePrefixFlag = findViewById<TextView>(R.id.phone_prefix_flag)
    //private val sendMessageImageButton = findViewById<ImageButton>(R.id.send_message_image_button)
    //private val toBottomFab = findViewById<FloatingActionButton>(R.id.to_bottom_fab)
    //private val toolbar = findViewById<Toolbar>(R.id.toolbar)
    //val inputMessageEditText = findViewById<EditText>(R.id.input_message_edit_text)
    //val send_message_image_button = findViewById<>(R.id.send_message_image_button)
    //val webView = findViewById<>(R.id.web_view)
    //val x = findViewById<>(R.id.container_web_view)
    private var containerWebView:  LinearLayout? = null

    private fun initViews() {
        setSupportActionBar(findViewById<Toolbar>(R.id.toolbar))

        findViewById<ImageButton>(R.id.close_image_button).setOnClickListener { presenter.onTapCloseButton() }
        findViewById<ImageButton>(R.id.open_dialogs_image_button).setOnClickListener {
            presenter.onTapGoToHistoryDialogsButton(
                startedFromNotification
            )
        }

        //LogToElk.write("test message", MessageToElkType.RTS_CONNECT, HashMap())

        findViewById<FloatingActionButton>(R.id.to_bottom_fab).hide()
        findViewById<FloatingActionButton>(R.id.to_bottom_fab).setOnClickListener { presenter.onTabToBottomScroll() }
        findViewById<EditText>(R.id.input_message_edit_text).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                presenter.onInputText(s.toString())
            }

            override fun afterTextChanged(s: Editable) {

            }
        })

        val display: Display = windowManager.defaultDisplay
        val smallestSize = Point()
        val largestSize = Point()
        display.getCurrentSizeRange(smallestSize, largestSize)
        val height: Int = largestSize.y

        findViewById<ImageButton>(R.id.attach_file_image_button).setOnClickListener {
            presenter.onOpenPicker(height * 2 / 3)
        }

        findViewById<ImageButton>(R.id.send_message_image_button).setOnClickListener {
            presenter.onTapSendMessage(
                findViewById<EditText>(R.id.input_message_edit_text).text.toString()
            )
        }

        findViewById<ConstraintLayout>(R.id.phone_prefix).setOnClickListener {
            presenter.onTapPhonePrefix(this)
        }

        findViewById<RootContainerForKeyboard>(R.id.dialog_act_root_container).setSizeObserver(
            object : Observer<Pair<Int, Int>> {
                override fun onSubscribe(d: Disposable) {

                }

                override fun onNext(oldNewSize: Pair<Int, Int>) {
                    val oldHeight = oldNewSize.first
                    val newHeight = oldNewSize.second
                    val delta = oldHeight!! - newHeight!!
                    val barsHeight = findViewById<ConstraintLayout>(R.id.bottom_bar).measuredHeight + findViewById<ConstraintLayout>(R.id.buttons_bar).measuredHeight

                    if (delta > 0) {
                        presenter.onViewKeyboardShow(oldHeight, newHeight, barsHeight)
                    } else {
                        presenter.onViewKeyboardHide(oldHeight, newHeight, barsHeight)
                    }
                }

                override fun onError(e: Throwable) {

                }

                override fun onComplete() {

                }
            })

        val params = findViewById<AppBarLayout>(R.id.app_bar).layoutParams as CoordinatorLayout.LayoutParams
        val behavior = params.behavior as AppBarLayout.Behavior?
        behavior?.setDragCallback(object : AppBarLayout.Behavior.DragCallback() {
            override fun canDrag(appBarLayout: AppBarLayout): Boolean {
                return false
            }
        })
        disableAppBarExpandState()
        disableInput()

        isInitView = true
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        this.intent = intent

        presenter.onChangeConversationId(
            when (intentHasConversationId()) {
                true -> getConversationIdFromIntent()
                false -> ""
            }
        )
        reloadWebView()
    }


    override fun getTheme(): Resources.Theme {
        val theme = super.getTheme()
        when (getThemeUseCase(this)) {
            SimpleTheme.DARK -> {
                theme.applyStyle(R.style.DarkCqSdkTheme, true)
            }
            else -> {
                theme.applyStyle(R.style.LightCqSdkTheme, true)
            }
        }
        return theme
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        //presenter.onCreate()

        // Установка ориентации
        try {
            requestedOrientation = if(isTablet(this)) {
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        } catch (e: Exception) {
            Log.d("SetOrientation", "$e")
        }

        super.onCreate(savedInstanceState)

        try {
            // установка темы
            updateTheme()
        }catch (e: Exception) {
            Log.e(tag, "Set theme error: $e")
        }


        try {
            setContentView(R.layout.activity_dialog_new)

            //
            //enableEdgeToEdge()
            //setContentView(R.layout.activity_test)
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.dialog_act_root_container)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom)
                insets
            }


        } catch (e: Exception) {
            Log.e(tag, "Set content view error: $e")
        }

        try {
            updateThemeManual()
        }catch (e: Exception) {
            Log.d(tag, "Update theme error: $e")
        }

        val carrotIsInit = Carrot.isInit()

        if (!carrotIsInit) {
            val apiKey = SharedPreferencesLib.getString(this, "api_key")
            val appId = SharedPreferencesLib.getString(this, "app_id")
            val isUseEuServers = Carrot.isUseEuApi()

            var isConnected = false
            Carrot.setup(this, apiKey, appId, isUseEuServers, object : Carrot.Callback<Boolean> {
                override fun onResponse(result: Boolean?) {
                    if(isConnected) {
                        return
                    }
                    isConnected = true

                    if (result == true && !carrotIsInit) {
                        init(savedInstanceState)
                    } else {
                        Log.e(tag, "Oops. carrotIsInit = $carrotIsInit, result = $result")
                    }
                }

                override fun onFailure(t: Throwable?) {
                    Log.e(tag, "Carrot.setup() onFailure: $t")
                }
            })
        } else {
            init(savedInstanceState)
        }
    }

    override fun onResume() {
        super.onResume()
        presenter.onResume()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById<RootContainerForKeyboard>(R.id.dialog_act_root_container)) { v, windowInsets ->
            val insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars())
            // Apply the insets as a margin to the view. This solution sets
            // only the bottom, left, and right dimensions, but you can apply whichever
            // insets are appropriate to your layout. You can also update the view padding
            // if that's more appropriate.
            val oldParams =  v.layoutParams

            val newParams = FrameLayout.LayoutParams(oldParams)
            newParams.leftMargin = insets.left
            newParams.bottomMargin = insets.bottom
            newParams.rightMargin = insets.right
            newParams.topMargin = insets.top

            v.layoutParams = newParams


            // Return CONSUMED if you don't want want the window insets to keep passing
            // down to descendant views.
            WindowInsetsCompat.CONSUMED
        }
    }

    override fun onPause() {
        presenter.onPause()
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
    }

    private fun init(savedInstanceState: Bundle?) {
        if (intent.hasExtra(STARTED_FROM_NOT_ARG)) {
            startedFromNotification = intent.getBooleanExtra(STARTED_FROM_NOT_ARG, false)
        }

        carrotWebView = CarrotWebView(this)

        try {
            presenter.attachView(this)
            presenter.onCreate()
        }catch (e:Exception) {
            Log.e(tag, "$e")
        }
        //if (!isInitView) {
            initViews()
       // }



        carrotWebView?.addLoadingObserver(object : Observer<Boolean> {
            override fun onComplete() {

            }

            override fun onSubscribe(d: Disposable) {

            }

            override fun onNext(isLoadingWebView: Boolean) {
                if (isLoadingWebView) {
                    if (intent != null && intent.hasExtra(CONVERSATION_ID_ARG) && !TextUtils.isEmpty(
                            intent.getStringExtra(CONVERSATION_ID_ARG)
                        )
                    ) {
                        if (intent.getStringExtra(CONVERSATION_ID_ARG) == "last_conversation") {
                            presenter.onOpenLastDialog()
                        } else {
                            presenter.onOpenDialog()
                        }
                    } else {
                        presenter.onOpenNewDialog()
                    }
                }
            }

            override fun onError(e: Throwable) {
                Log.e(tag, e.toString())
                showErrorSomething()
            }
        })
        carrotWebView?.setErrorObserver { isError ->
            presenter.onChangeErrorStateWebView(isError)
        }


        //val viewStub = findViewById<ViewStub>(R.id.dialog_web_view_stub)
        val viewStub = findViewById<ViewStub>(R.id.dialog_web_view_stub)
        if(viewStub == null || viewStub.layoutInflater == null) {
            return
        }

        viewStub.layoutResource = R.layout.stub_web_view_layout
        //val viewStubView = viewStub.inflate()
        containerWebView = if (viewStub.parent != null) {
            viewStub.inflate().findViewById<LinearLayout>(R.id.container_web_view)
        } else {
            viewStub.findViewById<LinearLayout>(R.id.container_web_view)
        }
        //val containerWebView = viewStubView.findViewById<LinearLayout>(R.id.container_web_view)

        containerWebView?.removeAllViews()
        val param = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT,
            1.0f
        )
        carrotWebView?.layoutParams = param
        containerWebView?.addView(carrotWebView)

        carrotWebView?.setOnScroll { v, _, scrollY, _, _ ->
            val offsetY = (v as WebView).contentHeight * v.scale - (scrollY + v.height)
            presenter.onScrollDialog(offsetY, scrollY)
        }

        presenter.onChangeConversationId(
            when (intentHasConversationId()) {
                true -> getConversationIdFromIntent()
                false -> ""
            }
        )

        presenter.onCreateWebView(
            if (intent != null && intent.hasExtra(CONVERSATION_ID_ARG)) intent.getStringExtra(
                CONVERSATION_ID_ARG
            )!! else ""
        )

        reloadWebView()
    }

    override fun loadUrl() {
        try {
            carrotWebView?.loadUrl(BuildConfig.DIALOG_URL)
        } catch (e: java.lang.Exception) {
            Log.e(tag, e)
        }
        carrotWebView?.initJsInterface(
            DialogJSInterface(
                this@DialogActivity,
                presenter,
                carrotWebView
            )
        )
    }

    override fun onBackPressed() {
        //super.onBackPressed()
        presenter.onBackPressed(startedFromNotification)
    }

    override fun setupWebView(webView: CarrotWebView) {

    }

    override fun initStartView(jsonScript: String) {
        carrotWebView?.executeJsInWebView(jsonScript)
    }

    override fun hideLoadError() {
        carrotWebView?.hideLoadError()
    }

    override fun hideLoading() {
        carrotWebView?.hideLoading()
    }

    override fun showMessage(messageJson: String) {
        carrotWebView?.executeJsInWebView(messageJson)
    }

    override fun deleteMessage(messageJson: String) {
        carrotWebView?.executeJsInWebView(messageJson)
    }

    override fun deleteAllMessages(js: String) {
        carrotWebView?.executeJsInWebView(js)
    }

    override fun updateMessage(messageJson: String) {
        carrotWebView?.executeJsInWebView(messageJson)
    }

    override fun scrollWebView(js: String) {
        carrotWebView?.executeJsInWebView(js)
    }

    override fun updateElevationHeader(elevation: Float) {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP && findViewById<AppBarLayout>(R.id.app_bar).elevation != elevation) {
            val elevationAnimator = ValueAnimator.ofFloat(findViewById<AppBarLayout>(R.id.app_bar).elevation, elevation)
            elevationAnimator.duration = 200
            elevationAnimator.addUpdateListener { animation ->
                run {
                    findViewById<AppBarLayout>(R.id.app_bar).elevation = animation.animatedValue as Float
                }
            }
            elevationAnimator.start()
        }
    }

    override fun hideToBottomButton() {
        if (findViewById<FloatingActionButton>(R.id.to_bottom_fab).isShown) {
            findViewById<FloatingActionButton>(R.id.to_bottom_fab).hide()
        }
    }

    override fun showToBottomButton() {
        if (!findViewById<FloatingActionButton>(R.id.to_bottom_fab).isShown) {
            findViewById<FloatingActionButton>(R.id.to_bottom_fab).show()
        }
    }

    override fun collapseHeader(operatorsInOnline: Boolean) {
        updateElevationHeader(carrotWebView?.findViewById<ObservableWebView>(R.id.web_view)?.scrollY?.toFloat() ?: 0.0f)
        enableCollapse()

        val countLinesName = findViewById<TextView>(R.id.app_name_text_view).lineCount
        val hAppBar: Float =
            if ((countLinesName * 20 + 18 * 2) < 56) 56.0f else (countLinesName * 20 + 18 * 2).toFloat()
        val hAppBarPx = GraphicUtils.dpToPx(this, hAppBar)
        //app_bar.layoutParams.height = hAppBarPx
        val starthAppBarPx = findViewById<AppBarLayout>(R.id.app_bar).layoutParams.height

        val params = findViewById<AppBarLayout>(R.id.app_bar).layoutParams as CoordinatorLayout.LayoutParams
        val behavior = params.behavior as AppBarLayout.Behavior?
        if (behavior != null) {
            val valueAnimator = ValueAnimator.ofInt()
            valueAnimator.interpolator = DecelerateInterpolator()
            valueAnimator.addUpdateListener { animation ->
                behavior.topAndBottomOffset = animation.animatedValue as Int
                findViewById<AppBarLayout>(R.id.app_bar).requestLayout()
            }

            valueAnimator.addListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) {
                    updateTopMarginWebView(hAppBarPx)
                }

                override fun onAnimationEnd(animation: Animator) {
                    //toolbar.setBackgroundResource(R.color.colorLabelBkg)
                    disableAppBarCollapseState()
                }

                override fun onAnimationCancel(animation: Animator) {

                }

                override fun onAnimationRepeat(animation: Animator) {

                }
            })

            valueAnimator.setIntValues(0, -(starthAppBarPx - hAppBarPx))
            valueAnimator.duration = 400
            valueAnimator.start()

            val alphaDesc = ValueAnimator.ofFloat(1f, 0f)
            alphaDesc.addUpdateListener { animation ->
                run {
                    findViewById<TextView>(R.id.description_text_view).alpha = animation.animatedValue as Float
                    findViewById<LinearLayout>(R.id.admins_container).alpha = animation.animatedValue as Float
                }
            }
            alphaDesc.start()

            updateStatusCollapsedAppBar(operatorsInOnline)
        }
    }

    override fun updateUnreadConversationsCount(count: Int) {
        if (count > 0) {
            findViewById<TextView>(R.id.bubble_unread_conversations_count_text_view).text = count.toString()
            findViewById<TextView>(R.id.bubble_unread_conversations_count_text_view).visibility = View.VISIBLE
        } else {
            findViewById<TextView>(R.id.bubble_unread_conversations_count_text_view).visibility = View.GONE
        }
    }

    override fun updateAdminsAvatars(avatars: Array<ImageView>) {
        runOnUiThread {
            findViewById<LinearLayout>(R.id.admins_container).removeAllViews()
            for (avatarImageView in avatars) {
                findViewById<LinearLayout>(R.id.admins_container).addView(avatarImageView)
            }
        }
    }

    override fun updateAdminName(adminName: String) {
        updateAdminName(adminName, true)
    }

    override fun updateAdminName(adminName: String, needResize: Boolean) {
        runOnUiThread {
            findViewById<TextView>(R.id.app_name_text_view).text = adminName
            if (needResize) {
                findViewById<TextView>(R.id.app_name_text_view).post { resizeAppBar() }
            }
        }
    }

    override fun updateAppName(appName: String) {

    }

    override fun updateStatus(status: OperatorStatus) {

    }

    override fun updateAppDescription(description: String, operatorsInOnline: Boolean) {
        runOnUiThread {
            val ssb = SpannableStringBuilder("   ${description.trimStart()}")
            val statusIndicator = when (operatorsInOnline) {
                true -> R.drawable.ic_cq_online
                false -> R.drawable.ic_cq_ofline
            }
            ssb.setSpan(
                ImageSpan(this, statusIndicator, DynamicDrawableSpan.ALIGN_BASELINE),
                0,
                1,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            findViewById<TextView>(R.id.description_text_view).setText(ssb, TextView.BufferType.SPANNABLE)
            findViewById<TextView>(R.id.app_name_text_view).post { resizeAppBar() }
        }
    }

    override fun updateStatusCollapsedAppBar(operatorsInOnline: Boolean) {
        val appName = findViewById<TextView>(R.id.app_name_text_view).text.toString().trimEnd()
        val ssb = SpannableStringBuilder("$appName   ")
        val statusIndicator = when (operatorsInOnline) {
            true -> R.drawable.ic_cq_online
            false -> R.drawable.ic_cq_ofline
        }
        ssb.setSpan(
            ImageSpan(this, statusIndicator, DynamicDrawableSpan.ALIGN_BASELINE),
            appName.length + 2,
            appName.length + 3,
            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        findViewById<TextView>(R.id.app_name_text_view).setText(ssb, TextView.BufferType.SPANNABLE)
    }

    override fun updateAppColor(color: Int) {
        val c: Int = when (getThemeUseCase(this)) {
            SimpleTheme.DARK -> {
                Color.parseColor("#FFFFFF")
            }
            else -> {
                color
            }
        }

        val cButtonToBottom =
            if (getThemeUseCase(this) === SimpleTheme.DARK) resources.getColor(R.color.colorButtonToBottomDialogFABDark) else resources.getColor(
                R.color.colorButtonToBottomDialogFAB
            )
        findViewById<ImageButton>(R.id.close_image_button).setColorFilter(c)
        findViewById<ImageButton>(R.id.open_dialogs_image_button).setColorFilter(c)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            findViewById<ImageButton>(R.id.send_message_image_button).backgroundTintList = ColorStateList.valueOf(color)
        } else {
            findViewById<ImageButton>(R.id.send_message_image_button).setColorFilter(color)
        }
        findViewById<FloatingActionButton>(R.id.to_bottom_fab).supportImageTintList = ColorStateList.valueOf(c)
        findViewById<FloatingActionButton>(R.id.to_bottom_fab).backgroundTintList = ColorStateList.valueOf(cButtonToBottom)

        carrotWebView?.setColor(color)

    }

    private fun updateTheme() {
        when (getThemeUseCase(this)) {
            SimpleTheme.DARK -> {
                setTheme(R.style.DarkCqSdkTheme)
            }
            else -> {
                setTheme(R.style.LightCqSdkTheme)
            }
        }
    }

    private fun updateThemeManual() {
        when (getThemeUseCase(this)) {
            SimpleTheme.DARK -> {
                findViewById<AppBarLayout>(R.id.app_bar).setBackgroundColor(Color.parseColor("#404040"))
                findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).setBackgroundColor(Color.parseColor("#404040"))
                findViewById<TextView>(R.id.description_text_view).setTextColor(Color.parseColor("#999999"))
                findViewById<TextView>(R.id.app_name_text_view).setTextColor(Color.parseColor("#FFFFFF"))

                findViewById<ConstraintLayout>(R.id.bottom_bar)?.setBackgroundColor(Color.parseColor("#333333"))
                findViewById<EditText>(R.id.input_message_edit_text).setTextColor(Color.parseColor("#FFFFFF"))
                findViewById<EditText>(R.id.input_message_edit_text).setHintTextColor(Color.parseColor("#B3B3B3"))

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    findViewById<ImageView>(R.id.phone_prefix_arrow)?.imageTintList = ColorStateList.valueOf(Color.parseColor("#999999"))
                } else {
                    findViewById<ImageView>(R.id.phone_prefix_arrow)?.setColorFilter(Color.parseColor("#999999"))
                }
            }
            else -> {
                findViewById<AppBarLayout>(R.id.app_bar).setBackgroundColor(Color.parseColor("#FFFFFF"))
                findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).setBackgroundColor(Color.parseColor("#FFFFFF"))
                findViewById<TextView>(R.id.description_text_view).setTextColor(Color.parseColor("#999999"))
                findViewById<TextView>(R.id.app_name_text_view).setTextColor(Color.parseColor("#000000"))

                findViewById<ConstraintLayout>(R.id.bottom_bar)?.setBackgroundColor(Color.parseColor("#FFFFFF"))
                findViewById<EditText>(R.id.input_message_edit_text).setTextColor(Color.parseColor("#000000"))
                findViewById<EditText>(R.id.input_message_edit_text).setHintTextColor(Color.parseColor("#B3B3B3"))

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    findViewById<ImageView>(R.id.phone_prefix_arrow)?.imageTintList = ColorStateList.valueOf(Color.parseColor("#5C6370"))
                } else {
                    findViewById<ImageView>(R.id.phone_prefix_arrow)?.setColorFilter(Color.parseColor("#5C6370"))
                }
            }
        }

    }

    override fun showErrorNoInternet() {
        runOnUiThread {
            hideLoading()
            carrotWebView?.showLoadError()
            carrotWebView?.showNoInternetError()
        }
    }

    override fun showErrorAirplaneMode() {
        runOnUiThread {
            hideLoading()
            carrotWebView?.showAirplaneModError()
        }
    }

    override fun showErrorSomething() {
        runOnUiThread {
            hideLoading()
            carrotWebView?.showLoadError()
        }
    }

    override fun showErrorFileNotFound() {
        Snackbar.make(
            findViewById<RootContainerForKeyboard>(R.id.dialog_act_root_container),
            getString(R.string.popup_powered_by_start_text),
            Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun showErrorSendMessage() {
        Snackbar.make(
            findViewById<RootContainerForKeyboard>(R.id.dialog_act_root_container),
            getString(R.string.cq_lib_something_wrong),
            Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun enableInput() {
        findViewById<ConstraintLayout>(R.id.bottom_bar)?.isEnabled = true
        findViewById<ImageButton>(R.id.attach_file_image_button).isEnabled = true
        findViewById<ImageButton>(R.id.attach_file_image_button).alpha = 1f
        findViewById<EditText>(R.id.input_message_edit_text).isEnabled = true
        findViewById<EditText>(R.id.input_message_edit_text).alpha = 1f
        //send_message_image_button.isEnabled = true
        //send_message_image_button.alpha = 1f
        changeEnabledSendButton(true)
    }

    override fun disableInput() {
        findViewById<ConstraintLayout>(R.id.bottom_bar)?.isEnabled = false
        findViewById<ImageButton>(R.id.attach_file_image_button).isEnabled = false
        findViewById<ImageButton>(R.id.attach_file_image_button).alpha = 0.5f
        findViewById<EditText>(R.id.input_message_edit_text).isEnabled = false
        findViewById<EditText>(R.id.input_message_edit_text).alpha = 0.5f
        //send_message_image_button.isEnabled = false
        changeEnabledSendButton(false)
        //send_message_image_button.alpha = 0.5f
    }

    override fun hideInput() {
        findViewById<ConstraintLayout>(R.id.bottom_bar)?.visibility = View.GONE
    }

    override fun showInput(conversationId: String) {
        val draftMessage = getDraftMessageUseCase(conversationId)
        if(draftMessage != null) {
            findViewById<EditText>(R.id.input_message_edit_text).setText(draftMessage)
            findViewById<EditText>(R.id.input_message_edit_text).setSelection(draftMessage.length)
        } else {
            clearInput()
        }

        findViewById<ConstraintLayout>(R.id.bottom_bar)?.visibility = View.VISIBLE
        if (findViewById<EditText>(R.id.input_message_edit_text).text.isNullOrEmpty()) {
            //hideSendButton()
            disableSendButton()
        } else {
            //showSendButton()
            //enableSendButton()
        }
    }

    private var currentInputMod = InputMod.NORMAL
    override fun setInputMod(mod: InputMod) {
        currentInputMod = mod
        runOnUiThread {
            when (currentInputMod) {
                InputMod.NORMAL -> {
                    //bottom_bar.input_message_edit_text.setText("")
                    findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<ImageButton>(R.id.attach_file_image_button)?.visibility = View.VISIBLE
                    findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.hint =
                        getString(R.string.input_message_hint_text)
                }
                InputMod.BOT_INPUT -> {
                    //bottom_bar.input_message_edit_text.setText("")
                    findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.hint = ""
                    findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.send_message_image_button)?.visibility = View.VISIBLE
                    findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<ImageButton>(R.id.attach_file_image_button)?.visibility = View.GONE
                }
                InputMod.ALLOW_USER_REPLIES -> {
                    //bottom_bar.input_message_edit_text.setText("")
                    findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<ImageButton>(R.id.attach_file_image_button)?.visibility = View.VISIBLE
                    findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.hint =
                        getString(R.string.input_message_hint_text)
                }
            }
        }
    }

    override fun updateHint(hint: String?) {

        if (hint == null) {
            findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.hint = getString(R.string.input_message_hint_text)
        } else {
            findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.hint = hint
        }
    }

    override fun updateMaxLengthInput(maxLength: Int?) {
        if(maxLength != null) {
            findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.filters =
                arrayOf(InputFilter.LengthFilter(maxLength))
        } else {
            findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.filters = arrayOf()
        }
    }

    fun setKeyboardType(keyboardType: Int = InputType.TYPE_TEXT_VARIATION_NORMAL) {
        findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.inputType = keyboardType
        findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.requestFocus()
    }

    override fun startDownloadFile(messageId: String) {
        val runnable = Runnable {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                presenter.onDownloadFile(messageId)
            } else {
                val listPermissions: List<String> = listOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                )


                //TODO !!!!!!
//                val rxPermissions = RealRxPermission.getInstance(this)
//                if (!rxPermissions.isGranted(Manifest.permission.READ_EXTERNAL_STORAGE) || !rxPermissions.isGranted(
//                        Manifest.permission.WRITE_EXTERNAL_STORAGE
//                    )
//                ) {
//                    rxPermissions
//                        .requestEach(*listPermissions.toTypedArray())
//                        .subscribe { permission ->
//                            if (permission.state() == Permission.State.GRANTED) {
//                                presenter.onDownloadFile(messageId)
//                            }
//                        }
//                } else {
//                    presenter.onDownloadFile(messageId)
//                }
            }
        }
        runOnUiThread(runnable)
    }

    override fun toBottomScroll() {
        if (carrotWebView != null) {
            carrotWebView?.executeJsInWebView("javascript:window.webView.forceScrollBottom()")
            findViewById<FloatingActionButton>(R.id.to_bottom_fab).hide()
        }
    }

    override fun showSendButton() {
        runOnUiThread {
            //attach_file_image_button.visibility = View.VISIBLE
            findViewById<ImageButton>(R.id.send_message_image_button).visibility = View.VISIBLE
        }
    }

    override fun hideSendButton() {
        runOnUiThread {
            findViewById<ImageButton>(R.id.send_message_image_button).visibility = View.GONE
            //attach_file_image_button.visibility = View.GONE
        }
    }

    override fun enableSendButton() {
        runOnUiThread {
            findViewById<ImageButton>(R.id.send_message_image_button).visibility = View.VISIBLE
            //send_message_image_button.isEnabled = true
            changeEnabledSendButton(true)
            //attach_file_image_button.visibility = View.GONE
        }
    }

    override fun disableSendButton() {
        runOnUiThread {
            findViewById<ImageButton>(R.id.send_message_image_button).visibility = View.VISIBLE
            //send_message_image_button.isEnabled = false
            changeEnabledSendButton(false)
            //attach_file_image_button.visibility = View.GONE
        }
    }

    override fun showAttachFileButton() {
        findViewById<ImageButton>(R.id.attach_file_image_button).visibility = View.VISIBLE
    }
    override fun hideAttachFileButton() {
        findViewById<ImageButton>(R.id.attach_file_image_button).visibility = View.GONE
    }

    override fun clearInput() {
        runOnUiThread {
            if (findViewById<EditText>(R.id.input_message_edit_text).text.isNotEmpty()) {
                findViewById<EditText>(R.id.input_message_edit_text).text.clear()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        presenter.onDestroy()
        carrotWebView?.onDestroy()
    }

    private fun reloadWebView() {
        if (carrotWebView != null) {
            carrotWebView?.showLoading()
            loadUrl()
        }
    }

//    override fun showPicker() {
//        picker.show(this)
//    }

    fun getContext(): Context = this

    private fun intentHasConversationId(): Boolean =
        intent != null && intent.hasExtra(CONVERSATION_ID_ARG)

    private fun getConversationIdFromIntent(): String {
        return if (intent != null && intent.hasExtra(CONVERSATION_ID_ARG)) intent.getStringExtra(
            CONVERSATION_ID_ARG
        )!! else ""
    }

    private fun updateTopMarginWebView(topMargin: Int) {
        if(containerWebView != null) {
            val webViewParams = containerWebView!!.layoutParams as ConstraintLayout.LayoutParams
            webViewParams.setMargins(
                webViewParams.leftMargin,
                topMargin,
                webViewParams.rightMargin,
                webViewParams.bottomMargin
            )
            containerWebView?.layoutParams = webViewParams
        }
    }

    private fun resizeAppBar() {
        val countLinesName = findViewById<TextView>(R.id.app_name_text_view).lineCount
        val countLinesDesc = findViewById<TextView>(R.id.description_text_view).lineCount

        val hToolBar: Float = (countLinesName * 20).toFloat()
        //val hToolBar: Float = if(tempHToolbar < 56) 56f else tempHToolbar

        val tempHAppBar: Float = (85 + hToolBar + countLinesDesc * 18)
        val hAppBar: Float = if (tempHAppBar < 56) 56f else tempHAppBar

        val params = findViewById<AppBarLayout>(R.id.app_bar).layoutParams
        val dropDownAppBar =
            DropDownAnim(findViewById<AppBarLayout>(R.id.app_bar), params.height, GraphicUtils.dpToPx(this, hAppBar))
        dropDownAppBar.duration = 200
        findViewById<AppBarLayout>(R.id.app_bar).startAnimation(dropDownAppBar)

        val paramsToolbar = findViewById<TextView>(R.id.app_name_text_view).layoutParams
        val dropDownToolBar = DropDownAnim(
            findViewById<TextView>(R.id.app_name_text_view),
            paramsToolbar.height,
            GraphicUtils.dpToPx(this, hToolBar)
        )
        dropDownToolBar.duration = 200
        findViewById<TextView>(R.id.app_name_text_view).startAnimation(dropDownToolBar)

        val dropDownToolBar2 =
            DropDownAnim(findViewById<Toolbar>(R.id.toolbar), paramsToolbar.height, GraphicUtils.dpToPx(this, hToolBar))
        dropDownToolBar2.duration = 200
        findViewById<Toolbar>(R.id.toolbar).startAnimation(dropDownToolBar2)

        val toolbarHeight = findViewById<AppBarLayout>(R.id.app_bar).height
        updateTopMarginWebView(toolbarHeight)
    }

    private fun disableAppBarExpandState() {
        findViewById<AppBarLayout>(R.id.app_bar).isActivated = false
        findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).isTitleEnabled = false

        val p = findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).layoutParams as (AppBarLayout.LayoutParams)
        p.scrollFlags = 0
        findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).layoutParams = p
        findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).isActivated = false
    }

    private fun disableAppBarCollapseState() {
        findViewById<AppBarLayout>(R.id.app_bar).isActivated = false
        findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).isTitleEnabled = false

        val p = findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).layoutParams as (AppBarLayout.LayoutParams)
        p.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS_COLLAPSED
        //p.height =  GraphicUtils.dpToPx(this, 56.0f)
        findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).layoutParams = p
        findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).isActivated = false

        val params = findViewById<AppBarLayout>(R.id.app_bar).layoutParams as CoordinatorLayout.LayoutParams
        val countLinesName = findViewById<TextView>(R.id.app_name_text_view).lineCount
        val hAppBar: Float =
            if ((countLinesName * 20 + 18 * 2) < 56) 56.0f else (countLinesName * 20 + 18 * 2).toFloat()
        params.height = GraphicUtils.dpToPx(this, hAppBar)
        findViewById<AppBarLayout>(R.id.app_bar).layoutParams = params
    }

    private fun enableCollapse() {
        findViewById<AppBarLayout>(R.id.app_bar).isActivated = true
        findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).isTitleEnabled = true

        val p = findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).layoutParams as (AppBarLayout.LayoutParams)
        p.scrollFlags = AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS_COLLAPSED
        findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).layoutParams = p
        findViewById<CollapsingToolbarLayout>(R.id.collapsing_toolbar).isActivated = true
    }


    override fun showDataSavedMessage() {
        Snackbar.make(
            findViewById<RootContainerForKeyboard>(R.id.dialog_act_root_container),
            getString(R.string.cq_your_data_is_saved),
            Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun startRoutingBot(jsonScript: String) {
        carrotWebView?.executeJsInWebView(jsonScript)
    }

    override fun addBrunch(jsonScript: String) {
        carrotWebView?.executeJsInWebView(jsonScript)
    }

    override fun openFilePicker() {
        documentPick.launch(FilePickerHelper.mAllowMimeTypes)
    }

    override fun updatePhoneRegionFlag(flag: String) {
        findViewById<TextView>(R.id.phone_prefix_flag)?.text = flag
    }

    override fun updatePhoneRegionPrefix(prefix: String) {
        findViewById<TextView>(R.id.phone_prefix_first_symbol)?.text = prefix
    }

    override fun getSupportParentActivityIntent(): Intent? {
        val parentActivityClassName = Carrot.getParentActivityClassName()
        if (parentActivityClassName.isNullOrEmpty()) {
            return super.getSupportParentActivityIntent()
        }
        return getParentActivityIntentImpl()
    }

    override fun getParentActivityIntent(): Intent? {
        val parentActivityClassName = Carrot.getParentActivityClassName()
        if (parentActivityClassName.isNullOrEmpty()) {
            return super.getParentActivityIntent()
        }
        return getParentActivityIntentImpl()
    }

    private fun getParentActivityIntentImpl(): Intent {
        val parentActivityClassName = Carrot.getParentActivityClassName()
        val parentActivityClass = Class.forName(parentActivityClassName)
        val i = Intent(this, parentActivityClass)
        i.flags = (Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        return i
    }

    fun goToParentActivity() {
        val parentActivityClassName = Carrot.getParentActivityClassName()

        if(parentActivityClassName == null || parentActivityClassName.isEmpty()) {
            val intent = this.packageManager.getLaunchIntentForPackage(this.packageName)
            intent?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            this.startActivity(intent)
        } else {
            try {
                val parentActivityClass = Class.forName(parentActivityClassName)
                val i = Intent(this, parentActivityClass)
                intent?.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(i)
            } catch (e: Exception) {
                Log.e(tag, e)
                finish()
            }
        }
    }


    override fun hidePhonePrefix() {
        findViewById<ConstraintLayout>(R.id.phone_prefix).visibility = View.GONE
    }

    override fun showPhonePrefix() {
        findViewById<ConstraintLayout>(R.id.phone_prefix).visibility = View.VISIBLE
    }

    private fun changeEnabledSendButton(isEnabled: Boolean) {
        val inputType = findViewById<EditText>(R.id.input_message_edit_text).inputType
        val correctEmail = if(inputType == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS) {
            android.util.Patterns.EMAIL_ADDRESS.matcher(findViewById<EditText>(R.id.input_message_edit_text).text).matches()
        } else true

        val correctPhone = if(inputType == InputType.TYPE_CLASS_PHONE) {
            android.util.Patterns.PHONE.matcher(findViewById<EditText>(R.id.input_message_edit_text).text).matches()
        } else true

        val enabled = isEnabled && findViewById<EditText>(R.id.input_message_edit_text).text.trim().isNotEmpty() && correctEmail && correctPhone
        findViewById<ImageButton>(R.id.send_message_image_button).isEnabled = enabled
        findViewById<ImageButton>(R.id.send_message_image_button).alpha = if(enabled) 1.0f else 0.5f
    }
}