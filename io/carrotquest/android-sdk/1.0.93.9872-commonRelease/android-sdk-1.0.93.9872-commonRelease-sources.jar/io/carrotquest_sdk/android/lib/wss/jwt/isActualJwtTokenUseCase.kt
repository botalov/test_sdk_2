package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import java.util.Date

fun isActualJwtToken(context: Context = CarrotLib.getLibComponents().getContext()): Boolean {
    val jwtToken = getJwtToken()
    val refreshToken = getRefreshToken()
    //Если токен не найден, то он актуальный
    if(jwtToken.isEmpty() ) {
        val oldToken = SharedPreferencesLib.getString(context, "CarrotToken")
        if(oldToken.isNotEmpty()) {
            return false
        }

        return refreshToken.isNullOrEmpty()
    }

    val updateTokenTimeStamp = getLastUpdateJwtTokenTime()
    //Если не найден таймштамп сохранения токена, то токен актуальный
    if(updateTokenTimeStamp <= 0) {
        return refreshToken.isNullOrEmpty()
    }

    val nowTime = Date().time

    //Токен актуальный, если разница между текущим временем и временем обновления токена меньше 55 минут
    return nowTime - updateTokenTimeStamp < jwtTokenLiveTime
}