package io.carrotquest_sdk.android.lib.wss;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.managers.BackgroundManager;
import io.carrotquest_sdk.android.lib.managers.UserPresenceService;
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager;
import io.carrotquest_sdk.android.lib.wss.response.WssResponse;
import io.carrotquest_sdk.android.lib.wss.utils.CloseReason;
import io.reactivex.Observer;

public class WssService implements IWssService {
    private static final String TAG = "WssService";

    private boolean isInit = false;
    private boolean isConnectNetwork = true;
    private boolean isForegroundApp = true;
    private Context context;
    private List<ClientWebSocket> currentSockets;
    private BackgroundManager backgroundManager;
    private NetworkManager networkManager;
    private boolean isUseEuServers = false;

    public WssService(Context context) {
        this.context = context;
    }

    public WssService(Context context, boolean isUseEuServers) {
        this.context = context;
        this.isUseEuServers = isUseEuServers;
    }

    @Override
    public void startSocket(String appId, List<Channel> channels, List<Observer<WssResponse>> observers) {
        if (!isInit) {
            this.isInit = true;
            this.currentSockets = new ArrayList<>();
            String authToken = CarrotLib.getLibComponents().getUserRep().getUser().getToken();
            ClientWebSocket clientWebSocket = new ClientWebSocket(authToken, appId, channels, observers,this.isUseEuServers);
            this.currentSockets.add(clientWebSocket);

            this.backgroundManager = BackgroundManager.getInstance();
            this.backgroundManager.addObserver(
                    isForeground -> {
                        isForegroundApp = isForeground;
                        changeStateSockets();
                    },
                    error -> Log.e(TAG, error.toString()),
                    () -> isForegroundApp = false
            );

            this.networkManager = NetworkManager.getInstance(context);
            this.networkManager.addObserver(
                    isConnect -> {
                        isConnectNetwork = isConnect;
                        changeStateSockets();
                    },
                    e -> Log.e(TAG, e.toString()),
                    () -> {
                        //onComplete
                        isConnectNetwork = false;
                    });
        }
    }

    @Override
    public void stopSocket(String appId) {
        if (currentSockets != null) {
            for (ClientWebSocket socket : currentSockets) {
                if (socket.getAppId().equals(appId)) {
                    socket.close(CloseReason.NONE);
                    break;
                }
            }
        }
    }

    @Override
    public void deInit() {
        this.isInit = false;

        if (backgroundManager != null) {
            backgroundManager.deInit();
        }
        if (networkManager != null) {
            networkManager.deInit();
        }

        if (currentSockets != null) {
            for (ClientWebSocket socket : currentSockets) {
                socket.close(CloseReason.DEINIT);
            }
        }
    }

    @Override
    public NetworkManager getNetworkManager() {
        return NetworkManager.getInstance(context);
    }

    /**
     * Открытие/закрытие сокетов в зависимости от состояния приложения и сети
     */
    private void changeStateSockets() {
        if (isConnectNetwork && isForegroundApp) {
            for (ClientWebSocket socket : currentSockets) {
                if (!socket.isConnected() && isInit) {
                    socket.connect();
                    UserPresenceService.Companion.getInstance().run();
                }
            }
        } else {
            for (ClientWebSocket socket : currentSockets) {
                if (socket.isConnected()) {
                    socket.close(isForegroundApp ? CloseReason.APP_TO_BACKGROUND : CloseReason.INTERNET_DISAPPEARED);
                    UserPresenceService.Companion.getInstance().stop();
                }
            }
        }
    }
}
