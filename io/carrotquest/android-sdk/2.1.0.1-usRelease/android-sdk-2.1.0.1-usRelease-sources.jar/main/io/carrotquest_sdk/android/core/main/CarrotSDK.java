package io.carrotquest_sdk.android.core.main;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import io.carrotquest_sdk.android.core.CarrotAuthState;
import io.carrotquest_sdk.android.core.CarrotState;
import io.carrotquest_sdk.android.core.SdkGlobalHandlers;
import io.carrotquest_sdk.android.core.SdkStateManager;
import io.carrotquest_sdk.android.core.StateFlowBridgeKt;
import kotlinx.coroutines.flow.StateFlow;
import io.carrotquest_sdk.android.core.auth.AuthManager;
import io.carrotquest_sdk.android.data.user.UserStateHolder;
import io.carrotquest_sdk.android.domain.use_cases.user.SaveAuthedUserIdUseCaseKt;
import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.models.UserProperty;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.lib.utils.AndroidUtils;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;
import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.Carrot;
import io.carrotquest_sdk.android.application.SdkApp;
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys;
import io.carrotquest_sdk.android.core.exceptions.CarrotException;
import io.carrotquest_sdk.android.core.exceptions.CarrotRepositoryException;
import io.carrotquest_sdk.android.core.exceptions.CarrotUserException;
import io.carrotquest_sdk.android.core.util.ConversationUtilsKt;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.core.util.sentry.SentryCQ_SDK;
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository;
import io.carrotquest_sdk.android.data.service.CarrotService;
import io.carrotquest_sdk.android.di.CarrotServiceModule;
import io.carrotquest_sdk.android.di.ContextSdkModule;
import io.carrotquest_sdk.android.di.DaggerSdkLibComponent;
import io.carrotquest_sdk.android.di.DataBaseModule;
import io.carrotquest_sdk.android.di.GsonModule;
import io.carrotquest_sdk.android.di.NotificationHelperModule;
import io.carrotquest_sdk.android.di.SdkLibComponent;
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.GetErrorMessagesUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.SendErrorMessagesUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.conversations.ClearHistoryUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.conversations.GetConversationsUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.triggers.TrackScreenUseCase;
import io.carrotquest_sdk.android.models.Operation;
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.DialogViewModel;
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogActivity;
import io.carrotquest_sdk.android.presentation.mvp.notifications.NotificationsConstants;
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper;
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.TrackHelperKt;
import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.subjects.BehaviorSubject;

public class CarrotSDK {
    private static final String TAG = "CarrotSDK";
    private static final String VERSION = BuildConfig.VERSION_SDK_NAME;

    private static volatile CarrotService service;
    static SdkLibComponent libComponent;


    private static boolean isDebug = false;
    private static ThemeSdk mTheme = null;

    private static boolean isUseEuApi = false;


    public interface Callback<T> {
        void onResponse(T result);
        void onFailure(Throwable t);
    }

    protected CarrotSDK(Context context) {

        isDebug = BuildConfig.BUILD_TYPE.toLowerCase().equals("debug");
        SdkApp.getInstance().initDataBase(context);
        libComponent = DaggerSdkLibComponent.builder()
                .gsonModule(new GsonModule())
                .carrotServiceModule(new CarrotServiceModule(context, app_id, isUseEuApi))
                .contextSdkModule(new ContextSdkModule(context))
                .dataBaseModule(new DataBaseModule(SdkApp.getInstance()))
                .build();
    }

    private static BehaviorSubject<Boolean> initBehaviorSubject;

    private static DisposableObserver<NetworkResponse> eventsObserver = new DisposableObserver<NetworkResponse>() {
        @Override
        public void onNext(NetworkResponse networkResponse) {
            Log.d(TAG, networkResponse.getData().toString());
        }

        @Override
        public void onError(Throwable e) {
            Log.e(TAG, e.toString());
        }

        @Override
        public void onComplete() {

        }
    };

    private static DisposableObserver<Boolean> userPropertyObserver = new DisposableObserver<Boolean>() {
        @Override
        public void onNext(Boolean aBoolean) {
            Log.d(TAG, "Set UserProperty");
        }

        @Override
        public void onError(Throwable e) {
            Log.e(TAG, e.toString());
        }

        @Override
        public void onComplete() {

        }
    };

    /**
     * Observe SDK init/deinit state with full detail.
     * Prefer this over getInitObservable() for new code.
     */
    public static StateFlow<CarrotState> getStateFlow() {
        return SdkStateManager.INSTANCE.getPublicState();
    }

    /**
     * Subscribe to SDK state changes. Returns a Disposable to stop observing.
     * The consumer receives the current state immediately, then all future transitions.
     */
    public static Disposable addStateObserver(Consumer<CarrotState> observer) {
        return StateFlowBridgeKt.addCarrotStateObserver(observer);
    }

    /**
     * Observe auth state (Idle / Authenticating / Authenticated / Failed).
     */
    public static StateFlow<CarrotAuthState> getAuthStateFlow() {
        return AuthManager.INSTANCE.getPublicState();
    }

    /**
     * Subscribe to "session expired" event — fires when SDK detects that the refresh token is
     * no longer valid and the session cannot be restored without re-auth. The typical client
     * reaction is to call {@code Carrot.deInit()} and then {@code Carrot.setup(...)} again.
     */
    public static Disposable addSessionExpiredObserver(Runnable onExpired) {
        return StateFlowBridgeKt.addSessionExpiredObserver(onExpired);
    }

    /**
     * @deprecated Use {@link #getStateFlow()} to observe rich SDK state.
     */
    @Deprecated
    public static BehaviorSubject<Boolean> getInitObservable() {
        if (initBehaviorSubject == null) {
            initBehaviorSubject = BehaviorSubject.createDefault(SdkStateManager.INSTANCE.isInit());
            StateFlowBridgeKt.attachInitSubject(initBehaviorSubject);
        }
        return initBehaviorSubject;
    }

    private static String api_key;
    private static String app_id;

    private static String parentActivityClassNameImpl;

    public static String getApiKey() {
        return api_key;
    }

    public static String getAppId() {
        return app_id;
    }

    /**
     * We recommend using the Carrot.setup(...) method with a callback in its parameters.
     * @param context
     * @param apiKey
     */
    @Deprecated
    public static void setup(@NonNull Context context, @NonNull String apiKey) {
        setup(context, apiKey, null);
    }

    public static void setup(@NonNull Context context,  @NonNull String apiKey, Callback<Boolean> callback) {
        commonSetup(context, apiKey, callback, true);
    }

    public static void setup(@NonNull Context context, @NonNull String apiKey, boolean useEuServers, Callback<Boolean> callback) {
        isUseEuApi = useEuServers;
        commonSetup(context, apiKey, callback, true);
    }

    public static void setupWithoutStartSession(@NonNull Context context, @NonNull String apiKey, Callback<Boolean> callback) {
        commonSetup(context, apiKey, callback, false);
    }

    public  static  void setupWithoutConnect(@NonNull Context context) {
        SdkGlobalHandlers.INSTANCE.ensureInstalled();
        try {
            SdkApp.getInstance().initDataBase(context);

            libComponent = DaggerSdkLibComponent.builder()
                    .gsonModule(new GsonModule())
                    .carrotServiceModule(new CarrotServiceModule(context, app_id, isUseEuApi))
                    .contextSdkModule(new ContextSdkModule(context))
                    .dataBaseModule(new DataBaseModule(SdkApp.getInstance()))
                    .notificationHelperModule(new NotificationHelperModule())
                    .build();
        }
        catch (Exception e){
            Log.d(TAG, e.toString());
        }
    }

    private static String getAppIdFromApiKey(String apiKey) {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalArgumentException("API key cannot be null or empty.");
        }

        int separatorIndex = apiKey.indexOf("-");

        if (separatorIndex == -1) {
            throw new IllegalArgumentException("Invalid API key format: No '-' separator found.");
        }

        if (separatorIndex == 0) {
            throw new IllegalArgumentException("Invalid API key format: App ID part is missing.");
        }

        return apiKey.substring(0, separatorIndex);
    }

    private static boolean isValidApiKey(String apiKey) {
        if(apiKey == null) {
            return false;
        }

        if(apiKey.isEmpty()) {
            return false;
        }

        final String API_KEY_PATTERN = "^\\d+-[a-f0-9]{1,30}$";
        return apiKey.matches(API_KEY_PATTERN);
    }

    private static void commonSetup(@NonNull Context context, @NonNull String apiKey, Callback<Boolean> callback, boolean startSession) {
        // Ставим глобальные охранники от крэшей ещё до любой работы SDK — гарантирует,
        // что ошибки в последующей инициализации не уронят хост.
        SdkGlobalHandlers.INSTANCE.ensureInstalled();

        if(!isValidApiKey(apiKey)) {
            String error = "Invalid API key format: " + apiKey;
            if(callback != null) {
                callback.onFailure(new IllegalArgumentException(error));
            } else {
                throw new IllegalArgumentException(error);
            }
        }

        String appId = null;
        try {
            appId = getAppIdFromApiKey(apiKey);
        } catch (IllegalArgumentException e) {
            Log.e(TAG, e);
        }

        api_key = apiKey;
        app_id = appId;

        //TODO: validate input fields
        //service = libComponent.getCarrotService();
        if (service == null) {
            new CarrotSDK(context);
            service = libComponent.getCarrotService();
        }

        //String sUserAgent = UserAgent.Companion.getInstance(context).getUserAgentString(Version.userAgent);
        SharedPreferencesLib.saveString(context, "api_key", apiKey);
        SharedPreferencesLib.saveString(context, "app_id", appId);

        UserStateHolder.INSTANCE.restoreFromPrefs(context);

        //Инициализация Sentry для мониторинга ошибок
        SentryCQ_SDK.init(context);
        if (SdkStateManager.INSTANCE.isInit() || SdkStateManager.INSTANCE.isInitializing()) {
            if (callback != null) callback.onResponse(true);
        } else {
            try {
                service.init(apiKey, callback, startSession);
            } catch (Exception e) {
                Log.e(TAG, "service init error: " + e.toString());
            }
        }


        //Отправляем события о прочтениях рассылок, если такие (неотправленные) есть
        TrackHelperKt.syncPendingDeliveredPushes(context);

        if (networkReconnectDisposable == null || networkReconnectDisposable.isDisposed()) {
            networkReconnectDisposable = Observable.just(1)
                    .take(1)
                    .delay(3, TimeUnit.SECONDS)
                    .subscribe(integer -> NetworkManager.getInstance(context).addObserver(isConnect -> {
                        Log.d(TAG, "setup(...) 5");
                        if (isConnect) {
                            if (!Carrot.isInit() && !SdkStateManager.INSTANCE.isInitializing()) {
                                commonSetup(context, apiKey, callback, startSession);
                            }
                            List<MessageData> errorMessages = GetErrorMessagesUseCaseKt.getAllErrorMessages();
                            if (!errorMessages.isEmpty()) {
                                SendErrorMessagesUseCaseKt.sendErrorMessages(errorMessages);
                            }
                            Log.d(TAG, "setup(...) 6");
                        }
                    }, t -> {
                    }, () -> {
                    }));
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    private static void checkNotificationPermission(Context context){
        int checkRes = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS);
        if(checkRes != PackageManager.PERMISSION_GRANTED && context instanceof Activity) {
            //requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            ActivityCompat.requestPermissions((Activity) context,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    1);
        }
    }

    public static void setUserProperty(String key, String value) {
        SdkGlobalHandlers.safeVoid("setUserProperty", () -> {
            checkInitialization();
            io.carrotquest_sdk.android.lib.models.UserProperty userProperty = new io.carrotquest_sdk.android.lib.models.UserProperty(key, value);
            ArrayList<UserProperty> properties = new ArrayList<>();
            properties.add(userProperty);
            service.setUserProperty(properties);
        });
    }

    public static void setUserProperty(Operation op, String key, String value) {
        SdkGlobalHandlers.safeVoid("setUserProperty(op)", () -> {
            checkInitialization();
            io.carrotquest_sdk.android.lib.models.UserProperty userProperty = new io.carrotquest_sdk.android.lib.models.UserProperty(op.name(), key, value);
            ArrayList<UserProperty> properties = new ArrayList<>();
            properties.add(userProperty);
            service.setUserProperty(properties);
        });
    }

    public static void setUserProperty(io.carrotquest_sdk.android.models.UserProperty userProperty) {
        SdkGlobalHandlers.safeVoid("setUserProperty(obj)", () -> {
            checkInitialization();
            ArrayList<io.carrotquest_sdk.android.lib.models.UserProperty> properties = new ArrayList<>();
            io.carrotquest_sdk.android.lib.models.UserProperty property =
                    new io.carrotquest_sdk.android.lib.models.UserProperty(
                            userProperty.operation,
                            userProperty.getKey(),
                            userProperty.getValue());
            properties.add(property);
            service.setUserProperty(properties, userPropertyObserver);
        });
    }


    public static void setNotificationIcon(int notificationIconId) {
        // Тихий no-op вместо краша: конфигурационный метод, клиент может вызвать его
        // до setup() — пусть запомнится и применится позже самим NotificationHelper,
        // а если DI ещё не готов, просто молча пропускаем.
        SdkLibComponent c = libComponent;
        if (c == null) {
            Log.e(TAG, "setNotificationIcon: SDK not initialized yet, skipped");
            return;
        }
        c.getNotificationHelper().setNotificationIcon(notificationIconId);
    }

    public static void setParentActivityClassName(String parentActivityClassName) {
        parentActivityClassNameImpl = parentActivityClassName;
        SdkLibComponent c = libComponent;
        if (c == null) {
            Log.e(TAG, "setParentActivityClassName: SDK not initialized yet, stored in memory only");
            return;
        }
        SharedPreferencesLib.saveString(c.getContextSdk(), "cq_parent_activity_class_name", parentActivityClassName);
    }

    public static String getParentActivityClassName() {
        if(parentActivityClassNameImpl != null && !parentActivityClassNameImpl.isEmpty()) {
            return parentActivityClassNameImpl;
        }
        SdkLibComponent c = libComponent;
        if (c == null) {
            return null;
        }
        return SharedPreferencesLib.getString(c.getContextSdk(), "cq_parent_activity_class_name");
    }

    public static void setUserProperty(List<io.carrotquest_sdk.android.models.UserProperty> userProperties) {
        SdkGlobalHandlers.safeVoid("setUserProperty(list)", () -> {
            checkInitialization();
            ArrayList<io.carrotquest_sdk.android.lib.models.UserProperty> properties = new ArrayList<>();
            for (io.carrotquest_sdk.android.models.UserProperty userProperty : userProperties) {
                io.carrotquest_sdk.android.lib.models.UserProperty property =
                        new io.carrotquest_sdk.android.lib.models.UserProperty(
                                userProperty.operation,
                                userProperty.getKey(),
                                userProperty.getValue());
                properties.add(property);
            }

            service.setUserProperty(properties, userPropertyObserver);
        });
    }

    public static void auth(String id, String userAuthKey) {
        auth(id, userAuthKey, null);
    }

    public static void auth(String id, String userAuthKey, Callback<String> callback) {
        if (android.text.TextUtils.isEmpty(id) || android.text.TextUtils.isEmpty(userAuthKey)) {
            IllegalArgumentException err = new IllegalArgumentException("auth(): id and userAuthKey must not be empty");
            if (callback != null) callback.onFailure(err);
            else Log.e(TAG, err.toString());
            return;
        }
        checkInitialization();
        if (AuthManager.INSTANCE.isAuthenticating()) return;
        AuthManager.INSTANCE.onAuthenticating();
        service.authUser(id, userAuthKey, new DisposableObserver<>() {
            @Override
            public void onNext(User user) {
                AuthManager.INSTANCE.onAuthenticated(user.getId() != null ? user.getId() : "");
                if (callback != null) callback.onResponse(user.getId());
                if (user != null) {
                    DialogViewModel.Companion.getInstance().updateCurrentConversationId("");
                    DialogViewModel.Companion.getInstance().setNeedStartRoutingBot(false);
                    DialogViewModel.Companion.getInstance().setRoutingBotId("");
                    ClearHistoryUseCaseKt.clearHistory(Observable.just(true)).take(1)
                            .subscribe(v -> {}, t -> Log.e(TAG, "clearHistory failed: " + t));
                }
            }

            @Override
            public void onError(Throwable e) {
                AuthManager.INSTANCE.onFailed(e);
                if (callback != null) callback.onFailure(e);
            }

            @Override
            public void onComplete() {}
        });
    }


    public static void hashedAuth(String id, String hash) {
        hashedAuth(id, hash, null);
    }

    public static void hashedAuth(String id, String hash, Callback<String> callback) {
        if (android.text.TextUtils.isEmpty(id) || android.text.TextUtils.isEmpty(hash)) {
            IllegalArgumentException err = new IllegalArgumentException("hashedAuth(): id and hash must not be empty");
            if (callback != null) callback.onFailure(err);
            else Log.e(TAG, err.toString());
            return;
        }
        checkInitialization();
        if (AuthManager.INSTANCE.isAuthenticating()) return;
        AuthManager.INSTANCE.onAuthenticating();
        service.hashedAuth(id, hash, new DisposableObserver<>() {
            @Override
            public void onNext(User user) {
                AuthManager.INSTANCE.onAuthenticated(user.getId() != null ? user.getId() : "");
                if (callback != null) callback.onResponse(user.getId());
                if (user != null) {
                    DialogViewModel.Companion.getInstance().updateCurrentConversationId("");
                    DialogViewModel.Companion.getInstance().setNeedStartRoutingBot(false);
                    DialogViewModel.Companion.getInstance().setRoutingBotId("");
                    ClearHistoryUseCaseKt.clearHistory(Observable.just(true)).take(1)
                            .subscribe(v -> {}, t -> Log.e(TAG, "clearHistory failed: " + t));
                }
            }

            @Override
            public void onError(Throwable e) {
                AuthManager.INSTANCE.onFailed(e);
                if (callback != null) callback.onFailure(e);
            }

            @Override
            public void onComplete() {}
        });
    }

    public static boolean isInit() {
        if (service != null) {
            return service.isInit();
        }
        return false;
    }

    public static void deInit() {
        SdkGlobalHandlers.safeVoid("deInit", () -> deInitInternal(null));
    }

    private static void deInitInternal(Callback<Boolean> callback) {
        Disposable d = Observable.just(true).observeOn(AndroidSchedulers.mainThread()).take(1).subscribe(aBoolean -> {
            SdkStateManager.INSTANCE.onDeInit();
            AuthManager.INSTANCE.onDeInit();

            DialogViewModel.Companion.getInstance().updateCurrentConversationId("");
            DialogViewModel.Companion.getInstance().setNeedStartRoutingBot(false);
            DialogViewModel.Companion.getInstance().setRoutingBotId("");
            ClearHistoryUseCaseKt.clearHistory(Observable.just(true))
                    .take(1)
                    .subscribe(v -> {}, t -> Log.e(TAG, "clearHistory failed: " + t));

            if (disposableUnreadConversationCallback != null && !disposableUnreadConversationCallback.isDisposed()) {
                disposableUnreadConversationCallback.dispose();
            }
            if (networkReconnectDisposable != null && !networkReconnectDisposable.isDisposed()) {
                networkReconnectDisposable.dispose();
            }
            networkReconnectDisposable = null;

            SaveAuthedUserIdUseCaseKt.saveConnectedUserIdUseCase("", libComponent.getContextSdk());
            SaveAuthedUserIdUseCaseKt.saveAuthedUserIdUseCase("", "", libComponent.getContextSdk());

            if (service != null) {
                service.deInit(() -> {
                    if (callback != null) callback.onResponse(true);
                });
                service = null;
            } else {
                if (callback != null) callback.onResponse(true);
            }



        });
    }

    public static void deInit(Callback<Boolean> callback) {
        try {
            deInitInternal(callback);
        } catch (Exception e) {
            callback.onFailure(e);
        }
    }

    public static void trackEvent(String eventName) {
        SdkGlobalHandlers.safeVoid("trackEvent", () -> {
            checkInitialization();
            service.trackEvent(eventName, null, eventsObserver);
        });
    }

    public static void trackEvent(String eventName, String eventParams) {
        SdkGlobalHandlers.safeVoid("trackEvent(params)", () -> {
            checkInitialization();
            service.trackEvent(eventName, eventParams, eventsObserver);
        });
    }

    public static void trackUtm(String url) {
        SdkGlobalHandlers.safeVoid("trackUtm(url)", () -> {
            if(url == null) {
                return;
            }

            TrackHelperKt.trackUtm(url);

        });
    }

    public static void openChat(Context context) {
        SdkGlobalHandlers.safeVoid("openChat", () -> {
            if (context != null) {
                Intent intent = new Intent(context, io.carrotquest_sdk.android.presentation.container.SdkContainerActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    /**
     * Send push notification to SDK
     * @param remoteMessage Message
     */
    @Deprecated
    public static void sendFirebasePushNotification(RemoteMessage remoteMessage, Context context) {
        SdkGlobalHandlers.safeVoid("sendFirebasePushNotification", () -> {
            if (remoteMessage != null) {
                sendPushNotification(remoteMessage.getData(), context);
            }
        });
    }

    /**
     * Send push notification to SDK
     */
    public static void sendPushNotification(Map<String, String> pushData, Context context) {
        SdkGlobalHandlers.safeVoid("sendPushNotification", () -> {
            if (Carrot.isInit()) {
                if (CarrotInternal.getLibComponent() != null) {
                    CarrotInternal.getLibComponent().getNotificationHelper().postNotification(pushData);
                }
            } else {
                Carrot.setupWithoutConnect(context);
                try {
                    PushNotificationHelper.getInstance().postNotification(pushData);
                } catch (Exception e){
                    Log.e(TAG, new Exception("postNotification(...) error. Result = " + e.toString()));
                }
            }
        });
    }

    /**
     * We recommend using the Carrot.sendPushToken(...)
     */
    @Deprecated
    public static void sendFcmToken(String fcmToken) {
        try {
            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(CarrotInternal.getLibComponent().getContextSdk());
            if(notificationManager.areNotificationsEnabled()) {
                String deviceId = AndroidUtils.getInstallId(CarrotInternal.getLibComponent().getContextSdk());
                String userId = CarrotInternal.getLibComponent().getUserRepository().getUser().getId();
                service.sendPushToken(userId, fcmToken, deviceId);
            }
        } catch (Exception e) {
            Log.e(TAG, e);
        }

    }

    public static void sendPushToken(String token) {
        sendFcmToken(token);
    }

    public static String getVersion() {
        return VERSION;
    }


    public static void setTheme(ThemeSdk theme) {
        mTheme = theme;
    }

    public static ThemeSdk getTheme() {
        return mTheme;
    }

    private static void checkInitialization() {
        if (service == null) {
            String textError = "Carrot is not init. Call setup(contex,apiKey) first.";
            if (isDebug) {
                Log.e(TAG, textError);
            }
            throw new RuntimeException(textError);
        }
    }

    private static void checkInitialization(Callback<Boolean> callback) {
        if (service == null) {
            String textError = "Carrot is not init. Call setup(context, apiKey) first.";
            if (isDebug) {
                Log.e(TAG, textError);
            }
            callback.onFailure(new Exception(textError));
            throw new RuntimeException(textError);
        } else {
            callback.onResponse(true);
        }
    }

    private void reInit() {

    }

    public static void setDebug(boolean value) {
        isDebug = value;
    }

    public static boolean isDebug() {
        return isDebug;
    }


    private static Disposable disposableUnreadConversationCallback;
    private static Disposable networkReconnectDisposable;
    public static void setUnreadConversationsCallback(Callback<List<String>> callback) {
        disposableUnreadConversationCallback = GetConversationsUseCaseKt.getUnreadConversations(GetConversationsUseCaseKt.getConversations(Observable.just(true)))
                .observeOn(AndroidSchedulers.mainThread())
                .map(x->{
                    ArrayList<String> res = new ArrayList<String>();
                    for(DataConversation entity : x) {
                        if(ConversationUtilsKt.recipientTypeIsRight(entity.getRecipientType())
                                && entity.getUnreadPartsCount() > 0 && entity.getId() != null) {
                            res.add(entity.getId());
                        }
                    }
                    return res;
                })
                .subscribe(callback::onResponse);
    }

    public static List<String> getUnreadConversations() throws CarrotException {
        checkInitialization();

        if (CarrotInternal.getLibComponent().getUserRepository() == null) {
            throw new CarrotRepositoryException("User repository is empty");
        }

        if (CarrotInternal.getLibComponent().getUserRepository().getUser() == null) {
            throw new CarrotUserException("User not found");
        }

        ArrayList<DataConversation> convs = ConversationsRepository.Companion.getInstance().getConversationsSync();
        ArrayList<String> res = new ArrayList<>();

        for(DataConversation entity : convs) {
            if(ConversationUtilsKt.recipientTypeIsRight(entity.getRecipientType())
                    && entity.getUnreadPartsCount() > 0 && entity.getId() != null) {
                res.add(entity.getId());
            }
        }

        return res;
    }



    public static String getPushActionUrl(RemoteMessage remoteMessage) {
        return SdkGlobalHandlers.safeCall("getPushActionUrl", null, () -> {
            if (remoteMessage == null) return null;
            Map<String, String> data = remoteMessage.getData();
            if (data == null) return null;
            if (data.containsKey(NotificationsConstants.CQ_SDK_PUSH) && "false".equals(data.get(NotificationsConstants.CQ_SDK_PUSH))) {
                if (data.containsKey(NotificationsConstants.CQ_SDK_PUSH_BODY_JSON)) {
                    String bodyJsonStr = data.get(NotificationsConstants.CQ_SDK_PUSH_BODY_JSON);
                    if (bodyJsonStr == null) {
                        bodyJsonStr = "{}";
                    }
                    JsonElement bodyJsonJson = JsonParser.parseString(bodyJsonStr);
                    if (bodyJsonJson != null && bodyJsonJson.isJsonObject()) {
                        JsonObject bodyJsonJsonObject = bodyJsonJson.getAsJsonObject();
                        if (bodyJsonJsonObject != null
                                && bodyJsonJsonObject.has(NotificationsConstants.CQ_SDK_PUSH_CLICK_ACTION)) {
                            JsonElement action = bodyJsonJsonObject.get(NotificationsConstants.CQ_SDK_PUSH_CLICK_ACTION);
                            if (action != null && action.isJsonPrimitive()) {
                                return action.getAsString();
                            }
                        }
                    }
                }
            }
            return null;
        });
    }

    @Deprecated
    public static boolean isCarrotPush(RemoteMessage remoteMessage) {
        return SdkGlobalHandlers.safeCall("isCarrotPush(rm)", false, () -> {
            if (remoteMessage == null) return false;
            Map<String, String> data = remoteMessage.getData();
            return data != null && data.containsKey(NotificationsConstants.CQ_SDK_PUSH);
        });
    }

    public static boolean isCarrotPush(Map<String, String> pushData) {
        return SdkGlobalHandlers.safeCall("isCarrotPush(map)", false,
                () -> pushData != null && pushData.containsKey(NotificationsConstants.CQ_SDK_PUSH));
    }

    @Deprecated
    public static boolean isAutoMessage(RemoteMessage remoteMessage) {
        return SdkGlobalHandlers.safeCall("isAutoMessage(rm)", false, () -> {
            if (remoteMessage == null) return false;
            Map<String, String> data = remoteMessage.getData();
            return data != null && data.containsKey(NotificationsConstants.CQ_SDK_PUSH) && data.containsKey(NotificationsConstants.CQ_SDK_SENT_VIA)
                && NotificationsConstants.CQ_SDK_AUTO_MESSAGE.equals(data.get(NotificationsConstants.CQ_SDK_SENT_VIA));
        });
    }

    public static boolean isAutoMessage(Map<String, String> pushData) {
        return SdkGlobalHandlers.safeCall("isAutoMessage(map)", false,
                () -> pushData != null && pushData.containsKey(NotificationsConstants.CQ_SDK_PUSH) && pushData.containsKey(NotificationsConstants.CQ_SDK_SENT_VIA)
                        && NotificationsConstants.CQ_SDK_AUTO_MESSAGE.equals(pushData.get(NotificationsConstants.CQ_SDK_SENT_VIA)));
    }

    public static void pushNotificationsUnsubscribe() {
        SdkGlobalHandlers.safeVoid("pushNotificationsUnsubscribe", () -> {
            checkInitialization();
            setUserProperty("$sdk_push_notifications_subscribed", "false");

            String key = SharedPreferenceKeys.SDK_PUSH_NOTIFICATIONS_UNSUBSCRIBED;
            SharedPreferencesLib.saveBoolean(CarrotLib.getLibComponents().getContext(), key, true);
        });
    }

    public static void pushCampaignsUnsubscribe() {
        SdkGlobalHandlers.safeVoid("pushCampaignsUnsubscribe", () -> {
            checkInitialization();
            setUserProperty("$sdk_push_campaigns_subscribed", "false");

            String key = SharedPreferenceKeys.SDK_PUSH_CAMPAIGNS_UNSUBSCRIBED;
            SharedPreferencesLib.saveBoolean(CarrotLib.getLibComponents().getContext(), key, true);
        });
    }


    private static boolean isSimplePushSdk(RemoteMessage remoteMessage) {
        Map<String, String> data = remoteMessage.getData();
        return data != null && data.containsKey(NotificationsConstants.CQ_SDK_PUSH) && "true".equals(data.get(NotificationsConstants.CQ_SDK_PUSH));
    }

    private static boolean isAutoPushSdk(RemoteMessage remoteMessage) {
        Map<String, String> data = remoteMessage.getData();
        return data != null && data.containsKey(NotificationsConstants.CQ_SDK_PUSH) && "false".equals(data.get(NotificationsConstants.CQ_SDK_PUSH));
    }

    public static boolean isUseEuApi() {
        return isUseEuApi;
    }

    public static void  setCloseChatCallback(Callback<Boolean> callback) {
        CarrotInternal.updateCloseChatCallback(callback);
    }

    public static void trackScreen(String screenName) {
        SdkGlobalHandlers.safeVoid("trackScreen", () -> {
            TrackScreenUseCase trackScreenUseCase = new TrackScreenUseCase();
            trackScreenUseCase.call(screenName);
        });
    }
}
