package io.carrotquest_sdk.android.presentation.mvp.notifications;

import androidx.room.EmptyResultSetException;
import android.content.Intent;

import javax.inject.Inject;

import io.carrotquest_sdk.android.application.SdkApp;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.data.db.CarrotSdkDB;
import io.carrotquest_sdk.android.data.db.messages.SendingMessageToBroadcastReceiver;
import io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications.IncomingMessage;
import io.carrotquest_sdk.android.core.util.Log;
import io.reactivex.Single;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class NotificationsAllHelper {
    private static final String TAG = "NotificationsAllHelper";

    @Inject
    CarrotSdkDB db;

    private NotificationsAllHelper() {

    }

    private static NotificationsAllHelper instance;

    public static NotificationsAllHelper getInstance() {

        if (instance == null) {
            instance = new NotificationsAllHelper();
            instance.db = CarrotInternal.getLibComponent().getSdkDataBase();
        }
        return instance;
    }

    /**
     * Принимает на вход идентификатор входящего сообщения
     * Запомниает это сообщение
     * Отправляет событие в BroadcastReceiver
     *
     * @param message входящее сообщения
     */
    public void pushMessage(IncomingMessage message) {
        String messageId = message.getMessageId();
        Disposable d = checkThatMessageNotSending(messageId).subscribe(
                messageNotSending -> {
                    if (messageNotSending) {
                        sendToBroadcastReceiver(message);
                    }
                },
                error -> {
                    if (error instanceof EmptyResultSetException) {
                        sendToBroadcastReceiver(message);
                    } else {
                        Log.e(TAG, error);
                    }
                }
        );
    }

    /**
     * Проверяет не отправлено ли еще уведомление об этом сообщении в BroadcastReceiver
     *
     * @param messageId Идентификатор сообщения
     * @return true - если уведомление об этом сообщении еще не отправлено
     */
    private Single<Boolean> checkThatMessageNotSending(String messageId) {
        SdkApp.getInstance().getDatabase();
        return db.sendingMessageToBroadcastReceiverDao().getById(messageId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .map((SendingMessageToBroadcastReceiver message) -> null == message);
    }

    /**
     * Запоминает, что это сообщение уже отправили и второй раз отправлять его не надо
     *
     * @param messageId Идентификатор сообщения
     */
    private void saveMessage(String messageId) {
        db.sendingMessageToBroadcastReceiverDao().insert(new SendingMessageToBroadcastReceiver(messageId));
    }

    /**
     * Отправляет событие в BroadcastReceiver
     *
     * @param message сообщение
     */
    private void sendToBroadcastReceiver(IncomingMessage message) {
        saveMessage(message.getMessageId());
        Intent intent = new Intent(NotificationsConstants.CQ_SDK_NEW_MESSAGE_ACTION);
        intent.putExtra(NotificationsConstants.CQ_SDK_NEW_MESSAGE_ARG, message);
        CarrotInternal.getLibComponent().getContextSdk().sendBroadcast(intent);
    }
}