package io.carrotquest_sdk.android.data.data_entities.popup

/*
import io.carrotquest_sdk.android.data.db.popup.PopUpDbEntity

fun modelToDbEntity(model: PopUpModel) : PopUpDbEntity {
    return PopUpDbEntity(
            id = model.id,
            bodyJson = model.bodyJson,
            state = model.state
    )
}

fun dbEntityToModel(entity: PopUpDbEntity) : PopUpModel {
    return PopUpModel(
            id = entity.id,
            bodyJson = entity.bodyJson,
            state = entity.state
    )
}*/
