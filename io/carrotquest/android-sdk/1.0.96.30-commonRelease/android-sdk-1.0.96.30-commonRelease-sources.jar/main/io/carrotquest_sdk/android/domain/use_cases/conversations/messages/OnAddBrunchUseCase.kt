package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.reactivex.Observable

fun <T> Observable<T>.onAddBatch() : Observable<String> {
    return Observable.defer {
        return@defer this.flatMap {
            MessagesRepository.getInstance().getAddedBatch()
        }
    }
}
