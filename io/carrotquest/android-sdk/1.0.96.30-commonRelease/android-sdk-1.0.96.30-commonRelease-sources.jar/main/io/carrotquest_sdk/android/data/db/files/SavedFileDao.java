package io.carrotquest_sdk.android.data.db.files;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;


@Dao
public interface SavedFileDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(SavedFile file);

    @Query("SELECT * FROM savedfile WHERE url = :url OR localUri = :url")
    SavedFile getByURL(String url);

    @Query("SELECT * FROM savedfile WHERE url = :url OR localUri = :url")
    List<SavedFile> getAllByURL(String url);

    @Query("SELECT * FROM savedfile")
    List<SavedFile> getAllSavedFiles();

    @Query("DELETE FROM savedfile WHERE url = :urll")
    void delete(String urll);
}
