package io.carrotquest_sdk.android.domain.use_cases.user

import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.data.repositories.UserRepository
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.carrotquest_sdk.android.core.util.Log
import io.reactivex.Observable

fun <T> Observable<T>.getCurrentUser() : Observable<UserEntity> {
    val tag = "Observable.getCurrentUser()"
    return Observable.defer {
        return@defer UserRepository.getInstance().getUser().flatMap { user ->
            return@flatMap if (user != null) {
                Observable.just(user)
            } else {
                SettingsRepository.getInstance().getSettings().flatMap { x ->
                    loadUserById(x.userId)
                        .doOnNext {
                            UserRepository.getInstance().saveUser(it)
                            Log.d(tag, "getCurrentUser from API")
                        }.onErrorReturn {
                            UserEntity(
                                id = "",
                                token = "",
                            )
                        }
                }

            }
        }
    }
}