package io.carrotquest_sdk.android.data.db.messages;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import io.reactivex.Single;


@Dao
public interface ReadMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(ReadMessage message);

    @Query("SELECT * FROM readmessage WHERE id = :idxxx")
    Single<ReadMessage> getById(String idxxx);
}
