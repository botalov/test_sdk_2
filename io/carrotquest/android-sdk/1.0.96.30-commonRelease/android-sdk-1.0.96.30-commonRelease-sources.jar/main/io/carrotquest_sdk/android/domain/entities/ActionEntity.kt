package io.carrotquest_sdk.android.domain.entities

data class ActionEntity(
        val id: String?,
        val messageId: String?,
        val type: String?,
        val body: String?,
        val nextBranchId: String?,
)