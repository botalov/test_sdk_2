package io.carrotquest_sdk.android.presentation.mvp.view_entities.messages

import com.google.gson.JsonElement
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import java.util.ArrayList

data class MessageViewEntity (
        val id: String,
        var created: String,
        var conversation: String,
        var body: String? = null,
        @SerializedName(F.BODY_JSON)
        var bodyJson: JsonElement? = null,
        var metaData: JsonElement? = null,
        var read: Boolean? = null,
        var type: String? = null,
        @SerializedName(F.SENT_VIA)
        var sentVia: String? = null,
        var first: Boolean = false,
        var direction: String? = null,
        var status: String? = null,
        @SerializedName(F.REPLY_TYPE)
        var replyType: String? = null,
        var randomId: String? = null,
        @SerializedName(F.FROM)
        var messageFrom: AdminViewEntity? = null,
        var attachments: ArrayList<AttachmentViewEntity>? = null,
        @SerializedName(F.META_DATA)
        var messageMetaData: MessageMetaDataViewEntity? = null,
        @SerializedName(F.KB_LINK)
        var kbLink: Boolean = false
)