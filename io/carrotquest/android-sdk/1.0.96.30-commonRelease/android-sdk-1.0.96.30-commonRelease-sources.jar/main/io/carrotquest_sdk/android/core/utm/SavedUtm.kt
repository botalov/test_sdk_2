package io.carrotquest_sdk.android.core.utm

import android.content.Context
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys

class SavedUtm private constructor(val context: Context) {
    private var sourceUtm: String? = null
    private var mediumUtm: String? = null
    private var campaignUtm: String? = null
    private var termUtm: String? = null
    private var contentUtm: String? = null

    init {
        sourceUtm = SharedPreferencesLib.getString(context, SharedPreferenceKeys.UTM_SOURCE)
        mediumUtm = SharedPreferencesLib.getString(context, SharedPreferenceKeys.UTM_MEDIUM)
        campaignUtm = SharedPreferencesLib.getString(context, SharedPreferenceKeys.UTM_CAMPAIGN)
        termUtm = SharedPreferencesLib.getString(context, SharedPreferenceKeys.UTM_TERM)
        contentUtm = SharedPreferencesLib.getString(context, SharedPreferenceKeys.UTM_CONTENT)
    }

    companion object {
        private var instance: SavedUtm? = null
        fun getInstance(context: Context): SavedUtm {
            if (instance == null) {
                instance = SavedUtm(context = context)
            }
            return instance!!
        }
    }

    fun hasUtm(): Boolean {
        return !sourceUtm.isNullOrEmpty() ||
                !mediumUtm.isNullOrEmpty() ||
                !campaignUtm.isNullOrEmpty() ||
                !termUtm.isNullOrEmpty() ||
                !contentUtm.isNullOrEmpty()
    }

    fun getUtmSource(): String {
        return sourceUtm ?: ""
    }

    fun getUtmMedium(): String {
        return mediumUtm ?: ""
    }

    fun getUtmCampaign(): String {
        return campaignUtm ?: ""
    }

    fun getUtmTerm(): String {
        return termUtm ?: ""
    }

    fun getUtmContent(): String {
        return contentUtm ?: ""
    }
}