package io.carrotquest_sdk.android.data.network.wss_responses;

public interface IRtsMessage {
    void process();
}
