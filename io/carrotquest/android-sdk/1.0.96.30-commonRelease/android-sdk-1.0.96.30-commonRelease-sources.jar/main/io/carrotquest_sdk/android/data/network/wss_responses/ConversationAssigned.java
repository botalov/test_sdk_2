package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository;
import io.carrotquest_sdk.android.domain.entities.MessageMetaData;

public class ConversationAssigned  implements IRtsMessage {
    @SerializedName(ResponseFields.CONVERSATION)
    public String conversation;

    @SerializedName(ResponseFields.ASSIGNEE)
    public Admin assigne;

    @Override
    public void process() {
        DataConversation conversationE = io.carrotquest_sdk.android.data.repositories.ConversationsRepository.Companion.getInstance().getConversationById(conversation);
        if(conversationE != null) {

            MessageMetaData messageMetaData = null;
            if (conversationE.getPartLast() != null && conversationE.getPartLast().getMessageMetaData() != null) {
                messageMetaData = new MessageMetaData(
                        conversationE.getPartLast().getMessageMetaData().getVote(),
                        conversationE.getPartLast().getMessageMetaData().getComment(),
                        conversationE.getPartLast().getMessageMetaData().getLoading(),
                        conversationE.getPartLast().getMessageMetaData().getReplied(),
                        conversationE.getPartLast().getMessageMetaData().getClosed(),
                        conversationE.getPartLast().getMessageMetaData().getDuration()
                );
            }
            MessageData messageEntity = null;
            if (conversationE.getPartLast() != null) {
                messageEntity = conversationE.getPartLast();
                messageEntity.setFirst(false);
                //todo xx
                //messageEntity.showKb(false);
            }

           ConversationsRepository.Companion.getInstance().assignedConversation(conversationE);
        }
    }
}
