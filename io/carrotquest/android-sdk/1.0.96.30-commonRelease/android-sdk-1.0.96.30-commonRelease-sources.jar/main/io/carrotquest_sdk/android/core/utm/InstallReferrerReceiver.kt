package io.carrotquest_sdk.android.core.utm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import io.carrotquest_sdk.android.core.util.Log

class InstallReferrerReceiver: BroadcastReceiver() {
    private val tag = "REFERRER"
    override fun onReceive(context: Context?, intent: Intent) {
        Log.d(tag, "has referrers: " + intent.hasExtra("referrer").toString())
        val referrer = intent.getStringExtra("referrer")
        if (referrer != null) {
            val utms = UtmUtil.getHashMapParamsFromQuery(referrer)
            UtmUtil.saveUtm(utms, context)
        }
    }
}