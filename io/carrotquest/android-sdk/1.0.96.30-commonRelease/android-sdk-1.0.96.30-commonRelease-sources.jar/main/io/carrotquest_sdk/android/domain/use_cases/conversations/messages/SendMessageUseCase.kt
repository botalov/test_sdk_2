package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import com.google.gson.JsonParser
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.saveErrorMessage
import io.reactivex.Observable
import java.util.Locale

fun Observable<MessageData>.sendMessage() : Observable<MessageData> {
    return Observable.defer {
        return@defer this.flatMap { message ->
            val randomId = ""
            CarrotInternal.getService().carrotLib.reply(message.conversation, message.body, true, randomId)
                    .flatMap {
                        if (it.meta.error == null) {
                            val conversation = ConversationsRepository.getInstance().getConversationById(message.conversation)
                            if (conversation != null) {
                                conversation.partLast = message
                                conversation.lastUpdate = message.created

                                val sourceConversation = conversation.sourceJsonData
                                if (sourceConversation != null) {
                                    sourceConversation.remove(F.PART_LAST)
                                    if(message.sourceJsonData != null) {
                                        val jsonPartLastString: String = message.sourceJsonData.toString()
                                        val jsonPartLast = JsonParser().parse(jsonPartLastString).asJsonObject
                                        sourceConversation.add(F.PART_LAST, jsonPartLast)
                                        conversation.sourceJsonData = sourceConversation
                                    }

                                    if(conversation.partsCount != null && conversation.partsCount >= 0) {
                                        if (sourceConversation.has(F.PARTS_COUNT)) {
                                            sourceConversation.remove(F.PARTS_COUNT)
                                        }
                                        sourceConversation.addProperty(F.PARTS_COUNT, conversation.partsCount.toString())
                                    }

                                    if (sourceConversation.has(F.LAST_UPDATE)) {
                                        sourceConversation.remove(F.LAST_UPDATE)
                                    }
                                    sourceConversation.addProperty(F.LAST_UPDATE, conversation.lastUpdate)
                                }

                                ConversationsRepository.getInstance().updateConversation(message.conversation, conversation)
                            }

                            message.id = it.data.id
                            message.status = MessageStatus.LOADED.name.lowercase(Locale.getDefault())

                            val jsonSource = message.sourceJsonData
                            if (jsonSource.has(F.STATUS)) {
                                jsonSource.remove(F.STATUS)
                            }
                            jsonSource.put(F.STATUS,
                                MessageStatus.LOADED.name.lowercase()
                            )

//                            message.randomId = it.data.id
                            if (jsonSource.has(F.ID)) {
                                jsonSource.remove(F.ID)
                            }
                            jsonSource.put(F.ID, it.data.id)

                            message.sourceJsonData = jsonSource

                            MessagesRepository.getInstance().updateMessage(message)
                            Observable.just(message)
                        } else {
                            Observable.just(onError(message))
                        }
                    }
                    .doOnError {
                        onError(message)
                    }
        }
    }
}

private fun onError(message: MessageData) : MessageData {
    message.status = MessageStatus.WARNING.name.lowercase(Locale.getDefault())
    MessagesRepository.getInstance().updateMessage(message)

    saveErrorMessage(message)

    return message
}