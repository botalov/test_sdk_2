package io.carrotquest_sdk.android.domain.use_cases.user

import io.carrotquest_sdk.android.lib.models.UserProperty
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.reactivex.Observable

fun Observable<String>.setUserProperty(key: String, value: String) : Observable<Boolean> {
    val userProperty = UserProperty("$$key", value)
    return Observable.defer {
        this.flatMap {userId->
            CarrotInternal.getService().carrotLib.setProperty(userId, userProperty)
                    .map {res->
                        return@map res.status == 200
                    }
        }
    }.onErrorReturn {
        false
    }
}