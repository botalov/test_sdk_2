package io.carrotquest_sdk.android.presentation.mvp.utils

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData

fun generateUpdatedParams(message: MessageData) : String {
    val strParams = StringBuilder()
    strParams.append("[{")

    strParams.append("\"")
    strParams.append("status")
    strParams.append("\"")
    strParams.append(":")
    strParams.append("\"")
    strParams.append(message.status)
    strParams.append("\"")

    strParams.append("}, {")

    strParams.append("\"")
    strParams.append("created")
    strParams.append("\"")
    strParams.append(":")
    strParams.append("\"")
    strParams.append(message.created)
    strParams.append("\"")

    if(message.messageMetaData != null) {
        strParams.append("}, {")

        strParams.append("\"")
        strParams.append("vote")
        strParams.append("\"")
        strParams.append(":")
        strParams.append("\"")
        strParams.append(message.messageMetaData?.vote.toString())
        strParams.append("\"")
    }

    strParams.append("}, {")

    strParams.append("\"")
    strParams.append("replied")
    strParams.append("\"")
    strParams.append(":")
    strParams.append(message.messageMetaData?.replied)


    strParams.append("}, {")

    strParams.append("\"")
    strParams.append("loading")
    strParams.append("\"")
    strParams.append(":")
    strParams.append(message.messageMetaData?.loading)

    strParams.append("}, {")

    strParams.append("\"")
    strParams.append("read")
    strParams.append("\"")
    strParams.append(":")
    strParams.append("\"")
    strParams.append(message.read)
    strParams.append("\"")





    strParams.append("}, {")

    strParams.append("\"")
    strParams.append("meta_data");
    strParams.append("\"")
    strParams.append(":")

    strParams.append(" [")

    strParams.append(" {")
    strParams.append("\"")
    strParams.append("answer_body")
    strParams.append("\"")
    strParams.append(":")
    strParams.append("\"")
    strParams.append(message.messageMetaData?.answerBody)
    strParams.append("\"")

    strParams.append("}, {")

    strParams.append("\"")
    strParams.append("answer_action_id")
    strParams.append("\"")
    strParams.append(":")
    strParams.append("\"")
    strParams.append(message.messageMetaData?.answerActionId)
    strParams.append("\"")

    strParams.append(" }")
    strParams.append(" ]")

    strParams.append("}]")

    return strParams.toString()
}