package io.carrotquest_sdk.android.data.data_entities

data class UserModel(
        val id: String
)