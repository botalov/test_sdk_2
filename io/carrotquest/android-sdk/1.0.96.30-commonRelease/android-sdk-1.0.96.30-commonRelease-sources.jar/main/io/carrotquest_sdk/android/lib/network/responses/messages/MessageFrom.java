package io.carrotquest_sdk.android.lib.network.responses.messages;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;
@Keep
public class MessageFrom {
    @SerializedName(F.ID)
    @Expose
    private String id;
    @SerializedName(F.NAME)
    @Expose
    private String name;
    @SerializedName(F.AVATAR)
    @Expose
    private String avatar;
    @SerializedName(F.TYPE)
    @Expose
    private String type;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
