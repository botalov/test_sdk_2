package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import java.util.Date
import java.util.Timer
import java.util.TimerTask

class JwtTokenRefreshService private constructor() {

    companion object {

        private var instance: JwtTokenRefreshService? = null

        fun getInstance(): JwtTokenRefreshService {
            if(instance == null) {
                instance = JwtTokenRefreshService()
            }

            return instance!!
        }
    }

    private val refreshTimer = Timer()
    private var isAlreadyStarted = false

    val updateJwtTokenObservable = BehaviorSubject.create<String>()

    fun start() {
        if (isAlreadyStarted) {
            return
        }
        isAlreadyStarted = true

        val delayMilliseconds = getDelayStartTime()
        Log.d("JWT", "delayMilliseconds = $delayMilliseconds")
        refreshTimer.schedule(object : TimerTask() {
            override fun run() {
                val d = updateJwtTokenObservable
                    .subscribeOn(Schedulers.io())
                    .take(1)
                    .subscribe { token ->
                        val user = CarrotLib.getLibComponents().userRep.user
                        user.token = token
                        CarrotLib.getLibComponents().userRep.saveUser(user)
                    }

                refreshJwtToken(updateJwtTokenObservable)
            }
        }, delayMilliseconds, jwtTokenLiveTime)

    }

    fun stop() {
        refreshTimer.cancel()
        isAlreadyStarted = false
    }

    private fun getDelayStartTime(): Long {
        val nowMilliseconds = Date().time
        val lastUpdateJwtTokenTimeMilliseconds = getLastUpdateJwtTokenTime()

        return if(lastUpdateJwtTokenTimeMilliseconds <= 0 || nowMilliseconds > (lastUpdateJwtTokenTimeMilliseconds + jwtTokenLiveTime)) {
            0L
        } else {
            (lastUpdateJwtTokenTimeMilliseconds + jwtTokenLiveTime) - nowMilliseconds
        }
    }
}