package io.carrotquest_sdk.android.domain.use_cases.user

import android.text.TextUtils
import com.google.gson.JsonObject
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getMessage
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.reactivex.Observable
import org.json.JSONObject
import java.util.*

fun <T> Observable<T>.sendVoteOperator(messageId: String, vote: Int, comment: String) : Observable<Boolean> {
    return Observable.defer {
        this.flatMap {
            if (voteIsWrong(vote)) {
                Observable.just(false)
            }
            val bodyMetaDataObject = JsonObject()
            bodyMetaDataObject.addProperty("vote", vote)
            if (!TextUtils.isEmpty(comment)) {
                bodyMetaDataObject.addProperty("comment", comment)
            }

            return@flatMap CarrotInternal.getService().carrotLib.conversationParts(messageId, bodyMetaDataObject)
                    .flatMap {
                        Observable.just(it.status == 200)
                    }
        }
    }
}

fun <T> Observable<T>.sendVoteOperator(messageId: String, vote: Int) : Observable<Boolean>{
    return sendVoteOperator(messageId, vote, comment = "")
}

fun <T> Observable<T>.wrongVoting(messageId: String) : Observable<Boolean> {
    return Observable.defer {
        this.flatMap {
            this.getMessage(messageId)
                    .take(1)
                    .map {
                        if (it.value == null) {
                            return@map false
                        }

                        val message = it.value
                        message.status = MessageStatus.WARNING.name.lowercase(Locale.getDefault())
                        MessagesRepository.getInstance().updateMessage(message)

                        return@map true
                    }
        }
    }
}

fun <T> Observable<T>.doneVoting(messageId: String, vote: Int) : Observable<Boolean> {
    return Observable.defer {
        this.flatMap {
            this.getMessage(messageId)
                    .take(1)
                    .map {
                        if (it.value == null) {
                            return@map false
                        }

                        val message = it.value
                        message.messageMetaData?.vote = vote

                        val sourceJson = message.sourceJsonData
                        val metaJson = JSONObject()
                        metaJson.put(F.VOTE, vote)
                        if(sourceJson.has(F.META_DATA)) {
                            sourceJson.remove(F.META_DATA)
                        }
                        sourceJson.put(F.META_DATA, metaJson)

                        MessagesRepository.getInstance().updateMessage(message)

                        return@map true
                    }
        }
    }
}

fun <T> Observable<T>.doneVotingComment(messageId: String, vote: Int) : Observable<Boolean> {
    return Observable.defer {
        this.flatMap {
            this.getMessage(messageId)
                    .take(1)
                    .map {
                        if (it.value == null) {
                            return@map false
                        }

                        val message = it.value
                        message.messageMetaData?.vote = vote

                        val sourceJson = message.sourceJsonData
                        val metaJson = JSONObject()
                        metaJson.put(F.VOTE, vote)
                        if(sourceJson.has(F.META_DATA)) {
                            sourceJson.remove(F.META_DATA)
                        }
                        sourceJson.put(F.META_DATA, metaJson)

                        MessagesRepository.getInstance().updateMessage(message)

                        return@map true
                    }
        }
    }
}


private fun voteIsWrong(vote: Int) : Boolean {
    return vote != 1 || vote != 3 || vote != 5
}
