package io.carrotquest_sdk.android.domain.entities

data class Optional<T>(val value: T?)