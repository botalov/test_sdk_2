package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.lib.models.Admin
import io.reactivex.Observable

fun Observable<String>.getCurrentAdmins() : Observable<ArrayList<Admin>> {
    return Observable.defer {
        this.flatMap { conversationId ->
            val admins = ArrayList<Admin>()

            this.getConversation(conversationId)
                    .map { x -> x.value!!.lastAdmin }
                    .map { y ->
                        {
                            val admins = ArrayList<Admin>()
                            admins.add(y)
                            admins

                        }
                    }


            return@flatMap Observable.just(admins)
        }
    }
}