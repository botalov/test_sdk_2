package io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages

import com.google.gson.Gson
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.sendMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.sendMessageWithAttachment
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.json.JSONObject

fun sendErrorMessages(messages: List<MessageData>) {
    val db: CarrotSdkDB = SdkApp.getInstance().database

    messages.forEach { message ->
        message.sourceJsonData = JSONObject(Gson().toJson(message))
        addMessageToConversation(message)

        db.failSendingMessageDao().updateProcessStatus(message.id, 1)

        if (message.attachments != null && message.attachments.isNotEmpty()) {
            val x = Observable.just(message)
                .take(1)
                .sendMessageWithAttachment(message.attachments[0].url)
                .subscribeOn(Schedulers.io())
                .doOnComplete {
                    clearErrorMessage(messageId = message.id)
                    updateMessagesAtConversation(message.conversation)
                }.doOnError {
                    db.failSendingMessageDao().updateProcessStatus(message.id, 0)
                }.subscribe()
        } else {
            val x = Observable.just(message)
                .take(1)
                .sendMessage()
                .subscribeOn(Schedulers.io())
                .doOnComplete {
                    clearErrorMessage(messageId = message.id)
                    updateMessagesAtConversation(message.conversation)
                }.doOnError {
                    db.failSendingMessageDao().updateProcessStatus(message.id, 0)
                }.subscribe()
        }
    }
}

private fun addMessageToConversation(message: MessageData) {
    MessagesRepository.getInstance().addMessage(message)
}

private fun updateMessagesAtConversation(conversationId: String) {
    val c = CarrotLib.getLibComponents().carrotApi
        .getMessages(conversationId)
        .take(1)
        .subscribe {
            val list = ArrayList<MessageData>()
            list.addAll(it.data)
            MessagesRepository.getInstance().addMessages(list)
        }
}