package io.carrotquest_sdk.android.domain.use_cases.rts

import android.content.Context
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

fun saveRtsHost(context: Context, host: String) {
    SharedPreferencesLib.saveString(context, hostRtsKey, host)
}