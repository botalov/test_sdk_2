package io.carrotquest_sdk.android.data.network

import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.data.network.wss_responses.BlockPopUpNet
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.carrotquest_sdk.android.data.network.wss_responses.Row
import java.lang.reflect.Type

class PopUpDeserializer: JsonDeserializer<PopUpMessage> {
    override fun deserialize(json: JsonElement?, typeOfT: Type?, context: JsonDeserializationContext?): PopUpMessage? {
        val jsonObject = json?.asJsonObject
        if (jsonObject != null) {
            if (jsonObject.has(ResponseFields.BLOCKS)) {
                val topArray = jsonObject.get(ResponseFields.BLOCKS).asJsonArray
                if (topArray != null) {
                    val rows = ArrayList<Row>()
                    for (js in topArray) {
                        val rowsArray = js.asJsonArray
                        if (rowsArray != null) {
                            val blocksArray = rowsArray.get(0).asJsonArray
                            val blocks = ArrayList<BlockPopUpNet>()
                            if (blocksArray != null) {
                                for (blockJson in blocksArray) {
                                    val type = if (blockJson.asJsonObject.has(ResponseFields.TYPE)) {
                                        blockJson.asJsonObject.get(ResponseFields.TYPE).asString
                                    } else ""

                                    val image = if (blockJson.asJsonObject.has(ResponseFields.PARAMS)) {
                                        val params = blockJson.asJsonObject.get(ResponseFields.PARAMS).asJsonObject
                                        if (params != null) {
                                            if (params.has(ResponseFields.BACKGROUND_IMAGE)) {
                                                params.get(ResponseFields.BACKGROUND_IMAGE).asString
                                            } else ""
                                        } else ""
                                    } else ""

                                    blocks.add(BlockPopUpNet(type, image))
                                }
                            }

                            rows.add(Row(blocks))
                        }

                    }


                    val expiration = if (jsonObject.has(ResponseFields.EXPIRATION_TIME) && !jsonObject.get(ResponseFields.EXPIRATION_TIME).isJsonNull) {
                        jsonObject.get(ResponseFields.EXPIRATION_TIME).asLong
                    } else {
                        0L
                    }

                    var backColor = ""
                    if(jsonObject.has(ResponseFields.PARAMS)) {
                        val params = jsonObject.get(ResponseFields.PARAMS).asJsonObject
                        if(params.has(ResponseFields.BACKGROUND_COLOR)) {
                            backColor = params.get(ResponseFields.BACKGROUND_COLOR).asString
                        }
                    }

                    return PopUpMessage(
                            jsonObject.get(ResponseFields.ID).asString,
                            json.toString(),
                            rows,
                            expiration,
                            backColor
                    )
                }
            }
        }

        return null
    }
}