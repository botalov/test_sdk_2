package io.carrotquest_sdk.android.lib.network.responses.messages;

import android.util.Log;

import androidx.annotation.Keep;

import com.google.gson.JsonElement;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.json.JSONObject;

import java.util.ArrayList;

import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.network.F;

@Keep
public class MessageData {

    @SerializedName(F.ID)
    @Expose
    private String id = null;
    @SerializedName(F.CREATED)
    @Expose
    private String created = null;
    @SerializedName(F.CONVERSATION)
    @Expose
    private String conversation = null;
    @SerializedName(F.BODY)
    @Expose
    private String body = "";
    @SerializedName(F.BODY_JSON)
    @Expose
    private JsonElement bodyJson = null;
    @SerializedName(F.READ)
    @Expose
    private Boolean read = false;
    @SerializedName(F.TYPE)
    @Expose
    private String type;
    @SerializedName(F.SENT_VIA)
    @Expose
    private String sentVia;
    @SerializedName(F.FIRST)
    @Expose
    private boolean first = false;
    @SerializedName(F.DIRECTION)
    @Expose
    private String direction;
    @SerializedName(F.STATUS)
    private String status;
    @SerializedName(F.REPLY_TYPE)
    private String replyType;

    @SerializedName(F.RANDOM_ID)
    @Expose
    private String randomId;

    @SerializedName(F.FROM)
    private Admin messageFrom;

    @SerializedName(F.ATTACHMENTS)
    private ArrayList<Attachment> attachments;

    @SerializedName(F.META_DATA)
    private MessageMetaData messageMetaData;

    @SerializedName(F.EXPIRATION_TIME)
    private Long expiraionTime;

    @SerializedName(F.ACTIONS)
    private ArrayList<ActionMessage> actions;

    private JSONObject sourceJsonData;

    @SerializedName(F.REMOVED)
    private String removed;

    @SerializedName(F.CONVERSATION_TYPE)
    private String conversationType;

    @SerializedName(F.KB_LINK)
    private Boolean hasKBLink;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getConversation() {
        return conversation;
    }

    public void setConversation(String conversation) {
        this.conversation = conversation;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public Boolean getRead() {
        return read;
    }

    public void setRead(Boolean read) {
        this.read = read;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSentVia() {
        return sentVia;
    }

    public void setSentVia(String sentVia) {
        this.sentVia = sentVia;
    }

    public boolean isFirst() {
        return first;
    }

    public void setFirst(boolean first) {
        this.first = first;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRandomId() {
        return randomId;
    }

    public void setRandomId(String randomId) {
        this.randomId = randomId;
    }

    public Admin getMessageFrom() {
        return messageFrom;
    }

    public void setMessageFrom(Admin messageFrom) {
        this.messageFrom = messageFrom;
    }

    public ArrayList<Attachment> getAttachments() {
        return attachments;
    }

    public void setAttachments(ArrayList<Attachment> attachments) {
        this.attachments = attachments;
    }

    public String getReplyType() {
        return replyType;
    }

    public void setReplyType(String replyType) {
        this.replyType = replyType;
    }

    public MessageMetaData getMessageMetaData() {
        return messageMetaData;
    }

    public void setMessageMetaData(MessageMetaData messageMetaData) {
        this.messageMetaData = messageMetaData;
    }

    public void setBodyJson(JsonElement bodyJson) {
        this.bodyJson = bodyJson;
    }

    public JsonElement getBodyJson() {
        return bodyJson;
    }

    public Long getExpiraionTime() {
        return expiraionTime;
    }

    public void setExpiraionTime(Long expiraionTime) {
        this.expiraionTime = expiraionTime;
    }

    public ArrayList<ActionMessage> getActions() {
        return actions;
    }

    public void setActions(ArrayList<ActionMessage> actions) {
        this.actions = actions;
    }

    public JSONObject getSourceJsonData() {
        return sourceJsonData;
    }

    public void setSourceJsonData(JSONObject sourceJsonData) {
        this.sourceJsonData = sourceJsonData;
    }

    public String getRemoved() {
        return removed;
    }

    public void setRemoved(String removed) {
        this.removed = removed;
    }

    public String getConversationType() {
        return conversationType;
    }

    public void setConversationType(String conversationType) {
        this.conversationType = conversationType;
    }

    public Boolean getHasKBLink() {
        return hasKBLink;
    }

    public void setHasKBLink(Boolean showKbLink) {
        this.hasKBLink = showKbLink;
    }
}
