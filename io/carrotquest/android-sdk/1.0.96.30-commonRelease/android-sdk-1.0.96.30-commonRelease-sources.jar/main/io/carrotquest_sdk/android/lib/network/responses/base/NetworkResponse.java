package io.carrotquest_sdk.android.lib.network.responses.base;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

@Keep
public class NetworkResponse implements IBaseResponse {
    @SerializedName("meta")
    private Meta meta;
    @SerializedName("data")
    private Data data;

    public int getStatus() {
        return meta.getStatus();
    }

    public Data getData() {
        return data;
    }

    public Meta getMeta() {
        return meta;
    }

    @Override
    public void setData(Data data) {
        this.data = data;
    }

    @Override
    public void setMeta(Meta meta) {
        this.meta = meta;
    }

    public NetworkResponse(String error){
        this.meta = new Meta();
        this.meta.setError(error);
    }
    public NetworkResponse(){}
}
