package io.carrotquest_sdk.android.data.data_entities

data class ConversationModel(
        val id: String
)