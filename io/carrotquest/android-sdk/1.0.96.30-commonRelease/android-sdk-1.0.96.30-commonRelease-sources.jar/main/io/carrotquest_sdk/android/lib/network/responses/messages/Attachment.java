package io.carrotquest_sdk.android.lib.network.responses.messages;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;

@Keep
public class Attachment {
    @SerializedName(F.TYPE)
    @Expose
    private String type;
    @SerializedName(F.ID)
    @Expose
    private String id;
    @SerializedName(F.FILENAME)
    @Expose
    private String filename;
    @SerializedName(F.MIME_TYPE)
    @Expose
    private String mimeType;
    @SerializedName(F.SIZE)
    @Expose
    private long size;
    @SerializedName(F.URL)
    @Expose
    private String url;
    @SerializedName(F.CREATED)
    @Expose
    private String created;
    @SerializedName(F.STATUS)
    @Expose
    private String status;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}