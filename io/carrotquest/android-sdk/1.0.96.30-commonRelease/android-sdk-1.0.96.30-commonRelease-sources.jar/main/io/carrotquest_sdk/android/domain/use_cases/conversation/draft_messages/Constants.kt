package io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages

const val DRAFT_MESSAGES_KEY: String = "draft_message_for_"