package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.data.repositories.ConversationsRepository

fun updateOpenedConversationId(conversationId: String) {
    ConversationsRepository.getInstance().saveOpenedConversation(conversationId)
}