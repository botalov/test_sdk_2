package io.carrotquest_sdk.android.presentation.mvp.notifications;

import static io.carrotquest_sdk.android.domain.use_cases.conversations.FindPopUpConversationsUseCaseKt.SHOWED_POPUP_IDS;

import android.Manifest;
import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;

import androidx.core.app.NotificationManagerCompat;
import androidx.room.EmptyResultSetException;
import androidx.room.Room;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import android.text.Html;
import android.text.TextUtils;

import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.vdurmont.emoji.EmojiParser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.inject.Inject;

import io.carrotquest_sdk.android.lib.managers.BackgroundManager;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.utils.AndroidUtils;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;
import io.carrotquest_sdk.android.Carrot;
import io.carrotquest_sdk.android.R;
import io.carrotquest_sdk.android.application.SdkApp;
import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.data.db.CarrotSdkDB;
import io.carrotquest_sdk.android.data.db.PushDB;
import io.carrotquest_sdk.android.data.db.messages.ReadMessage;
import io.carrotquest_sdk.android.data.db.messages.ShowedPush;
import io.carrotquest_sdk.android.data.db.pushes.PushInstanceDb;
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository;
import io.carrotquest_sdk.android.domain.use_cases.user.GetPushUnsubscribeInfoUseCaseKt;
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogActivity;
import io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications.IncomingMessage;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.observers.DisposableSingleObserver;
import io.reactivex.schedulers.Schedulers;
import kotlin.random.Random;

public class PushNotificationHelper {
    private static final String GROUP_KEY_DIALOG = "io.carrotquest.sdk.notify";
    private static PushNotificationHelper instance;
    private static final String TAG = "PushNotificationHelper";

    @Inject
    CarrotSdkDB db;

    public static PushNotificationHelper getInstance() {

        if (instance == null) {
            instance = new PushNotificationHelper();
        }
        return instance;
    }

    private HashMap<String, List<Integer>> displayedNotificationIds;

    private PushNotificationHelper() {
        //CarrotInternal.getLibComponent().inject(this);
        displayedNotificationIds = new HashMap<>();
    }

    private Integer iconId;

    public void setNotificationIcon(Integer iconId) {
        SharedPreferencesLib.saveInt(CarrotInternal.getLibComponent().getContextSdk(), "cq_notification_icon_id", iconId);
        this.iconId = iconId;
    }


    public void postNotification(String messageId, String title, String body,  String conversationId, String sentVia, String conversationType, String linkStr, Boolean isCarrot) {
        SdkApp.getInstance().getDatabase().readMessageDao().getById(messageId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new DisposableSingleObserver<ReadMessage>() {
                    @Override
                    public void onSuccess(ReadMessage v) {
                        if (v == null) {
                            if (conversationId != null && !conversationId.equals(ConversationsRepository.Companion.getInstance().getOpenedConversationId())) {
                                checkAndShowNotify(messageId, title, body, conversationId, linkStr, sentVia, conversationType, isCarrot);
                            }
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        if (e instanceof EmptyResultSetException)
                            if (conversationId != null && !conversationId.equals(ConversationsRepository.Companion.getInstance().getOpenedConversationId())) {
                                checkAndShowNotify(messageId, title, body, conversationId, linkStr, sentVia, conversationType, isCarrot);
                            }
                    }
                });
    }

    private String getDebugData(RemoteMessage remoteMessage) {
        Map<String, String> data = remoteMessage.getData();
        StringBuilder res = new StringBuilder();
        if (data.size() > 0) {
            for (String x : data.keySet()) {
                res.append(x).append(" = ").append(data.get(x)).append("; ");
            }
        }

        return res.toString();
    }

    public void postNotification(Map<String, String> pushData) {
        try {
            if (pushData.size() > 0) {
                try {
                    String messageId = String.valueOf(pushData.get(F.ID));
                    String title = pushData.get(F.TITLE);
                    String text = pushData.get(F.BODY);
                    String conversationId = pushData.get(F.CONVERSATION_ID);
                    String conversationType = pushData.get(F.CONVERSATION_TYPE);
                    String sentVia = pushData.get(F.SENT_VIA);
                    String bodyJson = pushData.get(F.BODY_JSON);
                    boolean isCarrot = Boolean.parseBoolean(pushData.get("is_carrot"));

                    String linkStr = null;
                    Log.i("PUSH_WITH_LINK", "Try get link");
                    Log.i("PUSH_WITH_LINK", "bodyJson = " + bodyJson);
                    if (bodyJson != null) {
                        JsonElement bJo = JsonParser.parseString(bodyJson);
                        if (!bJo.isJsonNull() && bJo.isJsonObject() && (bJo.getAsJsonObject()).has(F.CLICK_ACTION)) {
                            linkStr = (bJo.getAsJsonObject()).get(F.CLICK_ACTION).getAsString();
                        }
                    }

                    IncomingMessage.DirectionMessage directionMessage = IncomingMessage.DirectionMessage.USER_TO_ADMIN;
                    if (ResponseFields.ADMIN_2_USER.equals(pushData.get(F.DIRECTION))) {
                        directionMessage = IncomingMessage.DirectionMessage.ADMIN_TO_USER;
                    }

                    IncomingMessage.MessageType messageType = IncomingMessage.MessageType.TEXT;

                    Room.databaseBuilder(CarrotInternal.getLibComponent().getContextSdk(), PushDB.class, "carrot_pushes_sdk.db")
                            .allowMainThreadQueries().fallbackToDestructiveMigration().build()
                            .showedPushDao().insert(new ShowedPush(String.valueOf(Random.Default.nextInt(200))));

                    IncomingMessage incomingMessage = new IncomingMessage(IncomingMessage.IncomingMessageSourceType.PUSH, messageId, conversationId, text, directionMessage, messageType);
                    NotificationsAllHelper.getInstance().pushMessage(incomingMessage);
                    PushNotificationHelper.getInstance().postNotification(messageId, title, text, conversationId, sentVia, conversationType, linkStr, isCarrot);
                } catch (Exception e) {
                    //Log.e(TAG, e.getMessage());
                }
            }
        }catch (Exception e) {
            Log.i(TAG, e.toString());
        }
    }

    private void checkAndShowNotify(String messageId,
                                    String title,
                                    String body,
                                    String conversationId,
                                    String link,
                                    String sentVia,
                                    String conversationType,
                                    Boolean isCarrot) {

        if(db == null) {
            db = SdkApp.getInstance().getDatabase();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            for (StatusBarNotification statusBarNotification : getStatusBarNotifications()) {
                String convIdN = statusBarNotification.getTag();
                CharSequence channelId = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    channelId = statusBarNotification.getNotification().getChannelId();
                }

                CharSequence titleN = statusBarNotification.getNotification().extras.getCharSequence(Notification.EXTRA_TITLE);
                CharSequence textN = statusBarNotification.getNotification().extras.getCharSequence(Notification.EXTRA_TEXT);

                boolean hasFcmNotification = conversationId != null && conversationId.equals(convIdN)
                        && (titleN != null && titleN.toString().equals(title))
                        && (textN != null && textN.toString().equals(body));

                if (((android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O && channelId == "cq_notification_channel") || channelId == null)
                        && (convIdN == null
                        || convIdN.contains(messageId)
                        || hasFcmNotification)) {
                    return;
                }
            }
        }

        ShowedPush showedPush = PushInstanceDb.Companion.getDb(CarrotInternal.getLibComponent().getContextSdk()).showedPushDao().getById(messageId);
        if (showedPush == null) {
            ActivityManager am = (ActivityManager) CarrotInternal.getLibComponent().getContextSdk().getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningTaskInfo> allTasks = am.getRunningTasks(1);

            if (allTasks == null || allTasks.isEmpty()) {
                PushInstanceDb.Companion.getDb(CarrotInternal.getLibComponent().getContextSdk()).showedPushDao().insert(new ShowedPush(messageId));
                showNotify(messageId, title, body, conversationId, link, sentVia, conversationType, isCarrot);
            } else {
                for (ActivityManager.RunningTaskInfo aTask : allTasks) {
                    ComponentName aTaskComponentName = aTask.topActivity;

                    if (aTaskComponentName != null && aTaskComponentName.getClassName().contains(DialogActivity.class.getName())) {
                        boolean isInBackground = !BackgroundManager.getInstance().lastStateIsForeground();
                        boolean isNotOpenConversation = !(ConversationsRepository.Companion.getInstance().getLastOpenedConversationId().equals(conversationId)
                                || ConversationsRepository.Companion.getInstance().getOpenedConversationId().equals(conversationId));


                        DataConversation conv = ConversationsRepository.Companion.getInstance().getConversationById(conversationId);
                        if(conv != null) {
                            isNotOpenConversation = isNotOpenConversation && !ConversationsRepository.Companion.getInstance().getLastOpenedConversationId().equals(conv.getRandomId());
                        }

                        if (isInBackground || isNotOpenConversation) {
                            PushInstanceDb.Companion.getDb(CarrotInternal.getLibComponent().getContextSdk()).showedPushDao().insert(new ShowedPush(messageId));
                            showNotify(messageId, title, body, conversationId, link, sentVia, conversationType, isCarrot);
                            return;
                        }
                    } else {
                        PushInstanceDb.Companion.getDb(CarrotInternal.getLibComponent().getContextSdk()).showedPushDao().insert(new ShowedPush(messageId));
                        showNotify(messageId, title, body, conversationId, link, sentVia, conversationType, isCarrot);

                        return;
                    }
                }
            }
            db.readMessageDao().insert(new ReadMessage(messageId));
        }
    }

    private PendingIntent getPendingIntentWithSendEvent(Intent intent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                return PendingIntent.getActivity(CarrotInternal.getLibComponent().getContextSdk(), (new java.util.Random()).nextInt(), intent, PendingIntent.FLAG_MUTABLE);
            } else {
                return PendingIntent.getActivity(CarrotInternal.getLibComponent().getContextSdk(), (new java.util.Random()).nextInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT);
            }
        } else {
            return PendingIntent.getActivity(CarrotInternal.getLibComponent().getContextSdk(), (new java.util.Random()).nextInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT);
            //return PendingIntent.getBroadcast(CarrotInternal.getLibComponent().getContextSdk(), (new java.util.Random()).nextInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT);
        }
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            return PendingIntent.getBroadcast(CarrotInternal.getLibComponent().getContextSdk(), (new java.util.Random()).nextInt(), intent, PendingIntent.FLAG_MUTABLE);
//        } else {
//            return PendingIntent.getBroadcast(CarrotInternal.getLibComponent().getContextSdk(), (new java.util.Random()).nextInt(), intent, PendingIntent.FLAG_UPDATE_CURRENT);
//        }
//        TaskStackBuilder stackBuilder = TaskStackBuilder.create(CarrotInternal.getLibComponent().getContextSdk());
//        stackBuilder.addNextIntent(intent);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            Log.e("xxx", "3");
//            return stackBuilder.getPendingIntent( (new java.util.Random()).nextInt(),
//                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
//        } else {
//            Log.e("xxx", "4");
//            return stackBuilder.getPendingIntent( (new java.util.Random()).nextInt(),
//                    PendingIntent.FLAG_UPDATE_CURRENT);
//        }
    }

    private void showNotify(String messageId,
                            String title,
                            String body,
                            String conversationId,
                            String link,
                            String sentVia,
                            String conversationType,
                            Boolean isCarrot) {
        Set<String> exitedSet = SharedPreferencesLib.getStringSet(CarrotInternal.getLibComponent().getContextSdk(), SHOWED_POPUP_IDS);
        if (exitedSet != null
                && !exitedSet.isEmpty()
                && exitedSet.contains(conversationId)) {
            return;
        }

        NotificationManagerCompat notificationManagerX = NotificationManagerCompat.from(CarrotInternal.getLibComponent().getContextSdk());
        if(!notificationManagerX.areNotificationsEnabled()) {
            return;
        }


        Intent resultIntent = null;
        PendingIntent resultPendingIntent = null;
        //Если ссылка в пуше не NULL, то при тапе нужно открыть эту ссылку
        if (link != null && !link.isEmpty()) {
            Log.i("PUSH_WITH_LINK", "link is exists");

            // Если это автосообщение то нужно обрабатывать через бродкаст чтобы записать событие в статистику
            if ("message_auto".equalsIgnoreCase(sentVia) || "message_manual".equalsIgnoreCase(sentVia) || isCarrot == null || !isCarrot) {
                Log.i("PUSH_WITH_LINK", "start create intent to TapActivity");

                Intent intent;
                intent = new Intent(CarrotInternal.getLibComponent().getContextSdk(), PushTapActivity.class);
                intent.putExtra(PushTapReceiver.linkExtraKey, link);
                intent.putExtra(PushTapReceiver.conversationIdExtraKey, conversationId);
                intent.putExtra(PushTapReceiver.conversationTypeExtraKey, conversationType);
                intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                resultPendingIntent = getPendingIntentWithSendEvent(intent);
            } else {
                resultIntent = new Intent(Intent.ACTION_VIEW);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    resultIntent.addFlags(Intent.FLAG_ACTIVITY_FORWARD_RESULT);
                }
                resultIntent.setData(Uri.parse(link));
            }
        } else {
            if ("message_auto".equalsIgnoreCase(sentVia) || "message_manual".equalsIgnoreCase(sentVia)) {
                if ((isCarrot == null || isCarrot) && conversationId != null && !conversationId.isEmpty()) {
                    resultIntent = openDialogById(conversationId);
                } else {  //Если это автосообщение, то при тапе нужно просто открывать приложение и это не "Чат в SDK"
                    Intent intent;
                    //if(android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    intent = new Intent(CarrotInternal.getLibComponent().getContextSdk(), PushTapActivity.class);
//                    } else {
                    //intent = new Intent();
                    //intent.setAction("carrotquest.sdk.tap.push");
//                    }
                    intent.putExtra(PushTapReceiver.conversationIdExtraKey, conversationId);
                    intent.putExtra(PushTapReceiver.conversationTypeExtraKey, conversationType);
                    intent.addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    resultPendingIntent = getPendingIntentWithSendEvent(intent);
                }
            } else {
                resultIntent = openDialogById(conversationId);
            }
        }

        // Create the PendingIntent
        int notifyId = (int) (System.currentTimeMillis() / 1000);

        if (resultPendingIntent == null && resultIntent != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                resultPendingIntent = PendingIntent.getActivity(
                        CarrotInternal.getLibComponent().getContextSdk(), notifyId, resultIntent, PendingIntent.FLAG_MUTABLE
                );
            } else {
                resultPendingIntent = PendingIntent.getActivity(
                        CarrotInternal.getLibComponent().getContextSdk(), notifyId, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT
                );
            }
        }

        int savedIcon = SharedPreferencesLib.getInt(CarrotInternal.getLibComponent().getContextSdk(), "cq_notification_icon_id");
        if (savedIcon > 0) {
            iconId = savedIcon;
        } else {
            if (iconId == null) {
                iconId = R.drawable.ic_cq_notification;
            } else {
                String iconResourceName = CarrotInternal.getLibComponent().getContextSdk().getResources().getResourceName(iconId);
                if (iconResourceName == null) {
                    iconId = R.drawable.ic_cq_notification;
                }
            }
        }

        initChannels();
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(
                CarrotInternal.getLibComponent().getContextSdk(),
                "cq_notifications_channel");

        int priority;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            priority = NotificationManager.IMPORTANCE_DEFAULT;
        } else {
            priority = Notification.PRIORITY_DEFAULT;
        }

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//            body = Html.fromHtml(body, Html.FROM_HTML_MODE_LEGACY).toString();
//        } else {
//            body = Html.fromHtml(body).toString();
//        }
//
//        body = body.replace((char) 160, (char) 32).replace((char) 65532, (char) 32).trim();
        body = EmojiParser.parseToUnicode(body);
        if (TextUtils.isEmpty(body)) {
            body = "...";
        }

        Notification group = new NotificationCompat.Builder(CarrotInternal.getLibComponent().getContextSdk(), "cq_notifications_channel")
                .setLargeIcon(BitmapFactory.decodeResource(CarrotInternal.getLibComponent().getContextSdk().getResources(), iconId))
                .setSmallIcon(iconId)
                .setColor(ContextCompat.getColor(CarrotInternal.getLibComponent().getContextSdk(), R.color.colorCqNotify))
                .setContentTitle(title)
                .setContentText(body)
                .setColor(ContextCompat.getColor(CarrotInternal.getLibComponent().getContextSdk(), R.color.colorCqNotify))
                .setGroupSummary(true)
                .setPriority(priority)
                .setGroup(String.valueOf(conversationId))
                .setContentIntent(resultPendingIntent)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .build();

        Notification notification = new NotificationCompat.Builder(CarrotInternal.getLibComponent().getContextSdk(), "cq_notifications_channel")
                .setLargeIcon(BitmapFactory.decodeResource(CarrotInternal.getLibComponent().getContextSdk().getResources(), iconId))
                .setSmallIcon(iconId)
                .setColor(ContextCompat.getColor(CarrotInternal.getLibComponent().getContextSdk(), R.color.colorCqNotify))
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(priority)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setGroup(String.valueOf(conversationId))
                .setContentIntent(resultPendingIntent)
                .setAutoCancel(true)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .build();


        if (resultPendingIntent != null) {
            notificationBuilder.setContentIntent(resultPendingIntent);
        }
        List<Integer> notifyIds = displayedNotificationIds.get(conversationId);
        if (notifyIds == null) {
            notifyIds = new ArrayList<>();
        }
        notifyIds.add(notifyId);
        displayedNotificationIds.put(conversationId, notifyIds);


        Log.i("PUSH_WITH_LINK", "show notify");

        notificationManagerX.notify(Integer.parseInt(conversationId.substring(conversationId.length() - 9, conversationId.length() - 1)), group);
        notificationManagerX.notify(conversationId + "_" + messageId + "_"+ conversationType, notifyId, notification);

        //Если это автосообщение, то надо отправить событие о том, что сообщение прочитано
        if ("sdk_push".equalsIgnoreCase(conversationType)
                && ("message_auto".equalsIgnoreCase(sentVia) || "message_manual".equalsIgnoreCase(sentVia))) {

            //Если версия Android >= 13, то надо еще проверить на то,
            // что есть разрешение на показ пушей перед тем как отправлять событие о том, что сообщение прочитано
            boolean notificationPermissionIsGranted = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                notificationPermissionIsGranted = ContextCompat.checkSelfPermission(CarrotInternal.getLibComponent().getContextSdk(), Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            }

            if(notificationPermissionIsGranted) {
                Log.i("PUSH_WITH_LINK", "sendEventAboutAutoPushSDK()");
                sendEventAboutAutoPushSDK(conversationId);
            }
        }
    }

    private Intent openDialogById(String conversationId) {
        Intent resultIntent = new Intent(CarrotInternal.getLibComponent().getContextSdk(), DialogActivity.class);

        resultIntent.putExtra(DialogActivity.CONVERSATION_ID_ARG, conversationId);
        resultIntent.putExtra(DialogActivity.STARTED_FROM_NOT_ARG, true);
//        resultIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
//                | Intent.FLAG_ACTIVITY_NEW_TASK);
        resultIntent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);

        return resultIntent;
    }

    private void sendEventAboutAutoPushSDK(String conversationId) {
        Carrot.setupWithoutConnect(CarrotInternal.getLibComponent().getContextSdk());
        CarrotInternal.getService().markConversationAsRead(conversationId, new DisposableObserver<NetworkResponse>() {
            @Override
            public void onNext(@NonNull NetworkResponse networkResponse) {

            }

            @Override
            public void onError(@NonNull Throwable e) {
                Log.e(TAG, e);
            }

            @Override
            public void onComplete() {

            }
        });

//        Carrot.setupWithoutStartSession(CarrotInternal.getLibComponent().getContextSdk(), CarrotSDK.getApiKey(), CarrotSDK.getAppId(), new CarrotSDK.Callback<Boolean>() {
//            @Override
//            public void onResponse(Boolean result) {
//                if (result) {
//                    CarrotInternal.getService().markConversationAsRead(conversationId, new DisposableObserver<NetworkResponse>() {
//                        @Override
//                        public void onNext(@NonNull NetworkResponse networkResponse) {
//
//                        }
//
//                        @Override
//                        public void onError(@NonNull Throwable e) {
//                            Log.e(TAG, e);
//                        }
//
//                        @Override
//                        public void onComplete() {
//
//                        }
//                    });
//                }
//            }
//
//            @Override
//            public void onFailure(Throwable t) {
//                Log.e(TAG, t);
//            }
//        });
    }

    private void initChannels() {
        if (Build.VERSION.SDK_INT < 26) {
            return;
        }

        NotificationManager notificationManager = (NotificationManager) CarrotInternal.getLibComponent().getContextSdk().getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel("cq_notifications_channel",
                "Чаты",
                NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Уведомления чатов");

        notificationManager.createNotificationChannel(channel);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private StatusBarNotification[] getStatusBarNotifications() {
        NotificationManager notificationManager = (NotificationManager) CarrotInternal.getLibComponent().getContextSdk().getSystemService(Context.NOTIFICATION_SERVICE);
        return notificationManager.getActiveNotifications();
    }

//    public void clearNotifications(String conversationId) {
//        if (conversationId != null) {
//            NotificationManager notificationManager = (NotificationManager) CarrotInternal.getLibComponent().getContextSdk().getSystemService(Context.NOTIFICATION_SERVICE);
//            List<Integer> notifyIds = displayedNotificationIds.get(conversationId);
//            displayedNotificationIds.remove(conversationId);
//
//            try {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                    for (StatusBarNotification notification : notificationManager.getActiveNotifications()) {
//                        if (notification != null && notification.getTag() != null && notification.getTag().contains(conversationId)) {
//                            notificationManager.cancel(notification.getTag(), notification.getId());
//                        }
//                    }
//                } else {
//                    if (notifyIds != null) {
//                        for (Integer id : notifyIds) {
//                            notificationManager.cancel(id);
//                        }
//                    }
//                }
//            } catch (Exception e) {
//                Log.e("", "");
//            }
//        }
//    }

    public void clearNotifications(String dialogId) {
        if (dialogId != null && displayedNotificationIds != null) {
            NotificationManager notificationManager = (NotificationManager) CarrotInternal.getLibComponent().getContextSdk().getSystemService(Context.NOTIFICATION_SERVICE);
            if (notificationManager != null) {
                //Remove RTS notifications
                List<Integer> notifyIds = displayedNotificationIds.get(dialogId);
                if (notifyIds != null) {
                    displayedNotificationIds.remove(dialogId);
                    for (Integer id : notifyIds) {
                        if (id != null) {
                            notificationManager.cancel(id);
                        }
                    }
                }

                try {
                    if(!dialogId.isEmpty()) {
                        int x = dialogId.length() >= 9 ? Integer.parseInt(dialogId.substring(dialogId.length() - 9, dialogId.length() - 1))
                                : Integer.parseInt(dialogId);
                        notificationManager.cancel(x);
                    }
                } catch (Exception e) {
                    Log.e(TAG, e.toString());
                }
                //Remove firebase background notifications
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    try {
                        StatusBarNotification[] barNotifications = notificationManager.getActiveNotifications();
                        for (StatusBarNotification notification : barNotifications) {
                            if (notification.getPackageName().equalsIgnoreCase("carrotquest.mobil.inkov.carrotquest") && notification.getTag().contains(dialogId)) {
                                try {
                                    notificationManager.cancel(notification.getTag(), notification.getId());
                                } catch (Exception e) {
                                    Log.e(TAG, e.toString());
                                }
                            }
                        }
                    } catch (NullPointerException npe) {
                        Log.e(TAG, npe.toString());
                    }
                }
            }
        }
    }

    public void clearNotificationsByConversationType(String conversationType) {
        if (conversationType != null) {
            NotificationManager notificationManager = (NotificationManager) CarrotInternal.getLibComponent().getContextSdk().getSystemService(Context.NOTIFICATION_SERVICE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                for (StatusBarNotification notification : notificationManager.getActiveNotifications()) {
                    if (notification != null && notification.getTag() != null && notification.getTag().contains(conversationType)) {
                        notificationManager.cancel(notification.getTag(), notification.getId());
                    }
                }
            }

        }
    }
}