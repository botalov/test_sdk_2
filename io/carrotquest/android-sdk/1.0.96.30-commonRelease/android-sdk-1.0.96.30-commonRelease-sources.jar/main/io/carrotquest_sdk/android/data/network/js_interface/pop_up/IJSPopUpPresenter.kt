package io.carrotquest_sdk.android.data.network.js_interface.pop_up

interface IJSPopUpPresenter {
    fun popUpIsReady(width: Int, height: Int)
    fun close()
    fun openLink(url: String)
    fun trackEvent(eventName: String)
    fun setUserProperty(props: String)
    fun setTopOffsetCurrentInputBar(topOffset: Int)
}