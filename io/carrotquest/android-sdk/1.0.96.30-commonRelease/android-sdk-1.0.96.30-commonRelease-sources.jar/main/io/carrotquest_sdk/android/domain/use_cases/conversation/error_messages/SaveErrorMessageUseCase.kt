package io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.messages.FailSendingMessage
import io.carrotquest_sdk.android.data.repositories.MessagesRepository

fun saveErrorMessage(message: MessageData, attachPath: String? = null) {
    val db: CarrotSdkDB = SdkApp.getInstance().database

    val failMessage = FailSendingMessage(message.id)
    failMessage.conversationId = message.conversation
    failMessage.body = message.body
    failMessage.messageFrom = message.messageFrom.id
    failMessage.created = message.created
    failMessage.attachPath = attachPath
    val bodyJson = message.bodyJson
    if(bodyJson != null) {
        failMessage.bodyJson = bodyJson.toString()
    }
    failMessage.direction = message.direction
    failMessage.first = message.isFirst
    failMessage.randomId = message.randomId
    failMessage.read = message.read
    failMessage.replyType = message.replyType
    failMessage.sentVia = message.sentVia
    failMessage.status = message.status
    failMessage.type = message.type

    failMessage.inSendingProcess = false

    db.failSendingMessageDao().insert(failMessage)

    MessagesRepository.getInstance().removeMessage(failMessage.id)
}