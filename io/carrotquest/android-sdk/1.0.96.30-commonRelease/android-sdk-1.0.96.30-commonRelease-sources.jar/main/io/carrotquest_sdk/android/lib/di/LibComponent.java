package io.carrotquest_sdk.android.lib.di;

import android.content.Context;
import io.carrotquest_sdk.android.lib.CarrotApi;
import io.carrotquest_sdk.android.lib.di.ApiModule;
import io.carrotquest_sdk.android.lib.di.ContextModule;
import io.carrotquest_sdk.android.lib.di.GsonModule;
import io.carrotquest_sdk.android.lib.di.RepositoryModule;
import io.carrotquest_sdk.android.lib.di.WssServiceModule;
import io.carrotquest_sdk.android.lib.repositories.IUserRepository;
import io.carrotquest_sdk.android.lib.wss.WssService;
import com.google.gson.Gson;
import dagger.Component;

import javax.inject.Singleton;

@Singleton
@Component(modules = {ContextModule.class, GsonModule.class, RepositoryModule.class, io.carrotquest_sdk.android.lib.di.ApiModule.class, WssServiceModule.class})
public interface LibComponent {
    CarrotApi getCarrotApi();
    Context getContext();
    Gson getGson();
    IUserRepository getUserRep();
    WssService getWssService();

    void inject(ApiModule apiModule);
    void inject(RepositoryModule repositoryModule);

}