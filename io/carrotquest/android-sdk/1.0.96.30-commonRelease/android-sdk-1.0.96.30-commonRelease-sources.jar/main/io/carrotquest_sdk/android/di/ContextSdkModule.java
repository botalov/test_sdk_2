package io.carrotquest_sdk.android.di;

import android.content.Context;
import dagger.Module;
import dagger.Provides;

import javax.inject.Singleton;

@Module
public class ContextSdkModule {
    private Context mContext;

    public ContextSdkModule(Context context) {
        mContext = context;
    }

    @Provides
    @Singleton
    public Context provideContextSdk() {
        return mContext;
    }
}
