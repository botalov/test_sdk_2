package io.carrotquest_sdk.android.lib.wss;

import io.carrotquest_sdk.android.lib.managers.network.NetworkManager;
import io.carrotquest_sdk.android.lib.wss.response.WssResponse;
import io.reactivex.Observer;

import java.util.List;

public interface IWssService {

    void startSocket(String appId, List<Channel> channels, List<Observer<WssResponse>> observers);
    void stopSocket(String appId);
    void deInit();
    //NetworkManager getNetworkManager();
}
