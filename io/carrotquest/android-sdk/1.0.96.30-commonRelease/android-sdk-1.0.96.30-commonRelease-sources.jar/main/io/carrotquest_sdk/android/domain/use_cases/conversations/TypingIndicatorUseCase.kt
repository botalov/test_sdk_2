package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.reactivex.BackpressureStrategy
import io.reactivex.Flowable
import io.reactivex.Observable
import io.reactivex.disposables.Disposable
import java.util.concurrent.TimeUnit

private var endTypingDisposable: Disposable? = null

fun <T> Observable<T>.adminTypingEvent(conversationId: String) : Flowable<Boolean> {
    val tag = "Observable.adminTypingEvent()"
    return Flowable.defer {
        return@defer this
            .toFlowable(BackpressureStrategy.DROP)
            .flatMap {

                var itConversation = false
                CarrotInternal.getLibComponent().carrotService.adminTypingObservable()
                    .doOnNext { message ->
                        val typingConversationId = message.conversation
                        val typingAdmin = message.messageFrom
                        if (conversationId == typingConversationId) {
                            itConversation = true
                            MessagesRepository.getInstance().addMessageTyping(message)

                            if (endTypingDisposable != null) {
                                endTypingDisposable?.dispose()
                            }

                            endTypingDisposable = Observable.just(true)
                                .delay(message.duration.toLong(), TimeUnit.SECONDS)
                                .take(1)
                                .doOnComplete {
                                    MessagesRepository.getInstance().removeMessageTyping()
                                }
                                .subscribe()
                        } else {
                            itConversation = false
                        }
                    }
                    .doOnComplete {
                        Log.i("TEST_TYPING", "onComplete")
                        Log.d(tag, "onComplete")
                    }
                    .doOnTerminate {
                        Log.i("TEST_TYPING", "onTerminate")
                        Log.d(tag, "onTerminate")
                    }
                    .map { itConversation }
                    .toFlowable(BackpressureStrategy.DROP)
                    .publish()
                    .refCount()
            }
    }
}