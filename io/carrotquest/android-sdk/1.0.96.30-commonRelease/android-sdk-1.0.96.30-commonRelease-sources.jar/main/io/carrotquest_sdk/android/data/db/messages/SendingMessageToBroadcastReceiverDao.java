package io.carrotquest_sdk.android.data.db.messages;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import io.reactivex.Single;


@Dao
public interface SendingMessageToBroadcastReceiverDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(SendingMessageToBroadcastReceiver message);

    @Query("SELECT * FROM SendingMessageToBroadcastReceiver WHERE id = :idxxx")
    Single<SendingMessageToBroadcastReceiver> getById(String idxxx);
}
