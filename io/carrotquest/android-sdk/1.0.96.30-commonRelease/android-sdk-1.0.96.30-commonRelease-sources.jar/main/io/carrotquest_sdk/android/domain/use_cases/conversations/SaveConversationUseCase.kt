package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.entities.Optional
import io.reactivex.Observable

fun Observable<Optional<DataConversation>>.saveConversationSafety() : Observable<Optional<DataConversation>> {
    return Observable.defer {
        return@defer this.flatMap {
            if (it.value != null) {
                ConversationsRepository.getInstance().addConversation(it.value)
            }
            return@flatMap Observable.just(it)
        }
    }
}

fun Observable<DataConversation>.saveConversation() : Observable<DataConversation> {
    return Observable.defer {
        return@defer this.flatMap {
            ConversationsRepository.getInstance().addConversation(it)
            return@flatMap Observable.just(it)
        }
    }
}