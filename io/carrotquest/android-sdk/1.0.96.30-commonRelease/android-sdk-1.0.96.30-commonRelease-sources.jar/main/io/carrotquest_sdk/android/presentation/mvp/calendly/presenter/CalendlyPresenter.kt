package io.carrotquest_sdk.android.presentation.mvp.calendly.presenter

import io.carrotquest_sdk.android.presentation.mvp.base.BasePresenter
import io.carrotquest_sdk.android.presentation.mvp.calendly.view.ICalendlyView
import org.json.JSONObject

class CalendlyPresenter: BasePresenter() {

    fun onCreate() {
        getView()?.initWebView()
    }

    override fun getView(): ICalendlyView? {
        return if (super.getView() != null && super.getView() is ICalendlyView) {
            super.getView() as ICalendlyView
        } else {
            null
        }
    }

    fun onLoaded(joinUrl: String, signature: String) {
        val json = JSONObject()
        json.put("url", joinUrl)
        //json.put("url", "ya.ru")
        if(signature.isNotEmpty()) {
            val utmJson = JSONObject()
            utmJson.put("utmContent", signature)
            json.put("utm", utmJson)
        }
        getView()?.hideLoader()
        getView()?.showWidget(json.toString())
    }

    fun onLoadedError() {
        getView()?.hideLoader()
        getView()?.showError()
    }

    fun onTapCloseButton() {
        getView()?.close()
    }

}