package io.carrotquest_sdk.android.data.db.files;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.annotation.NonNull;


@Entity
public class SavedFile {
    @NonNull
    @PrimaryKey
    public String id;
    @NonNull
    public String localUri;
    @NonNull
    public String url;

    public SavedFile(@NonNull String id) {
        this.id = id;
    }
}
