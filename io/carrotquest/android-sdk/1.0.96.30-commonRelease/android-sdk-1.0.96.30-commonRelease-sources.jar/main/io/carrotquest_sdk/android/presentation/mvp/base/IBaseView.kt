package io.carrotquest_sdk.android.presentation.mvp.base

interface IBaseView {
}