package io.carrotquest_sdk.android.domain.entities.triggers

data class TriggerEntity(
    val id: String,
    val kind: Int,
    val url: String,
    val comparison: TriggerComparison,
)
