package io.carrotquest_sdk.android.lib.wss.response;

import android.util.Log;
import com.google.gson.JsonElement;

import io.carrotquest_sdk.android.lib.network.F;


public class WssResponse {
    private String id;
    private String channel;
    private JsonElement message;
    private String tag;
    private String time;

    public String getId() {
        return id;
    }

    public String getChannel() {
        return channel;
    }

    private void setChannel(String channel) {
        this.channel = channel;
    }

    public JsonElement getMessage() {
        return message;
    }

    public String getTag() {
        return tag;
    }

    private void setTag(String tag) {
        this.tag = tag;
    }

    public String getTime() {
        return time;
    }

    private void setTime(String time) {
        this.time = time;
    }

    private void setMessage(JsonElement message) {
        this.message = message;
    }

    private void setId(String id) {
        this.id = id;
    }

    public static WssResponse fromJson(JsonElement element) {
        WssResponse response = new WssResponse();
        try {
            if(!element.getAsJsonObject().has(F.ID)) {
                throw new Exception("ID is null");
            }
            response.setId(element.getAsJsonObject().get(F.ID).getAsString());

            if(!element.getAsJsonObject().has(F.CHANNEL)) {
                throw new Exception("CHANNEL is null");
            }
            response.setChannel(element.getAsJsonObject().get(F.CHANNEL).getAsString());

            if(!element.getAsJsonObject().has(F.TAG)) {
                throw new Exception("TAG is null");
            }
            response.setTag(element.getAsJsonObject().get(F.TAG).getAsString());

            if(!element.getAsJsonObject().has(F.TIME)) {
                throw new Exception("TIME is null");
            }
            response.setTime(element.getAsJsonObject().get(F.TIME).getAsString());

            if(!element.getAsJsonObject().has(F.MESSAGE)) {
                throw new Exception("TIME is null");
            }
            response.setMessage(element.getAsJsonObject().get(F.MESSAGE).getAsJsonObject());
        }
        catch (Exception e) {
            Log.e("WssResponse", e.toString());
            response = new WssResponse();
        }
        return response;
    }
}
