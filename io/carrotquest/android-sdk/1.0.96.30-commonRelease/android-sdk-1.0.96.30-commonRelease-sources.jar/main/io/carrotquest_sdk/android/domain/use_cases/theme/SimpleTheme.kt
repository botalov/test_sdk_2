package io.carrotquest_sdk.android.domain.use_cases.theme

enum class SimpleTheme {
    DEFAULT,
    DARK,
}