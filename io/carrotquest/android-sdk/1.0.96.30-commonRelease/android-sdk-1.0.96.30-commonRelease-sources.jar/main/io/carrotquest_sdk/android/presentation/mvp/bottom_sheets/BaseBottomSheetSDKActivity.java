package io.carrotquest_sdk.android.presentation.mvp.bottom_sheets;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import io.carrotquest_sdk.android.R;
import io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.presenters.ControlMessagePresenter;

public abstract class BaseBottomSheetSDKActivity extends AppCompatActivity {

    public static final String COLOR_ARG = "color_arg";
    public static final String MESSAGE_ID_ARG = "message_id_arg";

    private int mColor;
    protected String mMessageId;
    protected BottomSheetBehavior bottomSheetBehavior;
    protected ControlMessagePresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_up);
        super.onCreate(savedInstanceState);
        setStatusBarColor(false);

        setContentView(R.layout.activity_bottom_sheet_base_sdk);

        baseInit();

        presenter = new ControlMessagePresenter((Context)this);
        presenter.attachView(this);
    }

    @Override
    public void finish(){
        presenter.detachView();
        setStatusBarColor(false);
        super.finish();
        overridePendingTransition(R.anim.slide_in_down, R.anim.slide_out_down);
    }

    private void baseInit() {
        Intent intent = getIntent();
        mColor = 0;
        mMessageId = "";
        if(intent !=null) {
            mColor = intent.getIntExtra(COLOR_ARG, getResources().getColor(R.color.colorPrimaryDarkImpl));
            mMessageId = intent.getStringExtra(MESSAGE_ID_ARG);
        }

        View touchOutside = findViewById(R.id.touch_outside);
        if (touchOutside != null) {
            touchOutside.setOnClickListener(v -> finish());
        }

        RelativeLayout llBottomSheetContainer = findViewById(R.id.ll_bottom_sheet_content_container);
        if (llBottomSheetContainer != null) {
            bottomSheetBehavior = BottomSheetBehavior.from(llBottomSheetContainer);
            bottomSheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
                @Override
                public void onStateChanged(@NonNull View view, int newState) {
                    switch (newState) {
                        case BottomSheetBehavior.STATE_HIDDEN:
                            finish();
                            break;
                        case BottomSheetBehavior.STATE_EXPANDED:
                            setStatusBarColor(true);
                            break;
                        default:
                            setStatusBarColor(false);
                            break;
                    }
                }

                @Override
                public void onSlide(@NonNull View view, float v) {

                }
            });

            if(bottomSheetBehavior instanceof CarrotBottomSheetBehavior){
                ((CarrotBottomSheetBehavior<?>)bottomSheetBehavior).setAllowUserDragging(false);
            }
        }
    }

    private void setStatusBarColor(boolean isTop) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(isTop ? mColor : Color.TRANSPARENT);
        }
    }

    protected void setPeekHeight(int peekHeight){
        bottomSheetBehavior.setPeekHeight(peekHeight);
    }

    public void showError(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    };

    public void showMessageInfo(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public void expand() {
        ((CarrotBottomSheetBehavior<?>)bottomSheetBehavior).setState(BottomSheetBehavior.STATE_EXPANDED);
    }

    public void collapse() {
        ((CarrotBottomSheetBehavior<?>)bottomSheetBehavior).setState(BottomSheetBehavior.STATE_HALF_EXPANDED);
    }
}
