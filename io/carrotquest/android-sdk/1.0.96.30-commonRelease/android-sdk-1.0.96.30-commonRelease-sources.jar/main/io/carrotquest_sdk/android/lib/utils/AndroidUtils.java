package io.carrotquest_sdk.android.lib.utils;

import android.content.Context;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.UUID;

public class AndroidUtils {
    private static final String INSTALL_ID = "INSTALL_ID";

    public static String getInstallId(Context context) {
        String installId = SharedPreferencesLib.getString(context, INSTALL_ID);
        if (installId == null || installId.isEmpty() || !stringIsGuid(installId)) {
            installId = UUID.randomUUID().toString();
            SharedPreferencesLib.saveString(context, INSTALL_ID, installId);
        }

        return installId;
    }

    private static boolean stringIsGuid(String str) {
        return str.matches("[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}");
    }

    private static String MD5(String inputStr) {
        if(inputStr != null && !inputStr.isEmpty()) {
            try {
                MessageDigest e;
                (e = MessageDigest.getInstance("MD5")).update(inputStr.getBytes());
                byte[] outputData = e.digest();
                StringBuffer hashStr = new StringBuffer();
                Formatter formatter = new Formatter(hashStr);
                for (byte b : outputData) {
                    formatter.format("%02x", b);
                }

                formatter.close();
                return hashStr.toString();
            } catch (NoSuchAlgorithmException var9) {
                return "";
            }
        } else {
            return "";
        }
    }
}
