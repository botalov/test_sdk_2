package io.carrotquest_sdk.android.lib.models;

import androidx.annotation.Keep;

@Keep
public class EcommerceUserProperty extends UserProperty {
    enum Property {
        CART_AMOUNT("$cart_amount"),
        VIEWED_PRODUCTS("$viewed_products"),
        CART_ITEMS("$cart_items"),
        LAST_ORDER_STATUS("$last_order_status"),
        LAST_PAYMENT("$last_payment"),
        REVENUE("$revenue"),
        PROFIT("$profit"),
        GROUP("$group"),
        DISCOUNT("$discount"),
        ORDERS_COUNT("$orders_count"),
        ORDERED_ITEMS("$ordered_items"),
        ORDERED_CATEGORIES("$ordered_categories"),
        VIEWED_CATEGORIES("$viewed_categories");

        private final String text;

        Property(final String text) {
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }
    private String key;
    private String value;

    private EcommerceUserProperty(String key, String value) {
        super("update_or_create", key, value);
    }
    private EcommerceUserProperty(String operation, String key, String value) {
        super(operation, key, value);
    }

    public EcommerceUserProperty(Property key, String value) {
        this("update_or_create", key, value);
    }

    public EcommerceUserProperty(String operation, Property key, String value) {
        super(operation, key.toString(), value);
    }
}
