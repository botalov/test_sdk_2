package io.carrotquest_sdk.android.lib.network.deserializers

import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParseException
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.triggers.Trigger
import io.carrotquest_sdk.android.lib.network.responses.triggers.TriggersResponse
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil
import java.lang.reflect.Type

class GetTriggersDeserializer : JsonDeserializer<TriggersResponse> {
    override fun deserialize(
        json: JsonElement,
        typeOfT: Type?,
        context: JsonDeserializationContext?
    ): TriggersResponse {
        val response = TriggersResponse()

        if (!(GsonUtil.jsonElementNotNull(json.asJsonObject, F.META) && GsonUtil.jsonElementNotNull(
                json.asJsonObject,
                F.DATA
            ))
        ) {
            throw JsonParseException("meta is null or dataJsonElement is null")
        }

        val metaJsonElement = json.asJsonObject[F.META]
        val dataJsonElement = json.asJsonObject[F.DATA]

        if (metaJsonElement == null || dataJsonElement == null) {
            throw JsonParseException("(metaJsonElement == null) = ${metaJsonElement == null}; (dataJsonElement == null) = ${dataJsonElement == null}")
        }

        try {
            val t = TriggersResponse()
            t.setMeta(Gson().fromJson(metaJsonElement, Meta::class.java))

            if(dataJsonElement.isJsonArray) {
                val triggers = java.util.ArrayList<Trigger>()
                (dataJsonElement as JsonArray).forEach {jt ->
                    if(jt.isJsonObject) {
                        val jto = (jt as JsonObject)
                        val id = if(jto.has(F.ID)) {
                            jto[F.ID].asString
                        } else {
                            null
                        }
                        val kind = if(jto.has(F.KIND)) {
                            jto[F.KIND].asInt
                        } else {
                            null
                        }

                        val vlue = if(jto.has(F.VALUE) && jto[F.VALUE].isJsonObject) {
                            jto[F.VALUE].asJsonObject
                        } else {
                            null
                        }

                        if(vlue != null) {
                            val url = if(vlue.has(F.SDK_PAGE)) {
                                vlue[F.SDK_PAGE].asString
                            } else {
                                null
                            }

                            val comparison = if(vlue.has(F.COMPARISON)) {
                                vlue[F.COMPARISON].asString
                            } else {
                                null
                            }

                            if(id != null && url != null && comparison != null) {
                                val tr = Trigger()
                                tr.setId(id)
                                tr.setKind(kind?:-1)
                                tr.setUrl(url)
                                tr.setComparison(comparison)

                                triggers.add(tr)
                            }
                        }
                    }
                }

                t.setData(triggers)
            }

            return t
        } catch (e: Exception) {
            val errorResponse = TriggersResponse()
            val error = e.toString()
            val m = Meta()
            m.status = 503
            m.error = error
            errorResponse.setMeta(m)

            return errorResponse
        }

        return response
    }
}