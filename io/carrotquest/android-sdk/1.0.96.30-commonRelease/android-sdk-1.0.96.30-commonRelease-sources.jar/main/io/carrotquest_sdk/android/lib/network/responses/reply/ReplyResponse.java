package io.carrotquest_sdk.android.lib.network.responses.reply;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Data;
import io.carrotquest_sdk.android.lib.network.responses.base.IBaseResponse;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
@Keep
public class ReplyResponse implements IBaseResponse {
    @SerializedName(F.DATA)
    @Expose
    private ReplyData data;

    @SerializedName(F.META)
    @Expose
    private Meta meta;


    @Override
    public ReplyData getData() {
        return data;
    }

    @Override
    public Meta getMeta() {
        return meta;
    }

    @Override
    public void setData(Data data) {
        this.data = (ReplyData)data;
    }

    @Override
    public void setMeta(Meta meta) {
        this.meta = meta;
    }
}
