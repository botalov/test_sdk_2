package io.carrotquest_sdk.android.presentation.mvp.view_entities.messages

data class MessageMetaDataViewEntity (
        var vote: Int?,
        var comment: String?,
        var loading: Boolean?,
        var replied: Boolean?,
        var closed: Boolean?,
        var duration: Int?
)