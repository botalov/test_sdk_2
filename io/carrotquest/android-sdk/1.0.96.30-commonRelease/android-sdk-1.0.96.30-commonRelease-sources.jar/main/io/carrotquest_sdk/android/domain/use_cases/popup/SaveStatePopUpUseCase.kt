package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.db.popup.PopUpDbEntity
import io.carrotquest_sdk.android.domain.entities.popup.PopUpMessageEntity
import io.reactivex.Observable
import java.lang.Exception
import java.util.*

fun Observable<PopUpMessageEntity>.saveState(isShowed: Boolean) : Observable<PopUpMessageEntity> {
    return Observable.defer {
        this.flatMap {
            if (isShowed) {
                try {
                    val db = CarrotInternal.getLibComponent()?.sdkDataBase
                    db?.popUpDao()?.deleteById(it.id)
                } catch (e: Exception) {
                    Log.e("saveState(). Remove raw.", e)
                }
            } else {
                try {
                    val db = CarrotInternal.getLibComponent()?.sdkDataBase
                    db?.popUpDao()?.insert(PopUpDbEntity(
                            id = it.id,
                            state = StatePopUp.FAILED_SHOWED.name.lowercase(Locale.getDefault()),
                            bodyJson = it.sourceBodyJson,
                            expirationTime = it.expirationTime,
                            backgroundColor = it.backgroundColor
                    ))
                } catch (e: Exception) {
                    Log.e("saveState(). Add raw.", e)
                }
            }

            return@flatMap this
        }
    }
}