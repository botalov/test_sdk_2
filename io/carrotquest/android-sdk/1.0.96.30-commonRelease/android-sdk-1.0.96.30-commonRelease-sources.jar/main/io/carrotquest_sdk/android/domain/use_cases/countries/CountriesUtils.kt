package io.carrotquest_sdk.android.domain.use_cases.countries


/**
 * Const for set/get saved region
 */
const val SAVED_REGION = "SAVED_REGION"

/**
 * Get emoji flag (String) by region
 */
fun getEmoji(region: String) : String? {
    if (region.length != 2) {
        return null
    }

    val countryCodeCaps = region.uppercase()
    val firstLetter = Character.codePointAt(countryCodeCaps, 0) - 0x41 + 0x1F1E6
    val secondLetter = Character.codePointAt(countryCodeCaps, 1) - 0x41 + 0x1F1E6

    if (!countryCodeCaps[0].isLetter() || !countryCodeCaps[1].isLetter()) {
        return null
    }

    return String(Character.toChars(firstLetter)) + String(Character.toChars(secondLetter))
}