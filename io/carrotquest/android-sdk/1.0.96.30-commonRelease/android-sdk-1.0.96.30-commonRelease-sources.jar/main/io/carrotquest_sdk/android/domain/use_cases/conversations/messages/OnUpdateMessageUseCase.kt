package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.reactivex.Observable

fun <T> Observable<T>.onUpdateMessage() : Observable<MessageData?> {
    return Observable.defer {
        return@defer this.flatMap {
            MessagesRepository.getInstance().getUpdatedMessage()
                    .map { x ->
                        x.value
                    }
        }
    }
}