package io.carrotquest_sdk.android.presentation.entities

import java.io.Serializable

data class CountryEntity(
    val name: String,
    val flag: String?,
    val region: String,
    val regionCode: Int,
): Serializable
