package io.carrotquest_sdk.android.core.util.files.download_files;

import io.reactivex.Observer;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.PublishSubject;

import java.util.HashMap;

public class DownloadManager {
    private static HashMap<String, DisposableObserver> downloadFiles = new HashMap<>();

    public static void startDownload(String messageId, String url, long size, Observer<Integer> processObserver) {
        boolean isExist = false;
        if(downloadFiles != null && !downloadFiles.isEmpty() && downloadFiles.containsKey(messageId)) {
            isExist = true;
        }

        if(downloadFiles == null) {
            downloadFiles = new HashMap<>();
        }

        if(!isExist) {
            downloadFiles.put(messageId, DownloadUtil.download(messageId, url, size, processObserver));
        }
    }
    public static void cancelDownloading(String messageId) {
        if(downloadFiles != null && downloadFiles.size() > 0 && downloadFiles.containsKey(messageId)) {
            DownloadUtil.cancelDownload(downloadFiles.get(messageId));
            downloadFiles.remove(messageId);
        }
    }
}
