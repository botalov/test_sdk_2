package io.carrotquest_sdk.android.domain.use_cases.triggers

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.domain.entities.triggers.TriggerComparison
import io.carrotquest_sdk.android.domain.entities.triggers.TriggerEntity


class TrackScreenUseCase {
    fun call(screenName: String) {
        val d1 = SetPresenceCurrentScreenUseCase().call(screenName)
            .subscribe({ user ->
                val d2 = GetTriggersUseCase().call().subscribe { triggers ->
                    val posTriggers =
                        triggers.filter { t -> t.comparison == TriggerComparison.Eq || t.comparison == TriggerComparison.Contains }
                    val negTriggers =
                        triggers.filter { t -> t.comparison == TriggerComparison.Neq || t.comparison == TriggerComparison.NotContains }

                    val posIds = getPosTriggersIds(posTriggers, screenName.lowercase())
                    val negIds = getNegTriggersIds(negTriggers, screenName.lowercase())

                    val trIds = posIds.plus(negIds)

                    if (trIds.isNotEmpty()) {
                        val d3 = CarrotInternal.getService().carrotLib.sendTrigger(trIds)
                            .subscribe({
                                Log.i("SEND_TRIGGER", "${it.meta.status}")
                            }, { t ->
                                Log.i("SEND_TRIGGER", "error sendTrigger: $t")
                            })
                    }
                }
            }, { t ->
                Log.i("SEND_TRIGGER", "error setPresence: $t")
            })
    }

    private fun getPosTriggersIds(posTriggers: List<TriggerEntity>, screenName: String): List<String> {
        val eqIds =
            posTriggers.filter { t -> t.comparison == TriggerComparison.Eq }
                .filter { t -> t.url.lowercase() == screenName }.map { t -> t.id }
        val containsIds =
            posTriggers.filter { t -> t.comparison == TriggerComparison.Contains }
                .filter { t -> screenName.contains(t.url.lowercase()) }.map { t -> t.id }

        return eqIds.plus(containsIds)
    }

    private fun getNegTriggersIds(negTriggers: List<TriggerEntity>, screenName: String): List<String> {
        val neqIds =
            negTriggers.filter { t -> t.comparison == TriggerComparison.Neq }
                .filter { t -> t.url.lowercase() != screenName }.map { t -> t.id }

        val notContainsIds =
            negTriggers.filter { t -> t.comparison == TriggerComparison.NotContains }
                .filter { t -> !screenName.contains(t.url.lowercase()) }.map { t -> t.id }

        return neqIds.plus(notContainsIds)
    }
}