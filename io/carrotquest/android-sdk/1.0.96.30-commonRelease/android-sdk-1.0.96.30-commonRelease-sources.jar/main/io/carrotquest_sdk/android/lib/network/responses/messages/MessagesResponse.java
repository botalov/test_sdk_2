package io.carrotquest_sdk.android.lib.network.responses.messages;

import androidx.annotation.Keep;

import com.google.gson.JsonElement;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

import io.carrotquest_sdk.android.lib.network.F;
@Keep
public class MessagesResponse {
    @SerializedName(F.DATA)
    @Expose
    private List<MessageData> data = null;
    @SerializedName(F.META)
    @Expose
    private MetaMessages meta;

    private JsonElement sourceData;

    public List<MessageData> getData() {
        return data;
    }

    public void setData(List<MessageData> data) {
        this.data = data;
    }

    public MetaMessages getMeta() {
        return meta;
    }

    public void setMeta(MetaMessages meta) {
        this.meta = meta;
    }

    public JsonElement getSourceData() {
        return sourceData;
    }

    public void setSourceData(JsonElement sourceData) {
        this.sourceData = sourceData;
    }
}
