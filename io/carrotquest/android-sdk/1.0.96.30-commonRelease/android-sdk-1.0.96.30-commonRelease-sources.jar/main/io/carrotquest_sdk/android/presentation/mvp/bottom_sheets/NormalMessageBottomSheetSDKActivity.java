package io.carrotquest_sdk.android.presentation.mvp.bottom_sheets;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.view.View;
import android.view.ViewStub;
import android.widget.ImageView;
import android.widget.TextView;

import io.carrotquest_sdk.android.lib.utils.GraphicUtils;
import io.carrotquest_sdk.android.R;
import io.carrotquest_sdk.android.domain.use_cases.theme.GetThemeUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme;

public class NormalMessageBottomSheetSDKActivity extends BaseBottomSheetSDKActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ViewStub viewStubContent = findViewById(R.id.vs_for_content_bottom_sheet);
        viewStubContent.setLayoutResource(R.layout.content_bottom_sheet_tap_normal_message);
        View v = viewStubContent.inflate();
        if(GetThemeUseCaseKt.getThemeUseCase(this) == SimpleTheme.DARK) {
            v.setBackgroundColor(Color.parseColor("#333333"));
        }

        initViews();
        setPeekHeight(GraphicUtils.dpToPx(this, 66));
    }

    private void initViews() {
        ConstraintLayout copyTextButton = findViewById(R.id.copy_text_button);
        copyTextButton.setOnClickListener(v -> presenter.onCopyText(mMessageId));

        if(GetThemeUseCaseKt.getThemeUseCase(this) == SimpleTheme.DARK) {
            TextView tv = findViewById(R.id.copy_text_title_text_view);
            tv.setTextColor(Color.parseColor("#ffffff"));

            ImageView imv = findViewById(R.id.copy_text_icon_image_view);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                imv.setImageTintList(ColorStateList.valueOf(Color.parseColor("#ffffff")));
            }
        }
    }
}
