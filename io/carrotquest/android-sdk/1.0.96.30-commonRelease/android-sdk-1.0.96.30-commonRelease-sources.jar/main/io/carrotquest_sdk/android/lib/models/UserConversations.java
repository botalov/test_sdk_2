package io.carrotquest_sdk.android.lib.models;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.network.responses.conversation.MetaConversation;

@Keep
public class UserConversations {

    @SerializedName(F.DATA)
    private List<DataConversation> conversations = null;
    @SerializedName(F.META)
    private MetaConversation meta;

    public List<DataConversation> getConversations() {
        return conversations;
    }

    public void setConversations(List<DataConversation> conversations) {
        this.conversations = conversations;
    }

    public MetaConversation getMeta() {
        return meta;
    }

    public void setMeta(MetaConversation meta) {
        this.meta = meta;
    }
}
