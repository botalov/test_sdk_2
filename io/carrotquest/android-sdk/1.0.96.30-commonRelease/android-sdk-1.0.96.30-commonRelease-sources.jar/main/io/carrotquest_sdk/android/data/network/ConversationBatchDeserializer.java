package io.carrotquest_sdk.android.data.network;

import static io.carrotquest_sdk.android.lib.utils.json.GsonUtil.jsonElementNotNull;

import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;

import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageMetaData;
import io.carrotquest_sdk.android.lib.network.responses.utils.ConvertUtilsKt;
import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationPartsBatchRtsMessage;

public class ConversationBatchDeserializer implements JsonDeserializer<ConversationPartsBatchRtsMessage> {
    private static final String TAG = "ConversationReplyMessageDeserializer";

    @Override
    public ConversationPartsBatchRtsMessage deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        ConversationPartsBatchRtsMessage response = new ConversationPartsBatchRtsMessage();
        if (jsonElementNotNull(json, ResponseFields.RANDOM_ID)) {
            response.randomId = json.getAsJsonObject().get(ResponseFields.RANDOM_ID).getAsString();
        }

        if (jsonElementNotNull(json, ResponseFields.CONVERSATION)) {
            JsonElement je = json.getAsJsonObject().get(ResponseFields.CONVERSATION);
            response.conversation = geDataConversationFromJsonElement(je);
        }

        ArrayList<MessageData> partsArray = new ArrayList<>();
        if (jsonElementNotNull(json, ResponseFields.PARTS)) {
            JsonArray jsArray = json.getAsJsonObject().get(ResponseFields.PARTS).getAsJsonArray();
            //Gson gson = new Gson();
            for(JsonElement je : jsArray) {
                //MessageData m = gson.fromJson(je, MessageData.class);
                //MessageData m = parseMessageData(je);
                MessageData m = ConvertUtilsKt.convertJsonToMessageData(je);
                partsArray.add(m);
            }
        }
        response.parts = partsArray;

        return response;
    }

    private DataConversation geDataConversationFromJsonElement(JsonElement jsonElement) throws JsonParseException {
        DataConversation conversation = new DataConversation();
        JsonObject jsonObject = jsonElement.getAsJsonObject();

        if(!jsonElementNotNull(jsonObject, F.ID)) {
            throw new JsonParseException("Conversation Id is null");
        }
        conversation.setId(jsonObject.get(F.ID).getAsString());
        conversation.setSourceJsonData(jsonObject);

        if(jsonElementNotNull(jsonObject, F.RANDOM_ID)) {
            conversation.setRandomId(jsonObject.get(F.RANDOM_ID).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.CREATED)) {
            conversation.setCreated(jsonObject.get(F.CREATED).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.READ)) {
            conversation.setRead(jsonObject.get(F.READ).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.CLIKCKED)) {
            conversation.setClicked(jsonObject.get(F.CLIKCKED).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.UNSUBSCRIBED)) {
            conversation.setUnsubscribed(jsonObject.get(F.UNSUBSCRIBED).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.CLOSED)) {
            conversation.setClosed(jsonObject.get(F.CLOSED).getAsBoolean());
        }

        if(jsonElementNotNull(jsonObject, F.REPLY_TYPE)) {
            conversation.setReplyType(jsonObject.get(F.REPLY_TYPE).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.TYPE)) {
            conversation.setType(jsonObject.get(F.TYPE).getAsString());
        }

        if(jsonElementNotNull(jsonObject, F.PARTS_COUNT)) {
            conversation.setPartsCount(jsonObject.get(F.PARTS_COUNT).getAsInt());
        }

        if(jsonElementNotNull(jsonObject, F.UNREAD_PARTS_COUNT)) {
            conversation.setUnreadPartsCount(jsonObject.get(F.UNREAD_PARTS_COUNT).getAsInt());
        }

        if(jsonElementNotNull(jsonObject, F.USER_UNREAD_COUNT)) {
            conversation.setUserUnreadCount(jsonObject.get(F.USER_UNREAD_COUNT).getAsInt());
        }

        if(jsonElementNotNull(jsonObject, F.LAST_UPDATE)) {
            conversation.setLastUpdate(jsonObject.get(F.LAST_UPDATE).getAsString()
            );
        }

        if(jsonElementNotNull(jsonObject, F.PART_LAST)) {
            MessageData partLast = ConvertUtilsKt.convertJsonToMessageData(jsonObject.get(F.PART_LAST));
            conversation.setPartLast(partLast);
        }

        if(jsonElementNotNull(jsonObject, F.LAST_ADMIN)) {
            conversation.setLastAdmin(parseAdmin(jsonObject.get(F.LAST_ADMIN).getAsJsonObject()));
        }

        if(jsonElementNotNull(jsonObject, F.RECIPIENT_TYPE)) {
            conversation.setRecipientType(jsonObject.get(F.RECIPIENT_TYPE).getAsString());
        }


        return conversation;
    }

    private Admin parseAdmin(JsonObject lastAdminJsonObject) {
        Admin admin = new Admin();

        if (jsonElementNotNull(lastAdminJsonObject, F.ID)) {
            admin.setId(lastAdminJsonObject.get(F.ID).getAsString());
        }

        if (jsonElementNotNull(lastAdminJsonObject, F.NAME)) {
            admin.setName(lastAdminJsonObject.get(F.NAME).getAsString());
        }
        if (jsonElementNotNull(lastAdminJsonObject, F.TYPE)) {
            admin.setType(lastAdminJsonObject.get(F.TYPE).getAsString());
        }
        if (jsonElementNotNull(lastAdminJsonObject, F.AVATAR)) {
            admin.setAvatar(lastAdminJsonObject.get(F.AVATAR).getAsString());
        }

        return admin;
    }

    private MessageData parseMessageData(JsonElement element) {
        MessageData data = new MessageData();
        JsonObject joData = element.getAsJsonObject();
        if (joData != null) {
            try {
                data.setSourceJsonData(new JSONObject((new Gson()).toJson(joData)));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            ArrayList<Attachment> attachments = new ArrayList<>();
            String body = null;

            if (joData.has(F.ID))
                data.setId(joData.get(F.ID).getAsString());
            if (joData.has(F.CREATED))
                data.setCreated(joData.get(F.CREATED).getAsString());
            if (joData.has(F.CONVERSATION))
                data.setConversation(joData.get(F.CONVERSATION).getAsString());
            if (joData.has(F.BODY)) {
                body = joData.get(F.BODY).getAsString();
                data.setBody(body);
            }
            if (joData.has(F.BODY_JSON))
                data.setBodyJson(joData.get(F.BODY_JSON));
            if (joData.has(F.DIRECTION))
                data.setDirection(joData.get(F.DIRECTION).getAsString());
            if (joData.has(F.READ))
                data.setRead(joData.get(F.READ).getAsBoolean());
            if (joData.has(F.TYPE))
                data.setType(joData.get(F.TYPE).getAsString());
            if (joData.has(F.SENT_VIA)) {
                String sentVia = joData.get(F.SENT_VIA).getAsString();
                data.setSentVia(sentVia);

                if ("message_manual".equals(sentVia) && body != null) {
                    int startIndex = body.indexOf("https://files.carrotquest.io");
                    int endIndex = body.indexOf(" style=") - 1;
                    if (startIndex >= 0 && endIndex >= 0 && endIndex > startIndex) {
                        String path = body.substring(startIndex, endIndex);
                        if (URLUtil.isValidUrl(path)) {
                            Attachment attachment = new Attachment();
                            attachment.setUrl(path);
                            attachment.setId(data.getId());
                            attachment.setType(data.getType());
                            attachment.setCreated(data.getCreated());
                            attachment.setFilename("file");
                            String mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension((MimeTypeMap.getFileExtensionFromUrl(path)).toLowerCase());
                            attachment.setMimeType(mimeType);

                            attachments.add(attachment);
                        }
                    }
                    int startBodyIndex = body.indexOf("<p>");
                    int endBodyIndex = body.indexOf("<", 2);
                    if(startBodyIndex >= 0 && endBodyIndex >= 0 && endBodyIndex > startBodyIndex) {
                        data.setBody(body.substring(startBodyIndex, endBodyIndex));
                    }
                    else {
                        data.setBody("");
                    }
                }
            }
            if (joData.has(F.FIRST))
                data.setFirst(joData.get(F.FIRST).getAsBoolean());
            if (joData.has(F.REPLY_TYPE))
                data.setReplyType(joData.get(F.REPLY_TYPE).getAsString());

            if (joData.has(F.FROM)) {
                if (joData.get(F.FROM).isJsonObject()) {
                    Admin messageFrom = new Gson().fromJson(joData.get(F.FROM), Admin.class);
                    data.setMessageFrom(messageFrom);
                } else {
                    Admin messageFrom = new Admin();
                    messageFrom.setId(joData.get(F.FROM).getAsString());
                    data.setMessageFrom(messageFrom);
                }
            }
            if (joData.has(F.META_DATA)) {
                MessageMetaData messageMetaData = new Gson().fromJson(joData.get(F.META_DATA), MessageMetaData.class);
                data.setMessageMetaData(messageMetaData);
            }


            if (joData.has(F.ATTACHMENTS)) {
                JsonArray attachmentsJArray = joData.getAsJsonArray(F.ATTACHMENTS);
                if (attachmentsJArray != null && attachmentsJArray.size() > 0) {
                    //ArrayList<Attachment> attachments = new ArrayList<>();
                    for (JsonElement attachmentJElement : attachmentsJArray) {
                        Attachment attachment = new Gson().fromJson(attachmentJElement, Attachment.class);
                        if (attachment.getStatus() == null) {
                            attachment.setStatus("");
                        }
                        attachments.add(attachment);
                    }
                    data.setAttachments(attachments);
                }
            }
            if(data.getAttachments() == null && attachments.size() > 0) {
                data.setAttachments(attachments);
            }
        }
        return data;
    }
}
