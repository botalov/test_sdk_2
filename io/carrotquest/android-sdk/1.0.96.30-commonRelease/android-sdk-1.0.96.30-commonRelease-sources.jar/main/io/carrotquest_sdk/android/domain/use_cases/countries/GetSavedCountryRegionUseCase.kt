package io.carrotquest_sdk.android.domain.use_cases.countries

import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.core.main.CarrotInternal
import java.util.Locale

class GetSavedCountryRegionUseCase {
    fun call() : String {
        val context = CarrotInternal.getLibComponent().contextSdk
        val savedRegion = SharedPreferencesLib.getString(context, SAVED_REGION)
        if(savedRegion.length == 2) {
            return savedRegion
        }

        //Если по каким-то причинам не нашли сохраненного региона,
        // то возвращаем текущий регион утсройства
        return Locale.getDefault().country
    }
}