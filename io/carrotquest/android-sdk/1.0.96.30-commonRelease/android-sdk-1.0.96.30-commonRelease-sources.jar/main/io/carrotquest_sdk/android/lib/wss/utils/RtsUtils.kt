package io.carrotquest_sdk.android.lib.wss.utils

import android.text.TextUtils
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.wss.Channel
import java.net.URLEncoder

fun getRtsConnectUrl(host: String, appId: String, channels: ArrayList<Channel>, token: String): String {

    val tempBaseUrl = if (!host.contains("wss:") && !host.contains("ws:")) {
        "wss://$host"
    } else {
        host
    }

    val baseUrl = if (tempBaseUrl.endsWith("/", ignoreCase = true)) {
        tempBaseUrl
    } else {
        "$tempBaseUrl/"
    }

    val url = StringBuilder().append(baseUrl)

    if (channels.isNotEmpty()) {
        for (channel in channels) {
            val p = StringBuilder()
            if (channel.hasParams()) {
                for (s in channel.params) {
                    p.append("; ").append(s)
                }
            } else {
                p.append("channel doesn't have params")
            }

            url.append(getChanelStr(appId, channel))
        }
        if (channels.size > 0) {
            url.setLength(url.length - 1)
        }
    }

    url.append("?auth_token=").append(token)


    val tag: String = getLastTag(appId)
    url.append("&")
        .append("tag=").append(URLEncoder.encode(tag, "utf-8").replace("+", "%20"))

    val time: String = getLastTime(appId)
    url.append("&")
        .append("time=").append(URLEncoder.encode(time, "utf-8").replace("+", "%20"))


    return url.toString()
}

private fun getLastTag(appId: String): String {
    return SharedPreferencesLib.getString(CarrotLib.getLibComponents().context, shPrefTagKey + appId)
}

private fun getLastTime(appId: String): String {
    return SharedPreferencesLib.getString(CarrotLib.getLibComponents().context, shPrefTimeKey + appId)
}

private fun getChanelStr(appId: String, channel: Channel): String {
    val channelStr = java.lang.StringBuilder(channel.channelName)
    if (!TextUtils.isEmpty(channelStr)) {
        if (channelStr.toString() != "ping") {
            channelStr.append(".").append(appId)
        }

        if (channel.hasParams()) {
            for (param in channel.params) {
                channelStr.append(".").append(param)
            }
        }
        channelStr.append("/")

        return channelStr.toString()
    }
    return ""
}
