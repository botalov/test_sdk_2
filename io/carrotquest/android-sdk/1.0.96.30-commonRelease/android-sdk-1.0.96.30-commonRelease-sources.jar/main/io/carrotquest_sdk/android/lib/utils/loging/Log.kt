package io.carrotquest_sdk.android.lib.utils.loging

import android.util.Log
import io.carrotquest_sdk.android.lib.CarrotLib

class Log {
    companion object {
        fun i(tag: String?, msg: String?) {
            Log.i(tag, msg?:"")
        }

        fun e(tag: String?, msg: String?) {
            Log.e(tag, msg?:"")
        }

        fun e(tag: String?, e: Exception) {
            Log.e(tag, e.toString())
        }

        fun e(tag: String?, t: Throwable) {
            Log.e(tag, t.toString())
        }

        fun w(tag: String?, msg: String?) {
            if (CarrotLib.isDebug()) {
                Log.w(tag, msg?:"")
            }
        }

        fun d(tag: String?, msg: String?) {
            if (CarrotLib.isDebug()) {
                Log.d(tag, msg?:"")
            }
        }

        fun v(tag: String?, msg: String?) {
            if (CarrotLib.isDebug()) {
                Log.v(tag, msg?:"")
            }
        }
    }
}