package io.carrotquest_sdk.android.domain.entities

data class MessageMetaData(
        var vote: Int?,
        var comment: String?,
        var loading: Boolean?,
        var replied: Boolean?,
        var closed: Boolean?,
        var duration: Int?
)