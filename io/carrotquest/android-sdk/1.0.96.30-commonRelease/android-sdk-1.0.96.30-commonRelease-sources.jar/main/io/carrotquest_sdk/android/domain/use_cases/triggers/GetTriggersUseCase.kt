package io.carrotquest_sdk.android.domain.use_cases.triggers

import io.carrotquest_sdk.android.data.repositories.triggers.TriggersRepository
import io.carrotquest_sdk.android.domain.entities.triggers.TriggerComparison
import io.carrotquest_sdk.android.domain.entities.triggers.TriggerEntity
import io.reactivex.Flowable

class GetTriggersUseCase {
    fun call(): Flowable<List<TriggerEntity>> {
        return TriggersRepository.getInstance().getTriggers().map { l ->
            return@map l
                .filter { t -> t.kind == 7 }
                .map { t ->
                    TriggerEntity(
                        id = t.id,
                        kind = t.kind,
                        url = t.url,
                        comparison = when (t.comparison.lowercase()) {
                            "eq" -> TriggerComparison.Eq
                            "contains" -> TriggerComparison.Contains
                            "neq" -> TriggerComparison.Neq
                            "not_contains" -> TriggerComparison.NotContains
                            else -> TriggerComparison.Uncnown
                        }
                    )
                }
        }
    }
}