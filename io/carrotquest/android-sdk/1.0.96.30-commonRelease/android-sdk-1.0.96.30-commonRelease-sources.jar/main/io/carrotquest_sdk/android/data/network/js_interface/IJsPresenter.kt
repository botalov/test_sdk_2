package io.carrotquest_sdk.android.data.network.js_interface

import android.content.Context

interface IJsPresenter {
    fun onTapMessage(context: Context, messageId: String)
    fun onTapImage(url: String)
    fun onTapErrorSendingMessage(context: Context, messageId: String)
    fun cancelDownloadFile(messageId: String)
    fun openAttachFile(messageId: String)
    fun onStartDownloadFile(messageId: String)
    fun paginationMessages()
    fun setContactDetails(messageId: String, type: String, value: String)
    fun sendVote(messageId: String, vote: Int)
    fun sendCommentVote(messageId: String, vote: Int, comment: String)
    fun onGoToLink(link: String, context: Context)

    fun setUserProperty(props: String)
    fun onTapCalendlyButton(joinUrl: String,utm: String?, context: Context)
    fun onTapZoomMeetingButton(joinUrl: String, context: Context)

    fun onSelectBotBrunch(messageId: String, branchId: String, branchLinkId: String, answerBody: String, href: String, context: Context)
    fun onShowBotInput(messageId: String, branchId: String, branchLinkId: String, answerBody: String, context: Context)
}