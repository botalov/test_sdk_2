package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import javax.inject.Inject;

import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.data.repositories.old.UserRepository;

public class UserBanResponse implements IRtsMessage {

    @SerializedName("user_id")
    @Expose
    private String userId;

    @SerializedName("value")
    @Expose
    private boolean isBan;

    @Inject
    UserRepository userRepository;

    @Override
    public void process() {
        if(userRepository == null) {
            userRepository = CarrotInternal.getLibComponent().getUserRepository();
        }

        if(isBan) {
            userRepository.banUser(userId);
        }
        else {
            userRepository.unBanUser(userId);
        }
    }
}
