package io.carrotquest_sdk.android.lib.network.responses.conversation;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
@Keep
public class MetaConversation extends Meta {
    @SerializedName(F.NEXT_ARTER)
    @Expose
    private String nextAfter;
    @SerializedName(F.STATUS)

    public String getNextAfter() {
        return nextAfter;
    }

    public void setNextAfter(String nextAfter) {
        this.nextAfter = nextAfter;
    }
}
