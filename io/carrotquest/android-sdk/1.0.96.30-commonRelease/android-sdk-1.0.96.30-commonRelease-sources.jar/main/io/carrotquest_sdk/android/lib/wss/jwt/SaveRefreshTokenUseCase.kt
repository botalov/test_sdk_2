package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import java.util.Date

fun saveRefreshToken(token: String, context: Context = CarrotLib.getLibComponents().getContext()) {
    val oldRefreshToken = getRefreshToken(context)
    if(oldRefreshToken != token) {
        val currentTime = Date().time
        SharedPreferencesLib.saveLong(context, refreshTokenUpdateTimeStampKey, currentTime)
    }

    SharedPreferencesLib.saveString(context, refreshTokenKey, token)
}