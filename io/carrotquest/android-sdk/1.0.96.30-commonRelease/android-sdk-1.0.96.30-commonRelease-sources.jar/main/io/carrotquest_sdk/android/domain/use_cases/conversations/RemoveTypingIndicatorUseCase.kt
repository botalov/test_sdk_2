package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.data.repositories.MessagesRepository

fun removeTypingIndicator() {
    MessagesRepository.getInstance().removeMessageTyping()
}