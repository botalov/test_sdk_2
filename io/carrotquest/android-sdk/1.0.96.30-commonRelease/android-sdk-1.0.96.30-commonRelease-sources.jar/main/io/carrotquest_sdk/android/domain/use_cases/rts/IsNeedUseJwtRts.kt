package io.carrotquest_sdk.android.domain.use_cases.rts

/**
 * Нужно ли использовать новый метод подключения к РТС, используя JWT
 * Определяется на основе версии РТС
 */
//fun isNeedJwtRts(context: Context): Boolean {
//    val rtsVersion = getRtsVersion(context)
//    return rtsVersion > 1
//}