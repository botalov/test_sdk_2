package io.carrotquest_sdk.android.core.main

enum class ThemeSdk {
    LIGHT,
    DARK,
    FROM_WEB,
    FROM_DEVICE,
}