package io.carrotquest_sdk.android.lib.di;

import io.carrotquest_sdk.android.lib.repositories.IUserRepository;
import dagger.Module;
import dagger.Provides;

import javax.inject.Singleton;

/**
 * Date: 8/18/2016
 * Time: 14:50
 *
 * @author Artur Artikov
 */
@Module
public class RepositoryModule {


	private IUserRepository userRepository;

	public RepositoryModule(IUserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Provides @Singleton
	public IUserRepository provideUser() {
		return this.userRepository;
	}
}
