package io.carrotquest_sdk.android.data.db.messages;


import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class FailSendingMessage {
    @NonNull
    @PrimaryKey
    public String id;
    public String randomId;
    public String conversationId;
    public String created;
    public String body;
    public String bodyJson;
    public Boolean read;
    public String type;
    public String sentVia;
    public Boolean first;
    public String direction;
    public String status;
    public String replyType;
    public String messageFrom;
    public String attachPath;
    public Boolean inSendingProcess;



    public FailSendingMessage(@NonNull String id) {
        this.id = id;
    }
}
