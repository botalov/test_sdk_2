package io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.countries

import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.View.OnFocusChangeListener
import android.view.ViewStub
import android.widget.EditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.carrotquest_sdk.android.lib.utils.GraphicUtils
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.domain.use_cases.countries.getCountryEntityByRegion
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.presentation.entities.CountryEntity
import io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.BaseBottomSheetSDKActivity
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil


class CountriesBottomSheetSdkActivity: BaseBottomSheetSDKActivity() {

    override fun getTheme(): Resources.Theme {
        val theme = super.getTheme()
        when (getThemeUseCase(this)) {
            SimpleTheme.DARK -> {
                theme.applyStyle(R.style.DarkCqSdkBottomSheetTheme, true)
            }
            else -> {
                theme.applyStyle(R.style.LightCqSdkBottomSheetTheme, true)
            }
        }

        return theme
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val viewStubContent = findViewById<ViewStub>(R.id.vs_for_content_bottom_sheet)
        viewStubContent.layoutResource = R.layout.content_bottom_sheet_countries
        val v = viewStubContent.inflate()
        if (getThemeUseCase(this) == SimpleTheme.DARK) {
            v.setBackgroundColor(Color.parseColor("#333333"))
        }

        initViews()
        setPeekHeight(GraphicUtils.dpToPx(this, 500f))
    }

    private fun initViews() {
        val phoneNumberUtil = PhoneNumberUtil.createInstance(this)
        val allRegionsSet = phoneNumberUtil.supportedRegions

        val allRegions = ArrayList<String>()
        allRegions.addAll(allRegionsSet)

        val allCountries = ArrayList(allRegions.map { region ->
            getCountryEntityByRegion(region, phoneNumberUtil)
        })
        allCountries.sortBy { c -> c.name }

        val recyclerView = findViewById<RecyclerView>(R.id.countries_recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        val adapter = CountriesListAdapter(dataSet = ArrayList(allCountries))

        findViewById<EditText>(R.id.search_country_edit_text)?.onFocusChangeListener =
            OnFocusChangeListener { _, isFocus ->
                if(isFocus) {
                    expand()
                } else {
                    collapse()
                }
            }

        findViewById<EditText>(R.id.search_country_edit_text).addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(t: CharSequence?, p1: Int, p2: Int, p3: Int) {
                val text = t?.toString() ?: ""
                if(text.isEmpty()) {
                    adapter.setData(allCountries)
                    return
                }

                val filteredCountries = allCountries.filter {c ->
                    c.name.lowercase().contains(text.lowercase())
                            || c.regionCode.toString().lowercase().contains(text.lowercase())
                }
                adapter.setData(filteredCountries)
            }

            override fun afterTextChanged(p0: Editable?) {
            }

        })

        adapter.setOnClickListener(object : OnClickListener {
            override fun onClick(country: CountryEntity) {
                val intent = Intent()
                intent.putExtra("SELECTED_COUNTRY", country)
                setResult(RESULT_OK, intent)
                finish()
            }
        })
        recyclerView.adapter = adapter

    }
}