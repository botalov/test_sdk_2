package io.carrotquest_sdk.android.presentation.mvp.calendly.view

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.data.network.js_interface.CalendlyJSInterface
import io.carrotquest_sdk.android.presentation.mvp.base.BaseSdkActivity
import io.carrotquest_sdk.android.presentation.mvp.calendly.presenter.CalendlyPresenter
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView
import io.reactivex.Observer
import io.reactivex.disposables.Disposable

class CalendlyWidgetActivity: BaseSdkActivity(), ICalendlyView {

    companion object {
        const val JOIN_URL_ARG = "join_url_arg"
        const val UTM_ARG = "utm_arg"
        const val APP_COLOR = "app_color"
    }

    private val presenter = CalendlyPresenter()
    private var joinUrl: String = ""
    private var utm: String = ""
    private var appColor: Int = -1

    private val closeCalendlyButton = findViewById<ImageButton>(R.id.close_calendly_button)
    private val calendlyWebView = findViewById<CarrotWebView>(R.id.calendly_web_view)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendly)

        this.joinUrl = if(intent.hasExtra(JOIN_URL_ARG)) intent.getStringExtra(JOIN_URL_ARG)!! else ""
        this.utm = if(intent.hasExtra(UTM_ARG)) intent.getStringExtra(UTM_ARG)!! else ""
        this.appColor = if(intent.hasExtra(APP_COLOR)) intent.getIntExtra(APP_COLOR, -1) else -1

        this.presenter.attachView(this)
        this.presenter.onCreate()
    }

    override fun onResume() {
        super.onResume()
        updateColor()
        closeCalendlyButton.setOnClickListener {
            presenter.onTapCloseButton()
        }
    }

    override fun onDestroy() {
        presenter.detachView()
        calendlyWebView.onDestroy()
        super.onDestroy()
    }

    override fun initWebView() {

        calendlyWebView.addLoadingObserver(object : Observer<Boolean> {
            override fun onComplete() {

            }

            override fun onSubscribe(d: Disposable) {

            }

            override fun onNext(t: Boolean) {
                if (t && joinUrl.isNotEmpty()) {
                    presenter.onLoaded(joinUrl, utm)
                } else {
                    presenter.onLoadedError()
                }
            }

            override fun onError(e: Throwable) {

            }
        })
        calendlyWebView.loadUrl(BuildConfig.CALENDLY_URL)

        calendlyWebView.setErrorObserver {
            if(it) {
                calendlyWebView.findViewById<TextView>(R.id.message_error_text_view)?.visibility = View.GONE
            }
        }
    }

    override fun close() {
        this.finish()
    }

    override fun showError() {
        calendlyWebView.showLoadError()
    }

    override fun showWidget(eventData: String) {
        calendlyWebView.executeJsInWebView("javascript:window.webView.initCalendlyWidget($eventData)")
        //calendly_web_view.loadUrl("https://google.com")

        calendlyWebView?.initJsInterface(
            CalendlyJSInterface(
                this@CalendlyWidgetActivity,
                presenter,
                calendlyWebView
            )
        )
    }

    override fun hideLoader() {
        calendlyWebView.hideLoading()
    }

    private fun updateColor() {
        if(closeCalendlyButton != null) {
            closeCalendlyButton.visibility = View.VISIBLE
            closeCalendlyButton.setColorFilter(appColor)
        }

        calendlyWebView.setColor(appColor)
    }
}