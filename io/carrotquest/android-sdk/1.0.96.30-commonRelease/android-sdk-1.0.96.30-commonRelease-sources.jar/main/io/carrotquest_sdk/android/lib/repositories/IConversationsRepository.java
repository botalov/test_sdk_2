package io.carrotquest_sdk.android.lib.repositories;

import io.carrotquest_sdk.android.lib.models.UserConversations;

public interface IConversationsRepository {
    void saveConversations(UserConversations userConversations);
    UserConversations getUserConversations();

}
