package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import android.text.TextUtils
import com.google.gson.Gson
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.files.download_files.DownloadUtil
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.reactivex.Observable
import org.json.JSONObject

fun Observable<DataConversation>.paginationMessages() : Observable<ArrayList<MessageData>> {
    val tag = "Observable.paginationMessages()"
    return Observable.defer {
        return@defer this.flatMap { conversation ->
            val conversationId =
                conversation.id ?: return@flatMap Observable.just(ArrayList<MessageData>())

            val after = MessagesRepository.getInstance().getCurrentAfter()
            if (TextUtils.isEmpty(after)) {
                return@flatMap Observable.just(ArrayList<MessageData>())
            }

            CarrotInternal.getService().carrotLib.getMessages(conversationId, after)
                .map { response ->
                    if (response.meta.error != null || response.data == null) {
                        throw Exception("Error load conversation by pagination: ${response.meta.error}")
                    }

                    MessagesRepository.getInstance().setCurrentAfter(
                        response.meta.nextAfter
                            ?: ""
                    )

                    val x = DownloadUtil.replaceFilesLocalUrl(response)
                    val nArray = ArrayList<MessageData>()
                    for (m in x.data) {
                        val nm =
                            x.sourceData.asJsonArray.find { p -> p.asJsonObject.get("id").asString == m.id }
                        if (nm != null) {
                            m.sourceJsonData = JSONObject(Gson().toJson(nm))
                        }

                        nArray.add(m)
                    }

                    MessagesRepository.getInstance().addMessages(nArray)
                    return@map nArray
                }
                .doOnError {
                    Log.e(tag, it.toString())
                }
        }
    }
}