package io.carrotquest_sdk.android.lib.network.responses.messages;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;
import io.carrotquest_sdk.android.lib.network.F;

@Keep
public class ReplyFileData {

    @SerializedName(F.ID)
    private String id;
    @SerializedName(F.ATTACHMENT)
    private Attachment attachment;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Attachment getAttachment() {
        return attachment;
    }

    public void setAttachment(Attachment attachment) {
        this.attachment = attachment;
    }
}
