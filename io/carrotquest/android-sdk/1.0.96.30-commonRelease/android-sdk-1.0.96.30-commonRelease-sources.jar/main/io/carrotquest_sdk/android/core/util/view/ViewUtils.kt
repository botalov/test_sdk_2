package io.carrotquest_sdk.android.core.util.view

import android.view.View
import android.view.animation.Animation
import android.view.animation.Transformation


class DropDownAnim(private val view: View, private val startHeight: Int,private val targetHeight: Int) : Animation() {

    override fun applyTransformation(interpolatedTime: Float, t: Transformation) {
        val newHeight = startHeight + ((targetHeight - startHeight) * interpolatedTime).toInt()
        view.layoutParams.height = newHeight
        view.requestLayout()
    }

    override fun initialize(width: Int, height: Int, parentWidth: Int,
                            parentHeight: Int) {
        super.initialize(width, height, parentWidth, parentHeight)
    }

    override fun willChangeBounds(): Boolean {
        return true
    }
}
