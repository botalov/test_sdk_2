package io.carrotquest_sdk.android.domain.use_cases.rts


/**
 * Возвращает версию РТС
 */
//fun getRtsVersion(context: Context): Int {
//    val rtsHost = getRtsHost(context)
//    val prefixRtsHost = rtsHost.substringBefore(".", missingDelimiterValue = "")
//    if(prefixRtsHost.isEmpty()) {
//        return 1
//    }
//
//    return if(prefixRtsHost.contains("rts-v")) {
//        val rtsVersionStr = prefixRtsHost.substringAfter("rts-v", missingDelimiterValue = "")
//        if(rtsVersionStr.isEmpty()) {
//            1
//        } else {
//            rtsVersionStr.toIntOrNull() ?: 1
//        }
//    } else {
//        1
//    }
//}