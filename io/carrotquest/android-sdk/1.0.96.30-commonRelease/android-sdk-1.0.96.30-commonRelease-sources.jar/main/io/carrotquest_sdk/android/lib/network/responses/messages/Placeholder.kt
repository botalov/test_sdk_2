package io.carrotquest_sdk.android.lib.network.responses.messages

import androidx.annotation.Keep

@Keep
data class Placeholder(
    val type: String,
    val value: String,
)
