package io.carrotquest_sdk.android.lib.utils.messages

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData

fun MessageData.isByBotWithActions() : Boolean {
    return "chat_bot_user" == this.type && this.actions != null && this.actions.isNotEmpty()
}