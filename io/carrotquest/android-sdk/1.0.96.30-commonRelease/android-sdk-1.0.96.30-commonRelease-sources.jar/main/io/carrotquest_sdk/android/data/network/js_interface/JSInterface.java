package io.carrotquest_sdk.android.data.network.js_interface;

public interface JSInterface {
    String PUBLIC_INTERFACE_NAME = "SdkInterface";
}
