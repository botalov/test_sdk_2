package io.carrotquest_sdk.android.presentation.mvp.base

abstract class BasePresenter {
    private var view: IBaseView? = null
    open fun attachView(view: IBaseView) {
        this.view = view
    }

    fun detachView(){
        this.view = null
    }

    open fun getView() : IBaseView? {
        return view
    }
}