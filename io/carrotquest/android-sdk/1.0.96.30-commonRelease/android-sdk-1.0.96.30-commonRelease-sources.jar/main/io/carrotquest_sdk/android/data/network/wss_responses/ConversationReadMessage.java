package io.carrotquest_sdk.android.data.network.wss_responses;

import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.data.repositories.old.UserRepository;

import javax.inject.Inject;

public class ConversationReadMessage implements IRtsMessage {
    @Inject
    UserRepository userRepository;

    @SerializedName(ResponseFields.ID)
    public String id;

    @Override
    public void process() {

    }
}
