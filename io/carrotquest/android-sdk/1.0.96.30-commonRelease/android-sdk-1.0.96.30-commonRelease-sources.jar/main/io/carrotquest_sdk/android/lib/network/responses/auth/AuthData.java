package io.carrotquest_sdk.android.lib.network.responses.auth;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.network.responses.base.Data;

@Keep
public class AuthData extends Data {
    @SerializedName("auth_token")
    private String authToken;
    @SerializedName("user")
    private User user;

    @SerializedName("refresh")
    private String refreshToken;

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }
}
