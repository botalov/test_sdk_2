package io.carrotquest_sdk.android.lib.network.responses.conversation;

import androidx.annotation.Keep;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;
@Keep
public class ConversationResponse {
    @SerializedName(F.DATA)
    @Expose
    private DataConversation conversationModel;
    @SerializedName(F.META)
    @Expose
    private MetaConversation meta;

    public DataConversation getData() {
        return conversationModel;
    }

    public void setData(DataConversation conversationModel) {
        this.conversationModel = conversationModel;
    }

    public MetaConversation getMeta() {
        return meta;
    }

    public void setMeta(MetaConversation meta) {
        this.meta = meta;
    }
}
