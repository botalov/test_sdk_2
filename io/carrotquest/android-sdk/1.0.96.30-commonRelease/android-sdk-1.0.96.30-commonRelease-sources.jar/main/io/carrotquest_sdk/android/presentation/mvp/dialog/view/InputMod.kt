package io.carrotquest_sdk.android.presentation.mvp.dialog.view

enum class InputMod {
    NORMAL,
    ALLOW_USER_REPLIES,
    BOT_INPUT
}