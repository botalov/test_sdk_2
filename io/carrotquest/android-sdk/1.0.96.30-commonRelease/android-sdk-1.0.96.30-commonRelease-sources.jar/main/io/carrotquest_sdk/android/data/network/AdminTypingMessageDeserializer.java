package io.carrotquest_sdk.android.data.network;

import com.google.gson.Gson;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;

import io.carrotquest_sdk.android.lib.models.Admin;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;
import io.carrotquest_sdk.android.core.constants.ResponseFields;
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationTypingResponse;

public class AdminTypingMessageDeserializer implements JsonDeserializer<ConversationTypingResponse> {
    @Override
    public ConversationTypingResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        ConversationTypingResponse response = new ConversationTypingResponse();

        if(GsonUtil.jsonElementNotNull(json, ResponseFields.CONVERSATION)) {
            response.setConversation(json.getAsJsonObject().get(ResponseFields.CONVERSATION).getAsString());
        }
        String id = String.valueOf(System.currentTimeMillis());

        JsonObject jObject = json.getAsJsonObject();
        jObject.addProperty(F.ID, id);
        jObject.addProperty(F.TYPE, ResponseFields.TYPING);

        response.setId(id);
        response.setRandomId(id);
        response.setType(ResponseFields.TYPING);

        if(json.getAsJsonObject().has(F.DURATION)) {
            int durationFromBack = json.getAsJsonObject().get(F.DURATION).getAsInt();
            response.setDuration(durationFromBack);
        }

        if(json.getAsJsonObject().has(ResponseFields.ADMIN) && json.getAsJsonObject().get(ResponseFields.ADMIN).isJsonObject()) {
            Admin adminFrom = new Admin();
            JsonObject adminJsonElement = json.getAsJsonObject().get(ResponseFields.ADMIN).getAsJsonObject();
            if (GsonUtil.jsonElementNotNull(adminJsonElement, F.ID)) {
                adminFrom.setId(adminJsonElement.get(F.ID).getAsString());
            }
            if (GsonUtil.jsonElementNotNull(adminJsonElement, F.NAME)) {
                adminFrom.setName(adminJsonElement.get(F.NAME).getAsString());
            }
            if (GsonUtil.jsonElementNotNull(adminJsonElement, F.TYPE)) {
                adminFrom.setType(adminJsonElement.get(F.TYPE).getAsString());
            }
            if (GsonUtil.jsonElementNotNull(adminJsonElement, F.AVATAR)) {
                adminFrom.setAvatar(adminJsonElement.get(F.AVATAR).getAsString());
            }

            jObject.add(F.FROM, adminJsonElement);
            response.setMessageFrom(adminFrom);
        }

        try {
            response.setSourceJsonData(new JSONObject((new Gson()).toJson(jObject)));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return response;
    }

}
