package io.carrotquest_sdk.android.models

class EcommerceUserProperty : UserProperty {
    enum class Property(private val text: String) {
        CART_AMOUNT("\$cart_amount"),
        VIEWED_PRODUCTS("\$viewed_products"),
        CART_ITEMS("\$cart_items"),
        LAST_ORDER_STATUS("\$last_order_status"),
        LAST_PAYMENT("\$last_payment"),
        REVENUE("\$revenue"),
        PROFIT("\$profit"),
        GROUP("\$group"),
        DISCOUNT("\$discount"),
        ORDERS_COUNT("\$orders_count"),
        ORDERED_ITEMS("\$ordered_items"),
        ORDERED_CATEGORIES("\$ordered_categories"),
        VIEWED_CATEGORIES("\$viewed_categories");

        override fun toString(): String {
            return text
        }
    }

    private constructor(key: String, value: String) : super(Operation.UPDATE_OR_CREATE, key, value)
    private constructor(operation: Operation, key: String, value: String) : super(
        operation,
        key,
        value
    )

    constructor(key: Property, value: String) : this(Operation.UPDATE_OR_CREATE, key, value)
    constructor(operation: Operation, key: Property, value: String) : super(
        operation,
        key.toString(),
        value
    )
}