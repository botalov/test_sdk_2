package io.carrotquest_sdk.android.core.util

import android.content.Context
import android.content.pm.ApplicationInfo

import android.content.pm.PackageManager
import android.os.Build
import java.text.Normalizer
import java.util.*
import java.util.regex.Pattern


class UserAgent private constructor(ctx: Context) {
    private val userAgentString: String

    /**
     * Returns UserAgent string in format
     * "application_name/application_version (package_name; build:version_code; Android android_version; Model:device_model) networkClientUserAgent"
     *
     * @param networkClientUserAgent user agent of used http client. For okhttp/3.20 (Version.userAgent())
     * @return user agent string
     */
    fun getUserAgentString(networkClientUserAgent: String?): String {
        return deaccent(String.format("%s %s", userAgentString, networkClientUserAgent))
    }

    /**
     * Get device model eg. Nexus 5X, SM-A310F etc.
     *
     * @return String device model
     */
    private val model: String
        get() = Build.MODEL

    /**
     * Get version of android as string eg. 4.1.2, 7.0.1 etc.
     *
     * @return String as android version
     */
    private val androidVersion: String
        get() = Build.VERSION.RELEASE

    /**
     * Get application version code
     *
     *
     * If retrieving of version code fails for any reason, number 0 is returned as version code
     *
     * @param ctx application Context
     * @return integer as version code
     */
    private fun getVersionCode(ctx: Context): Int {
        return try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode
        } catch (e: PackageManager.NameNotFoundException) {
            0
        }
    }

    /**
     * Get package name of application
     *
     * @param ctx application Context
     * @return String as package name
     */
    private fun getPackageName(ctx: Context): String {
        return ctx.packageName
    }

    /**
     * Get version name of application eg. 1.2.3
     *
     *
     * If retrieving of version names fails for any reason, string "Unknown" is returned as version name
     *
     * @param ctx application Context
     * @return String as version name
     */
    private fun getVersionName(ctx: Context): String {
        return try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (e: PackageManager.NameNotFoundException) {
            "Unknown"
        }
    }

    /**
     * Get name of application that is defined in AndroidManifest by application entity
     *
     * @param context application Context
     * @return String app name
     */
    private fun getApplicationName(context: Context): String {
        val applicationInfo: ApplicationInfo = context.applicationInfo
        val stringId = applicationInfo.labelRes
        return if (stringId == 0) applicationInfo.nonLocalizedLabel.toString() else context.getString(stringId)
    }

    companion object {
        val TAG = UserAgent::class.java.name
        private var instance: UserAgent? = null

        /**
         * Getter for singleton instance
         *
         * @param ctx application Context
         * @return instance of UserAgent class
         */
        fun getInstance(ctx: Context): UserAgent? {
            if (instance == null) {
                instance = UserAgent(ctx)
            }
            return instance
        }

        /**
         * Removes all the diacritics from the source string
         *
         * @param source the string you want to remove the diacritics from
         * @return the source string without any diacritics
         */
        private fun deaccent(source: String): String {
            val nfdNormalizedString: String = Normalizer.normalize(source, Normalizer.Form.NFD)
            val pattern: Pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+")
            return pattern.matcher(nfdNormalizedString).replaceAll("")
        }
    }

    /**
     * Private constructor that generates and caches User-Agent string
     *
     * @param ctx application Context
     */
    init {
        userAgentString = java.lang.String.format(Locale.US, "%s/%s (%s; build:%d; Android %s; Model:%s)", getApplicationName(ctx), getVersionName(ctx), getPackageName(ctx), getVersionCode(ctx), androidVersion, model)
    }
}