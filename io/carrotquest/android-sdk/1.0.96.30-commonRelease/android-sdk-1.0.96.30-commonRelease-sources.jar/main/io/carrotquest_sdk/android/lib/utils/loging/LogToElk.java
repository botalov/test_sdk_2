package io.carrotquest_sdk.android.lib.utils.loging;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.reactivex.Observable;
import io.reactivex.disposables.Disposable;

public class LogToElk {
    /**
     * Список идентификаторов аппов, для которых разрешено логирование в ELK
     * 2782 - тестовый апп
     * 61364- ЯСНО
     */
    String[] allowApps = {"2782", "61364"};

    private static LogToElk instance;
    private Observable<NetworkResponse> observable;

    private LogToElk() {
        NetworkManager.getInstance(CarrotLib.getLibComponents().getContext()).addObserver(isConnect -> {
if(isConnect) {
    repeat();
}
        }, throwable -> {

        }, () -> {

        });
    }

    public static LogToElk getInstance() {
        if (instance == null) {
            instance = new LogToElk();
        }

        return instance;
    }

    public void write(String appId, String message, MessageToElkType messageType, HashMap<String, Object> params) {
        //Проверка на то, что для аппа разрешена отпавка логов
        if (allowApps == null || allowApps.length == 0) {
            return;
        }

        boolean containsApp = false;
        for (String allowApp : allowApps) {
            if (appId.equals(allowApp)) {
                containsApp = true;
                break;
            }
        }

        if (!containsApp) {
            return;
        }

        //
        params.put("app_id", appId);
        try {
            params.put("os", "Android");
            params.put("version_os", android.os.Build.VERSION.RELEASE);
            params.put("user_id", CarrotLib.getLibComponents().getUserRep().getUser().getId());
            //params["version_sdk"] = sdkVersion

            SimpleDateFormat sdf = new SimpleDateFormat("dd/M/yyyy hh:mm:ss");
            String currentDate = sdf.format(new Date());
            params.put("event_time", currentDate);

            params.put("connection_type", NetworkManager.getInstance(CarrotLib.getLibComponents().getContext()).getConnectionType());
        } catch (Exception e) {
            params.put("add_params_error", e.toString());
        }


        observable = CarrotLib.getLibComponents().getCarrotApi().sendLog(
                messageType.name().toLowerCase(),
                "Android_SDK: $message",
                new JSONObject(params).toString()
        ).onErrorReturn(throwable -> {
            NetworkResponse errorResponse = new NetworkResponse();
            Meta meta = new Meta();
            meta.setStatus(403);
            meta.setError(throwable.toString());
            errorResponse.setMeta(meta);

            return errorResponse;
        });

        if (observable != null) {
            Disposable d = observable.subscribe(response -> {
                if (response.getStatus() == 200) {
                    observable = null;
                }
            });
        }
    }

    private void repeat() {
        if (observable != null) {
            Disposable d = observable.subscribe(networkResponse -> observable = null);
        }
    }

}
