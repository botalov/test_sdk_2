package io.carrotquest_sdk.android.lib.utils.json;

import androidx.annotation.NonNull;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class GsonUtil {
    public static boolean jsonElementNotNull(@NonNull JsonObject json, @NonNull String jsonName) {
        return json.has(jsonName) && !json.get(jsonName).isJsonNull();
    }

    public static boolean jsonElementNotNull(@NonNull JsonElement json, @NonNull String jsonName) {
        JsonObject jsonObject = json.getAsJsonObject();
        return jsonObject.has(jsonName) && !jsonObject.get(jsonName).isJsonNull();
    }
}
