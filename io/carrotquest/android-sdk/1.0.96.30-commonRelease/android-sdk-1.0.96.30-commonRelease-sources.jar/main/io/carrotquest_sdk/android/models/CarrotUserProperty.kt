package io.carrotquest_sdk.android.models

class CarrotUserProperty : UserProperty {
    enum class Property(private val text: String) {
        NAME("\$name"), PHONE("\$phone"), EMAIL("\$email");

        override fun toString(): String {
            return text
        }
    }

    constructor(key: String, value: String) : super(Operation.UPDATE_OR_CREATE, key, value)
    constructor(operation: Operation, key: String, value: String) : super(
        operation,
        key,
        value
    )

    constructor(key: Property, value: String) : this(Operation.UPDATE_OR_CREATE, key, value)
    constructor(operation: Operation, key: Property, value: String) : super(
        operation,
        key.toString(),
        value
    )
}