package io.carrotquest_sdk.android.data.network.js_interface

import android.content.Context

interface IJsListPresenter {
    fun onSelectConversation(context: Context, conversationId: String)
    fun paginationConversations()
    fun domUpdated()
}