package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.domain.entities.Optional
import io.carrotquest_sdk.android.core.util.Log
import io.reactivex.Observable

fun <T> Observable<T>.getLastConversation() : Observable<Optional<DataConversation>> {
    val tag = "Observable.getLastConversation()"
    return Observable.defer {
        return@defer this.flatMap {
            Observable.just(true)
                    .getConversations()
                    .getNotPopupConversationsHard()
                    .flatMap { x ->
                        x.sortByDescending { y->y.lastUpdate }
                        Observable.just(Optional(x.firstOrNull()))
                    }
                    .doOnError {
                        Log.e(tag, it.toString())
                    }
                    .take(1)
        }
    }
}