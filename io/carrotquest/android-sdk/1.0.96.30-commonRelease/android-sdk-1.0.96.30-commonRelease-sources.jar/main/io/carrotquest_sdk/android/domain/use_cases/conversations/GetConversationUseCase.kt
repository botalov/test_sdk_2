package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.domain.entities.Optional
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import io.reactivex.Observable

fun <T> Observable<T>.getConversation(conversationId: String) : Observable<Optional<DataConversation>> {
    val tag = "Observable.getConversation(conversationId)"
    return Observable.defer {
        return@defer this.flatMap {
            Observable.just(true)
                .getConversations()
                .flatMap { x ->
                    val iterator = x.iterator()
                    var foundConversation: DataConversation? = null
                    while (iterator.hasNext()) {
                        val item = iterator.next()
                        if (item.id != null && item.id == conversationId) {
                            foundConversation = item
                            break
                        }
                    }

                    if (foundConversation != null) {
                        return@flatMap Observable.just(Optional(foundConversation))
                    } else {
                        return@flatMap Observable.defer {
                            this.flatMap {
                                Observable.just(true)
                                    .getCurrentUser()
                                    .loadConversations()
                                    .doOnError{
                                        Log.d(tag, "")
                                    }
                                    .take(1)
                                    .flatMap { conversations ->
                                        val loadedConversation =
                                            conversations.filter { c -> c.id == null }.find { c -> c.id == conversationId }

                                        if (loadedConversation != null) {
                                            Observable.just(Optional(loadedConversation))
                                        } else {
                                            Observable.just(conversationId)
                                                .loadConversation()
                                                .doOnError{
                                                    Log.d(tag, "")
                                                }
                                                .take(1)
                                                .onErrorReturn {
                                                    return@onErrorReturn null
                                                }
                                                .flatMap {
                                                    //val loadedConversation = it.find { c -> c.id == conversationId }
                                                    Observable.just(Optional(it))
                                                }
                                        }
                                    }
                                    .doOnError { e ->
                                        Log.Companion.e(tag, e)
                                    }
                                    .onErrorReturn {
                                        return@onErrorReturn Optional(null)
                                    }
                            }
                        }
                    }
                }
                .onErrorReturn {
                    return@onErrorReturn Optional(null)
                }
                .take(1)
        }
    }
}