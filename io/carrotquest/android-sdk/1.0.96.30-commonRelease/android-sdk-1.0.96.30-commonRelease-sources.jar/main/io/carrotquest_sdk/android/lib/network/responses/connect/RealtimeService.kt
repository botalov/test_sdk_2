package io.carrotquest_sdk.android.lib.network.responses.connect

import androidx.annotation.Keep

@Keep
data class RealtimeService(
    val hosts: Map<Int, String>,
    val channels: List<String>
)
