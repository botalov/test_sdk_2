package io.carrotquest_sdk.android.lib.wss;

import java.util.List;

public class Channel {
    private List<String> params;
    private String name;

    public Channel(ChannelEnum channel) {
        this.name = channel.name();
        this.params = null;
    }

    public Channel(ChannelEnum channel, List<String> params) {
        this.name = channel.name();
        this.params = params;
    }

    public Channel(String chanelName) {
        this.params = null;
        this.name = chanelName;
    }

    public Channel(String chanelName, List<String> params) {
        this.params = params;
        this.name = chanelName;
    }

    /**
     * Есть ли параметры у канала
     * @return Флаг наличия параметров
     */
    public boolean hasParams() {
        return params != null && !params.isEmpty();
    }

    /**
     * @return Список параметров
     */
    public List<String> getParams(){
        return params;
    }

    /**
     * @return Название канала
     */
    public String getChannelName() {
        return name;
    }
}
