package io.carrotquest_sdk.android.lib.repositories;

import java.util.ArrayList;

import io.carrotquest_sdk.android.lib.models.User;

public interface IUserRepository {
    User getUser();
    void saveUser(User user);

    void removeUsers(ArrayList<String> removedUsers);

    void banUser(String userId);

    void unBanUser(String userId);
}
