package io.carrotquest_sdk.android.di;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import io.carrotquest_sdk.android.data.network.ConversationReplyChangedMessageDeserializer;
import io.carrotquest_sdk.android.data.network.ConversationReplyMessageDeserializer;
import io.carrotquest_sdk.android.data.network.ErrorDeserializer;
import io.carrotquest_sdk.android.data.network.ErrorResponse;
import io.carrotquest_sdk.android.data.network.PopUpDeserializer;
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationReplyChangedMessage;
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationReplyMessage;
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage;

/**
 * Date: 8/18/2016
 * Time: 14:50
 *
 * @author Artur Artikov
 */
@Module
public class GsonModule {
	private Gson gson;

	public GsonModule() {

		gson = new GsonBuilder()
				.registerTypeAdapter(ErrorResponse.class, new ErrorDeserializer())
				.registerTypeAdapter(ConversationReplyMessage.class, new ConversationReplyMessageDeserializer())
				.registerTypeAdapter(ConversationReplyChangedMessage.class, new ConversationReplyChangedMessageDeserializer())
				.registerTypeAdapter(PopUpMessage.class, new PopUpDeserializer())
				.create();
	}

	@Provides
	@Singleton
	public Gson provideGson() {
		return gson;
	}
}
