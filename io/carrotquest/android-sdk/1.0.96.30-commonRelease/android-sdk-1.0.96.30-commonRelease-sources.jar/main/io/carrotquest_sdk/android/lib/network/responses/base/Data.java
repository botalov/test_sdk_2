package io.carrotquest_sdk.android.lib.network.responses.base;

public class Data {

}
