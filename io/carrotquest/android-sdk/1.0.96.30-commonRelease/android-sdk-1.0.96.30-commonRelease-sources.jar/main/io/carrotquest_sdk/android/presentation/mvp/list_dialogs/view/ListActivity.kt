package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view

import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.network.js_interface.HistoryDialogsJSInterface
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.presentation.mvp.base.BaseSdkActivity
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogActivity
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.RootContainerForKeyboard
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.presenter.ListPresentation
import io.carrotquest_sdk.android.presentation.mvp.utils.isTablet
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView
import io.reactivex.Observer
import io.reactivex.disposables.Disposable

class ListActivity : BaseSdkActivity(), IListView {

    private val tag = "ListActivity"
    private val presenter = ListPresentation()
    companion object ARGS {
        const val APP_COLOR = "APP_COLOR"
    }
    private var startedFromNotification = false

    //private val dialogWebView = findViewById<CarrotWebView>(R.id.dialog_web_view)
    //private val errorTitleClTextView = findViewById<TextView>(R.id.error_title_cl_text_view)
    //private val errorMessageClTextView = findViewById<TextView>(R.id.error_message_cl_text_view)
    //private val errorContainerConversationsList = findViewById<ConstraintLayout>(R.id.error_container_conversation_list)
    //private val createNewConversationButton = findViewById<FloatingActionButton>(R.id.create_new_conversation_button)
    //private val closeImageButton = findViewById<ImageButton>(R.id.close_image_button)
    //private val topBar = findViewById<ConstraintLayout>(R.id.top_bar)

    override fun onCreate(savedInstanceState: Bundle?) {
        // Установка ориентации
        try {
            requestedOrientation = if(isTablet(this)) {
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        } catch (e: Exception) {
            Log.d("SetOrientation", "$e")
        }

        when (getThemeUseCase(this)) {
            SimpleTheme.DARK -> {
                setTheme(R.style.DarkCqSdkTheme)
            }
            else -> {
                setTheme(R.style.LightCqSdkTheme)
            }
        }

        super.onCreate(savedInstanceState)
        init()
    }

    fun init() {
        setContentView(R.layout.activity_list_dialogs_new)
        if(intent.hasExtra(DialogActivity.STARTED_FROM_NOT_ARG)) {
            startedFromNotification = intent.getBooleanExtra(DialogActivity.STARTED_FROM_NOT_ARG, false)
        }
        presenter.attachView(this)
        presenter.setIsStartedFromNotification(startedFromNotification)

        val color = intent?.getIntExtra(APP_COLOR, resources.getColor(R.color.colorButton))!!
        initViews(color)

        reloadWebView()
    }

    override fun onResume() {
        super.onResume()

        ViewCompat.setOnApplyWindowInsetsListener(findViewById<ConstraintLayout>(R.id.dialogs_list_activity_root_container)) { v, windowInsets ->
            val insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars())
            // Apply the insets as a margin to the view. This solution sets
            // only the bottom, left, and right dimensions, but you can apply whichever
            // insets are appropriate to your layout. You can also update the view padding
            // if that's more appropriate.
            val oldParams =  v.layoutParams

            val newParams = FrameLayout.LayoutParams(oldParams)
            newParams.leftMargin = insets.left
            newParams.bottomMargin = insets.bottom
            newParams.rightMargin = insets.right
            newParams.topMargin = insets.top

            v.layoutParams = newParams


            // Return CONSUMED if you don't want want the window insets to keep passing
            // down to descendant views.
            WindowInsetsCompat.CONSUMED
        }
    }

    override fun closeActivity() {
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        presenter.onDestroy()

        findViewById<CarrotWebView>(R.id.dialog_web_view).onDestroy()
    }

    override fun onBackPressed() {
        presenter.onBack()
    }

    override fun setupWebView(webView: CarrotWebView) {

    }

    override fun loadUrl() {
        findViewById<CarrotWebView>(R.id.dialog_web_view)?.loadUrl(BuildConfig.DIALOGS_HISTORY_URL)
        findViewById<CarrotWebView>(R.id.dialog_web_view)?.initJsInterface(HistoryDialogsJSInterface(this@ListActivity, presenter, findViewById<CarrotWebView>(R.id.dialog_web_view)))
    }

    override fun hideLoading() {
        findViewById<CarrotWebView>(R.id.dialog_web_view).hideLoading()
    }

    override fun initList(initJson: String) {
        runOnUiThread {
            findViewById<CarrotWebView>(R.id.dialog_web_view).executeJsInWebView(initJson)
        }
    }
    
    override fun addDialog(dialogJson: String) {
        runOnUiThread {
            findViewById<CarrotWebView>(R.id.dialog_web_view).executeJsInWebView(dialogJson)
        }
    }
    
    override fun deleteDialog(dialogJson: String) {
        runOnUiThread {
            findViewById<CarrotWebView>(R.id.dialog_web_view).executeJsInWebView(dialogJson)
        }
    }

    override fun updateDialog(dialogJson: String) {
        runOnUiThread {
            findViewById<CarrotWebView>(R.id.dialog_web_view).executeJsInWebView(dialogJson)
        }
    }

    override fun showErrorNoInternet() {
        runOnUiThread {
            findViewById<CarrotWebView>(R.id.dialog_web_view)?.showNoInternetError()
        }
    }

    override fun showErrorAirplaneMode() {
        runOnUiThread {
            findViewById<CarrotWebView>(R.id.dialog_web_view)?.showAirplaneModError()
        }
    }

    override fun showErrorSomething() {
        runOnUiThread {
            findViewById<CarrotWebView>(R.id.dialog_web_view)?.showLoadError()
        }
    }

    override fun showErrorFileNotFound() {

    }

    override fun showErrorSendMessage() {

    }

    override fun showEmptyList() {
        if (findViewById<TextView>(R.id.error_title_cl_text_view) != null) {
            findViewById<TextView>(R.id.error_title_cl_text_view).setText(R.string.empty_conversation_list_title)
        }
        if (findViewById<TextView>(R.id.error_message_cl_text_view) != null) {
            findViewById<TextView>(R.id.error_message_cl_text_view).setText(R.string.empty_conversation_list_message)
        }

        findViewById<ConstraintLayout>(R.id.error_container_conversation_list).visibility = View.VISIBLE
    }

    override fun hideError() {
        findViewById<ConstraintLayout>(R.id.error_container_conversation_list).visibility = View.GONE
    }

    private fun initViews(color: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            findViewById<ConstraintLayout>(R.id.top_bar).translationZ = 4f
        } else {
            findViewById<ConstraintLayout>(R.id.top_bar).findViewById<View>(R.id.old_android_separator)?.visibility = View.VISIBLE
        }

        findViewById<ImageButton>(R.id.close_image_button).setOnClickListener { onBackPressed() }

        val c: Int = when (getThemeUseCase(this)) {
            SimpleTheme.DARK -> {
                Color.parseColor("#FFFFFF")
            }
            else -> {
                color
            }
        }
        findViewById<ImageButton>(R.id.close_image_button).setColorFilter(c)

        findViewById<CarrotWebView>(R.id.dialog_web_view).setColor(color)

        //create_new_conversation_button.setOnClickListener({ v -> presenter.onNewConversation(this) })
        findViewById<FloatingActionButton>(R.id.create_new_conversation_button).backgroundTintList = ColorStateList.valueOf(color)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            findViewById<CarrotWebView>(R.id.dialog_web_view).setOnScroll { v, _, scrollY, _, oldScrollY ->
                val dy = scrollY - oldScrollY
                if (scrollY == 0 || dy < 0 && !findViewById<FloatingActionButton>(R.id.create_new_conversation_button).isShown) {
                    findViewById<FloatingActionButton>(R.id.create_new_conversation_button).show()
                } else if (dy > 0 && findViewById<FloatingActionButton>(R.id.create_new_conversation_button).isShown) {
                    findViewById<FloatingActionButton>(R.id.create_new_conversation_button).hide()
                }
            }
        }

        findViewById<FloatingActionButton>(R.id.create_new_conversation_button).setOnClickListener {
            presenter.onStartCreateConversation()
        }
    }

    private fun reloadWebView() {
        if (findViewById<CarrotWebView>(R.id.dialog_web_view) != null) {
            findViewById<CarrotWebView>(R.id.dialog_web_view).showLoading()

            findViewById<CarrotWebView>(R.id.dialog_web_view).addLoadingObserver(object : Observer<Boolean> {
                override fun onComplete() {

                }

                override fun onSubscribe(d: Disposable) {

                }

                override fun onNext(isLoadingWebView: Boolean) {
                    if (isLoadingWebView) {
                        presenter.webViewIsReady()
                    }
                }

                override fun onError(e: Throwable) {
                    Log.e(tag, e.toString())
                    showErrorSomething()
                }
            })
            findViewById<CarrotWebView>(R.id.dialog_web_view).setErrorObserver { isError ->
                presenter.onChangeErrorStateWebView(isError)
            }


            loadUrl()
        }
    }
}