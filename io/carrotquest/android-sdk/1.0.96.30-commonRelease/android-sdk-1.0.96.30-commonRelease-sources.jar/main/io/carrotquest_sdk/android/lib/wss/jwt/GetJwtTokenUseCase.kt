package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

fun getJwtToken(): String {
    return SharedPreferencesLib.getString(CarrotLib.getLibComponents().context, jwtTokenKey)
}