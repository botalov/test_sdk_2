package io.carrotquest_sdk.android.lib.network.responses.triggers

import androidx.annotation.Keep
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F

@Keep
class TriggerValue {
    @SerializedName(F.SDK_PAGE)
    @Expose
    private var url: String? = null

    @SerializedName(F.COMPARISON)
    @Expose
    private var comparison: String? = null

    fun getUrl(): String? {
        return this.url
    }
    fun setUrl(url: String) {
        this.url = url
    }

    fun getComparison(): String? {
        return this.comparison
    }

    fun setComparison(comparison: String) {
        this.comparison = comparison
    }
}