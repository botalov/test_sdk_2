package io.carrotquest_sdk.android.lib.network.responses.connect;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.models.App;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Data;
@Keep
public class DataConnect extends Data {
    @SerializedName(F.APP)
    private App app;
    @SerializedName(F.AUTH_TOKEN)
    private String authToken;
    @SerializedName(F.USER)
    private User user;
    @SerializedName(F.ID)
    private String id;
    @SerializedName(F.DEVICE_GUID)
    private String deviceId;
    @SerializedName(F.REALTIME_SERVICES)
    private RealtimeService realtimeServices;

    public App getApp() {
        return app;
    }

    public void setApp(App app) {
        this.app = app;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public void setRealtimeServices(RealtimeService realtimeServices) {
        this.realtimeServices = realtimeServices;
    }

    public RealtimeService getRealtimeServices() {
        return realtimeServices;
    }
}
