package io.carrotquest_sdk.android.presentation.mvp.web_view;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceResponse;
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager;
import com.google.android.gms.common.util.IOUtils;

import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.R;
import io.carrotquest_sdk.android.data.db.CarrotSdkDB;
import io.carrotquest_sdk.android.data.db.files.SavedFile;
import io.carrotquest_sdk.android.core.util.Log;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;

import javax.inject.Inject;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;

public class CarrotWebViewPresenter {

    @Inject
    CarrotSdkDB db;

    private CarrotWebView view;
    private Context context;

    private static final String TAG = "CarrotWebViewPresenter";

    //Наблюдатель за состоянием загрузки страницы
    private Observer<Boolean> doneLoadObserver = new Observer<Boolean>() {
        @Override
        public void onSubscribe(Disposable d) {
        }

        @Override
        public void onNext(Boolean isLoad) {
            if (isLoad) {
                view.hideLoadError();
            } else {
                //view.showLoadError();
            }
        }

        @Override
        public void onError(Throwable e) {
            view.setOtherErrorContent();
            view.showLoadError();
        }

        @Override
        public void onComplete() {
        }
    };
    private List<Observer<Boolean>> loadingObservers = new ArrayList<>();

    CarrotWebViewPresenter(Context context) {
        this.context = context;
    }

    public void attachView(CarrotWebView view) {
        this.view = view;

//        NetworkManager.getInstance(view.getContext())
//                .addObserver(isConnect -> {
//                    if(isConnect) {
//                        view.hideLoadError();
//                    } else {
//                        view.showLoadError();
//                    }
//
//                }, throwable -> Log.e(TAG, throwable), new Action() {
//                    @Override
//                    public void run() throws Exception {
//
//                    }
//                });

    }

    public void detachView() {
        this.view = null;
    }

    void onStartView() {
        //NetworkManager networkManager = NetworkManager.getInstance(this.context);// CarrotLib.getLibComponents(context, new UserRepository(context)).getWssService().getNetworkManager();
        NetworkManager.getInstance(this.context).addObserver(
                isConnect -> {
                    if (view != null) {
                        if (isConnect) {
                            view.hideLoadError();
                            view.reloadUrl();
                        } else {
                            if (NetworkManager.isAirplaneModeOn()) {
                                view.setAirModeErrorContent();
                                view.showAirplaneModError();
                            } else {
                                view.setLoadErrorContent();
                                view.showNoInternetError();
                            }

                        }
                    }
                },
                e -> {
                    view.setOtherErrorContent();
                    view.showLoadError();
                },
                () -> {
                    //onComplete
                }
        );
    }

    void onSetColor(int color) {
        view.updateColor(color);
    }

    void onAddLoadingObserver(Observer<Boolean> observer) {
        loadingObservers.add(observer);
    }

    void onPageFinished(boolean pageInError) {
        doneLoadObserver.onNext(pageInError);
        try {
            Iterator<Observer<Boolean>> iterator = loadingObservers.iterator();
            while (iterator.hasNext()) {
                try {
                    Observer<Boolean> observer = (Observer<Boolean>) iterator.next();
                    if (observer != null) {
                        observer.onNext(!pageInError);
                    }
                } catch (Exception e) {
                    Log.e(TAG, e);
                }
            }
        } catch (ConcurrentModificationException modificationException) {
            Log.e(TAG, modificationException);
        }
    }

    WebResourceResponse shouldInterceptRequest(Uri url) {
        if (url != null) {
            if (!url.toString().contains(BuildConfig.DIALOG_URL)
                    && !url.toString().contains(BuildConfig.DIALOGS_HISTORY_URL)
                    && !url.toString().contains(BuildConfig.BASE_FILES_URL)
                    && !url.toString().contains("carrotquest.io")
            ) {
                Log.d(TAG, "Запрос со сторонним URL: " + url.toString());
            }

            return overrideResource(url);
        } else {
            return null;
        }
    }

    private WebResourceResponse overrideResource(Uri url) {
        String strUri = url.toString().toLowerCase();
        String strFakeStart = view.getResources().getString(R.string.fake_start_uri_for_image).toLowerCase();
        String strICarrotFile = BuildConfig.BASE_FILES_URL.toLowerCase();
        if (strUri.contains(strFakeStart)) {
            String truePath = strUri.substring(strFakeStart.length());
            ContentResolver contentResolver = (view.getContext()).getContentResolver();
            try {
                return new WebResourceResponse(contentResolver.getType(url), "UTF-8", new FileInputStream(truePath));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        } else if (strUri.contains(strICarrotFile)) {
            if (db == null) {
                db = CarrotInternal.getLibComponent().getSdkDataBase();
            }
            if (db.savedFileDao() != null) {
                ContentResolver contentResolver = (view.getContext()).getContentResolver();
                SavedFile localFile = db.savedFileDao().getByURL(strUri);
                File lFile = new File(localFile != null ? localFile.localUri : "");
                if (lFile.exists()) {
                    try {
                        return new WebResourceResponse(contentResolver.getType(url), "UTF-8", new FileInputStream(lFile));
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        String type = MimeTypeMap.getSingleton().getMimeTypeFromExtension((MimeTypeMap.getFileExtensionFromUrl(url.toString())).toLowerCase());
                        if (type != null && type.contains("image")) {
                            File downloadedFile = downloadFile(url);
                            if (downloadedFile != null) {
                                return new WebResourceResponse(contentResolver.getType(url), "UTF-8", new FileInputStream(downloadedFile.getAbsolutePath()));
                            }
                        }
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return null;
    }

    private File downloadFile(Uri url) throws IOException {
        File imagesDirectory = context.getCacheDir();
        boolean directoryIsExist = imagesDirectory.exists();

        URL urlObj = new URL(url.toString());
        URLConnection urlConnection = urlObj.openConnection();
        InputStream urlInput = urlConnection.getInputStream();

        if (directoryIsExist) {
            String localNameFile = String.valueOf(System.currentTimeMillis()) + ".jpg";
            File file = new File(imagesDirectory, localNameFile);
            boolean fileIsExist = file.createNewFile();

            if (fileIsExist) {
                FileOutputStream fileOutputStream = new FileOutputStream(file, false);

                byte[] dataBA = IOUtils.toByteArray(urlInput);
                if (dataBA != null && dataBA.length > 0) {
                    fileOutputStream.write(dataBA);
                }

                urlInput.close();
                fileOutputStream.close();

                //save image info to db
                SavedFile savedFile = new SavedFile(String.valueOf(System.currentTimeMillis()));
                savedFile.localUri = file.getAbsolutePath();
                savedFile.url = url.toString();
                db.savedFileDao().insert(savedFile);

                return file;
            }
        }
        return null;
    }

    void onOpenOutsideUrl(String url) {
        view.openOutsideUrl(url);
    }
}
