package io.carrotquest_sdk.android.lib.utils.loging;

public enum MessageToElkType {
    RTS_CONNECT,
    RTS_DISCONNECT,
    RTS_MESSAGE,
    RTS_MESSAGE_ADDED_TO_REPO,
    DOWNLOAD_FILE,
}
