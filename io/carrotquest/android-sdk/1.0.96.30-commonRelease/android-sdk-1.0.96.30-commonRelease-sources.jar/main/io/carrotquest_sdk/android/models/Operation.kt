package io.carrotquest_sdk.android.models

enum class Operation {
    update_or_create,
    set_once,
    add,
    delete,
    append,
    union,
    exclude
}