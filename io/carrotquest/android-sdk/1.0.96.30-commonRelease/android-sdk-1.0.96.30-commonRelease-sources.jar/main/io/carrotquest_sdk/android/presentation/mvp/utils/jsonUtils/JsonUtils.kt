package io.carrotquest_sdk.android.presentation.mvp.utils.jsonUtils

import android.content.Context
import com.google.gson.JsonObject
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import java.util.*

fun prepareJsonSettings(joSettings: JsonObject, context: Context?): JsonObject {

    if (joSettings.has("app")) {
        val app = joSettings.getAsJsonObject("app")
        if (app.has("settings")) {
            val settings = app.getAsJsonObject("settings")
            if (settings.has("locale")) {
                settings.remove("locale")
            }
            var currentLang = Locale.getDefault().language
            if (currentLang != "en" && currentLang != "ru") {
                currentLang = "en"
            }

            if(settings.has("messenger_theme")) {
                settings.remove("messenger_theme")
            }
            val theme = getThemeUseCase(context)
            val themeStr = if( theme == SimpleTheme.DARK) "dark" else "light"
            settings.addProperty("messenger_theme", themeStr)

            settings.addProperty("locale", currentLang)

            app.remove("settings")
            app.add("settings", settings)
        }
        joSettings.remove("app")
        joSettings.add("app", app)
    }

    if (joSettings.has("knowledge_base_domain")) {
        var kbDomain = joSettings.get("knowledge_base_domain").asString
        if (kbDomain != null && !kbDomain.contains("http://") && !kbDomain.contains("https://")) {
            kbDomain = "//$kbDomain"
        }
        joSettings.remove("knowledge_base_domain")
        joSettings.addProperty("knowledge_base_domain", kbDomain)
    }


    return joSettings
}