package io.carrotquest_sdk.android.ui.fab;

import android.content.Context;
import android.util.AttributeSet;

import org.jetbrains.annotations.NotNull;

public class FloatingButton extends io.carrotquest_sdk.android.presentation.mvp.button.view.FloatingButton {

    public FloatingButton(@NotNull Context context) {
        super(context);
    }

    public FloatingButton(@NotNull Context context, @NotNull AttributeSet attrs) {
        super(context, attrs);
    }
}