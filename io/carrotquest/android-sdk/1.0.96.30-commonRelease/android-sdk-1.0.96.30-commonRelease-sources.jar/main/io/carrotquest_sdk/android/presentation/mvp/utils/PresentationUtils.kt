
package io.carrotquest_sdk.android.presentation.mvp.utils

import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.core.main.CarrotInternal
import java.util.*

fun convertMessageEntityToMessageView(message: MessageData) : MessageData {
    val attachments:  ArrayList<Attachment>? = if(message.attachments == null)  null else ArrayList()
    if(attachments != null) {
        for (a in message.attachments!!) {

            val db = CarrotInternal.getLibComponent().sdkDataBase
            val savedFile = db?.savedFileDao()?.getByURL(a.url)

            if (savedFile != null && !a.mimeType.contains("image")) {
                a.url = savedFile.localUri
            }

            if(savedFile != null && !a.mimeType.contains("image")) {
                a.status = "loaded"
            }


            attachments.add(a)
        }
    }

    message.attachments = attachments

    val res = MessageData()
    res.id = message.id
    res.attachments = message.attachments
    res.sourceJsonData = message.sourceJsonData
    res.randomId = message.randomId
    res.status = message.status
    res.isFirst = message.isFirst
    res.body = message.body
    res.bodyJson = message.bodyJson
    res.conversation = message.conversation
    res.created = message.created
    res.direction = message.direction
    res.expiraionTime = message.expiraionTime
    res.messageFrom = message.messageFrom
    res.read = message.read
    res.messageMetaData = message.messageMetaData
    res.replyType = message.replyType
    res.sentVia = message.sentVia
    res.type = message.type
    res.actions = message.actions

    return res
}