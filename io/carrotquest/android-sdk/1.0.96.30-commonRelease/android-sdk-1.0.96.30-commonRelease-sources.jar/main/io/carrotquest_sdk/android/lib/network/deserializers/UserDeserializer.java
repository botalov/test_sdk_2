package io.carrotquest_sdk.android.lib.network.deserializers;

import com.google.gson.Gson;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;

import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.base.Meta;
import io.carrotquest_sdk.android.lib.network.responses.user.UserData;
import io.carrotquest_sdk.android.lib.network.responses.user.UserResponse;
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil;

public class UserDeserializer implements JsonDeserializer<UserResponse> {

    public UserDeserializer() {
    }

    @Override
    public UserResponse deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        if(!(GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.META) && GsonUtil.jsonElementNotNull(json.getAsJsonObject(), F.DATA))) {
            throw new JsonParseException("UserDeserializer. meta is null or dataJsonElement is null");
        }

        JsonObject meta = json.getAsJsonObject().getAsJsonObject(F.META);
        JsonObject data = json.getAsJsonObject().getAsJsonObject(F.DATA);

        UserResponse response = new UserResponse();
        if (data != null) {
            response.setData(new Gson().fromJson(data, UserData.class));
        }
        if (meta != null) {
            response.setMeta(new Gson().fromJson(meta, Meta.class));
        }

        return response;
    }
}