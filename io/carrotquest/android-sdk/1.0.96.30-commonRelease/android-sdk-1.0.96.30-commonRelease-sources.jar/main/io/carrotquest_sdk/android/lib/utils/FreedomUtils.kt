package io.carrotquest_sdk.android.lib.utils


import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.lib.CarrotLib


//TODO FREEDOM удалить потом


//private const val FREEDOM_AP_ID = "4706"
const val FREEDOM_AP_ID = "7643"
private const val DASHLY_TOKEN_FLAG_KEY = "DASHLY_TOKEN_FLAG_KEY"

fun isFreedom(appId: String): Boolean = appId == FREEDOM_AP_ID

fun isDashly(): Boolean = BuildConfig.FLAVOR == "us"

fun hasSavedDashlyTokenFlag(): Boolean {
    val context = CarrotLib.getLibComponents().context

    return SharedPreferencesLib.getBoolean(
        context,
        DASHLY_TOKEN_FLAG_KEY
    )
}

fun saveDashlyTokenFlag() {
    val context = CarrotLib.getLibComponents().context
    SharedPreferencesLib.saveBoolean(context, DASHLY_TOKEN_FLAG_KEY, true)
}