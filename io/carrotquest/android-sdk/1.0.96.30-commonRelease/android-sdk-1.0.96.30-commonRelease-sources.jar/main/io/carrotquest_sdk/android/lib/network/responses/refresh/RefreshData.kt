package io.carrotquest_sdk.android.lib.network.responses.refresh

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F

@Keep
data class RefreshData(
    @SerializedName(F.ACCESS)
    val access: String,
    @SerializedName(F.REFRESH)
    val refresh: String,
)
