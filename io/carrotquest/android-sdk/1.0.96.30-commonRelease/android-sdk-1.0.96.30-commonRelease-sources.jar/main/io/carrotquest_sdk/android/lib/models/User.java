package io.carrotquest_sdk.android.lib.models;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

import io.carrotquest_sdk.android.lib.network.F;

@Keep
public class User {
    private String id;
    private String token;
    @SerializedName(F.HAS_CONVERSATIONS)
    public boolean hasConversations;
    @SerializedName(F.IS_BANNED)
    private boolean isBanned;
    @SerializedName(F.CONVERSATIONS_UNREAD)
    private ArrayList<String> conversationsUnread;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public boolean isHasConversations() {
        return hasConversations;
    }

    public void setHasConversations(boolean hasConversations) {
        this.hasConversations = hasConversations;
    }

    public boolean isBanned() {
        return isBanned;
    }

    public void setBanned(boolean banned) {
        isBanned = banned;
    }

    public ArrayList<String> getConversationsUnread() {
        return conversationsUnread;
    }

    public void setConversationsUnread(ArrayList<String> conversationsUnread) {
        this.conversationsUnread = conversationsUnread;
    }
}
