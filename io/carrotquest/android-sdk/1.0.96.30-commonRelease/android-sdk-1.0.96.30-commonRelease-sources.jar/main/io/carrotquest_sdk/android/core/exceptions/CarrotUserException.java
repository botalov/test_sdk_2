package io.carrotquest_sdk.android.core.exceptions;

public class CarrotUserException extends CarrotException {
    public CarrotUserException(String message) {
        super(message);
    }
}
