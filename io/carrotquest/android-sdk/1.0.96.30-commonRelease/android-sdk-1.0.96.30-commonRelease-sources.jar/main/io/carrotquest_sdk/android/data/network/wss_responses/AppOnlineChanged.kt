package io.carrotquest_sdk.android.data.network.wss_responses

import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings
import io.carrotquest_sdk.android.presentation.constans.StatusOperators
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable

class AppOnlineChanged : IRtsMessage {
    private val tag = "AppOnlineChanged"

    @SerializedName(F.STATUS)
    val statusOperators = "online"

    private val compositeDisposable = CompositeDisposable()

    override fun process() {
        compositeDisposable.add(Observable.just(true)
                .getSettings()
                .take(1)
                .subscribe({ settings ->
                    if (settings != null) {
                        val updatedSettings = SettingsEntity(
                                userId = settings.userId,
                                isShowVK = settings.isShowVK,
                                textLinkVK = settings.textLinkVK,
                                isShowViber = settings.isShowViber,
                                textLinkViber = settings.textLinkViber,
                                isShowFB = settings.isShowFB,
                                textLinkFB = settings.textLinkFB,
                                isShowTelegram = settings.isShowTelegram,
                                textLinkTelegram = settings.textLinkTelegram,
                                isShowInstagram = settings.isShowInstagram,
                                textLinkInstagram = settings.textLinkInstagram,
                                isShowWhatsapp = settings.isShowWhatsapp,
                                textLinkWhatsapp = settings.textLinkWhatsapp,
                                appColor = settings.appColor,
                                welcomeMessage = settings.welcomeMessage,
                                messengerAvatar = settings.messengerAvatar,
                                showPoweredBy = settings.showPoweredBy,
                                sourceData = settings.sourceData,
                                appName = settings.appName,
                                appId = settings.appId,
                                statusOperators = when (statusOperators) {
                                    StatusOperators.ONLINE.value -> {
                                        StatusOperators.ONLINE
                                    }
                                    StatusOperators.OFFLINE.value -> {
                                        StatusOperators.OFFLINE
                                    }
                                    else -> {
                                        StatusOperators.UNKNOWN
                                    }
                                },
                                onlineMessage = settings.onlineMessage,
                                offlineMessage = settings.offlineMessage,
                                admins = settings.admins,
                                theme = settings.theme,
                                locale = settings.locale,
                        )

                        SettingsRepository.getInstance().saveSettings(updatedSettings)
                        if (!compositeDisposable.isDisposed) {
                            compositeDisposable.dispose()
                        }
                    }

                }, { error ->
                    Log.e(tag, error.toString())
                }))
    }
}