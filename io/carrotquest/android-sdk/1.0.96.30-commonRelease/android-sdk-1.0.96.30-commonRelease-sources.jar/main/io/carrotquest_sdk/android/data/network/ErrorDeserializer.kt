package io.carrotquest_sdk.android.data.network

import com.google.gson.*
import io.carrotquest_sdk.android.core.constants.ResponseFields
import java.lang.IllegalStateException
import java.lang.reflect.Type
import kotlin.Exception

class ErrorDeserializer: JsonDeserializer<ErrorResponse> {
    @Throws(JsonParseException::class)
    override fun deserialize(json: JsonElement, typeOfT: Type?, context: JsonDeserializationContext?): ErrorResponse? {
        try {
            val meta = json.asJsonObject[ResponseFields.META]
            return Gson().fromJson(meta, ErrorResponse::class.java)
        } catch (e: IllegalStateException) {
            val errorResponse = ErrorResponse()
            errorResponse.error = e.toString()
            errorResponse.status = 400

            return errorResponse
        } catch (e: Exception) {
            val errorResponse = ErrorResponse()
            errorResponse.error = e.toString()
            errorResponse.status = 400

            return errorResponse
        }
    }
}