package io.carrotquest_sdk.android.core.exceptions;

public class CarrotException extends Exception {
    private CarrotException() {

    }

    CarrotException(String message){
        super(message);
    }
}
