package io.carrotquest_sdk.android.data.network;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.lib.network.responses.utils.ConvertUtilsKt;
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationReplyChangedMessage;

public class ConversationReplyChangedMessageDeserializer implements JsonDeserializer<ConversationReplyChangedMessage> {
    private static final String TAG = "ConversationReplyMessageDeserializer";

    @Override
    public ConversationReplyChangedMessage deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        MessageData messageData = ConvertUtilsKt.convertJsonToMessageData(json);
        return new ConversationReplyChangedMessage(messageData);
    }

}
