package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.entities.Optional
import io.reactivex.Observable

fun <T> Observable<T>.getMessage(messageId: String) : Observable<Optional<MessageData>> {
    val tag = "Observable.getMessages() "
    return Observable.defer {
        return@defer this.flatMap {
            MessagesRepository.getInstance().getData()
                    .doOnError {
                        Log.d(tag, "id = $it")
                    }
                    .map { x-> Optional(x.data?.find{m->m.id == messageId}) }
                    .doOnError {
                        Log.e(tag, "ERROR: $it")
                    }
        }
    }
}

