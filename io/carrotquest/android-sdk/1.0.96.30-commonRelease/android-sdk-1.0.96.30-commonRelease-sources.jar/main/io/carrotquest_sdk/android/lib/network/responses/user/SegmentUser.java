package io.carrotquest_sdk.android.lib.network.responses.user;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;
@Keep
public class SegmentUser {
    @SerializedName("id")
    private Integer id;
    @SerializedName("app")
    private Integer app;
    @SerializedName("name")
    private String name;
    @SerializedName("filters")
    private String filters;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getApp() {
        return app;
    }

    public void setApp(Integer app) {
        this.app = app;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFilters() {
        return filters;
    }

    public void setFilters(String filters) {
        this.filters = filters;
    }
}
