package io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

fun clearDraftMessageUseCase(conversationId: String) {
    val context = CarrotLib.getLibComponents().context
    SharedPreferencesLib.saveString(context, DRAFT_MESSAGES_KEY + conversationId, "")
}