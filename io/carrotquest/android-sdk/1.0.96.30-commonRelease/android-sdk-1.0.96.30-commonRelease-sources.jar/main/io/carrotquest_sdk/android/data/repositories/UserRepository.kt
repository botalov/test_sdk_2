package io.carrotquest_sdk.android.data.repositories

import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.reactivex.Observable
import io.reactivex.subjects.BehaviorSubject

class UserRepository {
    private val currentUserSubject: BehaviorSubject<UserEntity?> = BehaviorSubject.create()

    companion object {
        private var instance : UserRepository? = null
        fun getInstance(): UserRepository {
            if(instance == null) {
                instance = UserRepository()
            }
            return instance!!
        }
    }

    fun getUser() : Observable<UserEntity?> {
        return this.currentUserSubject
    }

    fun saveUser(user: UserEntity) {
        this.currentUserSubject.onNext(user)
    }
}