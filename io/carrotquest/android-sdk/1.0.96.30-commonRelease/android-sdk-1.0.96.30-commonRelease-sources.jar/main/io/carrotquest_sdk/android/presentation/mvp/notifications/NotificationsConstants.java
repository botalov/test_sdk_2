package io.carrotquest_sdk.android.presentation.mvp.notifications;

public class NotificationsConstants {
    public static final String CQ_SDK_NEW_MESSAGE_ARG = "NEW_MESSAGE_ARG";
    public static final String CQ_SDK_NEW_MESSAGE_ACTION = "io.carrotquest_sdk.android.CQ_SDK_NEW_MESSAGE_ACTION";
    public static final String CQ_SDK_PUSH = "is_carrot";

    public static final String CQ_SDK_PUSH_BODY_JSON = "body_json";
    public static final String CQ_SDK_PUSH_CLICK_ACTION = "click_action";

    public static final String CQ_SDK_AUTO_MESSAGE = "message_auto";
    public static final String CQ_SDK_SENT_VIA = "sent_via";

}
