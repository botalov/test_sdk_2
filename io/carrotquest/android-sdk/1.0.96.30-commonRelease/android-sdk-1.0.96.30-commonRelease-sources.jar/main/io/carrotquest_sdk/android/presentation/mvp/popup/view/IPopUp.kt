package io.carrotquest_sdk.android.presentation.mvp.popup.view

import android.content.Context
import io.reactivex.Observer

interface IPopUp {
    //TODO change it
    fun showContent(contentJson: String)
    fun setLoadWebViewObserver(loadWebViewObserver: Observer<Boolean>)
    fun closePopUp()
    fun executeJs(script: String)
    
    fun setHeight(h: Int)
    fun updatePoweredBy(providerName: String, providerIcon: Int)
    fun showPoweredBy()
    fun openLink(url: String)
    fun updateUpScroll(offsetFocusInput: Int)
    fun updateDownScroll()
    fun updateBackground(color: String)
    fun reload()

    fun getContext(): Context?
}