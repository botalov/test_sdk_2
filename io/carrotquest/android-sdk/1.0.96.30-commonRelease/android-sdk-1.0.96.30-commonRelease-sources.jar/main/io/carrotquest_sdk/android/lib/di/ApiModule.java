package io.carrotquest_sdk.android.lib.di;

import io.carrotquest_sdk.android.lib.CarrotApi;
import dagger.Module;
import dagger.Provides;
import io.carrotquest_sdk.android.lib.di.RetrofitModule;
import retrofit2.Retrofit;

import javax.inject.Singleton;

@Module(includes = {RetrofitModule.class})
public class ApiModule {
    @Provides
    @Singleton
    public CarrotApi provideApi(Retrofit retrofit) {
        return retrofit.create(CarrotApi.class);
    }
}
