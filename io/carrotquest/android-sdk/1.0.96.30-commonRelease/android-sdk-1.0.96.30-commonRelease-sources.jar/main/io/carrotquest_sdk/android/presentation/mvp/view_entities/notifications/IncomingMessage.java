package io.carrotquest_sdk.android.presentation.mvp.view_entities.notifications;

import java.io.Serializable;

public class IncomingMessage implements Serializable {
    
    public enum IncomingMessageSourceType implements Serializable{
        PUSH,
        RTS
    }

    public enum DirectionMessage implements Serializable {
        ADMIN_TO_USER,
        USER_TO_ADMIN
    }

    public enum MessageType implements Serializable {
        TEXT,
        ATTACHMENT
    }

    
    private String messageId;
    private String conversationId;
    private String text;
    private IncomingMessageSourceType messageSourceType;
    private DirectionMessage direction;
    private MessageType messageType;

    public IncomingMessage(IncomingMessageSourceType messageSourceType, String messageId, String conversationId, String text, DirectionMessage direction, MessageType messageType) {
        this.messageSourceType = messageSourceType;
        this.messageId = messageId;
        this.conversationId = conversationId;
        this.text = text;
        this.direction = direction;
        this.messageType = messageType;
    }

    public String getMessageId() {
        return messageId;
    }

    public String getConversationId() {
        return conversationId;
    }

    public String getText() {
        return text;
    }

    public IncomingMessageSourceType getMessageSourceType() {
        return messageSourceType;
    }

    public DirectionMessage getDirection() {
        return direction;
    }

    public MessageType getMessageType() {
        return messageType;
    }
}
