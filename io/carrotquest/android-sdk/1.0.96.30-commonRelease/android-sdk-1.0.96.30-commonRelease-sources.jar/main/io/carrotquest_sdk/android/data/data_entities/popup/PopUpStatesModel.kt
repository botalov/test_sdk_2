package io.carrotquest_sdk.android.data.data_entities.popup

enum class PopUpStatesModel {
    PROCESS,
    SHOWED,
    FAILED
}