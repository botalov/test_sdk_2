package io.carrotquest_sdk.android.domain.use_cases.popup

import android.util.Pair
import io.carrotquest_sdk.android.lib.utils.isDashly
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.files.download_files.DownloadUtil
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

fun Single<PopUpMessage>.saveImages(appId: String?) : Single<PopUpMessage> {
    return Single.defer {
        val baseUrl = if (isDashly()) "https://files.dashly.app/message-images/${appId ?: ""}/" else "https://files.carrotquest.io/message-images/${appId ?: ""}/"
        this
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .flatMap {
                    val sourceEntity = it
                    val savedFiles = ArrayList<Pair<String, String>>()
                    val needSavedFiles = ArrayList<String>()
                    for (row in sourceEntity.rows) {
                        for (block in row.blocks) {
                            if (block.backgroundImage != null && block.backgroundImage.isNotEmpty()) {
                                needSavedFiles.add(
                                        if (!block.backgroundImage.contains("http://") && !block.backgroundImage.contains("https://"))
                                    baseUrl + block.backgroundImage
                                else
                                    block.backgroundImage
                                )
                            }
                        }
                    }

                    DownloadUtil.downloadFilesToCash(needSavedFiles, baseUrl)
                            .doOnNext { p ->
                                savedFiles.add(p)
                                Log.d("saveImages(). image = ", p.second)
                            }
                            .subscribe({}, { t ->
                                val s = if (needSavedFiles.isNullOrEmpty()) {
                                    var temp = ""
                                    for (item in needSavedFiles) {
                                        temp += ("$item, ")
                                    }
                                    temp
                                } else {
                                    "needSavedFiles is empty or null"
                                }
                                Log.e("saveImages()", t)
                                Log.e("saveImages()", s)
                            })

                    return@flatMap Single.just(sourceEntity)

                }
    }
}