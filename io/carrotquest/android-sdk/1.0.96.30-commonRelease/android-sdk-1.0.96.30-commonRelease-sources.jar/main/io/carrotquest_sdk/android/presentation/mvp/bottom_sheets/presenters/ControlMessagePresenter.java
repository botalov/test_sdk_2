package io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.presenters;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.R;
import io.carrotquest_sdk.android.data.repositories.MessagesRepository;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.BaseBottomSheetSDKActivity;

/**
 * Презентер для работы управления сообщениями в диалоге
 */
public class ControlMessagePresenter {
    private Context context;
    private BaseBottomSheetSDKActivity view;

    public ControlMessagePresenter(Context context) {
        this.context = context;
    }

    public void attachView(BaseBottomSheetSDKActivity view) {
        this.view = view;
    }

    public void detachView() {
        this.view = null;
    }

    private void showCopyError() {
        String messageError = context == null ? "Error" : context.getResources().getString(R.string.copy_text_error_message);
        view.showError(messageError);
        view.finish();
    }

    /**
     * Копирование текста сообщения
     *
     * @param messageId Идентификатор сообщения
     */
    public void onCopyText(String messageId) {
        if (messageId == null) {
            showCopyError();
            return;
        }

        try {
            MessageData message = MessagesRepository.Companion.getInstance().findMessageById(messageId);
            if (message != null) {
                ClipboardManager clipboard = (ClipboardManager) CarrotInternal.getLibComponent().getContextSdk().getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText(message.getBody(), message.getBody());
                clipboard.setPrimaryClip(clip);
                view.showMessageInfo(CarrotInternal.getLibComponent().getContextSdk().getString(R.string.copy_text_done_message));
                view.finish();
            } else {
                showCopyError();
            }
        } catch (Exception e) {
            showCopyError();
        }
    }

    /**
     * Удаление сообщения из диалога
     *
     * @param messageId Идентификатор сообщения
     */
    public void onDeleteMessage(String messageId) {
        MessageData message = MessagesRepository.Companion.getInstance().findMessageById(messageId);
        if (message != null) {
            MessagesRepository.Companion.getInstance().removeMessage(message);

        } else {
            view.showError(CarrotInternal.getLibComponent().getContextSdk().getString(R.string.delete_message_error_message));
        }
        view.finish();
    }

    /**
     * Повторная попытка отправки сообщения
     *
     * @param messageId Идентификатор сообщения
     */
    public void onRepeatSendMessage(String messageId) {
        MessageData message = MessagesRepository.Companion.getInstance().findMessageById(messageId);
        if (message != null) {
            /*MessagesRepository.Companion.getInstance().updateMessageStatus(message.getId(), MessageStatus.LOADING.name().lowercase());
            String conversationId = message.getConversation();

            CarrotInternal.getService().reply(conversationId, message.getBody(), true, message.getId(), new DisposableObserver<ReplyResponse>() {
                @Override
                public void onNext(ReplyResponse replyResponse) {
                    if (replyResponse != null && replyResponse.getMeta() != null && replyResponse.getMeta().getStatus() == 200) {
                        messagesRepository.updateMessageStatus(message.getId(), MessageStatus.NORMAL.name().lowercase());
                        messagesRepository.updateMessageId(message.getId(), replyResponse.getData().getId());

                    } else {
                        messagesRepository.updateMessageStatus(message.getId(), MessageStatus.WARNING.name().lowercase());
                    }
                }

                @Override
                public void onError(Throwable e) {
                    messagesRepository.updateMessageStatus(message.getId(), MessageStatus.WARNING.name().lowercase());
                }

                @Override
                public void onComplete() {
                }
            });*/

        } else {
            view.showError(CarrotInternal.getLibComponent().getContextSdk().getString(R.string.repeat_message_error_message));
        }
        view.finish();
    }

    /**
     * Открытие изображения по тапу на него
     *
     * @param imageUrl Адрес изображения
     */
    public void openImage(String imageUrl) {

    }

    /**
     * Переход по ссылке в тексте сообщения
     *
     * @param link Ссылка
     */
    public void openLink(String link) {

    }

    /**
     * Скаичвание прикрепленного файла
     *
     * @param messageId Идентификатор сррбщения
     */
    public void downloadAttachment(String messageId) {

    }

    /**
     * Отмена отправки файла
     *
     * @param messageId Идентификатор сообщения
     */
    public void cacelUploadFile(String messageId) {

    }
}