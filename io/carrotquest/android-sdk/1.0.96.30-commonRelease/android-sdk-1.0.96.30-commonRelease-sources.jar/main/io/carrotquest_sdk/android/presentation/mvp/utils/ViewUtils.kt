package io.carrotquest_sdk.android.presentation.mvp.utils

import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.view.View

internal fun bubbleToFront(view: View) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        view.elevation = 57f // Это магическое число выбрано из-за того, что по дефолту elevation у FAB = 56
    }
    view.bringToFront()
}

internal fun getScale(context: Context) : Float {
    return context.resources.displayMetrics.density;
}

internal fun isTablet(context: Context): Boolean {
    val xlarge =
        context.resources.configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK === 4
    val large =
        context.resources.configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK === Configuration.SCREENLAYOUT_SIZE_LARGE
    return xlarge || large
}

internal fun checkOrientation(context: Context, currentOrientation: Int): Boolean {
    return if (isTablet(context)) {
        currentOrientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                || currentOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    } else {
        currentOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                || currentOrientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
    }
}
