package io.carrotquest_sdk.android.core.util.files.download_files;

import android.os.Environment;
import androidx.annotation.NonNull;
import android.util.Pair;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.data.db.CarrotSdkDB;
import io.carrotquest_sdk.android.data.db.files.SavedFile;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Action;
import io.reactivex.functions.Function;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.schedulers.Schedulers;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

public class DownloadUtil {
    private static final String TAG = "DownloadUtil";
    public static final String BASE_URL = BuildConfig.BASE_FILES_URL;

    private static DownloadAPI api;

    static DisposableObserver<InputStream> download(String messageId, String url, long size, Observer<Integer> processObserver) {
        url = url.substring(BASE_URL.length() + 1);
        String fileName = url.substring(url.lastIndexOf('/') + 1);
        fileName = getFreeName(fileName, fileName, 1);

        File outputFile = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), fileName);


        DownloadProgressListener listener = (bytesRead, done) -> {
            int progress = (int) ((bytesRead * 100) / size);
            if (progress > 100) {
                progress = 100;
            }
            if (progress < 0) {
                progress = 0;
            }
            if(progress == 100) {
//                MessagesRepository.Companion.getInstance().getData().subscribe(new Consumer<MessagesResponse>() {
//                    @Override
//                    public void accept(MessagesResponse messagesResponse) throws Exception {
//                        Log.d("TEST_XXXXX", "1ccc");
//                        MessageData message = null;
//                        for(int i=0;i<messagesResponse.getData().size(); i++) {
//                            MessageData m = messagesResponse.getData().get(i);
//                            if(messageId.equals(m.getId()) || messageId.equals(m.getRandomId())) {
//                                message = m;
//                                break;
//                            }
//                        }
//
//                        if(message != null) {
//                            Log.d("TEST_XXXXX", "2");
//                            List<Attachment> atts = message.getAttachments();
//                            Log.d("TEST_XXXXX", "3 " + atts.size());
//                        }
//                    }
//                });
            }

            processObserver.onNext(progress);
        };




        api = new DownloadAPI(BASE_URL, listener);
        return api.downloadFile(url, outputFile, processObserver);

    }

    /**
     * Загружает сразу всю пачку файлов
     * @param urls Список файлов
     * @param baseUrl Базовая Url
     * @return Поток данных с абсолютными именами скаченных файлов
     */
    public static Observable<Pair<String, String>> downloadFilesToCash(ArrayList<String> urls, String baseUrl) {
        Observable<Pair<String, String>> res = Observable.just(new Pair<>("", ""));

        DownloadAPI api = new DownloadAPI(baseUrl);
        for (String url : urls) {
            if(!url.isEmpty()) {
                String fileNameUrl = url.substring(baseUrl.length());
                String fileName = fileNameUrl.substring(fileNameUrl.lastIndexOf('/') + 1);
                fileName = getFreeName(fileName, fileName, 1);

                String folderToSave = Environment.getExternalStorageDirectory().getPath();
                File folder = new File(folderToSave,"cq_sdk_cache");

                if (!folder.exists()) {
                    boolean x = folder.mkdir();
                }
                File outputFile = new File(folder, fileName);
                try {
                    outputFile.createNewFile();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                res = res.mergeWith(
                        api.downloadFile(url, outputFile)
                                .doOnNext(s -> {
                                    Log.d("","");
                                })
                                .doOnError(throwable -> {
                                    Log.d("",throwable.toString());
                                })
                                .map(s -> new Pair<>(url, s))
                );
            }
        }

        return res;
    }

    static void cancelDownload(DisposableObserver observer) {
        if (api != null && observer != null && !observer.isDisposed()) {
            observer.dispose();
        }
    }

    public static String getFreeName(String originalName, String modifyName, int suffNumber) {
        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), modifyName);
        if (!file.exists()) {
            return modifyName;
        }

        modifyName = stripExtension(originalName)[0] + " (" + String.valueOf(suffNumber) + ")" + stripExtension(originalName)[1];
        suffNumber++;
        return getFreeName(originalName, modifyName, suffNumber);
    }

    private static String[] stripExtension(String str) {
        if (str == null) {
            return null;
        }

        int pos = str.lastIndexOf(".");
        if (pos == -1) {
            return new String[]{str, ""};
        }

        return new String[]{str.substring(0, pos), str.substring(pos)};
    }


    private static class DownloadAPI {
        private static final String TAG = "DownloadAPI";
        private static final int DEFAULT_TIMEOUT = 15;
        private Retrofit retrofit;

        DownloadAPI(String baseUrl, DownloadProgressListener listener) {

            DownloadProgressInterceptor interceptor = new DownloadProgressInterceptor(listener);

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(interceptor)
                    .retryOnConnectionFailure(true)
                    .connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(client)
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.createWithScheduler(Schedulers.io()))
                    .build();
        }

        DownloadAPI(String baseUrl) {
            OkHttpClient client = new OkHttpClient.Builder()
                    .retryOnConnectionFailure(true)
                    .connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)
                    .build();

            retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(client)
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.createWithScheduler(Schedulers.io()))
                    .build();
        }

        DisposableObserver<InputStream> downloadFile(@NonNull String url, final File file, Observer<Integer> processObserver) {

            DisposableObserver<InputStream> observer = new DisposableObserver<InputStream>() {
                @Override
                public void onNext(InputStream inputStream) {
                }

                @Override
                public void onError(Throwable e) {
                    Log.e(TAG, e.toString());
                }

                @Override
                public void onComplete() {


                }
            };

            return retrofit.create(DownloadService.class)
                    .download(url)
                    .subscribeOn(Schedulers.io())
                    .unsubscribeOn(Schedulers.io())
                    .map(ResponseBody::byteStream)
                    .doOnError(throwable -> {
                        Log.e(TAG, throwable.toString());
                    })
                    .onErrorReturn(new Function<Throwable, InputStream>() {
                        @Override
                        public InputStream apply(Throwable throwable) throws Exception {
                            return null;
                        }
                    })
                    .observeOn(Schedulers.computation())
                    .doOnNext(
                            stream -> {
                                saveFile(stream, file);

                            })
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnError(throwable -> {
                        Log.e(TAG, throwable.toString());
                    })
                    .doOnComplete(new Action() {
                        @Override
                        public void run() throws Exception {
                            CarrotSdkDB db = CarrotInternal.getLibComponent().getSdkDataBase();

                            SavedFile savedFile = new SavedFile(String.valueOf(System.currentTimeMillis()));
                            savedFile.localUri = file.getAbsolutePath();
                            savedFile.url = BASE_URL + "/" + url;
                            db.savedFileDao().insert(savedFile);


                        }
                    })
                    .doOnDispose(new Action() {
                        @Override
                        public void run() throws Exception {
                            processObserver.onError(new Exception("Cancel"));
                            if (file.exists()) {
                                file.delete();
                            }
                            CarrotSdkDB db = CarrotInternal.getLibComponent().getSdkDataBase();
                            SavedFile savedFile = db.savedFileDao().getByURL(BASE_URL + url);
                            if (savedFile != null) {
                                db.savedFileDao().delete(savedFile.url);
                            }
                        }
                    })
                    .subscribeWith(observer);
        }

        Observable<String> downloadFile(@NonNull String url, final File file) {

            return retrofit.create(DownloadService.class)
                    .download(url)
                    .subscribeOn(Schedulers.io())
                    .unsubscribeOn(Schedulers.io())
                    .map(ResponseBody::byteStream)
                    .observeOn(Schedulers.computation())
                    .doOnNext(
                            stream -> {
                                if(file.exists()) {
                                    saveFile(stream, file);
                                }

                            })
                    .observeOn(AndroidSchedulers.mainThread())
                    .doOnError(throwable -> {
                        Log.e(TAG, throwable.toString());
                    })
                    .doOnComplete(() -> {
                        if(file.exists()) {
                            CarrotSdkDB db = CarrotInternal.getLibComponent().getSdkDataBase();

                            SavedFile savedFile = new SavedFile(String.valueOf(System.currentTimeMillis()));
                            savedFile.localUri = file.getAbsolutePath();
                            savedFile.url = BASE_URL + url;
                            db.savedFileDao().insert(savedFile);
                        }
                    })
                    .doOnDispose(() -> {
                        //processObserver.onError(new Exception("Cancel"));
                        if (file.exists()) {
                            file.delete();
                        }
                        CarrotSdkDB db = CarrotInternal.getLibComponent().getSdkDataBase();
                        SavedFile savedFile = db.savedFileDao().getByURL(BASE_URL + url);
                        if (savedFile != null) {
                            db.savedFileDao().delete(savedFile.url);
                        }
                    })
                    .map(inputStream -> file.getAbsolutePath());
        }

        private void saveFile(InputStream stream, File file) {
            try {
                if(!file.exists()) {
                    file.createNewFile();
                }

                if(file.exists()) {
                    OutputStream output = new FileOutputStream(file);
                    try {
                        byte[] buffer = new byte[4 * 1024];// IOUtils.toByteArray(stream);
                        int read;

                        while ((read = stream.read(buffer)) != -1) {
                            output.write(buffer, 0, read);
                        }

                        output.flush();

                    } catch (Exception ex) {
                        Log.e(TAG, ex);
                    } finally {
                        output.close();
                    }
                }
            } catch (IOException ioEx) {
                Log.e(TAG, ioEx.toString());
            }
        }

    }

    public static MessagesResponse replaceFilesLocalUrl(MessagesResponse response) {
        if(response == null) {
            return null;
        }

        if(response.getData() == null) {
            return null;
        }


        for(int i=0; i<response.getData().size(); i++) {

            if(response.getData().get(i).getAttachments() == null || response.getData().get(i).getAttachments().isEmpty()) {
                continue;
            }

            for (int j=0; j<response.getData().get(i).getAttachments().size(); j++) {
                CarrotSdkDB db = CarrotInternal.getLibComponent().getSdkDataBase();
                SavedFile savedFile = db.savedFileDao().getByURL(response.getData().get(i).getAttachments().get(j).getUrl());

                if ( savedFile != null && (new File(savedFile.localUri).exists()) && !response.getData().get(i).getAttachments().get(j).getMimeType().contains("image")) {
                    response.getData().get(i).getAttachments().get(j).setUrl(savedFile.localUri);
                    response.getData().get(i).getAttachments().get(j).setType("loaded");
                    response.getData().get(i).getAttachments().get(j).setStatus("loaded");

                    response = replaceFileLocalUrlInSource(response, savedFile);
                }
            }
        }

        return response;
    }

    public static MessagesResponse replaceFileLocalUrlInSource(MessagesResponse response, SavedFile savedFile) {
        if(response == null) {
            return null;
        }

        if(response.getSourceData() == null) {
            return response;
        }

        JsonElement sourceData = response.getSourceData();
        if(sourceData.isJsonArray()) {
            JsonArray jsonArray = sourceData.getAsJsonArray();
            for(int i = 0; i< jsonArray.size(); i++) {
                JsonElement jsonMessage = jsonArray.get(i);
                if(jsonMessage.isJsonObject()) {
                    if(jsonMessage.getAsJsonObject().has(F.ATTACHMENTS) && jsonMessage.getAsJsonObject().get(F.ATTACHMENTS).isJsonArray()) {
                        JsonArray jsonAttachments = jsonMessage.getAsJsonObject().get(F.ATTACHMENTS).getAsJsonArray();
                        for(int j=0; j< jsonAttachments.size(); j++) {
                            if(jsonAttachments.get(j).isJsonObject()
                                    && jsonAttachments.get(j).getAsJsonObject().has(F.URL)
                                    && savedFile.url.equals(jsonAttachments.get(j).getAsJsonObject().get(F.URL).getAsString())) {

                                jsonAttachments.get(j).getAsJsonObject().remove(F.URL);
                                jsonAttachments.get(j).getAsJsonObject().addProperty(F.URL, savedFile.localUri);

                                jsonAttachments.get(j).getAsJsonObject().remove(F.TYPE);
                                jsonAttachments.get(j).getAsJsonObject().addProperty(F.TYPE, "loaded");

                                jsonAttachments.get(j).getAsJsonObject().remove(F.STATUS);
                                jsonAttachments.get(j).getAsJsonObject().addProperty(F.STATUS, "loaded");

                            }
                        }
                    }
                }
            }
            response.setSourceData(sourceData);

        } else {
            return response;
        }

        return response;
    }
}
