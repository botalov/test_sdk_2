package io.carrotquest_sdk.android.core.main;

import io.carrotquest_sdk.android.di.SdkLibComponent;
import io.carrotquest_sdk.android.data.service.CarrotService;

public class CarrotInternal {
    private static CarrotSDK.Callback<Boolean> closeChatCallback;
    public static CarrotSDK.Callback<Boolean> getCloseChatCallback() {
        return closeChatCallback;
    }
    public static void updateCloseChatCallback(CarrotSDK.Callback<Boolean> callback) {
        closeChatCallback = callback;
    }

    public static CarrotService getService() {
        return CarrotSDK.libComponent.getCarrotService();
    }
    public static SdkLibComponent getLibComponent() {
        return CarrotSDK.libComponent;
    }
}

