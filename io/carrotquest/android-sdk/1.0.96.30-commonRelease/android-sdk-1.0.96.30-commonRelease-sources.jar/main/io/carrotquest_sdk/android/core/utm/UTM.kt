package io.carrotquest_sdk.android.core.utm

enum class UTM(val value: String) {
    SOURCE("utm_source"),
    MEDIUM("utm_medium"),
    CAMPAIGN("utm_campaign"),
    TERM("utm_term"),
    CONTENT("utm_content")
}