package io.carrotquest_sdk.android.domain.entities.popup

import io.carrotquest_sdk.android.domain.entities.popup.content.IBlockContent

data class BlockPopUp(
        val id: String,
        val content: IBlockContent
)