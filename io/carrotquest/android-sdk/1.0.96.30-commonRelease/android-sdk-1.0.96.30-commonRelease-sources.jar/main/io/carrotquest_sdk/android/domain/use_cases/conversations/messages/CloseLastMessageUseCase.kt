package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.domain.entities.Optional
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.messages.ClosedMessage
import io.carrotquest_sdk.android.core.util.Log
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.observers.DisposableSingleObserver
import io.reactivex.schedulers.Schedulers

fun Observable<Optional<MessageData>>.closeLastMessage() : Observable<Optional<MessageData>> {
    val tag = "Observable.closeLastMessage()"
    return Observable.defer {
        return@defer this.flatMap {
            Observable.just(it)
                    .doOnNext { res ->
                        val message = res.value
                        if (message != null) {
                            val db: CarrotSdkDB = SdkApp.getInstance().database
                            val newId = message.id
                            db.closedMessageDao().getById(newId)
                                    .subscribeOn(Schedulers.io())
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribe(object : DisposableSingleObserver<ClosedMessage>() {
                                        override fun onSuccess(t: ClosedMessage) {
                                            Log.d(tag, "write new closed message")
                                        }

                                        override fun onError(e: Throwable) {
                                            db.closedMessageDao().insert(ClosedMessage(newId))
                                        }
                                    })
                        }
                    }
                    .doOnError { error ->
                        Log.e(tag, error)
                    }

        }
    }
}