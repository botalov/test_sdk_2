package io.carrotquest_sdk.android.lib.wss.jwt

const val jwtTokenLiveTime: Long = 3_000_000 //50 * 60 * 1000  //minutes * seconds * milliseconds
const val refreshTokenLiveTime: Long = 2_592_000_000 //30 * 24 * 60 * 60 * 1000 //days * hours * minutes * seconds * milliseconds

const val jwtTokenKey = "JWT_TOKEN_KEY"
const val refreshTokenKey = "REFRESH_TOKEN_KEY"
const val jwtTokenUpdateTimeStampKey = "JWT_TOKEN_UPDATE_TIMESTAMP_KEY"
const val refreshTokenUpdateTimeStampKey = "REFRESH_TOKEN_UPDATE_TIMESTAMP_KEY"