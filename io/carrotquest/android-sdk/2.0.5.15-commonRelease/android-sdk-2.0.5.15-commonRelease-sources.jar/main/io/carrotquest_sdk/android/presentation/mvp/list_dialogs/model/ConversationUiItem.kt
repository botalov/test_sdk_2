package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model

import androidx.compose.runtime.Immutable

@Immutable
data class ConversationUiItem(
    val id: String,
    val lastMessageText: String,
    val lastMessagePrefix: String? = null,  // имя оператора перед текстом, без HTML
    val lastMessageIcon: PreviewIcon = PreviewIcon.NONE,
    val lastMessageTime: String,
    val unreadCount: Int,
    val adminName: String?,
    val adminAvatarUrl: String?,
    val lastAdminId: String?,
    val isClosed: Boolean,
    val isRecent: Boolean,
    // true, если последнее сообщение было удалено — превью рендерится тем же
    // приглушённым цветом, что и имя оператора, чтобы визуально отличаться от
    // обычного текста сообщения.
    val isLastMessageDeleted: Boolean = false,
)

enum class PreviewIcon { NONE, IMAGE, FILE, KNOWLEDGE_BASE_ARTICLE }
