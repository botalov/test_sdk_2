package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import java.util.Date

fun isActualJwtToken(context: Context = CarrotLib.getLibComponents().getContext()): Boolean {
    val jwtToken = getJwtToken()
    Log.i("JWT_RTS", "jwtToken = $jwtToken")
    val refreshToken = getRefreshToken()
    Log.i("JWT_RTS", "refreshToken = $refreshToken")
    //Если токен не найден, то он актуальный
    if(jwtToken.isEmpty()) {
        val oldToken = SharedPreferencesLib.getString(context, "CarrotToken")
        Log.i("JWT_RTS", "oldToken = $oldToken")
        if(oldToken.isNotEmpty()) {
            return false
        }

        Log.i("JWT_RTS", "refreshToken.isNullOrEmpty() 1 = ${refreshToken.isNullOrEmpty()}")
        return refreshToken.isNullOrEmpty()
    }

    val updateTokenTimeStamp = getLastUpdateJwtTokenTime()
    //Если не найден таймштамп сохранения токена, то токен актуальный
    if(updateTokenTimeStamp <= 0) {
        Log.i("JWT_RTS", "refreshToken.isNullOrEmpty() 2 = ${refreshToken.isNullOrEmpty()}")
        return refreshToken.isNullOrEmpty()
    }

    val nowTime = Date().time

    //Токен актуальный, если разница между текущим временем и временем обновления токена меньше 55 минут
    Log.i("JWT_RTS", "nowTime - updateTokenTimeStamp = ${nowTime - updateTokenTimeStamp}")
    Log.i("JWT_RTS", "jwtTokenLiveTime = $jwtTokenLiveTime")
    Log.i("JWT_RTS", "nowTime - updateTokenTimeStamp < jwtTokenLiveTime = ${nowTime - updateTokenTimeStamp < jwtTokenLiveTime}")
    return nowTime - updateTokenTimeStamp < jwtTokenLiveTime
}