package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.utils.loging.Log
import java.util.Date

fun saveJwtToken(token: String, context: Context = CarrotLib.getLibComponents().getContext()) {
    val oldToken = getJwtToken()
    if(oldToken != token) {
        val currentTime = Date().time
        Log.i("JWT_RTS", "update save token time: $currentTime")
        SharedPreferencesLib.saveLong(context, jwtTokenUpdateTimeStampKey, currentTime)
    }

    Log.i("JWT_RTS", "update JWT-token: $token ($oldToken)")
    SharedPreferencesLib.saveString(context, jwtTokenKey, token)
}