package io.carrotquest_sdk.android.lib.managers.network;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import io.carrotquest_sdk.android.core.util.Log;

public class NetworkStateReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.i("JWT_RTS_CONNECT", "onReceive NetworkStateReceiver");
        if(isConnect(context)) {
            Log.i("JWT_RTS_CONNECT", "onReceive NetworkStateReceiver IS_CONNECT");
            NetworkManager.getInstance(context).onConnect();
        }
        else {
            Log.i("JWT_RTS_CONNECT", "onReceive NetworkStateReceiver IS_DISCONNECT");
            NetworkManager.getInstance(context).offConnect();
        }
    }

    private boolean isConnect(Context context) {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = manager.getActiveNetworkInfo();
        return activeNetworkInfo != null
                && activeNetworkInfo.isConnected();
    }
}
