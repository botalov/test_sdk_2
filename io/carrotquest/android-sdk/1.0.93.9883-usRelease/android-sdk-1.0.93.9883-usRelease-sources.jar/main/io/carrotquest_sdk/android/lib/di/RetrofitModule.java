package io.carrotquest_sdk.android.lib.di;

import android.content.Context;

import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.repositories.IUserRepository;
import com.google.gson.Gson;
import dagger.Module;
import dagger.Provides;
import io.carrotquest_sdk.android.lib.utils.FreedomUtilsKt;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;
import io.carrotquest_sdk.android.lib.utils.loging.Log;
import io.carrotquest_sdk.android.lib.wss.jwt.GetRefreshTokenUseCaseKt;
import io.carrotquest_sdk.android.lib.wss.jwt.RefreshJwtTokenUseCaseKt;
import io.carrotquest_sdk.android.lib.core.ConstantsKt;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;
import okhttp3.*;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.HttpException;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

import javax.inject.Singleton;

import java.util.UUID;
import java.util.concurrent.TimeUnit;


@Module(includes = {ContextModule.class})
public class RetrofitModule {

    private final Gson gson;

    private final Context context;
    private final IUserRepository userRepository;
    private final boolean isUseEuServers;

    public RetrofitModule(Context context, IUserRepository userRepository, boolean isUseEuServers) {
        this.context = context;
        gson = new GsonModule(context).provideGson();
        this.userRepository = userRepository;
        this.isUseEuServers = isUseEuServers;
    }

    @Provides
    @Singleton
    public Retrofit provideRetrofit(Retrofit.Builder builder) {
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();

        Interceptor paramAdds = chain -> {
            Request request = chain.request();
            User user = userRepository.getUser();
            String nonce = UUID.randomUUID().toString().replace("-", "");

            HttpUrl.Builder urlBuilder = request.url().newBuilder()
                    .addQueryParameter(F.NONCE, nonce)
                    .addQueryParameter(F.USER_AGENT, "android_sdk")
                    .addQueryParameter(F.ID_AS_STRING, "1");


            //TODO FREEDOM удалить потом
            String appId = SharedPreferencesLib.getString(context, "X_APP_ID_KEY");
            String userToken = user == null ? "" : user.getToken();
            if(userToken.isEmpty()) {
                Log.Companion.i("JWT_REFRESH", "userToken.isEmpty() is empty");
                Log.Companion.i("JWT_REFRESH", "url = " + request.url());
                if(request.url().toString().contains("refresh")) {
                    String refreshToken = GetRefreshTokenUseCaseKt.getRefreshToken(context);
                    Log.Companion.i("JWT_REFRESH", "refreshToken = " + refreshToken);
                    if(refreshToken != null) {
                        urlBuilder.addQueryParameter(F.AUTH_TOKEN, refreshToken);
                    }
                }
            } else {
                Log.Companion.i("JWT_REFRESH_2", "userToken = " + userToken);
                if (request.url().toString().contains("connect")
                        && !FreedomUtilsKt.hasSavedDashlyTokenFlag()
                        && FreedomUtilsKt.isDashly()
                        && appId.equals(FreedomUtilsKt.FREEDOM_AP_ID)) {
                    urlBuilder.addQueryParameter("carrotquest_auth_token", userToken);
                } else {//if(!request.url().toString().contains("connect"))
                    if(request.url().toString().contains("refresh")) {
                        String refreshToken = GetRefreshTokenUseCaseKt.getRefreshToken(context);
                        if(refreshToken == null || refreshToken.isEmpty()) {
                            refreshToken = SharedPreferencesLib.getString(context, "CarrotToken");
                        }
                        Log.Companion.i("JWT_REFRESH_2", "refreshToken = " + refreshToken);
                        urlBuilder.addQueryParameter(F.AUTH_TOKEN, refreshToken);
                    } else {//if(!request.url().toString().contains("connect")) {
                        Log.Companion.i("JWT", "request = " + request.url());
                        Log.Companion.i("JWT", "token = " + userToken);
                        Log.Companion.i("JWT", "--------------------------------------------------");
                        urlBuilder.addQueryParameter(F.AUTH_TOKEN, userToken);
                    }
                }
            }

            HttpUrl url = urlBuilder.build();
            request = request.newBuilder().url(url).build();

            // try the request
            try {
                return chain.proceed(request);
            } catch (Exception e) {
                if(e instanceof HttpException) {
                    int code = ((HttpException)e).code();
                    if(code == 503 || code == 501) {
                        BehaviorSubject<String> b = BehaviorSubject.create();
                        Disposable d = b
                                .subscribeOn(Schedulers.io())
                                .take(1)
                                .subscribe(token -> {
                                    User tempUser = userRepository.getUser();
                                    tempUser.setToken(token);
                                    userRepository.saveUser(tempUser);
                                }, throwable -> {
                                    Log.Companion.e("RetrofitModule", "refresh token error: " + throwable.toString());
                                });
                        RefreshJwtTokenUseCaseKt.refreshJwtToken(b);
                    }
                }

                Response r = new Response.Builder()
                        .protocol(Protocol.HTTP_1_1)
                        .request(request)
                        .code(999)
                        .message(e.toString())
                        .body(ResponseBody.create(null, e.toString())).build();

                return  r;
            }

        };

        logging.setLevel(CarrotLib.isDebug() ? HttpLoggingInterceptor.Level.BODY :  HttpLoggingInterceptor.Level.NONE);
        OkHttpClient client = new OkHttpClient.Builder()
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .addInterceptor(paramAdds)
                .build();


        String baseUrl = BuildConfig.BASE_API_URL;
        if (isUseEuServers) {
            baseUrl = ConstantsKt.EU_BASE_URL;
        }
        return builder
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .addCallAdapterFactory(RxJava2CallAdapterFactory.createWithScheduler(Schedulers.io()))
                .build();
    }

    @Provides
    @Singleton
    public Retrofit.Builder provideRetrofitBuilder() {
        return new Retrofit.Builder()
                .addConverterFactory(ScalarsConverterFactory.create());
    }
}
