package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

fun getRefreshToken(context: Context = CarrotLib.getLibComponents().getContext()): String? {
    val savedRefreshToken = SharedPreferencesLib.getString(context, refreshTokenKey)
    Log.i("JWT_RTS", "getRefreshToken savedRefreshToken = $savedRefreshToken")
    return  savedRefreshToken
}