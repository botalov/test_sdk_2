package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.recipientTypeIsRight
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.reactivex.Observable

const val TAG = "Observable.getConversations() "
fun <T> Observable<T>.getConversations() : Observable<ArrayList<DataConversation>> {

    return Observable.defer {
        return@defer this.flatMap {
            return@flatMap ConversationsRepository.getInstance().getConversations()
                .map { x ->
                    val startList = x.filter { e -> e.id != null }.distinctBy { e -> e.id }
                    val arr = ArrayList<DataConversation>()
                    for (y in startList) {
                        if (y.recipientType.recipientTypeIsRight()) {
                            arr.add(y)
                        }
                    }

                    return@map arr
                }
                .doOnError { t ->
                    Log.e(TAG, t)
                }
        }
    }
}

fun Observable<ArrayList<DataConversation>>.getPopupConversations() : Observable<ArrayList<DataConversation>> {
    return Observable.defer {
        return@defer this.flatMap { conversations ->
            conversations
                .filter { x ->
                    x.id != null && x.type == ConversationType.BLOCK_POPUP_SMALL.stringValue
                            && x.recipientType.recipientTypeIsRight()
                }
                .let { popUpConversation ->
                    return@flatMap Observable.just(ArrayList(popUpConversation))
                }
        }
    }
}


fun Observable<ArrayList<DataConversation>>.getNotPopupConversations() : Observable<ArrayList<DataConversation>> {
    return Observable.defer {
        return@defer this.flatMap {
            return@flatMap if (it.size > 0) {
                val iterator = it.iterator()
                val array = ArrayList<DataConversation>()
                while (iterator.hasNext()) {
                    try {
                        val entity = iterator.next()
                        if (entity.id != null && entity.type != null) {
                            array.add(entity)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, e.toString())
                    }
                }
                Observable.just(array)
            } else {
                Observable.just(ArrayList())
            }
        }.doOnError { t ->
            Log.e(TAG, t)
        }
    }
}

fun Observable<ArrayList<DataConversation>>.getNotPopupConversationsHard() : Observable<ArrayList<DataConversation>> {
    return Observable.defer {
        return@defer this.flatMap {
            return@flatMap if (it.size > 0) {
                val iterator = it.iterator()
                val array = ArrayList<DataConversation>()
                while (iterator.hasNext()) {
                    try {
                        val entity = iterator.next()
                        if (entity.id != null && entity.type != null
                            && (ConversationType.CHAT.stringValue == entity.type
                                    || ConversationType.ROUTING_BOT.stringValue == entity.type
                                    || ConversationType.LEAD_BOT.stringValue == entity.type)
                            && entity.recipientType.recipientTypeIsRight()
                        ) {
                            array.add(entity)
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, e.toString())
                    }
                }
                Observable.just(array)
            } else {
                Observable.just(ArrayList())
            }
        }.doOnError { t ->
            Log.e(TAG, t)
        }
    }
}

fun Observable<ArrayList<DataConversation>>.getUnreadConversations() : Observable<ArrayList<DataConversation>> {
    return Observable.defer {
        return@defer this.flatMap {
            Observable.just(ArrayList(it.filter { x -> x.id != null && x.unreadPartsCount > 0 && x.recipientType.recipientTypeIsRight() }))
        }.doOnError { t ->
            Log.e(TAG, t)
        }
    }
}