package io.carrotquest_sdk.android.core.util.huawei

import android.os.Build
import java.util.Locale

/**
 * Возвращает true, если устройство производства Huawei
 */
fun isHuawei(): Boolean {
    val manufacturer = Build.MANUFACTURER
    val brand = Build.BRAND

    return manufacturer.lowercase().contains("huawei") || brand.lowercase(Locale.getDefault()).contains("huawei")
}