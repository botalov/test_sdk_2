package io.carrotquest_sdk.android.core.main;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.models.UserProperty;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.lib.utils.AndroidUtils;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;
import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.Carrot;
import io.carrotquest_sdk.android.application.SdkApp;
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys;
import io.carrotquest_sdk.android.core.exceptions.CarrotException;
import io.carrotquest_sdk.android.core.exceptions.CarrotRepositoryException;
import io.carrotquest_sdk.android.core.exceptions.CarrotUserException;
import io.carrotquest_sdk.android.core.util.ConversationUtilsKt;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.core.util.sentry.SentryCQ_SDK;
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository;
import io.carrotquest_sdk.android.data.service.CarrotService;
import io.carrotquest_sdk.android.di.CarrotServiceModule;
import io.carrotquest_sdk.android.di.ContextSdkModule;
import io.carrotquest_sdk.android.di.DaggerSdkLibComponent;
import io.carrotquest_sdk.android.di.DataBaseModule;
import io.carrotquest_sdk.android.di.GsonModule;
import io.carrotquest_sdk.android.di.NotificationHelperModule;
import io.carrotquest_sdk.android.di.SdkLibComponent;
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.GetErrorMessagesUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.SendErrorMessagesUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.conversations.ClearHistoryUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.conversations.GetConversationsUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.triggers.TrackScreenUseCase;
import io.carrotquest_sdk.android.models.Operation;
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.DialogViewModel;
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogActivity;
import io.carrotquest_sdk.android.presentation.mvp.notifications.NotificationsConstants;
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Consumer;
import io.reactivex.observers.DisposableObserver;
import io.reactivex.subjects.BehaviorSubject;

public class CarrotSDK {
    private static final String TAG = "CarrotSDK";
    private static final String VERSION = BuildConfig.VERSION_SDK_NAME;

    private static CarrotService service;
    static SdkLibComponent libComponent;


    private static boolean isDebug = false;
    private static ThemeSdk mTheme = null;

    private static boolean isUseEuApi = false;


    public interface Callback<T> {
        void onResponse(T result);
        void onFailure(Throwable t);
    }

    protected CarrotSDK(Context context) {

        isDebug = BuildConfig.BUILD_TYPE.toLowerCase().equals("debug");
        SdkApp.getInstance().initDataBase(context);
        libComponent = DaggerSdkLibComponent.builder()
                .gsonModule(new GsonModule())
                .carrotServiceModule(new CarrotServiceModule(context, app_id, isUseEuApi))
                .contextSdkModule(new ContextSdkModule(context))
                .dataBaseModule(new DataBaseModule(SdkApp.getInstance()))
                .build();
    }

    private static BehaviorSubject<Boolean> initBehaviorSubject;

    private static DisposableObserver<NetworkResponse> eventsObserver = new DisposableObserver<NetworkResponse>() {
        @Override
        public void onNext(NetworkResponse networkResponse) {
            Log.d(TAG, networkResponse.getData().toString());
        }

        @Override
        public void onError(Throwable e) {
            Log.e(TAG, e.toString());
        }

        @Override
        public void onComplete() {

        }
    };

    private static DisposableObserver<Boolean> userPropertyObserver = new DisposableObserver<Boolean>() {
        @Override
        public void onNext(Boolean aBoolean) {
            Log.d(TAG, "Set UserProperty");
        }

        @Override
        public void onError(Throwable e) {
            Log.e(TAG, e.toString());
        }

        @Override
        public void onComplete() {

        }
    };

    public static BehaviorSubject<Boolean> getInitObservable() {
        if (initBehaviorSubject == null) {
            initBehaviorSubject = BehaviorSubject.createDefault(false);
        }
        return initBehaviorSubject;
    }

    private static String api_key;
    private static String app_id;

    private static String parentActivityClassNameImpl;

    public static String getApiKey() {
        return api_key;
    }

    public static String getAppId() {
        return app_id;
    }

    public static void setup(@NonNull Context context, @NonNull String apiKey, @NonNull String appId) {
        setup(context, apiKey, appId, null);
    }

    public static void setup(@NonNull Context context, @NonNull String apiKey, @NonNull String appId, Callback<Boolean> callback) {
        commonSetup(context, apiKey, appId, callback, true);
    }

    public static void setup(@NonNull Context context, @NonNull String apiKey, @NonNull String appId, boolean useEuServers, Callback<Boolean> callback) {
        isUseEuApi = useEuServers;
        commonSetup(context, apiKey, appId, callback, true);
    }

    public static void setupWithoutStartSession(@NonNull Context context, @NonNull String apiKey, @NonNull String appId, Callback<Boolean> callback) {
        commonSetup(context, apiKey, appId, callback, false);
    }

    public  static  void setupWithoutConnect(@NonNull Context context) {
        try {
            SdkApp.getInstance().initDataBase(context);

            libComponent = DaggerSdkLibComponent.builder()
                    .gsonModule(new GsonModule())
                    .carrotServiceModule(new CarrotServiceModule(context, app_id, isUseEuApi))
                    .contextSdkModule(new ContextSdkModule(context))
                    .dataBaseModule(new DataBaseModule(SdkApp.getInstance()))
                    .notificationHelperModule(new NotificationHelperModule())
                    .build();

            Log.d(TAG, "");
        }
        catch (Exception e){
            Log.d(TAG, e.toString());
        }
    }

    private static void commonSetup(@NonNull Context context, @NonNull String apiKey, @NonNull String appId, Callback<Boolean> callback, boolean startSession) {
        if (initBehaviorSubject == null) {
            initBehaviorSubject = BehaviorSubject.createDefault(false);
        }

        api_key = apiKey;
        app_id = appId;

        //TODO: validate input fields
        //service = libComponent.getCarrotService();
        if (service == null) {
            new CarrotSDK(context);
            service = libComponent.getCarrotService();
        }

        //String sUserAgent = UserAgent.Companion.getInstance(context).getUserAgentString(Version.userAgent);
        SharedPreferencesLib.saveString(context, "api_key", apiKey);
        SharedPreferencesLib.saveString(context, "app_id", appId);

        //Инициализация Sentry для мониторинга ошибок
        SentryCQ_SDK.init(context);
        try {
            service.init(apiKey, callback, startSession);
        } catch (Exception e) {
            Log.e(TAG, "service init error: " + e.toString());
        }

        NetworkManager.getInstance(context).addObserver((Consumer<Boolean>) isConnect -> {
            if(isConnect) {
                if(!Carrot.isInit()) {
                    commonSetup(context, apiKey, appId, callback, startSession);
                }
                List<MessageData> errorMessages = GetErrorMessagesUseCaseKt.getAllErrorMessages();

                if(!errorMessages.isEmpty()) {
                    SendErrorMessagesUseCaseKt.sendErrorMessages(errorMessages);
                }
            }
        }, t -> {
        }, () -> {

        });


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            checkNotificationPermission(context);
        }
//        else {
//            String deviceId = AndroidUtils.getInstallId(CarrotInternal.getLibComponent().getContextSdk());
//            String userId = CarrotInternal.getLibComponent().getUserRepository().getUser().getId();
//            //Если разрешения на пуши нет, то удаляем токен
//            service.unsubscribePush(userId, deviceId);
//        }
    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    private static void checkNotificationPermission(Context context){
        int checkRes = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS);
        if(checkRes != PackageManager.PERMISSION_GRANTED && context instanceof Activity) {
            //requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            ActivityCompat.requestPermissions((Activity) context,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    1);
        }
    }

    public static void setUserProperty(String key, String value) {
        io.carrotquest_sdk.android.lib.models.UserProperty userProperty = new io.carrotquest_sdk.android.lib.models.UserProperty(key, value);
        ArrayList<UserProperty> properties = new ArrayList<>();
        properties.add(userProperty);
        service.setUserProperty(properties);
    }

    public static void setUserProperty(Operation op, String key, String value) {
        io.carrotquest_sdk.android.lib.models.UserProperty userProperty = new io.carrotquest_sdk.android.lib.models.UserProperty(op.name(), key, value);
        ArrayList<UserProperty> properties = new ArrayList<>();
        properties.add(userProperty);
        service.setUserProperty(properties);
    }

    public static void setUserProperty(io.carrotquest_sdk.android.models.UserProperty userProperty) {
        ArrayList<io.carrotquest_sdk.android.lib.models.UserProperty> properties = new ArrayList<>();
        io.carrotquest_sdk.android.lib.models.UserProperty property =
                new io.carrotquest_sdk.android.lib.models.UserProperty(
                        userProperty.operation,
                        userProperty.getKey(),
                        userProperty.getValue());
        properties.add(property);
        service.setUserProperty(properties, userPropertyObserver);
    }


    public static void setNotificationIcon(int notificationIconId) {
        CarrotSDK.libComponent.getNotificationHelper().setNotificationIcon(notificationIconId);
    }

    public static void setParentActivityClassName(String parentActivityClassName) {
        parentActivityClassNameImpl = parentActivityClassName;
        SharedPreferencesLib.saveString(CarrotInternal.getLibComponent().getContextSdk(), "cq_parent_activity_class_name", parentActivityClassName);
        //CarrotSDK.libComponent.getNotificationHelper().setParentActivityClassName(parentActivityClassName);
    }

    public static String getParentActivityClassName() {
        if(parentActivityClassNameImpl != null && !parentActivityClassNameImpl.isEmpty()) {
            return parentActivityClassNameImpl;
        }
        return SharedPreferencesLib.getString(CarrotInternal.getLibComponent().getContextSdk(), "cq_parent_activity_class_name");
    }

    public static void setUserProperty(List<io.carrotquest_sdk.android.models.UserProperty> userProperties) {
        //TODO: validate input fields
        checkInitialization();
        ArrayList<io.carrotquest_sdk.android.lib.models.UserProperty> properties = new ArrayList<>();
        for (io.carrotquest_sdk.android.models.UserProperty userProperty : userProperties) {
            io.carrotquest_sdk.android.lib.models.UserProperty property =
                    new io.carrotquest_sdk.android.lib.models.UserProperty(
                            userProperty.operation,
                            userProperty.getKey(),
                            userProperty.getValue());
            properties.add(property);
        }
        service.setUserProperty(properties, userPropertyObserver);
    }

    public static void auth(String id, String userAuthKey) {
        auth(id, userAuthKey, null);
    }

    public static void auth(String id, String userAuthKey, Callback<String> callback) {
        checkInitialization(new Callback<Boolean>() {
            @Override
            public void onResponse(Boolean result) {
                if(!result) {
                    callback.onFailure(new Exception("result is false"));
                }
            }

            @Override
            public void onFailure(Throwable t) {
                callback.onFailure(t);
            }
        });

        service.authUser(id, userAuthKey, new DisposableObserver<User>() {
            @Override
            public void onNext(User user) {
                if(callback != null) {
                    callback.onResponse(user.getId());
                }

                if(user != null) {
                    DialogViewModel.Companion.getInstance().updateCurrentConversationId("");
                    DialogViewModel.Companion.getInstance().setNeedStartRoutingBot(false);
                    DialogViewModel.Companion.getInstance().setRoutingBotId("");
                    ClearHistoryUseCaseKt.clearHistory(Observable.just(true))
                            .take(1)
                            .subscribe();
                }
            }

            @Override
            public void onError(Throwable e) {
                if (callback != null) {
                    callback.onFailure(e);
                }
            }

            @Override
            public void onComplete() {

            }
        });
    }


    public static void hashedAuth(String id, String hash) {
        hashedAuth(id, hash, null);
    }

    public static void hashedAuth(String id, String hash, Callback<String> callback) {
        checkInitialization(new Callback<Boolean>() {
            @Override
            public void onResponse(Boolean result) {
                if(!result) {
                    callback.onFailure(new Exception("result is false"));
                }
            }

            @Override
            public void onFailure(Throwable t) {
                callback.onFailure(t);
            }
        });

        service.hashedAuth(id, hash, new DisposableObserver<User>() {
            @Override
            public void onNext(User user) {
                if(callback != null) {
                    callback.onResponse(user.getId());
                }

                if(user != null) {
                    DialogViewModel.Companion.getInstance().updateCurrentConversationId("");
                    DialogViewModel.Companion.getInstance().setNeedStartRoutingBot(false);
                    DialogViewModel.Companion.getInstance().setRoutingBotId("");
                    ClearHistoryUseCaseKt.clearHistory(Observable.just(true))
                            .take(1)
                            .subscribe();
                }
            }

            @Override
            public void onError(Throwable e) {
                if (callback != null) {
                    callback.onFailure(e);
                }
            }

            @Override
            public void onComplete() {

            }
        });
    }

    public static boolean isInit() {
        if (service != null) {
            return service.isInit();
        }
        return false;
    }

    public static void deInit() {
        deInitInternal(null);
    }

    private static void deInitInternal(Callback<Boolean> callback) {
        Disposable d = Observable.just(true).observeOn(AndroidSchedulers.mainThread()).take(1).subscribe(aBoolean -> {
            if (service != null) {
                service.deInit();
            }
            if (initBehaviorSubject != null) {
                initBehaviorSubject.onNext(false);
            }

            DialogViewModel.Companion.getInstance().updateCurrentConversationId("");
            DialogViewModel.Companion.getInstance().setNeedStartRoutingBot(false);
            DialogViewModel.Companion.getInstance().setRoutingBotId("");
            ClearHistoryUseCaseKt.clearHistory(Observable.just(true))
                    .take(1)
                    .subscribe();

            if(disposableUnreadConversationCallback != null && !disposableUnreadConversationCallback.isDisposed()) {
                disposableUnreadConversationCallback.dispose();
            }

            if(callback != null) {
                callback.onResponse(true);
            }
        });
    }

    public static void deInit(Callback<Boolean> callback) {
        try {
            deInitInternal(callback);
        } catch (Exception e) {
            callback.onFailure(e);
        }
    }

    public static void trackEvent(String eventName) {
        //TODO: validate input fields
        checkInitialization();
        service.trackEvent(eventName, null, eventsObserver);
    }

    public static void trackEvent(String eventName, String eventParams) {
        //TODO: validate input fields
        checkInitialization();
        service.trackEvent(eventName, eventParams, eventsObserver);
    }

    public static void openChat(Context context) {
        if (context != null) {
            Intent intent = new Intent(context, DialogActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra(DialogActivity.CONVERSATION_ID_ARG, "last_conversation");

            context.startActivity(intent);
        }
    }

    /**
     * Send push notification to SDK
     * @param remoteMessage Message
     */
    @Deprecated
    public static void sendFirebasePushNotification(RemoteMessage remoteMessage, Context context) {
        sendPushNotification(remoteMessage.getData(), context);
    }

    /**
     * Send push notification to SDK
     */
    public static void sendPushNotification(Map<String, String> pushData, Context context) {
        if (Carrot.isInit()) {
            if (CarrotInternal.getLibComponent() != null) {
                CarrotInternal.getLibComponent().getNotificationHelper().postNotification(pushData);
            }
        } else {
            Carrot.setupWithoutConnect(context);
            try {
                PushNotificationHelper.getInstance().postNotification(pushData);
            } catch (Exception e){
                Log.e(TAG, new Exception("postNotification(...) error. Result = " + e.toString()));
            }
        }
    }

    public static void sendFcmToken(String fcmToken) {
        try {
            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(CarrotInternal.getLibComponent().getContextSdk());
            if(notificationManager.areNotificationsEnabled()) {
                String deviceId = AndroidUtils.getInstallId(CarrotInternal.getLibComponent().getContextSdk());
                String userId = CarrotInternal.getLibComponent().getUserRepository().getUser().getId();
                service.sendPushToken(userId, fcmToken, deviceId);
            }
        } catch (Exception e) {

        }

    }

    public static String getVersion() {
        return VERSION;
    }


    public static void setTheme(ThemeSdk theme) {
        mTheme = theme;
    }

    public static ThemeSdk getTheme() {
        return mTheme;
    }

    private static void checkInitialization() {
        if (service == null) {
            String textError = "Carrot is not init. Call setup(contex,apiKey) first.";
            if (isDebug) {
                Log.e(TAG, textError);
            }
            throw new RuntimeException(textError);
        }
    }

    private static void checkInitialization(Callback<Boolean> callback) {
        if (service == null) {
            String textError = "Carrot is not init. Call setup(contex,apiKey) first.";
            if (isDebug) {
                Log.e(TAG, textError);
            }
            callback.onFailure(new Exception(textError));
            throw new RuntimeException(textError);
        }
    }

    public static void setDebug(boolean value) {
        isDebug = value;
    }

    public static boolean isDebug() {
        return isDebug;
    }


    private static Disposable disposableUnreadConversationCallback;
    public static void setUnreadConversationsCallback(Callback<List<String>> callback) {
        disposableUnreadConversationCallback = GetConversationsUseCaseKt.getUnreadConversations(GetConversationsUseCaseKt.getConversations(Observable.just(true)))
                .observeOn(AndroidSchedulers.mainThread())
                .map(x->{
                    ArrayList<String> res = new ArrayList<String>();
                    for(DataConversation entity : x) {
                        if(ConversationUtilsKt.recipientTypeIsRight(entity.getRecipientType())
                                && entity.getUnreadPartsCount() > 0 && entity.getId() != null) {
                            res.add(entity.getId());
                        }
                    }
                    return res;
                })
                .subscribe(callback::onResponse);
    }

    public static List<String> getUnreadConversations() throws CarrotException {
        checkInitialization();

        if (CarrotInternal.getLibComponent().getUserRepository() == null) {
            throw new CarrotRepositoryException("User repository is empty");
        }

        if (CarrotInternal.getLibComponent().getUserRepository().getUser() == null) {
            throw new CarrotUserException("User not found");
        }

        ArrayList<DataConversation> convs = ConversationsRepository.Companion.getInstance().getConversationsSync();
        ArrayList<String> res = new ArrayList<>();

        for(DataConversation entity : convs) {
            if(ConversationUtilsKt.recipientTypeIsRight(entity.getRecipientType())
                    && entity.getUnreadPartsCount() > 0 && entity.getId() != null) {
                res.add(entity.getId());
            }
        }

        return res;
    }



    public static String getPushActionUrl(RemoteMessage remoteMessage) {
        Map<String, String> data = remoteMessage.getData();
        if (data.containsKey(NotificationsConstants.CQ_SDK_PUSH) && "false".equals(data.get(NotificationsConstants.CQ_SDK_PUSH))) {
            if (data.containsKey(NotificationsConstants.CQ_SDK_PUSH_BODY_JSON)) {
                String bodyJsonStr = data.get(NotificationsConstants.CQ_SDK_PUSH_BODY_JSON);
                if (bodyJsonStr == null) {
                    bodyJsonStr = "{}";
                }
                JsonElement bodyJsonJson = JsonParser.parseString(bodyJsonStr);
                if (bodyJsonJson.isJsonObject()) {
                    JsonObject bodyJsonJsonObject = bodyJsonJson.getAsJsonObject();
                    if (bodyJsonJsonObject != null) {
                        if (bodyJsonJsonObject.has(NotificationsConstants.CQ_SDK_PUSH_CLICK_ACTION)) {
                            return bodyJsonJsonObject.get(NotificationsConstants.CQ_SDK_PUSH_CLICK_ACTION).getAsString();
                        }
                    }
                }
            }
        }
        return null;
    }

    @Deprecated
    public static boolean isCarrotPush(RemoteMessage remoteMessage) {
        Map<String, String> data = remoteMessage.getData();
        return data != null && data.containsKey(NotificationsConstants.CQ_SDK_PUSH);
    }

    public static boolean isCarrotPush(Map<String, String> pushData) {
        return pushData != null && pushData.containsKey(NotificationsConstants.CQ_SDK_PUSH);
    }

    @Deprecated
    public static boolean isAutoMessage(RemoteMessage remoteMessage) {
        Map<String, String> data = remoteMessage.getData();
        return data != null && data.containsKey(NotificationsConstants.CQ_SDK_PUSH) && data.containsKey(NotificationsConstants.CQ_SDK_SENT_VIA)
            && NotificationsConstants.CQ_SDK_AUTO_MESSAGE.equals(data.get(NotificationsConstants.CQ_SDK_SENT_VIA));
    }

    public static boolean isAutoMessage(Map<String, String> pushData) {
        return pushData != null && pushData.containsKey(NotificationsConstants.CQ_SDK_PUSH) && pushData.containsKey(NotificationsConstants.CQ_SDK_SENT_VIA)
                && NotificationsConstants.CQ_SDK_AUTO_MESSAGE.equals(pushData.get(NotificationsConstants.CQ_SDK_SENT_VIA));
    }

    public static void pushNotificationsUnsubscribe() {
        checkInitialization();
        setUserProperty("$sdk_push_notifications_subscribed", "false");

        String key = SharedPreferenceKeys.SDK_PUSH_NOTIFICATIONS_UNSUBSCRIBED;
        SharedPreferencesLib.saveBoolean(CarrotLib.getLibComponents().getContext(), key, true);
    }

    public static void pushCampaignsUnsubscribe() {
        checkInitialization();
        setUserProperty("$sdk_push_campaigns_subscribed", "false");

        String key = SharedPreferenceKeys.SDK_PUSH_CAMPAIGNS_UNSUBSCRIBED;
        SharedPreferencesLib.saveBoolean(CarrotLib.getLibComponents().getContext(), key, true);    }


    private static boolean isSimplePushSdk(RemoteMessage remoteMessage) {
        Map<String, String> data = remoteMessage.getData();
        return data != null && data.containsKey(NotificationsConstants.CQ_SDK_PUSH) && "true".equals(data.get(NotificationsConstants.CQ_SDK_PUSH));
    }

    private static boolean isAutoPushSdk(RemoteMessage remoteMessage) {
        Map<String, String> data = remoteMessage.getData();
        return data != null && data.containsKey(NotificationsConstants.CQ_SDK_PUSH) && "false".equals(data.get(NotificationsConstants.CQ_SDK_PUSH));
    }

    public static boolean isUseEuApi() {
        return isUseEuApi;
    }

    public static void  setCloseChatCallback(Callback<Boolean> callback) {
        CarrotInternal.updateCloseChatCallback(callback);
    }

    public static void trackScreen(String screenName) {
        TrackScreenUseCase trackScreenUseCase = new TrackScreenUseCase();
        trackScreenUseCase.call(screenName);
    }
}
