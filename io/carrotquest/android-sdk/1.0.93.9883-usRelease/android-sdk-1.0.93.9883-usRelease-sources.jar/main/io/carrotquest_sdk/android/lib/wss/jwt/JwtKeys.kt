package io.carrotquest_sdk.android.lib.wss.jwt

//TODO
const val jwtTokenLiveTime: Long = 1 * 10 * 1000 //Long = 55 * 60 * 1000  //minutes * seconds * milliseconds

const val jwtTokenKey = "JWT_TOKEN_KEY"
const val refreshTokenKey = "REFRESH_TOKEN_KEY"
const val jwtTokenUpdateTimeStampKey = "JWT_TOKEN_UPDATE_TIMESTAMP_KEY"