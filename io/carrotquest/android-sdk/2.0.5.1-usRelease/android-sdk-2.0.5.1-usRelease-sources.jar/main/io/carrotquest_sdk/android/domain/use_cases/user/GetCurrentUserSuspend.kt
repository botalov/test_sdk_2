package io.carrotquest_sdk.android.domain.use_cases.user

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.data.repositories.UserRepository
import io.carrotquest_sdk.android.domain.entities.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private const val TAG = "GetCurrentUserSuspend"

/**
 * Suspend version of getCurrentUser. Returns the cached user if available,
 * otherwise fetches from API and caches the result.
 *
 * Coexists with the RxJava extension [Observable<T>.getCurrentUser()] —
 * different signatures, no conflict.
 */
suspend fun getCurrentUser(): UserEntity? = withContext(Dispatchers.IO) {
    val cached = UserRepository.getInstance().getUserSync()
    if (cached != null && cached.id.isNotEmpty()) return@withContext cached

    val settings = SettingsRepository.getInstance().getSettingsObject()
        ?: return@withContext null

    try {
        val user = CarrotInternal.getService().carrotLib
            .getUser(settings.userId)
            .blockingFirst(null)
            ?: return@withContext null

        UserEntity(
            id = user.id,
            token = user.token,
            hasConversations = user.hasConversations,
            isBanned = user.isBanned,
            conversationsUnread = user.conversationsUnread ?: emptyList()
        ).also { UserRepository.getInstance().saveUser(it) }
    } catch (e: Exception) {
        Log.e(TAG, e)
        null
    }
}
