package io.carrotquest_sdk.android.presentation.mvp.web_view;

import static android.util.Log.INFO;
import static android.util.Log.println;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.ViewCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

import io.carrotquest_sdk.android.lib.managers.network.NetworkManager;
import io.carrotquest_sdk.android.R;
import io.carrotquest_sdk.android.data.network.js_interface.JSInterface;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.domain.use_cases.theme.GetThemeUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme;
import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.Scheduler;
import io.reactivex.Single;
import io.reactivex.SingleEmitter;
import io.reactivex.SingleOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import io.reactivex.subjects.BehaviorSubject;

public class CarrotWebView extends ConstraintLayout {
    private static final String TAG = "CarrotWebView";

    private CarrotWebViewPresenter presenter;

    private static final int ANIMATE_PROGRESS_BAR_DURATION = 0;

    private String mUrl;

    private final Context context;
    protected ObservableWebView webView;
    private ConstraintLayout progressBarContainer;
    private ProgressBar loadingProgressBar;
    private ConstraintLayout errorContainer;
    private ConstraintLayout webViewContainer;
    private TextView reloadButtonTextView;
    private TextView errorTitleTextView;
    private TextView errorMessageTextView;

    private BehaviorSubject<Boolean> errorSubject = BehaviorSubject.createDefault(false);
    private CompositeDisposable compositeDisposable;


    private Scheduler loadWebViewScheduler = Schedulers.newThread();

    public CarrotWebView(Context context) {
        super(context);
        this.context = context;
       initViews();
    }

    public CarrotWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;

        initViews();
    }


    public void setErrorObserver(Consumer<Boolean> observer) {
        if(compositeDisposable == null) {
            compositeDisposable = new CompositeDisposable();
        }

        compositeDisposable.add(this.errorSubject.subscribe(observer));
    }

    @Override
    public void setBackgroundColor(int color) {
        super.setBackgroundColor(color);
        webView.setBackgroundColor(color);
    }

    @SuppressLint("AddJavascriptInterface")
    private void initViews() {
        presenter = new CarrotWebViewPresenter(context);
        presenter.attachView(this);

        LayoutInflater inflater = ((Activity) context).getLayoutInflater();
        inflater.inflate(R.layout.carrot_web_view_layout, this);

        webView = findViewById(R.id.web_view);
        webView.scrollTo(0, 0);
        ViewCompat.setNestedScrollingEnabled(webView, false);

        progressBarContainer = findViewById(R.id.load_progress_bar_container);
        loadingProgressBar = progressBarContainer.findViewById(R.id.load_progress_bar);
        errorContainer = findViewById(R.id.error_container);
        webViewContainer = findViewById(R.id.web_view_container);

        if (GetThemeUseCaseKt.getThemeUseCase(context) == SimpleTheme.DARK) {
            webViewContainer.setBackgroundColor(Color.parseColor("#333333"));
            webView.setBackgroundColor(Color.parseColor("#333333"));
            progressBarContainer.setBackgroundColor(Color.parseColor("#333333"));
        } else {
            progressBarContainer.setBackgroundColor(Color.parseColor("#ffffff"));
        }

        reloadButtonTextView = errorContainer.findViewById(R.id.reload_button_text_view);
        reloadButtonTextView.setOnClickListener(v -> {
            boolean hasInternet = NetworkManager.getInstance(context).getHasConnect();
            if(!hasInternet) {
                progressBarContainer.setVisibility(VISIBLE);
                hideLoadError(false);

                compositeDisposable.add(Observable.just(true)
                        .delay(2, TimeUnit.SECONDS)
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeOn(Schedulers.io())
                        .take(1)
                        .subscribe(aBoolean -> {
                            showNoInternetError();
                        }));
            } else {
                progressBarContainer.setVisibility(VISIBLE);
                hideLoadError();
                reloadUrl();
            }
        });

        errorTitleTextView = errorContainer.findViewById(R.id.title_error_text_view);
        errorMessageTextView = errorContainer.findViewById(R.id.message_error_text_view);
        if (GetThemeUseCaseKt.getThemeUseCase(context) == SimpleTheme.DARK) {
            errorTitleTextView.setTextColor(Color.parseColor("#ffffff"));
            errorMessageTextView.setTextColor(Color.parseColor("#ffffff"));
        }

        webView.setWebViewClient(new CarrotWebViewClient(presenter));
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d("WEB_CHROME_CLIENT", consoleMessage.message());
                return true;
            }
        });
        webView.setFocusableInTouchMode(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        //webView.getSettings().setAppCacheEnabled(true);
        webView.getSettings().setSupportZoom(false);
        webView.setHapticFeedbackEnabled(false);

        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

        //Отключение эффектов при скролле
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        //Отключение выбора текста на странице
        //А точнее переопределяем событие долгого нажатия
        webView.setOnLongClickListener(v -> true);
        webView.setLongClickable(false);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            if (0 != (getContext().getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE)) {
                WebView.setWebContentsDebuggingEnabled(true);
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        } else {
            CookieManager.getInstance().setAcceptCookie(true);
        }

        presenter.onStartView();
    }

    public void showNoInternetError() {
        setLoadErrorContent();
        Observable.just(true)
                .observeOn(AndroidSchedulers.mainThread())
                .take(1)
                .doOnNext(aBoolean -> {
                    errorSubject.onNext(true);
                    errorContainer
                            .animate()
                            .alphaBy(0.0f).alpha(1.0f)
                            .setDuration(ANIMATE_PROGRESS_BAR_DURATION)
                            .setListener(new Animator.AnimatorListener() {
                                @Override
                                public void onAnimationStart(@NonNull Animator animation) {
                                    //
                                    errorContainer.setAlpha(1.0f);
                                    errorContainer.setVisibility(VISIBLE);

                                    progressBarContainer.setVisibility(GONE);
                                }

                                @Override
                                public void onAnimationEnd(@NonNull Animator animation) {
                                    hideLoading();
                                }

                                @Override
                                public void onAnimationCancel(@NonNull Animator animation) {
                                }

                                @Override
                                public void onAnimationRepeat(@NonNull Animator animation) {
                                }
                            });
                })
                .subscribe();
    }

    public void showAirplaneModError() {
        setAirModeErrorContent();
        Observable.just(true)
                .observeOn(AndroidSchedulers.mainThread())
                .take(1)
                .doOnNext(aBoolean -> {
                    errorSubject.onNext(true);
                    errorContainer
                            .animate()
                            .alphaBy(0.0f).alpha(1.0f)
                            .setDuration(ANIMATE_PROGRESS_BAR_DURATION)
                            .setListener(new Animator.AnimatorListener() {
                                @Override
                                public void onAnimationStart(@NonNull Animator animation) {
                                    //
                                    errorContainer.setAlpha(1.0f);
                                    errorContainer.setVisibility(VISIBLE);

                                    progressBarContainer.setVisibility(GONE);
                                }

                                @Override
                                public void onAnimationEnd(@NonNull Animator animation) {
                                    hideLoading();
                                }

                                @Override
                                public void onAnimationCancel(@NonNull Animator animation) {
                                }

                                @Override
                                public void onAnimationRepeat(@NonNull Animator animation) {
                                }
                            });
                })
                .subscribe();
    }

    public void showLoadError() {
        setOtherErrorContent();
        Observable.just(true)
                .observeOn(AndroidSchedulers.mainThread())
                .take(1)
                .doOnNext(aBoolean -> {
                    errorSubject.onNext(true);
                    errorContainer
                            .animate()
                            .alphaBy(0.0f).alpha(1.0f)
                            .setDuration(ANIMATE_PROGRESS_BAR_DURATION)
                            .setListener(new Animator.AnimatorListener() {
                        @Override
                        public void onAnimationStart(@NonNull Animator animation) {
                            //
                            errorContainer.setAlpha(1.0f);
                            errorContainer.setVisibility(VISIBLE);

                            progressBarContainer.setVisibility(GONE);
                        }

                        @Override
                        public void onAnimationEnd(@NonNull Animator animation) {
                            hideLoading();
                        }

                        @Override
                        public void onAnimationCancel(@NonNull Animator animation) {
                        }

                        @Override
                        public void onAnimationRepeat(@NonNull Animator animation) {
                        }
                    });
                })
                .subscribe();
    }
    public void hideLoadError() {
        hideLoadError(true);
    }

    public void hideLoadError(boolean removeError) {
        Observable.just(true)
                .observeOn(AndroidSchedulers.mainThread())
                .doOnNext(aBoolean -> {
                    if(removeError) {
                        errorSubject.onNext(false);
                    }

                    errorContainer.animate().alpha(0.0f).setDuration(ANIMATE_PROGRESS_BAR_DURATION).setListener(new Animator.AnimatorListener() {
                        @Override
                        public void onAnimationStart(Animator animation) {
                        }

                        @Override
                        public void onAnimationEnd(Animator animation) {
                            errorContainer.setVisibility(GONE);
                        }

                        @Override
                        public void onAnimationCancel(Animator animation) {
                        }

                        @Override
                        public void onAnimationRepeat(Animator animation) {
                        }
                    });
                })
                .subscribe();
    }


    public void reloadUrl() {
        if(URLUtil.isValidUrl(mUrl)) {
            webView.post(() -> webView.loadUrl(mUrl));
        }
    }

    public void setOnScroll(ObservableWebView.OnScrollChangeListener listener) {
        webView.setOnScrollChangeListener(listener);
    }

    @SuppressLint({"AddJavascriptInterface", "JavascriptInterface"})
    public void initJsInterface(JSInterface jsInterface) {
        webView.addJavascriptInterface(jsInterface, JSInterface.PUBLIC_INTERFACE_NAME);
    }

    public void loadUrl(String url){
        if(URLUtil.isValidUrl(url)) {
            mUrl = url;
            webView.post(() -> {
                try {
                    webView.loadUrl(mUrl);
                } catch (Exception e) {
                    Log.e(TAG, e);
                }
            });
        }
    }

    public void setColor(int color){
        presenter.onSetColor(color);
    }

    void updateColor(int color) {
        reloadButtonTextView.setTextColor(color);
        int c = color;
        if(GetThemeUseCaseKt.getThemeUseCase(context) == SimpleTheme.DARK) {
            c = Color.parseColor("#FFFFFF");
        }
        loadingProgressBar.getIndeterminateDrawable().setColorFilter(c, android.graphics.PorterDuff.Mode.SRC_IN);
    }

    public void executeJsInWebView(String js) {
        webView.post(() -> {
            try {
                webView.loadUrl(js);
            } catch (Exception e) {
                Log.e(TAG, e);
            }
        });
    }

    public void executeJsInWebView(String js, ValueCallback<String> callback) {
        webView.post(() -> webView.evaluateJavascript(js, callback));
    }

    void setLoadErrorContent() {
        errorTitleTextView.setText(context.getString(R.string.title_load_error_str));
        errorMessageTextView.setText(context.getString(R.string.message_load_error_str));

        if(GetThemeUseCaseKt.getThemeUseCase(context) == SimpleTheme.DARK) {
            errorContainer.setBackgroundColor(Color.parseColor("#333333"));
        } else {
            errorContainer.setBackgroundColor(Color.parseColor("#ffffff"));
        }
    }
    void setAirModeErrorContent() {
        errorTitleTextView.setText(context.getString(R.string.title_air_mode_error_str));
        errorMessageTextView.setText(context.getString(R.string.message_air_mode_error_str));

        if(GetThemeUseCaseKt.getThemeUseCase(context) == SimpleTheme.DARK) {
            errorContainer.setBackgroundColor(Color.parseColor("#333333"));
        } else {
            errorContainer.setBackgroundColor(Color.parseColor("#ffffff"));
        }
    }
    void setOtherErrorContent() {
        errorTitleTextView.setText(context.getString(R.string.title_load_other_error_str));
        errorMessageTextView.setText(context.getString(R.string.message_load_other_error_str));

        if(GetThemeUseCaseKt.getThemeUseCase(context) == SimpleTheme.DARK) {
            errorContainer.setBackgroundColor(Color.parseColor("#333333"));
        } else {
            errorContainer.setBackgroundColor(Color.parseColor("#ffffff"));
        }
    }

    public void addLoadingObserver(Observer<Boolean> observer) {
        presenter.onAddLoadingObserver(observer);
    }

    public void hideLoading(){
        progressBarContainer.setVisibility(GONE);
    }

    public void setCustomOnLongClickListener(View.OnLongClickListener longClickListener) {
        if(longClickListener != null) {
            webView.setOnLongClickListener(longClickListener);
            webView.setLongClickable(false);
        }
    }

    /**
     * Уведомление о ТАПЕ пользователя в пустую область WebView (вне ссылок и картинок).
     * Используется фрагментом, чтобы убрать фокус с поля ввода и скрыть клавиатуру.
     *
     * Различает жесты через GestureDetector — скролл, long press, fling не вызывают
     * listener. Обычный tap дополнительно фильтруется через WebView.HitTestResult:
     * если палец попал на ссылку, картинку, e-mail или телефон, listener не срабатывает —
     * пользователь, скорее всего, хочет продолжить ввод (откроет картинку, вернётся
     * назад и продолжит набор).
     *
     * Listener никогда не потребляет событие — поведение WebView не меняется.
     */
    public void setOnInteractionListener(Runnable onInteraction) {
        if (onInteraction == null) {
            webView.setOnTouchListener(null);
            return;
        }
        final android.view.GestureDetector gestureDetector = new android.view.GestureDetector(
                context,
                new android.view.GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onSingleTapUp(android.view.MotionEvent e) {
                        if (isTapOnInteractiveElement()) return false;
                        try {
                            onInteraction.run();
                        } catch (Exception ex) {
                            Log.e(TAG, ex);
                        }
                        return false;
                    }
                });
        webView.setOnTouchListener((v, event) -> {
            gestureDetector.onTouchEvent(event);
            return false;
        });
    }

    /**
     * true, если последний touch попал в кликабельный элемент WebView (ссылка/картинка).
     * Используем HitTestResult — он обновляется при каждом касании и держит тип под
     * курсором.
     */
    private boolean isTapOnInteractiveElement() {
        try {
            android.webkit.WebView.HitTestResult hit = webView.getHitTestResult();
            if (hit == null) return false;
            int type = hit.getType();
            return type == android.webkit.WebView.HitTestResult.SRC_ANCHOR_TYPE
                    || type == android.webkit.WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
                    || type == android.webkit.WebView.HitTestResult.IMAGE_TYPE
                    || type == android.webkit.WebView.HitTestResult.EMAIL_TYPE
                    || type == android.webkit.WebView.HitTestResult.PHONE_TYPE
                    || type == android.webkit.WebView.HitTestResult.GEO_TYPE;
        } catch (Throwable t) {
            // HitTestResult в редких случаях кидается на пересоздаваемом WebView —
            // лучше пропустить hide клавиатуры, чем уронить SDK.
            return true;
        }
    }

    public void onDestroy(){
        if(presenter != null) {
            presenter.detachView();
        }
        presenter = null;
        webView.destroy();
    }

    public void openOutsideUrl(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        context.startActivity(intent);
    }

    public int getWebViewScrollY() {
        return webView.getScrollY();
    }
    public int getWebViewContentHeight() {
        return webView.getMeasuredHeight();
    }
    public  int getWebViewHeight() {
        return (int) Math.floor(webView.getContentHeight() * webView.getScale());
    }
    public float getWebViewScale() {
        return webView.getScale();
    }

    public void showLoading() {
        progressBarContainer.setVisibility(VISIBLE);
    }
}
