package io.carrotquest_sdk.android.presentation.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.ColorUtils

internal object SdkColors {
    // Фон карточек / поверхностей
    fun background(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFF2F2F2)
    // Фон страницы (контейнер)
    fun pageBackground(isDark: Boolean): Color = if (isDark) Color(0xFF333333) else Color(0xFFFFFFFF)
    // Заголовки, основной текст
    fun title(isDark: Boolean): Color = if (isDark) Color(0xFFFFFFFF) else Color(0xFF333333)
    // Вторичный текст, метаданные
    fun secondaryText(isDark: Boolean): Color = if (isDark) Color(0xFFF2F2F2) else Color(0xFF595959)
    // Рамки карточек
    fun cardBorder(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFF2F2F2)
    // Разделитель (линия)
    fun divider(isDark: Boolean): Color = if (isDark) Color(0xFF4D4D4D) else Color(0xFFE6E6E6)
    // Метка раздела (например, «История»)
    val sectionLabel: Color = Color(0xFF999999)
    // Бейдж непрочитанных сообщений
    val unreadBadge: Color = Color(0xFFFF3B30)
    // Текст и иконки поверх акцентного цвета шапки/кнопок — чёрные на светлом accent,
    // белые на тёмном. Порог luminance 0.5 совпадает с логикой статус-бара.
    fun onAccent(accent: Color): Color =
        if (ColorUtils.calculateLuminance(accent.toArgb()) > 0.45) Color(0xFF333333) else Color.White
    // Полупрозрачный скрим под шторкой
    val scrim: Color = Color.Black.copy(alpha = 0.25f)
    // Акцентный цвет фокуса в полях ввода
    val focusAccent: Color = Color(0xFF007AFF)
}
