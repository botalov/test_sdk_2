package io.carrotquest_sdk.android.lib.view.full_image_view.presenter

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.StrictMode
import android.provider.MediaStore
import io.carrotquest_sdk.android.lib.utils.files.SaveImageCallback
import io.carrotquest_sdk.android.lib.utils.files.saveBitmapImageToGallery
import io.carrotquest_sdk.android.lib.utils.loging.Log
import java.io.File
import java.io.FileOutputStream
import java.lang.reflect.Method

class FullImageViewPresenter {

    private var bitmap: Bitmap? = null

    fun onLoadResource(resource: Drawable, context: Context): Uri? {
        return try {
            val cachePath = File(context.cacheDir, "images")
            cachePath.mkdirs()
            val nFile = File(cachePath, "image.png")
            val stream = FileOutputStream(nFile)

            bitmap = (resource as? BitmapDrawable)?.bitmap ?: return null
            bitmap!!.compress(Bitmap.CompressFormat.PNG, 100, stream)
            stream.close()

            if (Build.VERSION.SDK_INT >= 24) {
                try {
                    val m: Method = StrictMode::class.java.getMethod("disableDeathOnFileUriExposure")
                    m.invoke(null)
                } catch (e: Exception) {
                    Log.e("FullImageViewPresenter", e)
                }
            }

            Uri.fromFile(nFile)
        } catch (e: Exception) {
            Log.e("onLoadResource", e)
            null
        }
    }

    fun createShareIntent(context: Context): Intent? {
        val bmp = bitmap ?: return null
        val path = MediaStore.Images.Media.insertImage(context.contentResolver, bmp, "", "")
            ?: return null
        return Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, Uri.parse(path))
        }
    }

    fun saveImage(contentResolver: ContentResolver, callback: SaveImageCallback) {
        val bmp = bitmap ?: run { callback.fail(); return }
        saveBitmapImageToGallery(bmp, contentResolver, callback)
    }
}
