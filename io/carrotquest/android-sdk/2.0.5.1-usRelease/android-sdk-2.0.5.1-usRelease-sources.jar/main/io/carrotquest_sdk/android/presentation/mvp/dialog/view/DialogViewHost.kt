package io.carrotquest_sdk.android.presentation.mvp.dialog.view

import android.widget.ImageView
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.OperatorStatus
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView

class DialogViewHost(private val carrotWebView: CarrotWebView) : IDialogView {

    // ── WebView delegation ────────────────────────────────────────────────────

    override fun setupWebView(webView: CarrotWebView) {}

    override fun loadUrl() {
        carrotWebView.reloadUrl()
    }

    override fun initStartView(jsonScript: String) {
        carrotWebView.executeJsInWebView(jsonScript)
    }

    override fun showMessage(messageJson: String) {
        carrotWebView.executeJsInWebView(messageJson)
    }

    override fun deleteMessage(messageJson: String) {
        carrotWebView.executeJsInWebView(messageJson)
    }

    override fun deleteAllMessages(js: String) {
        carrotWebView.executeJsInWebView(js)
    }

    override fun updateMessage(messageJson: String) {
        carrotWebView.executeJsInWebView(messageJson)
    }

    override fun scrollWebView(js: String) {
        carrotWebView.executeJsInWebView(js)
    }

    override fun toBottomScroll() {
        carrotWebView.executeJsInWebView("javascript:window.webView.forceScrollBottom()")
    }

    override fun startRoutingBot(jsonScript: String) {
        carrotWebView.executeJsInWebView(jsonScript)
    }

    override fun addBrunch(jsonScript: String) {
        carrotWebView.executeJsInWebView(jsonScript)
    }

    override fun hideLoadError() {
        carrotWebView.hideLoadError()
    }

    override fun hideLoading() {
        carrotWebView.hideLoading()
    }

    override fun showErrorNoInternet() {
        carrotWebView.showNoInternetError()
    }

    override fun showErrorAirplaneMode() {
        carrotWebView.showAirplaneModError()
    }

    override fun showErrorSomething() {
        carrotWebView.showLoadError()
    }

    // ── Stubs (UI overlay — not available in embedded mode) ───────────────────

    override fun updateUnreadConversationsCount(count: Int) {}
    override fun updateAdminsAvatars(avatars: Array<ImageView>) {}
    override fun updateAdminName(adminName: String) {}
    override fun updateAdminName(adminName: String, needResize: Boolean) {}
    override fun updateAppName(appName: String) {}
    override fun updateStatus(status: OperatorStatus) {}
    override fun updateAppDescription(description: String, operatorsInOnline: Boolean) {}
    override fun updateStatusCollapsedAppBar(operatorsInOnline: Boolean) {}
    override fun updateAppColor(color: Int) {}
    override fun showErrorFileNotFound() {}
    override fun showErrorSendMessage() {}
    override fun startDownloadFile(messageId: String, attachmentId: String) {}
    override fun showSendButton() {}
    override fun hideSendButton() {}
    override fun showAttachFileButton() {}
    override fun hideAttachFileButton() {}
    override fun enableSendButton() {}
    override fun disableSendButton() {}
    override fun showPhonePrefix() {}
    override fun hidePhonePrefix() {}
    override fun enableInput() {}
    override fun disableInput() {}
    override fun hideInput() {}
    override fun showInput(conversationId: String) {}
    override fun clearInput() {}
    override fun setInputMod(mod: InputMod) {}
    override fun updateHint(hint: String?) {}
    override fun updateMaxLengthInput(maxLength: Int?) {}
    override fun showToBottomButton() {}
    override fun hideToBottomButton() {}
    override fun collapseHeader(operatorsInOnline: Boolean) {}
    override fun updateElevationHeader(elevation: Float) {}
    override fun showDataSavedMessage() {}
    override fun openFilePicker() {}
    override fun updatePhoneRegionFlag(flag: String) {}
    override fun updatePhoneRegionPrefix(prefix: String) {}
    override fun setKeyboardType(keyboardType: Int) {}
    override fun getCurrentContext(): android.content.Context? = null
    override fun getSupportFragmentManager(): androidx.fragment.app.FragmentManager? = null
    override fun goToParentActivity() {}
    override fun finish() {}
}
