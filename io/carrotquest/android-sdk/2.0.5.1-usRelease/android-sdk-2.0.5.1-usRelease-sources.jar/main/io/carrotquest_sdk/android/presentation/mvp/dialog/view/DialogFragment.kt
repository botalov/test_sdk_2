package io.carrotquest_sdk.android.presentation.mvp.dialog.view

import android.Manifest
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Point
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Pair
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts.OpenDocument
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.os.bundleOf
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.vanniktech.rxpermission.Permission
import com.vanniktech.rxpermission.RealRxPermission
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.network.js_interface.DialogJSInterface
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.getDraftMessageUseCase
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.OperatorStatus
import io.carrotquest_sdk.android.presentation.mvp.dialog.presenter.DialogPresenter
import io.carrotquest_sdk.android.presentation.mvp.file_picker.FilePickerHelper
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView
import io.reactivex.Observer
import io.reactivex.disposables.Disposable

class DialogFragment : Fragment(), IDialogView {

    companion object {
        private const val TAG = "DialogFragment"
        private const val ARG_CONVERSATION_ID = "conversation_id"

        fun newInstance(conversationId: String) = DialogFragment().apply {
            arguments = bundleOf(ARG_CONVERSATION_ID to conversationId)
        }
    }

    private val presenter = DialogPresenter()
    private var carrotWebView: CarrotWebView? = null
    private var currentInputMod = InputMod.NORMAL

    private val documentPick = registerForActivityResult(OpenDocument()) { uri ->
        presenter.onOpenFile(uri)
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val conversationId = arguments?.getString(ARG_CONVERSATION_ID) ?: ""

        applyTheme()

        carrotWebView = CarrotWebView(requireActivity())

        try {
            presenter.attachView(this)
            presenter.onCreate()
        } catch (e: Exception) {
            Log.e(TAG, "$e")
        }

        initViews(conversationId)

        val webViewContainer = view.findViewById<FrameLayout>(R.id.web_view_container)
        carrotWebView?.let { wv ->
            webViewContainer.addView(
                wv,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        carrotWebView?.addLoadingObserver(object : Observer<Boolean> {
            override fun onSubscribe(d: Disposable) {}
            override fun onComplete() {}
            override fun onError(e: Throwable) {
                Log.e(TAG, e.toString())
                showErrorSomething()
            }

            override fun onNext(isLoadingWebView: Boolean) {
                if (isLoadingWebView) {
                    when {
                        conversationId == "last_conversation" -> presenter.onOpenLastDialog()
                        conversationId.isNotEmpty() -> presenter.onOpenDialog()
                        else -> presenter.onOpenNewDialog()
                    }
                }
            }
        })

        carrotWebView?.setErrorObserver { isError ->
            presenter.onChangeErrorStateWebView(isError)
        }

        carrotWebView?.setOnScroll { v, _, scrollY, _, _ ->
            val offsetY = (v as android.webkit.WebView).contentHeight * v.scale - (scrollY + v.height)
            presenter.onScrollDialog(offsetY, scrollY)
        }

        // Синхронизация фокуса и клавиатуры — два направления:
        //
        // 1) Тап в тело диалога (WebView) → снимаем фокус с поля ввода и прячем клавиатуру.
        //    Без этого тестер видел: фокус уходит, но IME остаётся "висеть", звуки нажатий
        //    есть, текст никуда не вводится.
        carrotWebView?.setOnInteractionListener {
            view.findViewById<EditText?>(R.id.input_message_edit_text)?.let { et ->
                if (et.hasFocus()) {
                    val imm = et.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                    imm.hideSoftInputFromWindow(et.windowToken, 0)
                    et.clearFocus()
                }
            }
        }

        // 2) Скрытие клавиатуры системной кнопкой ↓ → editText сохраняет фокус, курсор
        //    продолжает моргать. Снимаем фокус явно, когда RootContainerForKeyboard
        //    зафиксировал увеличение окна (delta < 0 = клавиатура исчезла).
        view.findViewById<EditText?>(R.id.input_message_edit_text)?.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                val imm = v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(v.windowToken, 0)
            }
        }

        // Keyboard size detection
        view.findViewById<RootContainerForKeyboard>(R.id.dialog_fragment_root)
            .setSizeObserver(object : Observer<Pair<Int, Int>> {
                override fun onSubscribe(d: Disposable) {}
                override fun onError(e: Throwable) {}
                override fun onComplete() {}
                override fun onNext(oldNewSize: Pair<Int, Int>) {
                    val oldHeight = oldNewSize.first
                    val newHeight = oldNewSize.second
                    val delta = oldHeight - newHeight
                    val barsHeight = requireView()
                        .findViewById<ConstraintLayout>(R.id.bottom_bar)
                        ?.measuredHeight ?: 0
                    if (delta > 0) {
                        presenter.onViewKeyboardShow(oldHeight, newHeight, barsHeight)
                    } else {
                        presenter.onViewKeyboardHide(oldHeight, newHeight, barsHeight)
                        // Клавиатура была скрыта пользователем (стрелка вниз / system back).
                        // EditText сам фокус не сбрасывает — синхронизируем здесь.
                        // Порог 100px фильтрует мелкие переразметки (status bar, IME bar).
                        if (delta < -100) {
                            requireView().findViewById<EditText?>(R.id.input_message_edit_text)?.clearFocus()
                        }
                    }
                }
            })

        presenter.onChangeConversationId(conversationId)
        presenter.onCreateWebView(conversationId)
        reloadWebView()
    }

    override fun onResume() {
        super.onResume()
        presenter.onResume()
    }

    override fun onPause() {
        presenter.onPause()
        super.onPause()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        presenter.onDestroy()
        carrotWebView?.onDestroy()
        carrotWebView = null
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private fun initViews(conversationId: String) {
        val view = requireView()

        view.findViewById<ImageButton>(R.id.attach_file_image_button).setOnClickListener {
            presenter.onOpenPicker(getScreenHeight() * 2 / 3)
        }

        view.findViewById<ImageButton>(R.id.send_message_image_button).setOnClickListener {
            presenter.onTapSendMessage(
                view.findViewById<EditText>(R.id.input_message_edit_text).text.toString()
            )
        }

        view.findViewById<EditText>(R.id.input_message_edit_text).addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun afterTextChanged(s: Editable) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                presenter.onInputText(s.toString())
            }
        })

        view.findViewById<FloatingActionButton>(R.id.to_bottom_fab).setOnClickListener {
            presenter.onTabToBottomScroll()
        }

        view.findViewById<ConstraintLayout?>(R.id.phone_prefix)?.setOnClickListener {
            presenter.onTapPhonePrefix(requireActivity() as androidx.appcompat.app.AppCompatActivity)
        }

        disableInput()
    }

    private fun applyTheme() {
        val view = requireView()
        when (getThemeUseCase(requireContext())) {
            SimpleTheme.DARK -> {
                view.setBackgroundColor(Color.parseColor("#333333"))
                view.findViewById<ConstraintLayout?>(R.id.bottom_bar)
                    ?.setBackgroundColor(Color.parseColor("#333333"))
                view.findViewById<EditText?>(R.id.input_message_edit_text)
                    ?.setTextColor(Color.parseColor("#FFFFFF"))
                view.findViewById<EditText?>(R.id.input_message_edit_text)
                    ?.setHintTextColor(Color.parseColor("#B3B3B3"))
                view.findViewById<ImageView?>(R.id.phone_prefix_arrow)
                    ?.imageTintList = ColorStateList.valueOf(Color.parseColor("#999999"))
            }
            else -> {
                view.setBackgroundColor(Color.parseColor("#FFFFFF"))
                view.findViewById<ConstraintLayout?>(R.id.bottom_bar)
                    ?.setBackgroundColor(Color.parseColor("#FFFFFF"))
                view.findViewById<EditText?>(R.id.input_message_edit_text)
                    ?.setTextColor(Color.parseColor("#000000"))
                view.findViewById<EditText?>(R.id.input_message_edit_text)
                    ?.setHintTextColor(Color.parseColor("#B3B3B3"))
                view.findViewById<ImageView?>(R.id.phone_prefix_arrow)
                    ?.imageTintList = ColorStateList.valueOf(Color.parseColor("#5C6370"))
            }
        }
    }

    private fun reloadWebView() {
        carrotWebView?.showLoading()
        loadUrl()
    }

    private fun getScreenHeight(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            requireActivity().windowManager.currentWindowMetrics.bounds.height()
        } else {
            @Suppress("DEPRECATION")
            val size = Point()
            @Suppress("DEPRECATION")
            requireActivity().windowManager.defaultDisplay.getSize(size)
            size.y
        }
    }

    private fun changeEnabledSendButton(isEnabled: Boolean) {
        val editText = view?.findViewById<EditText>(R.id.input_message_edit_text) ?: return
        val text = editText.text.toString().trim()
        val isNotEmpty = text.isNotEmpty()

        val inputType = editText.inputType
        val correctEmail = if (inputType == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS) {
            android.util.Patterns.EMAIL_ADDRESS.matcher(text).matches()
        } else true
        val correctPhone = if (inputType == InputType.TYPE_CLASS_PHONE) {
            text.length > 5
        } else true

        val sendButton = view?.findViewById<ImageButton>(R.id.send_message_image_button) ?: return
        val enabled = isEnabled && correctEmail && correctPhone && isNotEmpty
        sendButton.isEnabled = enabled
        sendButton.alpha = if (enabled) 1f else 0.5f
    }

    // ── IDialogView: WebView ──────────────────────────────────────────────────

    override fun setupWebView(webView: CarrotWebView) {}

    override fun loadUrl() {
        carrotWebView?.loadUrl(BuildConfig.DIALOG_URL)
        carrotWebView?.initJsInterface(DialogJSInterface(requireActivity(), presenter, carrotWebView))
    }

    override fun initStartView(jsonScript: String) {
        carrotWebView?.executeJsInWebView(jsonScript)
    }

    override fun showMessage(messageJson: String) {
        carrotWebView?.executeJsInWebView(messageJson)
    }

    override fun deleteMessage(messageJson: String) {
        carrotWebView?.executeJsInWebView(messageJson)
    }

    override fun deleteAllMessages(js: String) {
        carrotWebView?.executeJsInWebView(js)
    }

    override fun updateMessage(messageJson: String) {
        carrotWebView?.executeJsInWebView(messageJson)
    }

    override fun scrollWebView(js: String) {
        carrotWebView?.executeJsInWebView(js)
    }

    override fun toBottomScroll() {
        carrotWebView?.executeJsInWebView("javascript:window.webView.forceScrollBottom()")
        view?.findViewById<FloatingActionButton>(R.id.to_bottom_fab)?.hide()
    }

    override fun startRoutingBot(jsonScript: String) {
        carrotWebView?.executeJsInWebView(jsonScript)
    }

    override fun addBrunch(jsonScript: String) {
        carrotWebView?.executeJsInWebView(jsonScript)
    }

    override fun hideLoadError() {
        carrotWebView?.hideLoadError()
    }

    override fun hideLoading() {
        carrotWebView?.hideLoading()
    }

    // ── IDialogView: Errors ───────────────────────────────────────────────────

    override fun showErrorNoInternet() {
        requireActivity().runOnUiThread {
            hideLoading()
            carrotWebView?.showNoInternetError()
        }
    }

    override fun showErrorAirplaneMode() {
        requireActivity().runOnUiThread {
            hideLoading()
            carrotWebView?.showAirplaneModError()
        }
    }

    override fun showErrorSomething() {
        requireActivity().runOnUiThread {
            hideLoading()
            carrotWebView?.showLoadError()
        }
    }

    override fun showErrorFileNotFound() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_lib_something_wrong),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun showErrorSendMessage() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_lib_something_wrong),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    override fun showDataSavedMessage() {
        val rootView = view ?: return
        com.google.android.material.snackbar.Snackbar.make(
            rootView, getString(R.string.cq_your_data_is_saved),
            com.google.android.material.snackbar.Snackbar.LENGTH_SHORT
        ).show()
    }

    // ── IDialogView: Input ────────────────────────────────────────────────────

    override fun enableInput() {
        requireActivity().runOnUiThread {
            val v = view ?: return@runOnUiThread
            v.findViewById<ConstraintLayout?>(R.id.bottom_bar)?.isEnabled = true
            v.findViewById<ImageButton?>(R.id.attach_file_image_button)?.let { btn ->
                btn.isEnabled = true
                btn.alpha = 1f
            }
            v.findViewById<EditText?>(R.id.input_message_edit_text)?.let { et ->
                et.isEnabled = true
                et.alpha = 1f
            }
            changeEnabledSendButton(true)
        }
    }

    override fun disableInput() {
        val v = view ?: return
        v.findViewById<ConstraintLayout?>(R.id.bottom_bar)?.isEnabled = false
        v.findViewById<ImageButton?>(R.id.attach_file_image_button)?.let { btn ->
            btn.isEnabled = false
            btn.alpha = 0.5f
        }
        v.findViewById<EditText?>(R.id.input_message_edit_text)?.let { et ->
            et.isEnabled = false
            et.alpha = 0.5f
        }
        changeEnabledSendButton(false)
    }

    override fun hideInput() {
        view?.findViewById<ConstraintLayout?>(R.id.bottom_bar)?.isGone = true
    }

    override fun showInput(conversationId: String) {
        val v = view ?: return
        val draftMessage = getDraftMessageUseCase(conversationId)
        val editText = v.findViewById<EditText?>(R.id.input_message_edit_text)
        if (draftMessage != null) {
            editText?.setText(draftMessage)
            editText?.setSelection(draftMessage.length)
        } else {
            clearInput()
        }
        v.findViewById<ConstraintLayout?>(R.id.bottom_bar)?.isVisible = true
        if (editText?.text.isNullOrEmpty()) {
            disableSendButton()
        }
    }

    override fun clearInput() {
        requireActivity().runOnUiThread {
            view?.findViewById<EditText?>(R.id.input_message_edit_text)?.let { et ->
                if (et.text.isNotEmpty()) et.text.clear()
            }
        }
    }

    override fun setInputMod(mod: InputMod) {
        currentInputMod = mod
        requireActivity().runOnUiThread {
            val v = view ?: return@runOnUiThread
            when (currentInputMod) {
                InputMod.NORMAL, InputMod.ALLOW_USER_REPLIES -> {
                    v.findViewById<ImageButton?>(R.id.attach_file_image_button)?.isVisible = true
                    v.findViewById<EditText?>(R.id.input_message_edit_text)?.hint =
                        getString(R.string.input_message_hint_text)
                }
                InputMod.BOT_INPUT -> {
                    v.findViewById<ImageButton?>(R.id.attach_file_image_button)?.isGone = true
                    v.findViewById<EditText?>(R.id.input_message_edit_text)?.hint = ""
                }
            }
        }
    }

    override fun updateHint(hint: String?) {
        view?.findViewById<EditText?>(R.id.input_message_edit_text)?.hint =
            hint ?: getString(R.string.input_message_hint_text)
    }

    override fun updateMaxLengthInput(maxLength: Int?) {
        view?.findViewById<EditText?>(R.id.input_message_edit_text)?.filters =
            if (maxLength != null) arrayOf(InputFilter.LengthFilter(maxLength)) else arrayOf()
    }

    override fun showSendButton() {
        requireActivity().runOnUiThread {
            view?.findViewById<ImageButton?>(R.id.send_message_image_button)?.isVisible = true
        }
    }

    override fun hideSendButton() {
        requireActivity().runOnUiThread {
            view?.findViewById<ImageButton?>(R.id.send_message_image_button)?.isGone = true
        }
    }

    override fun enableSendButton() {
        requireActivity().runOnUiThread {
            view?.findViewById<ImageButton?>(R.id.send_message_image_button)?.isVisible = true
            changeEnabledSendButton(true)
        }
    }

    override fun disableSendButton() {
        requireActivity().runOnUiThread {
            view?.findViewById<ImageButton?>(R.id.send_message_image_button)?.isVisible = true
            changeEnabledSendButton(false)
        }
    }

    override fun showAttachFileButton() {
        view?.findViewById<ImageButton?>(R.id.attach_file_image_button)?.isVisible = true
    }

    override fun hideAttachFileButton() {
        view?.findViewById<ImageButton?>(R.id.attach_file_image_button)?.isGone = true
    }

    override fun showPhonePrefix() {
        view?.findViewById<ConstraintLayout?>(R.id.phone_prefix)?.isVisible = true
    }

    override fun hidePhonePrefix() {
        view?.findViewById<ConstraintLayout?>(R.id.phone_prefix)?.isGone = true
    }

    override fun updatePhoneRegionFlag(flag: String) {
        view?.findViewById<TextView?>(R.id.phone_prefix_flag)?.text = flag
    }

    override fun updatePhoneRegionPrefix(prefix: String) {
        view?.findViewById<TextView?>(R.id.phone_prefix_first_symbol)?.text = prefix
    }

    override fun setKeyboardType(keyboardType: Int) {
        view?.findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.inputType = keyboardType
        view?.findViewById<ConstraintLayout>(R.id.bottom_bar)?.findViewById<EditText>(R.id.input_message_edit_text)?.requestFocus()

    }

    // ── IDialogView: Scroll button ────────────────────────────────────────────

    override fun showToBottomButton() {
        view?.findViewById<FloatingActionButton?>(R.id.to_bottom_fab)?.show()
    }

    override fun hideToBottomButton() {
        view?.findViewById<FloatingActionButton?>(R.id.to_bottom_fab)?.hide()
    }

    // ── IDialogView: File ─────────────────────────────────────────────────────

    override fun openFilePicker() {
        requireActivity().runOnUiThread {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                documentPick.launch(FilePickerHelper.mAllowMimeTypes)
            } else {
                val rxPermissions = RealRxPermission.getInstance(requireActivity())
                val permissions = listOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                )
                if (!rxPermissions.isGranted(Manifest.permission.READ_EXTERNAL_STORAGE) ||
                    !rxPermissions.isGranted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    rxPermissions.requestEach(*permissions.toTypedArray())
                        .subscribe { permission ->
                            if (permission.state() == Permission.State.GRANTED) {
                                documentPick.launch(FilePickerHelper.mAllowMimeTypes)
                            }
                        }
                } else {
                    documentPick.launch(FilePickerHelper.mAllowMimeTypes)
                }
            }
        }
    }

    override fun startDownloadFile(messageId: String, attachmentId: String) {
        requireActivity().runOnUiThread {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                presenter.onDownloadFile(messageId, attachmentId)
            } else {
                val rxPermissions = RealRxPermission.getInstance(requireActivity())
                val permissions = listOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                )
                if (!rxPermissions.isGranted(Manifest.permission.READ_EXTERNAL_STORAGE) ||
                    !rxPermissions.isGranted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                    rxPermissions.requestEach(*permissions.toTypedArray())
                        .subscribe { permission ->
                            if (permission.state() == Permission.State.GRANTED) {
                                presenter.onDownloadFile(messageId, attachmentId)
                            }
                        }
                } else {
                    presenter.onDownloadFile(messageId, attachmentId)
                }
            }
        }
    }

    override fun getCurrentContext(): Context? = context ?: activity

    override fun getSupportFragmentManager(): androidx.fragment.app.FragmentManager? =
        if (isAdded) parentFragmentManager else null

    override fun goToParentActivity() {
        // Handled by SdkContainerActivity
    }

    override fun finish() {
        // Close handled by SdkContainerActivity's shared header
    }

    // ── IDialogView: Header stubs (handled by shared Compose header) ──────────

    override fun updateUnreadConversationsCount(count: Int) {}
    override fun updateAdminsAvatars(avatars: Array<android.widget.ImageView>) {}
    override fun updateAdminName(adminName: String) {}
    override fun updateAdminName(adminName: String, needResize: Boolean) {}
    override fun updateAppName(appName: String) {}
    override fun updateStatus(status: OperatorStatus) {}
    override fun updateAppDescription(description: String, operatorsInOnline: Boolean) {}
    override fun updateStatusCollapsedAppBar(operatorsInOnline: Boolean) {}
    override fun updateAppColor(color: Int) {
        carrotWebView?.setColor(color)

        val currentTheme = getThemeUseCase(requireContext())
        val cButtonToBottom = if (currentTheme == SimpleTheme.DARK) {
            @Suppress("DEPRECATION") resources.getColor(R.color.colorButtonToBottomDialogFABDark)
        } else {
            @Suppress("DEPRECATION") resources.getColor(R.color.colorButtonToBottomDialogFAB)
        }

        view?.findViewById<ImageButton>(R.id.send_message_image_button)?.let { btn ->
            btn.backgroundTintList = ColorStateList.valueOf(color)
            btn.imageTintList = ColorStateList.valueOf(cButtonToBottom)
        }

        view?.findViewById<FloatingActionButton>(R.id.to_bottom_fab)?.let { fab ->
            fab.supportImageTintList = ColorStateList.valueOf(color)
            fab.backgroundTintList = ColorStateList.valueOf(cButtonToBottom)
        }
    }
    override fun collapseHeader(operatorsInOnline: Boolean) {}
    override fun updateElevationHeader(elevation: Float) {}


}
