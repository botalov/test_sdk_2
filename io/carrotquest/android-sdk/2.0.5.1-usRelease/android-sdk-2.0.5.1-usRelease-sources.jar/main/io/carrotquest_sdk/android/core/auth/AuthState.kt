package io.carrotquest_sdk.android.core.auth

sealed class AuthState {
    object Idle : AuthState()
    object Authenticating : AuthState()
    data class Authenticated(val userId: String) : AuthState()
    data class Failed(val error: Throwable) : AuthState()
}