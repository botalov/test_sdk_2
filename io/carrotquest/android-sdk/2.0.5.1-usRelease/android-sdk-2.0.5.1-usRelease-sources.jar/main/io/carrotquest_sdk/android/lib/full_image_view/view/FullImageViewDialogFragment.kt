package io.carrotquest_sdk.android.lib.full_image_view.view

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import com.google.android.material.snackbar.Snackbar
import com.vanniktech.rxpermission.Permission
import com.vanniktech.rxpermission.RealRxPermission
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.lib.utils.files.SaveImageCallback
import io.carrotquest_sdk.android.lib.view.full_image_view.presenter.FullImageViewPresenter
import java.io.File

class FullImageViewDialogFragment : DialogFragment() {

    private val presenter = FullImageViewPresenter()

    private var isLoading by mutableStateOf(true)
    private var showError by mutableStateOf(false)
    private var controlsVisible by mutableStateOf(true)
    private var canSaveShare by mutableStateOf(false)

    companion object {
        private const val URL_IMAGE = "url_image_for_full_view"
        private const val FILE_PATH = "file_path_for_full_view"
        private const val BITMAP = "bitmap_for_full_view"

        fun newInstance(url: String) = FullImageViewDialogFragment().apply {
            setStyle(STYLE_NO_FRAME, R.style.FullScreenDialog)
            arguments = Bundle().also { it.putString(URL_IMAGE, url) }
        }

        fun newInstance(file: File) = FullImageViewDialogFragment().apply {
            setStyle(STYLE_NO_FRAME, R.style.FullScreenDialog)
            arguments = Bundle().also { it.putString(FILE_PATH, file.path) }
        }

        fun newInstance(bitmap: Bitmap) = FullImageViewDialogFragment().apply {
            setStyle(STYLE_NO_FRAME, R.style.FullScreenDialog)
            arguments = Bundle().also { it.putParcelable(BITMAP, bitmap) }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val imageSource = resolveImageSource() ?: ImageSource.FromUrl("").also {
            isLoading = false
            showError = true
        }

        return ComposeView(requireContext()).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                FullImageViewScreen(
                    imageSource = imageSource,
                    isLoading = isLoading,
                    showError = showError,
                    controlsVisible = controlsVisible,
                    canSaveShare = canSaveShare,
                    onBack = { dismiss() },
                    onDismiss = { dismiss() },
                    onDragOffsetChanged = { offset -> updateWindowAlpha(offset) },
                    onImageTap = { controlsVisible = !controlsVisible },
                    onShare = { handleShare() },
                    onSave = { handleSave() },
                    onImageLoaded = { drawable ->
                        isLoading = false
                        val uri = presenter.onLoadResource(drawable, requireContext())
                        if (uri != null) canSaveShare = true
                    },
                    onImageLoadFailed = {
                        isLoading = false
                        showError = true
                    }
                )
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewLifecycleOwner.lifecycleScope.launch {
            snapshotFlow { controlsVisible }.collect { visible ->
                val window = dialog?.window ?: return@collect
                val controller = WindowInsetsControllerCompat(window, window.decorView)
                if (visible) {
                    controller.show(WindowInsetsCompat.Type.statusBars())
                } else {
                    controller.systemBarsBehavior =
                        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(WindowInsetsCompat.Type.statusBars())
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.let { window ->
            window.setBackgroundDrawableResource(android.R.color.transparent)
            WindowCompat.setDecorFitsSystemWindows(window, false)
            window.setWindowAnimations(R.style.DialogAnimationFade)
            window.attributes = window.attributes.also { it.alpha = 1f }
            WindowInsetsControllerCompat(window, window.decorView)
                .show(WindowInsetsCompat.Type.statusBars())
        }
    }

    private fun updateWindowAlpha(offset: Float) {
        dialog?.window?.let { window ->
            window.attributes = window.attributes.also {
                it.alpha = (1f - offset / 800f).coerceIn(0f, 1f)
            }
        }
    }

    private fun resolveImageSource(): ImageSource? {
        val args = arguments ?: return null
        return when {
            args.getString(URL_IMAGE) != null -> ImageSource.FromUrl(args.getString(URL_IMAGE)!!)
            args.getString(FILE_PATH) != null -> ImageSource.FromFile(File(args.getString(FILE_PATH)!!))
            args.getParcelable<Bitmap>(BITMAP) != null -> ImageSource.FromBitmap(args.getParcelable(BITMAP)!!)
            else -> null
        }
    }

    private fun handleShare() {
        val intent = presenter.createShareIntent(requireContext()) ?: return
        startActivity(Intent.createChooser(intent, getString(R.string.cq_lib_share_intent_title)))
    }

    private fun handleSave() {
        RealRxPermission.getInstance(context)
            .request(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            .subscribe { _: Permission? ->
                presenter.saveImage(
                    requireActivity().contentResolver,
                    object : SaveImageCallback {
                        override fun done() {
                            view?.let { Snackbar.make(it, getString(R.string.cq_lib_save_success), Snackbar.LENGTH_LONG).show() }
                        }
                        override fun fail() {
                            view?.let { Snackbar.make(it, getString(R.string.cq_lib_something_wrong), Snackbar.LENGTH_LONG).show() }
                        }
                    }
                )
            }
    }
}
