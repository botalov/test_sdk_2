package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.viewmodel

import com.vdurmont.emoji.EmojiParser
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.PreviewIcon

/**
 * Stateless builder: принимает [MessageData] и набор локализованных строк,
 * возвращает текст превью и иконку вложения.
 * Не зависит от Android Context — легко покрывается юнит-тестами.
 */
internal object MessagePreviewBuilder {

    data class Strings(
        val file: String,
        val image: String,
        val images: String,
        val files: String,
        val deleted: String,
    )

    fun build(msg: MessageData?, strings: Strings): Pair<String, PreviewIcon> {
        if (msg == null) return "" to PreviewIcon.NONE

        if (!msg.removed.isNullOrEmpty()) return strings.deleted to PreviewIcon.NONE

        if (msg.type == ResponseFields.ARTICLE) {
            val title = runCatching {
                msg.bodyJson?.takeIf { it.isJsonObject }
                    ?.asJsonObject?.get(F.NAME)?.asString
            }.getOrNull()
            return (title ?: strings.file) to PreviewIcon.NONE
        }

        val body = EmojiParser.parseToUnicode(msg.body ?: "")
        val attachments = msg.attachments.orEmpty()
        val hasText = body.isNotBlank()

        return when {
            attachments.isEmpty() -> body to PreviewIcon.NONE

            hasText -> {
                val icon = if (attachments.first().mimeType?.startsWith("image/") == true)
                    PreviewIcon.IMAGE else PreviewIcon.FILE
                body to icon
            }

            attachments.size == 1 -> {
                val att = attachments.first()
                if (att.mimeType?.startsWith("image/") == true) {
                    strings.image to PreviewIcon.IMAGE
                } else {
                    (att.filename ?: strings.file) to PreviewIcon.FILE
                }
            }

            else -> {
                val allImages = attachments.all { it.mimeType?.startsWith("image/") == true }
                if (allImages) strings.images to PreviewIcon.IMAGE
                else strings.files to PreviewIcon.FILE
            }
        }
    }
}
