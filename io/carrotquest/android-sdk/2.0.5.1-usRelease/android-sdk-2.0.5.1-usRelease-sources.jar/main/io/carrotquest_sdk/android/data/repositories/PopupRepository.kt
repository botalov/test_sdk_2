package io.carrotquest_sdk.android.data.repositories

import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.db.popup.PopUpDbEntity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.PublishSubject
import java.sql.Timestamp
import java.util.concurrent.TimeUnit

class PopupRepository {

    companion object {
        private val expirationSubject = PublishSubject.create<String>()

        fun savePopUp(popUp: PopUpDbEntity) {
            SdkApp
                    .getInstance()
                    .database
                    .popUpDao()
                    .insert(popUp)

            if (popUp.expirationTime > 0) {
                startPopUpExpiration(popUp.id, popUp.expirationTime)
            }
        }

        fun removePopUpById(id: String) {
            SdkApp
                    .getInstance()
                    .database
                    .popUpDao()
                    .deleteById(id)
        }

        fun getAllPopUps(): ArrayList<PopUpDbEntity> {
            val dbArray = SdkApp
                    .getInstance()
                    .database
                    .popUpDao()
                    .getAllPopUpsSync()

            return ArrayList(dbArray
                    .filterNotNull())
        }

        fun getAllPopUpsObservable(): Observable<ArrayList<PopUpDbEntity>> {
            return SdkApp
                    .getInstance()
                    .database
                    .popUpDao()
                    .getAllPopUps()
                    .subscribeOn(Schedulers.io())
                    .toObservable()
                    .map { dbEntities ->
                        return@map ArrayList<PopUpDbEntity>(dbEntities)
                    }
        }

        fun expirationObservable(): Observable<String> = expirationSubject

        private fun startPopUpExpiration(id: String, expirationTime: Long) {
            val correctExpirationTime: Long = expirationTime * 1000
            val currentTime = Timestamp(System.currentTimeMillis()).time
            val minExpirationTime = 30 * 1000L
            //Считаем разницу между временем, в которое надо удалить сообщение и текущим времененм
            val diff = if (correctExpirationTime - currentTime < minExpirationTime) {
                minExpirationTime
            } else {
                correctExpirationTime - currentTime
            }
            val x = Observable.just(true)
                    .delay(diff, TimeUnit.MILLISECONDS)
                    .subscribe({
                        removePopUpById(id)
                        expirationSubject.onNext(id)
                    }, { t ->
                        Log.e("PopUpRepository", t)
                    })
        }
    }
}