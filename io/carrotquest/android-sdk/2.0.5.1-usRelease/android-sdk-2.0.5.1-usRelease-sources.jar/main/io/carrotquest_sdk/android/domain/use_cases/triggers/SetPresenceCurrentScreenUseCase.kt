package io.carrotquest_sdk.android.domain.use_cases.triggers

import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import io.reactivex.Observable

class SetPresenceCurrentScreenUseCase {
    fun call(screenName: String): Observable<UserEntity> {
        return Observable.just(true)
            .getCurrentUser()
            .take(1)
            .doOnNext { user ->
                val d1 = CarrotInternal.getService().carrotLib.setPresenceCurrentScreen(
                    F.ONLINE_USER,
                    screenName
                )
                    .subscribe({
                        Log.d("setPresenceCurrentScreen", "success")
                    }, { t ->
                        Log.e("setPresenceCurrentScreen", "error: $t")
                    })
            }
    }
}