package io.carrotquest_sdk.android.domain.use_cases.user

import android.content.Context
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib

fun getAuthedUserIdUseCase(context: Context = CarrotLib.getLibComponents().context): List<String>? {
    val key = SharedPreferenceKeys.AUTHED_USER_ID_KEY
    val idsString: String = SharedPreferencesLib.getString(context, key)

    if(idsString.isEmpty() || !idsString.contains(":")) {
        return null
    }

    val idsList = idsString.split(":")
    if(idsList.size != 2) {
        return null
    }

    return idsList
}

fun getConnectedUserIdUseCase(context: Context = CarrotLib.getLibComponents().context): String? {
    val key = SharedPreferenceKeys.CONNECTED_USER_ID_KEY
    val id: String = SharedPreferencesLib.getString(context, key)

    if(id.isEmpty()) {
        return null
    }

    return id
}