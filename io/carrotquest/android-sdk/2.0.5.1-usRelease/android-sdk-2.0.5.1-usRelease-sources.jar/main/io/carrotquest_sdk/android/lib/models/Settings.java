package io.carrotquest_sdk.android.lib.models;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.network.F;

@Keep
public class Settings {
    //VK
    @SerializedName(F.MESSENGER_ICON_VK_SHOW)
    private boolean isShowVK;
    @SerializedName(F.MESSENGER_ICON_VK_TEXT)
    private String textLinkVK;
    //Viber
    @SerializedName(F.MESSENGER_ICON_VIBER_SHOW)
    private boolean isShowViber;
    @SerializedName(F.MESSENGER_ICON_VIBER_TEXT)
    private String textLinkViber;
    //FB
    @SerializedName(F.MESSENGER_ICON_FACEBOOK_SHOW)
    private boolean isShowFB;
    @SerializedName(F.MESSENGER_ICON_FACEBOOK_TEXT)
    private String textLinkFB;
    //Telegram
    @SerializedName(F.MESSENGER_ICON_TELEGRAM_SHOW)
    private boolean isShowTelegram;
    @SerializedName(F.MESSENGER_ICON_TELEGRAM_TEXT)
    private String textLinkTelegram;
    //Instagram
    @SerializedName(F.MESSENGER_ICON_INSTAGRAM_SHOW)
    private boolean isShowInstagram;
    @SerializedName(F.MESSENGER_ICON_INSTAGRAM_TEXT)
    private String textLinkInstagram;
    //WhatsApp
    @SerializedName(F.MESSENGER_ICON_WHATSAPP_SHOW)
    private boolean isShowWhatsapp;
    @SerializedName(F.MESSENGER_ICON_WHATSAPP_TEXT)
    private String textLinkWhatsapp;

    @SerializedName(F.MESSENGER_COLLAPSED_COLOR)
    private String appColor;
    @SerializedName(F.MESSENGER_WELCOME_MESSAGE)
    private String welcomeMessage;
    @SerializedName(F.MESSENGER_AVATAR)
    private String messengerAvatar;
    @SerializedName(F.MESSENGER_SHOW_POWERED_BY)
    private boolean showPoweredBy;
    @SerializedName(F.MESSENGER_SHOW_KB_LINK_IN_WELCOME_MESSAGE)
    private boolean showKbLinkInWelcomeMessage;

    @SerializedName(F.MESSENGER_OFFLINE_MESSAGE)
    private String offlineMessage;
    @SerializedName(F.MESSENGER_ONLINE_MESSAGE)
    private String onlineMessage;

    @SerializedName(F.MESSENGER_THEME)
    private String theme;
    @SerializedName(F.MESSENGER_NAME)
    private String messengerName;

    @SerializedName(F.LOCALE)
    private String locale;

    @SerializedName(F.MESSENGER_PATTERN)
    private String messengerPattern;


    public boolean isShowVK() {
        return isShowVK;
    }

    public void setShowVK(boolean showVK) {
        isShowVK = showVK;
    }

    public String getTextLinkVK() {
        return textLinkVK;
    }

    public void setTextLinkVK(String textLinkVK) {
        this.textLinkVK = textLinkVK;
    }

    public boolean isShowViber() {
        return isShowViber;
    }

    public void setShowViber(boolean showViber) {
        isShowViber = showViber;
    }

    public String getTextLinkViber() {
        return textLinkViber;
    }

    public void setTextLinkViber(String textLinkViber) {
        this.textLinkViber = textLinkViber;
    }

    public boolean isShowFB() {
        return isShowFB;
    }

    public void setShowFB(boolean showFB) {
        isShowFB = showFB;
    }

    public String getTextLinkFB() {
        return textLinkFB;
    }

    public void setTextLinkFB(String textLinkFB) {
        this.textLinkFB = textLinkFB;
    }

    public boolean isShowTelegram() {
        return isShowTelegram;
    }

    public void setShowTelegram(boolean showTelegram) {
        isShowTelegram = showTelegram;
    }

    public String getTextLinkTelegram() {
        return textLinkTelegram;
    }

    public void setTextLinkTelegram(String textLinkTelegram) {
        this.textLinkTelegram = textLinkTelegram;
    }

    public boolean isShowInstagram() {
        return isShowInstagram;
    }
    public void setShowInstagram(boolean showInstagram) {
        isShowInstagram = showInstagram;
    }
    public String getTextLinkInstagram() {
        return textLinkInstagram;
    }

    public boolean isShowWhatsapp() {
        return isShowWhatsapp;
    }
    public void setShowWhatsapp(boolean showWhatsapp) {
        isShowWhatsapp = showWhatsapp;
    }
    public String getTextLinkWhatsapp() {
        return textLinkWhatsapp;
    }

    public String getAppColor() {
        return appColor;
    }

    public void setAppColor(String appColor) {
        this.appColor = appColor;
    }

    public String getWelcomeMessage() {
        return welcomeMessage;
    }

    public void setWelcomeMessage(String welcomeMessage) {
        this.welcomeMessage = welcomeMessage;
    }

    public String getMessengerAvatar() {
        return messengerAvatar;
    }

    public void setMessengerAvatar(String messengerAvatar) {
        this.messengerAvatar = messengerAvatar;
    }

    public boolean isShowPoweredBy() {
        return showPoweredBy;
    }

    public void setShowPoweredBy(boolean showPoweredBy) {
        this.showPoweredBy = showPoweredBy;
    }

    public boolean isShowKbLinkInWelcomeMessage() {
        return showKbLinkInWelcomeMessage;
    }

    public void setShowKbLinkInWelcomeMessage(boolean showKbLinkInWelcomeMessage) {
        this.showKbLinkInWelcomeMessage = showKbLinkInWelcomeMessage;
    }

    public String getOfflineMessage() {
        return offlineMessage;
    }

    public void setOfflineMessage(String offlineMessage) {
        this.offlineMessage = offlineMessage;
    }

    public String getOnlineMessage() {
        return onlineMessage;
    }

    public void setOnlineMessage(String onlineMessage) {
        this.onlineMessage = onlineMessage;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getMessengerName() {
        return messengerName;
    }

    public void setMessengerName(String messengerName) {
        this.messengerName = messengerName;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public String getMessengerPattern() {
        return messengerPattern;
    }

    public void setMessengerPattern(String messengerPattern) {
        this.messengerPattern = messengerPattern;
    }
}
