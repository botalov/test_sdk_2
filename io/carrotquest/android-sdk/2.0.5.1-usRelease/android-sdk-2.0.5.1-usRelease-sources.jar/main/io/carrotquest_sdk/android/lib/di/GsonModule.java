package io.carrotquest_sdk.android.lib.di;

import android.content.Context;

import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse;
import io.carrotquest_sdk.android.lib.network.responses.conversation.ConversationResponse;
import io.carrotquest_sdk.android.lib.network.responses.refresh.RefreshResponse;
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse;
import io.carrotquest_sdk.android.lib.network.deserializers.*;
import io.carrotquest_sdk.android.lib.network.responses.auth.AuthResponse;
import io.carrotquest_sdk.android.lib.network.responses.PushSubResponse;
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse;
import io.carrotquest_sdk.android.lib.models.UserConversations;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse;
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse;
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dagger.Module;
import dagger.Provides;
import io.carrotquest_sdk.android.lib.network.responses.triggers.TriggersResponse;
import io.carrotquest_sdk.android.lib.network.responses.user.UserResponse;

import javax.inject.Singleton;

/**
 * Date: 8/18/2016
 * Time: 14:50
 *
 * @author Artur Artikov
 */
@Module
public class GsonModule {
	private Gson gson;

	public GsonModule(Context context) {

		gson = new GsonBuilder()
				.registerTypeAdapter(AuthResponse.class, new AuthDeserializer())
				.registerTypeAdapter(ConnectResponse.class, new ConnectDeserializer())
				.registerTypeAdapter(UserConversations.class, new ConversationsDeserializer())
				.registerTypeAdapter(ConversationResponse.class, new ConversationDeserializer())
				.registerTypeAdapter(StartConversationResponse.class, new StartConversationDeserializer())
				.registerTypeAdapter(MessagesResponse.class, new MessageDeserializer())
				.registerTypeAdapter(ReplyFileResponse.class, new ReplyFileDeserializer())
				.registerTypeAdapter(ReplyResponse.class, new ReplyDeserializer())
				.registerTypeAdapter(ChooseRoutingBotResponse.class, new ChooseRoutingBotDeserializer())
				.registerTypeAdapter(PushSubResponse.class, new PushSubscribeDeserializer())
				.registerTypeAdapter(UserResponse.class, new UserDeserializer())
				.registerTypeAdapter(TriggersResponse.class, new GetTriggersDeserializer())
				.registerTypeAdapter(RefreshResponse.class, new RefreshTokenDeserializer())
				.create();
	}

	@Provides
	@Singleton
	public Gson provideGson() {
		return gson;
	}
}
