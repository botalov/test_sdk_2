package io.carrotquest_sdk.android.presentation.mvp.button.view

import android.animation.Animator
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.TypedArray
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.AttributeSet
import android.view.View
import android.view.ViewAnimationUtils
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.android.material.floatingactionbutton.FloatingActionButton
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.utils.GraphicUtils.dpToPx
import io.carrotquest_sdk.android.presentation.mvp.button.presenter.FloatingButtonPresenter
import io.carrotquest_sdk.android.presentation.mvp.utils.bubbleToFront
import kotlin.math.hypot


abstract class FloatingButton : ConstraintLayout, IFloatingButton {
    private val ANIMATE_DURATION = 300L

    private var iconFloatingButtonOnExpandState: Drawable? = resources.getDrawable(R.drawable.ic_cq_message)
    private var locationFloatingButton: LocationFloatingButton = LocationFloatingButton.BOTTOM_RIGHT
    private var marginFloatingButton = dpToPx(context, 16.0f)

    //private val TAG = "FloatingButton"
    private val presenter = FloatingButtonPresenter()
    private var typedArray: TypedArray? = null

    //======
    //private val bubbleUnreadConversationsCountTextView = findViewById<TextView>(R.id.bubble_unread_conversations_count_text_view)
    //private val fabMain = findViewById<FloatingActionButton>(R.id.fab_main)

    //private val fbButton = findViewById<FloatingActionButton>(R.id.fb_button)
    //private val fbCardView = findViewById<CardView>(R.id.fb_card_view)
    //private val fbTextView = findViewById<TextView>(R.id.fb_text_view)

    //private val tgButton = findViewById<FloatingActionButton>(R.id.telegram_button)
    //private val tgCardView = findViewById<CardView>(R.id.telegram_card_view)
    //private val tgTextView = findViewById<TextView>(R.id.telegram_text_view)

    //private val viberButton = findViewById<FloatingActionButton>(R.id.viber_button)
    //private val viberCardView = findViewById<CardView>(R.id.viber_card_view)
    //private val viberTextView = findViewById<TextView>(R.id.viber_text_view)

    //private val vkButton = findViewById<FloatingActionButton>(R.id.vk_button)
    //private val vkCardView = findViewById<CardView>(R.id.vk_card_view)
    //private val vkTextView = findViewById<TextView>(R.id.vk_text_view)

    //private val waButton = findViewById<FloatingActionButton>(R.id.whatsapp_button)
    //private val waCardView = findViewById<CardView>(R.id.whatsapp_card_view)
    //private val waTextView = findViewById<TextView>(R.id.whatsapp_text_view)

    //private val instButton = findViewById<FloatingActionButton>(R.id.instagram_button)
    //private val instCardView = findViewById<CardView>(R.id.instagram_card_view)
    //private val instTextView = findViewById<TextView>(R.id.instagram_text_view)

    //private val mainBkgView = findViewById<View>(R.id.main_bkg_view)
    //private val labelCard = findViewById<CardView>(R.id.label_card)
    //private val iconAdminCard = findViewById<CardView>(R.id.icon_admin_card)
    //private val closeLastMessageButton = findViewById<ImageButton>(R.id.close_last_message_button)
    //private val fabMainCardView = findViewById<CardView>(R.id.fab_main_card_view)
    //private val fabMainTextView = findViewById<TextView>(R.id.fab_main_text_view)
    //private val labelTextView = findViewById<TextView>(R.id.label_text_view)
    //private val iconAdminImageView = findViewById<ImageView>(R.id.icon_admin_image_view)

    constructor(context: Context) : super(context) {
        this.presenter.attachView(this)
        this.typedArray = null
        val view = inflate(context, R.layout.fab_layout, this)

        this.presenter.onStart()
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        this.presenter.attachView(this)
        this.typedArray = context.obtainStyledAttributes(attrs, R.styleable.FloatingButton)

        val view =inflate(context, R.layout.fab_layout, this)

        this.presenter.onStart()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        destroy()
    }

    override fun onFinishInflate() {
        super.onFinishInflate()

        initAttributes(typedArray)
    }

    override fun initView() {
        initButtonLocation()

        bubbleToFront(findViewById<TextView>(R.id.bubble_unread_conversations_count_text_view))
        findViewById<FloatingActionButton>(R.id.fab_main).setOnClickListener { presenter.onTapFloatingButton() }

        findViewById<FloatingActionButton>(R.id.fb_button).setOnClickListener { presenter.onTapFB() }
        findViewById<CardView>(R.id.fb_card_view).setOnClickListener { presenter.onTapFB() }

        findViewById<FloatingActionButton>(R.id.telegram_button).setOnClickListener { presenter.onTapTelegram() }
        findViewById<CardView>(R.id.telegram_card_view).setOnClickListener { presenter.onTapTelegram() }

        findViewById<FloatingActionButton>(R.id.viber_button).setOnClickListener { presenter.onTapViber() }
        findViewById<CardView>(R.id.viber_card_view).setOnClickListener { presenter.onTapViber() }

        findViewById<FloatingActionButton>(R.id.vk_button).setOnClickListener { presenter.onTapVK() }
        findViewById<CardView>(R.id.vk_card_view).setOnClickListener { presenter.onTapVK() }

        findViewById<FloatingActionButton>(R.id.instagram_button).setOnClickListener { presenter.onTapInstagram() }
        findViewById<CardView>(R.id.instagram_card_view).setOnClickListener { presenter.onTapInstagram() }

        findViewById<FloatingActionButton>(R.id.whatsapp_button).setOnClickListener { presenter.onTapWhatsapp() }
        findViewById<CardView>(R.id.whatsapp_card_view).setOnClickListener { presenter.onTapWhatsapp() }

        findViewById<CardView>(R.id.label_card).setOnClickListener { presenter.onTapLastMessage() }
        findViewById<CardView>(R.id.icon_admin_card).setOnClickListener { presenter.onTapLastMessage() }

        findViewById<View>(R.id.main_bkg_view).setOnClickListener { presenter.onTapEmptySpace() }

        findViewById<ImageButton>(R.id.close_last_message_button).setOnClickListener { presenter.onTapCloseLastMessage() }

        presenter.onCreatedView()
    }

    private fun initAttributes(typedArray: TypedArray?) {
        if(typedArray != null) {
            presenter.onSetAttributes(typedArray)
        }

    }

    override fun updateIconOnFloatingButton(icon: Drawable?) {
        if (icon != null) {
            iconFloatingButtonOnExpandState = icon
            findViewById<FloatingActionButton>(R.id.fab_main)?.setImageDrawable(icon)
        }
    }

    override fun setLocationFloatingButton(location: LocationFloatingButton) {
        this.locationFloatingButton = location
        initButtonLocation()
    }

    override fun setMarginFloatingButton(margin: Float) {
        this.marginFloatingButton = margin.toInt()
    }

    override fun updateMainBackgroundAlpha(alpha: Float) {
        findViewById<View>(R.id.main_bkg_view)?.alpha = alpha
    }

    private fun destroy() {
        presenter.onDestroy()
    }


    private fun initButtonLocation() {
        val constraintSet = ConstraintSet()

        if(findViewById<FloatingActionButton>(R.id.fab_main) == null) {
            return
        }

        if(findViewById<FloatingActionButton>(R.id.fab_main).parent != null && findViewById<FloatingActionButton>(R.id.fab_main).parent is ConstraintLayout) {
            constraintSet.clone(findViewById<FloatingActionButton>(R.id.fab_main).parent as ConstraintLayout)
        }
        constraintSet.clear(R.id.fab_main, ConstraintSet.TOP)
        constraintSet.clear(R.id.fab_main, ConstraintSet.BOTTOM)
        constraintSet.clear(R.id.fab_main, ConstraintSet.START)
        constraintSet.clear(R.id.fab_main, ConstraintSet.END)
        constraintSet.clear(R.id.fab_main, ConstraintSet.LEFT)
        constraintSet.clear(R.id.fab_main, ConstraintSet.RIGHT)

        when (locationFloatingButton) {
            LocationFloatingButton.TOP_LEFT -> {
                constraintSet.connect(R.id.fab_main, ConstraintSet.START, R.id.main_container, ConstraintSet.START, marginFloatingButton)
                constraintSet.connect(R.id.fab_main, ConstraintSet.TOP, R.id.main_container, ConstraintSet.TOP, marginFloatingButton)
            }
            LocationFloatingButton.TOP_RIGHT -> {
                constraintSet.connect(R.id.fab_main, ConstraintSet.END, R.id.main_container, ConstraintSet.END, marginFloatingButton)
                constraintSet.connect(R.id.fab_main, ConstraintSet.TOP, R.id.main_container, ConstraintSet.TOP, marginFloatingButton)
            }
            LocationFloatingButton.BOTTOM_LEFT -> {
                constraintSet.connect(R.id.fab_main, ConstraintSet.START, R.id.main_container, ConstraintSet.START, marginFloatingButton)
                constraintSet.connect(R.id.fab_main, ConstraintSet.BOTTOM, R.id.main_container, ConstraintSet.BOTTOM, marginFloatingButton)
            }
            LocationFloatingButton.BOTTOM_RIGHT -> {
                constraintSet.connect(R.id.fab_main, ConstraintSet.END, R.id.main_container, ConstraintSet.END, marginFloatingButton)
                constraintSet.connect(R.id.fab_main, ConstraintSet.BOTTOM, R.id.main_container, ConstraintSet.BOTTOM, marginFloatingButton)
            }
        }
        constraintSet.applyTo(findViewById<FloatingActionButton>(R.id.fab_main).getParent() as ConstraintLayout)
        
        val marginSubButtons = dpToPx(context, 16.0f).toFloat()
        when (locationFloatingButton) {
            LocationFloatingButton.TOP_LEFT -> {
                initFromTopToBottomSubButtons(marginSubButtons.toInt())
                initRightLabel()
            }
            LocationFloatingButton.TOP_RIGHT -> {
                initFromTopToBottomSubButtons(marginSubButtons.toInt())
                initLeftLabel()
            }
            LocationFloatingButton.BOTTOM_LEFT -> {
                initFromBottomToTopSubButtons(marginSubButtons.toInt())
                initRightLabel()
            }
            LocationFloatingButton.BOTTOM_RIGHT -> {
                initFromBottomToTopSubButtons(marginSubButtons.toInt())
                initLeftLabel()
            }
        }
    }

    private fun initRightLabel() {
        val constraintSet = ConstraintSet()
        constraintSet.clone(findViewById<FloatingActionButton>(R.id.fab_main).parent as ConstraintLayout)
        
        constraintSet.clear(R.id.label_card, ConstraintSet.END)
        constraintSet.connect(R.id.label_card, ConstraintSet.START, R.id.fab_main, ConstraintSet.START, 0)

        constraintSet.clear(R.id.icon_admin_card, ConstraintSet.END)
        constraintSet.connect(R.id.icon_admin_card, ConstraintSet.START, R.id.label_card, ConstraintSet.END, dpToPx(context,10.0f))

        constraintSet.clear(R.id.close_last_message_button, ConstraintSet.END)
        constraintSet.connect(R.id.close_last_message_button, ConstraintSet.START, R.id.label_card, ConstraintSet.START, 0)

        constraintSet.connect(R.id.fb_card_view, ConstraintSet.START, R.id.fb_button, ConstraintSet.END, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.fb_card_view, ConstraintSet.BOTTOM, R.id.fb_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.fb_card_view, ConstraintSet.TOP, R.id.fb_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.telegram_card_view, ConstraintSet.START, R.id.telegram_button, ConstraintSet.END, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.telegram_card_view, ConstraintSet.BOTTOM, R.id.telegram_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.telegram_card_view, ConstraintSet.TOP, R.id.telegram_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.vk_card_view, ConstraintSet.START, R.id.vk_button, ConstraintSet.END, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.vk_card_view, ConstraintSet.BOTTOM, R.id.vk_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.vk_card_view, ConstraintSet.TOP, R.id.vk_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.viber_card_view, ConstraintSet.START, R.id.viber_button, ConstraintSet.END, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.viber_card_view, ConstraintSet.BOTTOM, R.id.viber_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.viber_card_view, ConstraintSet.TOP, R.id.viber_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.instagram_card_view, ConstraintSet.START, R.id.instagram_button, ConstraintSet.END, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.instagram_card_view, ConstraintSet.BOTTOM, R.id.instagram_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.instagram_card_view, ConstraintSet.TOP, R.id.instagram_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.whatsapp_card_view, ConstraintSet.START, R.id.whatsapp_button, ConstraintSet.END, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.whatsapp_card_view, ConstraintSet.BOTTOM, R.id.whatsapp_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.whatsapp_card_view, ConstraintSet.TOP, R.id.whatsapp_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.fab_main_card_view, ConstraintSet.START, R.id.fab_main, ConstraintSet.END, dpToPx(context, 18.0f))
        constraintSet.connect(R.id.fab_main_card_view, ConstraintSet.BOTTOM, R.id.fab_main, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.fab_main_card_view, ConstraintSet.TOP, R.id.fab_main, ConstraintSet.TOP)

        constraintSet.applyTo(findViewById<FloatingActionButton>(R.id.fab_main).parent as ConstraintLayout)
    }

    private fun initLeftLabel() {
        val constraintSet = ConstraintSet()
        constraintSet.clone(findViewById<FloatingActionButton>(R.id.fab_main).parent as ConstraintLayout)

        constraintSet.clear(R.id.label_card, ConstraintSet.START)
        constraintSet.connect(R.id.label_card, ConstraintSet.END, R.id.fab_main, ConstraintSet.END, 0)

        constraintSet.clear(R.id.icon_admin_card, ConstraintSet.START)
        constraintSet.connect(R.id.icon_admin_card, ConstraintSet.END, R.id.label_card, ConstraintSet.START, dpToPx(context,10.0f))

        constraintSet.clear(R.id.close_last_message_button, ConstraintSet.START)
        constraintSet.connect(R.id.close_last_message_button, ConstraintSet.END, R.id.label_card, ConstraintSet.END, 0)

        constraintSet.connect(R.id.fb_card_view, ConstraintSet.END, R.id.fb_button, ConstraintSet.START, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.fb_card_view, ConstraintSet.BOTTOM, R.id.fb_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.fb_card_view, ConstraintSet.TOP, R.id.fb_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.telegram_card_view, ConstraintSet.END, R.id.telegram_button, ConstraintSet.START, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.telegram_card_view, ConstraintSet.BOTTOM, R.id.telegram_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.telegram_card_view, ConstraintSet.TOP, R.id.telegram_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.vk_card_view, ConstraintSet.END, R.id.vk_button, ConstraintSet.START, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.vk_card_view, ConstraintSet.BOTTOM, R.id.vk_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.vk_card_view, ConstraintSet.TOP, R.id.vk_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.viber_card_view, ConstraintSet.END, R.id.viber_button, ConstraintSet.START, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.viber_card_view, ConstraintSet.BOTTOM, R.id.viber_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.viber_card_view, ConstraintSet.TOP, R.id.viber_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.instagram_card_view, ConstraintSet.END, R.id.instagram_button, ConstraintSet.START, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.instagram_card_view, ConstraintSet.BOTTOM, R.id.instagram_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.instagram_card_view, ConstraintSet.TOP, R.id.instagram_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.whatsapp_card_view, ConstraintSet.END, R.id.whatsapp_button, ConstraintSet.START, dpToPx(context, 26.0f))
        constraintSet.connect(R.id.whatsapp_card_view, ConstraintSet.BOTTOM, R.id.whatsapp_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.whatsapp_card_view, ConstraintSet.TOP, R.id.whatsapp_button, ConstraintSet.TOP)

        constraintSet.connect(R.id.fab_main_card_view, ConstraintSet.END, R.id.fab_main, ConstraintSet.START, dpToPx(context, 18.0f))
        constraintSet.connect(R.id.fab_main_card_view, ConstraintSet.BOTTOM, R.id.fab_main, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.fab_main_card_view, ConstraintSet.TOP, R.id.fab_main, ConstraintSet.TOP)

        constraintSet.applyTo(findViewById<FloatingActionButton>(R.id.fab_main).parent as ConstraintLayout)
    }

    private fun initFromTopToBottomSubButtons(margin: Int) {
        val constraintSet = ConstraintSet()
        constraintSet.clone(findViewById<FloatingActionButton>(R.id.fab_main).parent as ConstraintLayout)

        clearSubButtons(constraintSet)

        constraintSet.connect(R.id.viber_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.viber_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.viber_button, ConstraintSet.TOP, R.id.fab_main, ConstraintSet.BOTTOM, margin)

        constraintSet.connect(R.id.telegram_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.telegram_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.telegram_button, ConstraintSet.TOP, R.id.viber_button, ConstraintSet.BOTTOM, margin)

        constraintSet.connect(R.id.whatsapp_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.whatsapp_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.whatsapp_button, ConstraintSet.TOP, R.id.telegram_button, ConstraintSet.BOTTOM, margin)

        constraintSet.connect(R.id.instagram_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.instagram_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.instagram_button, ConstraintSet.TOP, R.id.whatsapp_button, ConstraintSet.BOTTOM, margin)

        constraintSet.connect(R.id.vk_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.vk_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.vk_button, ConstraintSet.TOP, R.id.instagram_button, ConstraintSet.BOTTOM, margin)

        constraintSet.connect(R.id.fb_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.fb_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.fb_button, ConstraintSet.TOP, R.id.vk_button, ConstraintSet.BOTTOM, margin)

        constraintSet.connect(R.id.label_card, ConstraintSet.TOP, R.id.fab_main, ConstraintSet.BOTTOM, margin)

        constraintSet.connect(R.id.icon_admin_card, ConstraintSet.TOP, R.id.label_card, ConstraintSet.TOP, 0)

        constraintSet.clear(R.id.close_last_message_button, ConstraintSet.BOTTOM)
        constraintSet.connect(R.id.close_last_message_button, ConstraintSet.TOP, R.id.label_card, ConstraintSet.BOTTOM,  dpToPx(context,10.0f))

        constraintSet.applyTo(findViewById<FloatingActionButton>(R.id.fab_main).parent as ConstraintLayout)
    }

    private fun initFromBottomToTopSubButtons(margin: Int) {
        val constraintSet = ConstraintSet()
        constraintSet.clone(findViewById<FloatingActionButton>(R.id.fab_main).parent as ConstraintLayout)

        clearSubButtons(constraintSet)

        constraintSet.connect(R.id.viber_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.viber_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.viber_button, ConstraintSet.BOTTOM, R.id.fab_main, ConstraintSet.TOP, margin)

        constraintSet.connect(R.id.telegram_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.telegram_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.telegram_button, ConstraintSet.BOTTOM, R.id.viber_button, ConstraintSet.TOP, margin)

        constraintSet.connect(R.id.whatsapp_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.whatsapp_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.whatsapp_button, ConstraintSet.BOTTOM, R.id.telegram_button, ConstraintSet.TOP, margin)

        constraintSet.connect(R.id.instagram_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.instagram_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.instagram_button, ConstraintSet.BOTTOM, R.id.whatsapp_button, ConstraintSet.TOP, margin)

        constraintSet.connect(R.id.vk_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.vk_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.vk_button, ConstraintSet.BOTTOM, R.id.instagram_button, ConstraintSet.TOP, margin)

        constraintSet.connect(R.id.fb_button, ConstraintSet.START, R.id.fab_main, ConstraintSet.START)
        constraintSet.connect(R.id.fb_button, ConstraintSet.END, R.id.fab_main, ConstraintSet.END)
        constraintSet.connect(R.id.fb_button, ConstraintSet.BOTTOM, R.id.vk_button, ConstraintSet.TOP, margin)

        constraintSet.connect(R.id.label_card, ConstraintSet.BOTTOM, R.id.fab_main, ConstraintSet.TOP, margin)

        constraintSet.connect(R.id.icon_admin_card, ConstraintSet.TOP, R.id.label_card, ConstraintSet.TOP, 0)

        constraintSet.clear(R.id.close_last_message_button, ConstraintSet.TOP)
        constraintSet.connect(R.id.close_last_message_button, ConstraintSet.BOTTOM, R.id.label_card, ConstraintSet.TOP, dpToPx(context,10.0f))

        constraintSet.applyTo(findViewById<FloatingActionButton>(R.id.fab_main).parent as ConstraintLayout)
    }

    private fun clearSubButtons(constraintSet: ConstraintSet) {
        constraintSet.clear(R.id.viber_button, ConstraintSet.TOP)
        constraintSet.clear(R.id.viber_button, ConstraintSet.BOTTOM)
        constraintSet.clear(R.id.viber_button, ConstraintSet.START)
        constraintSet.clear(R.id.viber_button, ConstraintSet.END)
        constraintSet.clear(R.id.viber_button, ConstraintSet.LEFT)
        constraintSet.clear(R.id.viber_button, ConstraintSet.RIGHT)

        constraintSet.clear(R.id.viber_card_view, ConstraintSet.RIGHT)
        constraintSet.clear(R.id.viber_card_view, ConstraintSet.LEFT)
        constraintSet.clear(R.id.viber_card_view, ConstraintSet.START)
        constraintSet.clear(R.id.viber_card_view, ConstraintSet.END)


        constraintSet.clear(R.id.telegram_button, ConstraintSet.TOP)
        constraintSet.clear(R.id.telegram_button, ConstraintSet.BOTTOM)
        constraintSet.clear(R.id.telegram_button, ConstraintSet.START)
        constraintSet.clear(R.id.telegram_button, ConstraintSet.END)
        constraintSet.clear(R.id.telegram_button, ConstraintSet.LEFT)
        constraintSet.clear(R.id.telegram_button, ConstraintSet.RIGHT)

        constraintSet.clear(R.id.telegram_card_view, ConstraintSet.RIGHT)
        constraintSet.clear(R.id.telegram_card_view, ConstraintSet.LEFT)
        constraintSet.clear(R.id.telegram_card_view, ConstraintSet.START)
        constraintSet.clear(R.id.telegram_card_view, ConstraintSet.END)

        constraintSet.clear(R.id.instagram_button, ConstraintSet.TOP)
        constraintSet.clear(R.id.instagram_button, ConstraintSet.BOTTOM)
        constraintSet.clear(R.id.instagram_button, ConstraintSet.START)
        constraintSet.clear(R.id.instagram_button, ConstraintSet.END)
        constraintSet.clear(R.id.instagram_button, ConstraintSet.LEFT)
        constraintSet.clear(R.id.instagram_button, ConstraintSet.RIGHT)

        constraintSet.clear(R.id.instagram_card_view, ConstraintSet.RIGHT)
        constraintSet.clear(R.id.instagram_card_view, ConstraintSet.LEFT)
        constraintSet.clear(R.id.instagram_card_view, ConstraintSet.START)
        constraintSet.clear(R.id.instagram_card_view, ConstraintSet.END)

        constraintSet.clear(R.id.whatsapp_button, ConstraintSet.TOP)
        constraintSet.clear(R.id.whatsapp_button, ConstraintSet.BOTTOM)
        constraintSet.clear(R.id.whatsapp_button, ConstraintSet.START)
        constraintSet.clear(R.id.whatsapp_button, ConstraintSet.END)
        constraintSet.clear(R.id.whatsapp_button, ConstraintSet.LEFT)
        constraintSet.clear(R.id.whatsapp_button, ConstraintSet.RIGHT)

        constraintSet.clear(R.id.whatsapp_card_view, ConstraintSet.RIGHT)
        constraintSet.clear(R.id.whatsapp_card_view, ConstraintSet.LEFT)
        constraintSet.clear(R.id.whatsapp_card_view, ConstraintSet.START)
        constraintSet.clear(R.id.whatsapp_card_view, ConstraintSet.END)

        constraintSet.clear(R.id.vk_button, ConstraintSet.TOP)
        constraintSet.clear(R.id.vk_button, ConstraintSet.BOTTOM)
        constraintSet.clear(R.id.vk_button, ConstraintSet.START)
        constraintSet.clear(R.id.vk_button, ConstraintSet.END)
        constraintSet.clear(R.id.vk_button, ConstraintSet.LEFT)
        constraintSet.clear(R.id.vk_button, ConstraintSet.RIGHT)

        constraintSet.clear(R.id.vk_card_view, ConstraintSet.RIGHT)
        constraintSet.clear(R.id.vk_card_view, ConstraintSet.LEFT)
        constraintSet.clear(R.id.vk_card_view, ConstraintSet.START)
        constraintSet.clear(R.id.vk_card_view, ConstraintSet.END)


        constraintSet.clear(R.id.fb_button, ConstraintSet.TOP)
        constraintSet.clear(R.id.fb_button, ConstraintSet.BOTTOM)
        constraintSet.clear(R.id.fb_button, ConstraintSet.START)
        constraintSet.clear(R.id.fb_button, ConstraintSet.END)
        constraintSet.clear(R.id.fb_button, ConstraintSet.LEFT)
        constraintSet.clear(R.id.fb_button, ConstraintSet.RIGHT)

        constraintSet.clear(R.id.fb_card_view, ConstraintSet.RIGHT)
        constraintSet.clear(R.id.fb_card_view, ConstraintSet.LEFT)
        constraintSet.clear(R.id.fb_card_view, ConstraintSet.START)
        constraintSet.clear(R.id.fb_card_view, ConstraintSet.END)


        constraintSet.clear(R.id.label_card, ConstraintSet.TOP)
        constraintSet.clear(R.id.label_card, ConstraintSet.BOTTOM)
        constraintSet.clear(R.id.label_card, ConstraintSet.START)
        constraintSet.clear(R.id.label_card, ConstraintSet.END)
        constraintSet.clear(R.id.label_card, ConstraintSet.LEFT)
        constraintSet.clear(R.id.label_card, ConstraintSet.RIGHT)

        constraintSet.clear(R.id.fab_main_card_view, ConstraintSet.RIGHT)
        constraintSet.clear(R.id.fab_main_card_view, ConstraintSet.LEFT)
        constraintSet.clear(R.id.fab_main_card_view, ConstraintSet.START)
        constraintSet.clear(R.id.fab_main_card_view, ConstraintSet.END)
    }

    override fun show() {
        this.post {
            findViewById<FloatingActionButton>(R.id.fab_main)?.show()
            presenter.onShowButton()
        }
    }

    override fun hide() {
        this.post{
            findViewById<FloatingActionButton>(R.id.fab_main)?.hide()
            presenter.onHideButton()
        }
    }

    override fun expand() {
        findViewById<CardView>(R.id.label_card)?.visibility = View.GONE
        findViewById<ImageButton>(R.id.close_last_message_button)?.visibility = View.GONE
        findViewById<CardView>(R.id.icon_admin_card)?.visibility = View.GONE

        val startRadius = 0
        val endRadius = hypot((parent as View).width.toDouble(), (parent as View).height.toDouble()).toInt()
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            val animator = ViewAnimationUtils.createCircularReveal(findViewById<View>(R.id.main_bkg_view),
                findViewById<FloatingActionButton>(R.id.fab_main).x.toInt() + findViewById<FloatingActionButton>(R.id.fab_main).width / 2,
                findViewById<FloatingActionButton>(R.id.fab_main).y.toInt() + findViewById<FloatingActionButton>(R.id.fab_main).height / 2,
                    startRadius.toFloat(), endRadius.toFloat())

            findViewById<View>(R.id.main_bkg_view)?.visibility = View.VISIBLE
            animator.start()
        } else {
            findViewById<View>(R.id.main_bkg_view).animate().alphaBy(0.0f).alpha(1.0f).setDuration(ANIMATE_DURATION).setListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) {
                    findViewById<View>(R.id.main_bkg_view)?.alpha = 0.0f
                    findViewById<View>(R.id.main_bkg_view)?.visibility = View.VISIBLE
                }

                override fun onAnimationEnd(animation: Animator) {}

                override fun onAnimationCancel(animation: Animator) {}

                override fun onAnimationRepeat(animation: Animator) {}
            })
        }

        if (findViewById<CardView>(R.id.label_card)?.visibility == View.VISIBLE) {
            findViewById<CardView>(R.id.label_card).visibility = View.GONE
            findViewById<ImageButton>(R.id.close_last_message_button)?.visibility = View.GONE
        }

        findViewById<FloatingActionButton>(R.id.fab_main)?.hide()
        findViewById<FloatingActionButton>(R.id.fab_main)?.setImageResource(R.drawable.ic_cq_edit)
        findViewById<FloatingActionButton>(R.id.fab_main)?.show()
    }

    override fun collapse() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            val startRadius = hypot((parent as View).width.toDouble(), (parent as View).height.toDouble()).toInt()
            val endRadius = 0
            val animator = ViewAnimationUtils.createCircularReveal(findViewById<View>(R.id.main_bkg_view),
                findViewById<FloatingActionButton>(R.id.fab_main).x.toInt() + findViewById<FloatingActionButton>(R.id.fab_main).width / 2,
                findViewById<FloatingActionButton>(R.id.fab_main).y.toInt() + findViewById<FloatingActionButton>(R.id.fab_main).height / 2,
                    startRadius.toFloat(), endRadius.toFloat())

            animator.start()
            animator.addListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) {

                }

                override fun onAnimationEnd(animation: Animator) {
                    findViewById<View>(R.id.main_bkg_view)?.visibility = View.GONE
                    presenter.onCollapseEnd()
                }

                override fun onAnimationCancel(animation: Animator) {

                }

                override fun onAnimationRepeat(animation: Animator) {

                }
            })
        } else {
            findViewById<View>(R.id.main_bkg_view).animate().alpha(0.0f).setDuration(ANIMATE_DURATION).setListener(object : Animator.AnimatorListener {
                override fun onAnimationStart(animation: Animator) {}

                override fun onAnimationEnd(animation: Animator) {
                    findViewById<View>(R.id.main_bkg_view)?.visibility = View.GONE
                }

                override fun onAnimationCancel(animation: Animator) {}

                override fun onAnimationRepeat(animation: Animator) {}
            })
        }

        findViewById<FloatingActionButton>(R.id.fab_main)?.hide()
        findViewById<FloatingActionButton>(R.id.fab_main)?.setImageDrawable(iconFloatingButtonOnExpandState)
        if(NetworkManager.getInstance(context).hasConnect) {
            findViewById<FloatingActionButton>(R.id.fab_main)?.show()
        }

        findViewById<CardView>(R.id.fab_main_card_view)?.visibility = View.GONE
    }

    override fun showLastMessage() {
        this.post {
            findViewById<CardView>(R.id.label_card)?.visibility = View.VISIBLE
            findViewById<CardView>(R.id.icon_admin_card)?.visibility = View.VISIBLE
            findViewById<ImageButton>(R.id.close_last_message_button)?.visibility = View.VISIBLE
        }
    }

    override fun showLastMessageWithoutAvatar() {
        this.post {
            findViewById<CardView>(R.id.label_card)?.visibility = View.VISIBLE
            findViewById<CardView>(R.id.icon_admin_card)?.visibility = View.GONE
            findViewById<ImageButton>(R.id.close_last_message_button)?.visibility = View.VISIBLE
        }
    }

    override fun hideLastMessage() {
        this.post {
            findViewById<CardView>(R.id.label_card)?.visibility = View.GONE
            findViewById<CardView>(R.id.icon_admin_card)?.visibility = View.GONE
            findViewById<ImageButton>(R.id.close_last_message_button)?.visibility = View.GONE
        }
    }

    override fun updateTextLastMessage(text: String) {
        findViewById<TextView>(R.id.label_text_view)?.text = text
    }

    override fun updateLastAdminIcon(avatar: String) {
        if(avatar.isEmpty()) {
            findViewById<ImageView>(R.id.icon_admin_image_view).visibility = View.GONE

            return
        }
        try {
            findViewById<ImageView>(R.id.icon_admin_image_view).visibility = View.VISIBLE
            Glide.with(context)
                    .load(avatar)
                    .apply(RequestOptions.circleCropTransform())
                    .into(findViewById<ImageView>(R.id.icon_admin_image_view))
        } catch (e: Exception) {
            io.carrotquest_sdk.android.core.util.Log.e("FloatingButton", e)
        }
    }

    override fun showUnreadCounter() {
        findViewById<TextView>(R.id.bubble_unread_conversations_count_text_view)?.visibility = View.VISIBLE
    }

    override fun hideUnreadCounter() {

        findViewById<TextView>(R.id.bubble_unread_conversations_count_text_view)?.visibility = View.GONE
    }

    override fun updateUnreadCount(strCount: String) {
        findViewById<TextView>(R.id.bubble_unread_conversations_count_text_view)?.text = strCount
    }

    override fun updateTheme(theme: SimpleTheme) {
        if(theme == SimpleTheme.DARK) {
            findViewById<View>(R.id.main_bkg_view).setBackgroundColor(Color.parseColor("#E6333333"))
        } else {
            findViewById<View>(R.id.main_bkg_view).setBackgroundColor(Color.parseColor("#ccffffff"))
        }

        val color = if(theme == SimpleTheme.DARK) {
            Color.parseColor("#595959")
        } else {
            Color.parseColor("#FFFFFF")
        }

        val textColor = if(theme == SimpleTheme.DARK) {
            Color.parseColor("#FFFFFF")
        } else {
            Color.parseColor("#757575")
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            findViewById<CardView>(R.id.vk_card_view)?.backgroundTintList = ColorStateList.valueOf(color)
            findViewById<TextView>(R.id.vk_text_view)?.setTextColor(textColor)

            findViewById<CardView>(R.id.fb_card_view)?.backgroundTintList = ColorStateList.valueOf(color)
            findViewById<TextView>(R.id.fb_text_view)?.setTextColor(textColor)

            findViewById<CardView>(R.id.instagram_card_view)?.backgroundTintList = ColorStateList.valueOf(color)
            findViewById<TextView>(R.id.instagram_text_view)?.setTextColor(textColor)

            findViewById<CardView>(R.id.telegram_card_view)?.backgroundTintList = ColorStateList.valueOf(color)
            findViewById<TextView>(R.id.telegram_text_view)?.setTextColor(textColor)

            findViewById<CardView>(R.id.whatsapp_card_view)?.backgroundTintList = ColorStateList.valueOf(color)
            findViewById<TextView>(R.id.whatsapp_text_view)?.setTextColor(textColor)

            findViewById<CardView>(R.id.viber_card_view)?.backgroundTintList = ColorStateList.valueOf(color)
            findViewById<TextView>(R.id.viber_text_view)?.setTextColor(textColor)

            findViewById<CardView>(R.id.fab_main_card_view)?.backgroundTintList = ColorStateList.valueOf(color)
            findViewById<TextView>(R.id.fab_main_text_view)?.setTextColor(textColor)

            findViewById<CardView>(R.id.label_card)?.backgroundTintList = ColorStateList.valueOf(color)
            findViewById<TextView>(R.id.label_text_view)?.setTextColor(textColor)
            if(theme == SimpleTheme.DARK) {
                findViewById<ImageButton>(R.id.close_last_message_button)?.imageTintList = ColorStateList.valueOf(Color.parseColor("#000000"))
            } else {
                findViewById<ImageButton>(R.id.close_last_message_button)?.imageTintList = ColorStateList.valueOf(Color.parseColor("#ffffff"))
            }
        }
    }

    override fun updateColor(colorFromSettings: ColorStateList) {
        findViewById<FloatingActionButton>(R.id.fab_main)?.backgroundTintList = colorFromSettings
        findViewById<CardView>(R.id.icon_admin_card).setCardBackgroundColor(colorFromSettings)
    }

    override fun hideFbButton() {
        findViewById<FloatingActionButton>(R.id.fb_button)?.hide()
    }

    override fun hideFbLabelButton() {
        findViewById<CardView>(R.id.fb_card_view)?.visibility = View.GONE
    }

    override fun hideVkButton() {
        findViewById<FloatingActionButton>(R.id.vk_button)?.hide()
    }

    override fun hideVkLabelButton() {
        findViewById<CardView>(R.id.vk_card_view)?.visibility = View.GONE
    }

    override fun hideTelegramButton() {
        findViewById<FloatingActionButton>(R.id.telegram_button)?.hide()
    }

    override fun hideTelegramLabelButton() {
        findViewById<CardView>(R.id.telegram_card_view)?.visibility = View.GONE
    }

    override fun hideViberButton() {
        findViewById<FloatingActionButton>(R.id.viber_button)?.hide()
    }

    override fun hideInstagramButton() {
        findViewById<FloatingActionButton>(R.id.instagram_button)?.hide()
    }

    override fun hideWhatsappButton() {
        findViewById<FloatingActionButton>(R.id.whatsapp_button)?.hide()
    }

    override fun hideViberLabelButton() {
        findViewById<CardView>(R.id.viber_card_view)?.visibility = View.GONE
    }

    override fun hideInstagramLabelButton() {
        findViewById<CardView>(R.id.instagram_card_view)?.visibility = View.GONE
    }

    override fun hideWhatsappLabelButton() {
        findViewById<CardView>(R.id.whatsapp_card_view)?.visibility = View.GONE
    }

    override fun showFbButton() {
        findViewById<FloatingActionButton>(R.id.fb_button)?.show()
    }

    override fun showFbLabelButton() {
        findViewById<CardView>(R.id.fb_card_view)?.visibility = View.VISIBLE
    }

    override fun showVkButton() {
        findViewById<FloatingActionButton>(R.id.vk_button)?.show()
    }

    override fun showVkLabelButton() {
        findViewById<CardView>(R.id.vk_card_view)?.visibility = View.VISIBLE
    }

    override fun showTelegramButton() {
        findViewById<FloatingActionButton>(R.id.telegram_button)?.show()
    }

    override fun showTelegramLabelButton() {
        findViewById<CardView>(R.id.telegram_card_view)?.visibility = View.VISIBLE
    }

    override fun showViberButton() {
        findViewById<FloatingActionButton>(R.id.viber_button)?.show()
    }

    override fun showInstagramButton() {
        findViewById<FloatingActionButton>(R.id.instagram_button)?.show()
    }

    override fun showWhatsappButton() {
        findViewById<FloatingActionButton>(R.id.whatsapp_button)?.show()
    }

    override fun showViberLabelButton() {
        findViewById<CardView>(R.id.viber_card_view)?.visibility = View.VISIBLE
    }

    override fun showInstagramLabelButton() {
        findViewById<CardView>(R.id.instagram_card_view)?.visibility = View.VISIBLE
    }

    override fun showWhatsappLabelButton() {
        findViewById<CardView>(R.id.whatsapp_card_view)?.visibility = View.VISIBLE
    }

    override fun hideOpenChatLabel() {
        findViewById<CardView>(R.id.fab_main_card_view)?.visibility = View.GONE
    }

    override fun showOpenChatLabel() {
        findViewById<CardView>(R.id.fab_main_card_view)?.visibility = View.VISIBLE
    }

    override fun doVisible(){
        this.visibility = View.VISIBLE
    }
    override fun doGone(){
        this.visibility = View.GONE
    }
}