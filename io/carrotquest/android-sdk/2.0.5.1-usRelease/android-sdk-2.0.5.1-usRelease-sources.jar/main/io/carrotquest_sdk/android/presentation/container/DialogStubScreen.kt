package io.carrotquest_sdk.android.presentation.container

import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.FragmentContainerView
import androidx.fragment.app.FragmentManager
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogFragment

private const val DIALOG_FRAGMENT_TAG = "sdk_dialog_fragment"

@Composable
fun DialogScreen(
    conversationId: String,
    fragmentManager: FragmentManager,
    modifier: Modifier = Modifier
) {
    val containerId = remember { View.generateViewId() }

    DisposableEffect(conversationId) {
        onDispose {
            if (fragmentManager.isStateSaved) return@onDispose
            val frag = fragmentManager.findFragmentByTag(DIALOG_FRAGMENT_TAG) ?: return@onDispose
            if (frag.id == containerId) {
                fragmentManager.beginTransaction()
                    .remove(frag)
                    .commitAllowingStateLoss()
            }
        }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            FragmentContainerView(ctx).also { fcv ->
                fcv.id = containerId

                // Добавляем фрагмент сразу, не дожидаясь post.
                // Это критично для плавности анимации AnimatedContent,
                // чтобы контент был готов в первом же кадре.
                if (!fragmentManager.isStateSaved) {
                    val tx = fragmentManager.beginTransaction()
                    val existingFrag = fragmentManager.findFragmentByTag(DIALOG_FRAGMENT_TAG)

                    if (existingFrag != null && existingFrag.id != containerId) {
                        tx.remove(existingFrag)
                    }

                    tx.add(
                        containerId,
                        DialogFragment.newInstance(conversationId),
                        DIALOG_FRAGMENT_TAG
                    )
                    tx.commitAllowingStateLoss()
                }
            }
        },
        update = { /* Не пересоздаем фрагмент при обновлении параметров, если id тот же */ }
    )
}
