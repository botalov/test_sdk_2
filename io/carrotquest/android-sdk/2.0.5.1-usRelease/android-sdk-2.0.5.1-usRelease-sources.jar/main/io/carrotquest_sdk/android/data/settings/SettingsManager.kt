package io.carrotquest_sdk.android.data.settings

import android.content.Context
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse
import io.carrotquest_sdk.android.presentation.constans.StatusOperators
import io.carrotquest_sdk.android.presentation.mvp.utils.app_color_utils.AppColorUtils

internal object SettingsManager {

    fun applyFromConnectResponse(response: ConnectResponse, context: Context) {
        applyTheme(response)
        SettingsRepository.getInstance().saveSettings(buildSettingsEntity(response, context))
    }

    private fun applyTheme(response: ConnectResponse) {
        if (CarrotSDK.getTheme() == ThemeSdk.FROM_WEB) {
            val rawTheme = response.data?.app?.settings?.theme
            CarrotSDK.setTheme(if ("dark" == rawTheme) ThemeSdk.DARK else ThemeSdk.LIGHT)
        }
    }

    private fun buildSettingsEntity(response: ConnectResponse, context: Context): SettingsEntity {
        val app = response.data.app
        val settings = app.settings
        val user = response.data.user
        val rawColor = settings.appColor ?: ""
        val correctedColor = AppColorUtils.getCorrectAccentColor(context, rawColor)
        val admins = ArrayList<Admin>(app.admins)
        val appName = settings?.messengerName ?: app.name

        return SettingsEntity(
            userId = user.id,
            isShowVK = settings.isShowVK,
            textLinkVK = settings.textLinkVK,
            isShowViber = settings.isShowViber,
            textLinkViber = settings.textLinkViber,
            isShowFB = settings.isShowFB,
            textLinkFB = settings.textLinkFB,
            isShowTelegram = settings.isShowTelegram,
            textLinkTelegram = settings.textLinkTelegram,
            isShowInstagram = settings.isShowInstagram,
            textLinkInstagram = settings.textLinkInstagram,
            isShowWhatsapp = settings.isShowWhatsapp,
            textLinkWhatsapp = settings.textLinkWhatsapp,
            appColor = correctedColor,
            originalAppColor = rawColor,
            welcomeMessage = settings.welcomeMessage,
            messengerAvatar = settings.messengerAvatar,
            showPoweredBy = settings.isShowPoweredBy,
            sourceData = response.sourceData ?: "",
            appName = appName,
            appId = app.id,
            showLinkKbAtWelcomeMessage = settings.isShowKbLinkInWelcomeMessage,
            statusOperators = if ("online" == app.statusOperators) StatusOperators.ONLINE else StatusOperators.OFFLINE,
            onlineMessage = settings.onlineMessage,
            offlineMessage = settings.offlineMessage,
            admins = admins,
            theme = settings.theme,
            locale = settings.locale ?: "",
            messengerPattern = settings.messengerPattern
        )
    }
}
