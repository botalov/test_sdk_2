package io.carrotquest_sdk.android.core.connection

import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.network.wss_responses.RtsMessageFactory
import io.carrotquest_sdk.android.domain.use_cases.rts.getRtsHost
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.wss.Channel
import io.carrotquest_sdk.android.lib.wss.ChannelEnum
import io.carrotquest_sdk.android.lib.wss.IWssService
import io.carrotquest_sdk.android.lib.wss.jwt.JwtWssService
import io.carrotquest_sdk.android.lib.wss.response.WssResponse
import io.reactivex.Observer
import io.reactivex.disposables.Disposable

internal object WssManager {

    private const val TAG = "WssManager"
    private var wssService: IWssService? = null

    fun start(appId: String, userId: String) {
        stop()
        val context = CarrotLib.getLibComponents().context
        val host = getRtsHost(context)
        wssService = JwtWssService(context, host)

        val params = mutableListOf(userId)
        val channels = mutableListOf(
            Channel(ChannelEnum.ping),
            Channel(ChannelEnum.conversation_typing, params),
            Channel(ChannelEnum.conversation, params),
            Channel(ChannelEnum.message_conversation_started, params),
            Channel(ChannelEnum.conversation_read, params),
            Channel(ChannelEnum.conversation_reply, params),
            Channel(ChannelEnum.run_script, params),
            Channel(ChannelEnum.user_ban, params),
            Channel(ChannelEnum.users_removed, params),
            Channel(ChannelEnum.app_online_changed),
            Channel(ChannelEnum.conversation_reply_changed, params),
            Channel(ChannelEnum.chat_bot_conversation_finished, params),
            Channel(ChannelEnum.conversation_parts_batch, params)
        )

        val observers = mutableListOf<Observer<WssResponse>>(object : Observer<WssResponse> {
            override fun onSubscribe(d: Disposable) {}
            override fun onNext(response: WssResponse) {
                // Конкретное сообщение может сломать процессинг (malformed JSON, NPE внутри
                // .process()). Глотаем на уровне пакета — подписка продолжает работать,
                // остальные WSS-события обрабатываются штатно.
                try {
                    RtsMessageFactory.createResponse(response)?.process()
                } catch (t: Throwable) {
                    Log.e(TAG, "WSS message processing failed, skipping: $t")
                }
            }
            override fun onError(e: Throwable) { Log.e(TAG, e.toString()) }
            override fun onComplete() {}
        })

        wssService!!.stopSocket(appId)
        wssService!!.startSocket(appId, channels, observers)
    }

    fun stop() {
        wssService?.deInit()
        wssService = null
    }
}
