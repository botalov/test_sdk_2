package io.carrotquest_sdk.android.presentation.mvp.notifications.tracking

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.google.gson.Gson
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.utm.UTM
import io.carrotquest_sdk.android.core.utm.UtmUtil
import io.carrotquest_sdk.android.lib.models.UserProperty
import io.carrotquest_sdk.android.models.Operation
import io.reactivex.observers.DisposableObserver
import java.util.Locale
import java.util.concurrent.TimeUnit

fun trackClick(conversationId: String, callback: CarrotSDK.Callback<Boolean>) {
    if(CarrotInternal.getService() != null && CarrotInternal.getService().isInit) {
        callTrackClickByPush(conversationId, callback)
    } else {
        Carrot.setupWithoutConnect(CarrotInternal.getLibComponent().contextSdk)
        callTrackClickByPush(conversationId, callback)
    }
}

private fun callTrackClickByPush(conversationId: String, callback: CarrotSDK.Callback<Boolean>) {
    CarrotInternal.getService()
        .trackClickByPush(conversationId, object : DisposableObserver<NetworkResponse?>() {
            override fun onNext(response: NetworkResponse) {
                Log.d("clicked", response.meta.status.toString())
                callback.onResponse(true)
            }

            override fun onError(e: Throwable) {
                callback.onFailure(e)
            }
            override fun onComplete() {}
        })
}

fun trackUtm(link: String) {
    if(CarrotInternal.getService() != null && CarrotInternal.getService().isInit) {
        recordUtm(link)
    } else {
        Carrot.setupWithoutConnect(CarrotInternal.getLibComponent().contextSdk)
        recordUtm(link)
    }
}

private fun recordUtm(link: String) {
    val utmString = link.substringAfter("?", "")
    if(utmString.isEmpty()) {
        return
    }

    val utmList = UtmUtil.getHashMapParamsFromQuery(utmString)



    trackEvents(utmList)

    setProps(utmList)
}

private fun trackEvents(utmList: HashMap<String, String>) {
    val filteredMap = utmList.filter { (k, _) -> k.lowercase() == UTM.SOURCE.value
            || k.lowercase() == UTM.CAMPAIGN.value
            || k.lowercase() == UTM.CONTENT.value
            || k.lowercase() == UTM.TERM.value
            || k.lowercase() == UTM.MEDIUM.value }
    val jsonStrForEvent = Gson().toJson(filteredMap).toString()
    CarrotInternal.getService().trackEventSimple(
        "\$utm_hit",
        jsonStrForEvent,
        object : DisposableObserver<NetworkResponse>() {
            override fun onNext(t: NetworkResponse) {

            }

            override fun onError(e: Throwable) {

            }

            override fun onComplete() {

            }
        })

    for (key in utmList.keys.reversed()) {
        val utmKeyLowerCase = key.lowercase(Locale.getDefault())
        if (utmKeyLowerCase == "cq_event") {
            val eventName = utmList[key]

            val index = utmList.keys.indexOf(key)
            val droppedKeys = utmList.keys.drop(index)

            val params = HashMap<String, String>()
            droppedKeys.forEach { k ->
                if (k.lowercase().contains("cq_event_")) {
                    params[k.replace("cq_event_", "")] = utmList[k].toString()
                }
            }

            CarrotInternal.getService().trackEventSimple(
                eventName,
                Gson().toJson(params).toString(),
                object : DisposableObserver<NetworkResponse>() {
                    override fun onNext(t: NetworkResponse) {

                    }

                    override fun onError(e: Throwable) {

                    }

                    override fun onComplete() {

                    }
                })


            break
        }
    }
}

private fun setProps(utmList: HashMap<String, String>) {
    val propsArray = ArrayList<UserProperty>()
    for (utmKey in utmList.keys) {
        val key = when (val utmKeyLowerCase = utmKey.lowercase(Locale.getDefault())) {
            UTM.SOURCE.value -> {
                "\$last_utm_source"
            }

            UTM.MEDIUM.value -> {
                "\$last_utm_medium"
            }

            UTM.CAMPAIGN.value -> {
                "\$last_utm_campaign"
            }

            UTM.TERM.value -> {
                "\$last_utm_term"
            }

            UTM.CONTENT.value -> {
                "\$last_utm_content"
            }

            else -> {
                if (utmKeyLowerCase.contains("cq_identify_")) {
                    utmKeyLowerCase.substringAfter("cq_identify_")
                } else {
                    ""
                }
            }
        }

        if (key.isNotEmpty()) {
            val value = utmList[utmKey]
            propsArray.add(
                UserProperty(
                    Operation.update_or_create.name,
                    key,
                    value
                )
            )
        }
    }

    CarrotInternal.getService().setUserPropertySimple(propsArray)
}

fun trackDelivered(context: Context, conversationId: String) {
    Log.d("trackDelivered start", conversationId)
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    val workData = workDataOf("CONVERSATION_ID" to conversationId)

    val workRequest = OneTimeWorkRequestBuilder<PushDeliveryWorker>()
        .setConstraints(constraints)
        .setInputData(workData)
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
        .build()

    // Используем enqueueUniqueWork (APPEND), чтобы не плодить дубликаты задач
    // для одного и того же пуша, если мы будем вызывать это при старте приложения
    WorkManager.getInstance(context).enqueueUniqueWork(
        "delivery_push_$conversationId",
        ExistingWorkPolicy.REPLACE,
        workRequest
    )
}

fun syncPendingDeliveredPushes(context: Context) {
    Log.d("syncPendingDeliveredPushes", "start")
    // Запускаем в отдельном потоке, чтобы не тормозить UI при чтении SharedPreferences
    Thread {
        val context = CarrotInternal.getLibComponent().contextSdk
        val pendingPushes = PushStorage.getPendingPushes(context)
        Log.d("syncPendingDeliveredPushes", pendingPushes.toString())
        for (conversationId in pendingPushes) {
            // Снова ставим их в очередь WorkManager
            trackDelivered(context, conversationId)
        }
    }.start()
}