package io.carrotquest_sdk.android.presentation.mvp.popup.view

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.PorterDuff
import android.graphics.Rect
import android.net.Uri
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.DynamicDrawableSpan
import android.text.style.ImageSpan
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.widget.NestedScrollView
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.network.js_interface.pop_up.PopUpJSInterface
import io.carrotquest_sdk.android.lib.utils.GraphicUtils
import io.carrotquest_sdk.android.presentation.mvp.popup.presenter.PopUpPresenter
import io.reactivex.Observer
import io.reactivex.disposables.Disposable
import kotlin.math.min

class PopupAlertDialog(private val ctx: Context, styleId: Int) : AlertDialog.Builder(ctx, styleId), IPopUp {
    companion object {
        const val MIN_KEYBOARD_HEIGHT_PX = 150

        private var isShowing = false
        fun isShowing() = isShowing
    }

    private val presenter = PopUpPresenter(this)
    private val tag = this.javaClass.name
    private var initJson = ""

    private var currentScrollY = 0
    private var keyboardHeight = 0
    private var scrollBeforeShowKeyboard = 0

    private var view: View? = null
    private var alertDialog: AlertDialog? = null

    private val popUpView = PopUpWebView(ctx)

    override fun show(): AlertDialog {
        val builder = PopupAlertDialog(ctx, R.style.popUpStyle)
        alertDialog = builder.create()
        if (ctx is Activity) {
            alertDialog?.setOwnerActivity(ctx)
        }


        view = LayoutInflater.from(ctx).inflate(R.layout.popup_layout_temp, null)

        onCreate()

        alertDialog?.setView(view)
        alertDialog?.setOnDismissListener {
            presenter.onDestroy()
            isShowing = false
        }
        isShowing = true


        return alertDialog!!
    }

    private fun onCreate() {
        //super.onCreate(savedInstanceState)
        //supportRequestWindowFeature(Window.FEATURE_NO_TITLE)
        //setContentView(R.layout.popup_layout)

        val webViewLayoutParams = ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT)
        popUpView.layoutParams = webViewLayoutParams
        view?.findViewById<FrameLayout>(R.id.popup_web_view_container)?.addView(popUpView)

        view?.findViewById<ImageButton>(R.id.close_popup_btn)?.setOnClickListener { presenter.onTabCloseButton() }

        view?.findViewById<NestedScrollView>(R.id.main_popup_scroll)?.viewTreeObserver?.addOnScrollChangedListener {
            currentScrollY = view?.findViewById<NestedScrollView>(R.id.main_popup_scroll)?.scrollY!!
        }

        val decorView = alertDialog?.ownerActivity?.window?.decorView
        decorView?.viewTreeObserver?.addOnGlobalLayoutListener(object :
            ViewTreeObserver.OnGlobalLayoutListener {
            private val windowVisibleDisplayFrame = Rect()
            private var lastVisibleDecorViewHeight = 0
            override fun onGlobalLayout() {
                decorView.getWindowVisibleDisplayFrame(windowVisibleDisplayFrame)
                val visibleDecorViewHeight = windowVisibleDisplayFrame.height()
                if (lastVisibleDecorViewHeight != 0) {
                    if (lastVisibleDecorViewHeight > visibleDecorViewHeight + MIN_KEYBOARD_HEIGHT_PX) {
                        if(lastVisibleDecorViewHeight - visibleDecorViewHeight > 0) {
                            keyboardHeight = lastVisibleDecorViewHeight - visibleDecorViewHeight
                        }
                        presenter.onShowKeyboard()
                    } else if (lastVisibleDecorViewHeight + MIN_KEYBOARD_HEIGHT_PX < visibleDecorViewHeight) {
                        presenter.onHideKeyboard()
                    }
                }
                lastVisibleDecorViewHeight = visibleDecorViewHeight
            }
        })

        popUpView.addLoadingObserver(object : Observer<Boolean> {
            override fun onComplete() {

            }

            override fun onSubscribe(d: Disposable) {

            }

            override fun onNext(t: Boolean) {
                presenter.onLoaded(initJson)
                popUpView.setOnTouchListener { v, event ->
                    when (event?.action) {
                        MotionEvent.ACTION_DOWN -> Log.d("","")
                    }

                    v?.onTouchEvent(event) ?: true
                }
            }

            override fun onError(e: Throwable) {
                Log.e(tag, e)
            }
        })

        popUpView.requestFocus()
    }

    fun setData(popUpId: String, popUpBlocks: String, popUpBkg: String) {
        presenter.onResume(popUpId, popUpBlocks, popUpBkg)
        resizePopUp()
    }

    override fun updateBackground(color: String) {
        val drawable = context?.resources?.getDrawable(R.drawable.cq_popup_bkg)
        drawable?.setColorFilter(Color.parseColor(color), PorterDuff.Mode.SRC_ATOP)

        view?.findViewById<FrameLayout>(R.id.popup_web_view_container)?.background = drawable
        view?.findViewById<PopUpWebView>(R.id.popup_web_view)?.setBackgroundColor(Color.parseColor(color))
    }

    override fun showContent(contentJson: String) {
        initJson = contentJson
        popUpView.initJsInterface(PopUpJSInterface(ctx, presenter, popUpView))
        popUpView.loadUrl(BuildConfig.POP_UP_URL)

        //popUpView.loadUrl("http://192.168.1.63:8080/popup/")

        //popUpView.loadUrl("https://cdn.carrotquest.io/external-widget/0.4.26/android/popup/")

    }

    override fun reload() {
        popUpView.reloadUrl()
    }

    override fun setLoadWebViewObserver(loadWebViewObserver: Observer<Boolean>) {
        popUpView.addLoadingObserver(loadWebViewObserver)
    }

    override fun closePopUp() {
        alertDialog?.dismiss()
    }

    override fun executeJs(script: String) {
        popUpView.executeJsInWebView(script)
    }

    override fun setHeight(h: Int) {
        alertDialog?.ownerActivity?.runOnUiThread {
            val p = Point()
            alertDialog?.ownerActivity?.window?.windowManager?.defaultDisplay?.getSize(p)

            val params = view?.findViewById<FrameLayout>(R.id.popup_web_view_container)?.layoutParams
            params?.height = GraphicUtils.dpToPx(context, h.toFloat() + 30)
            view?.findViewById<FrameLayout>(R.id.popup_web_view_container)?.layoutParams = params
            view?.findViewById<FrameLayout>(R.id.popup_web_view_container)?.requestLayout()
        }
    }

    override fun updatePoweredBy(providerName: String, providerIcon: Int) {
        val startText = context.getString(R.string.popup_powered_by_start_text) + "   "
        val drawableIcon = context.resources.getDrawable(providerIcon)
        val poweredByTextView = view?.findViewById<TextView>(R.id.powered_by_popup_tv)!!
        drawableIcon.bounds = Rect(0,0,poweredByTextView.lineHeight,poweredByTextView.lineHeight)
        val ssb = SpannableStringBuilder(startText)
        ssb.setSpan(ImageSpan(drawableIcon, DynamicDrawableSpan.ALIGN_BOTTOM), startText.length - 1, startText.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        ssb.append(" $providerName")

        view?.findViewById<TextView>(R.id.powered_by_popup_tv)?.text = ssb
    }

    override fun showPoweredBy() {
        view?.findViewById<ConstraintLayout>(R.id.powered_by_main_cl)?.visibility = View.VISIBLE
    }

    override fun openLink(url: String) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(url)
        context.startActivity(intent)
    }

    override fun updateUpScroll(offsetFocusInput: Int) {
        val decorView = alertDialog?.ownerActivity?.window?.decorView
        val windowVisibleDisplayFrame = Rect()
        decorView?.getWindowVisibleDisplayFrame(windowVisibleDisplayFrame)
        val visibleDecorViewHeight = windowVisibleDisplayFrame.height()

        val yInput = GraphicUtils.dpToPx(context, offsetFocusInput.toFloat()) + view?.findViewById<FrameLayout>(R.id.popup_web_view_container)?.y!!
        val y = yInput - visibleDecorViewHeight

        scrollBeforeShowKeyboard = currentScrollY
        //main_popup_scroll.scrollTo(0, currentScrollY + keyboardHeight)
        view?.findViewById<NestedScrollView>(R.id.main_popup_scroll)?.scrollTo(0, currentScrollY + if(y.toInt() > 0) y.toInt() else 0)
    }

    override fun updateDownScroll() {
        view?.findViewById<NestedScrollView>(R.id.main_popup_scroll)?.scrollTo(0, scrollBeforeShowKeyboard)
    }

    private fun resizePopUp() {
        val p = Point()
        alertDialog?.ownerActivity?.window?.windowManager?.defaultDisplay?.getSize(p)
        if (p.x > 0) {
            val params = view?.findViewById<FrameLayout>(R.id.popup_web_view_container)?.layoutParams
            params?.width = min(p.x, GraphicUtils.dpToPx(context, 350.0f)) - GraphicUtils.dpToPx(context, 30.0f)
            view?.findViewById<FrameLayout>(R.id.popup_web_view_container)?.layoutParams = params
        }
    }

    private fun getStatusBarHeight(): Int {
        var result = 0
        val resourceId = context.resources.getIdentifier("status_bar_height", "dimen", "android")
        if (resourceId > 0) {
            result = context.resources.getDimensionPixelSize(resourceId)
        }
        return result
    }
}