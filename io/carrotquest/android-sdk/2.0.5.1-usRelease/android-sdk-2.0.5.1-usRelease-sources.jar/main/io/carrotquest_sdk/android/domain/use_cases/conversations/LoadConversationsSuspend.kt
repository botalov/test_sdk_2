package io.carrotquest_sdk.android.domain.use_cases.conversations

import com.google.gson.Gson
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

private const val loadConversationTag = "LoadConversationsSuspend"

/**
 * Suspend versions of load conversations use cases.
 * Coexist with the RxJava Observable extensions in LoadConversationsUseCase.kt —
 * different signatures (no Observable receiver), no conflict.
 */

suspend fun loadConversations(userId: String) = withContext(Dispatchers.IO) {
    try {
        val response = CarrotInternal.getService().carrotLib
            .getConservations(userId)
            .blockingFirst(null) ?: return@withContext

        val repo = ConversationsRepository.getInstance()
        val conversations = ArrayList<DataConversation>()
        if (response.conversations?.isNotEmpty() == true) {
            conversations.addAll(response.conversations)
        }
        response.meta?.nextAfter?.let { repo.setCurrentAfter(it) }

        for (c in conversations) {
            runCatching {
                val json = Gson().toJson(c)
                c.sourceJsonData = JsonParser.parseString(json).asJsonObject
            }
        }
        repo.saveConversations(conversations)
    } catch (e: Exception) {
        Log.e(loadConversationTag, e)
    }
}

suspend fun loadMoreConversations(userId: String, after: String) = withContext(Dispatchers.IO) {
    try {
        val response = CarrotInternal.getService().carrotLib
            .getConservations(userId, after)
            .blockingFirst(null) ?: return@withContext

        val repo = ConversationsRepository.getInstance()
        val conversations = ArrayList<DataConversation>()
        if (response.conversations?.isNotEmpty() == true) {
            conversations.addAll(response.conversations)
        }
        for (c in conversations) {
            repo.addConversation(c)
        }
    } catch (e: Exception) {
        Log.e(loadConversationTag, e)
    }
}

suspend fun reloadConversation(conversationId: String): DataConversation? = withContext(Dispatchers.IO) {
    try {
        val response = CarrotInternal.getService().carrotLib
            .getConservation(conversationId)
            .filter { it.meta != null && it.data != null }
            .blockingFirst(null) ?: return@withContext null

        if (response.meta?.error != null) return@withContext null

        val conversation = response.data ?: return@withContext null
        val jsonStr = Gson().toJson(conversation)
        if (jsonStr != null) {
            conversation.sourceJsonData = JsonParser.parseString(jsonStr).asJsonObject
            conversation.partLast?.let { part ->
                part.sourceJsonData = JSONObject(Gson().toJson(part))
            }
            conversation.partLast?.actions?.let { actions ->
                conversation.partLast.actions = actions.onEach { it.messageId = conversation.partLast.id }
            }
        }
        ConversationsRepository.getInstance().updateConversation(conversationId, conversation)
        conversation
    } catch (e: Exception) {
        Log.e(loadConversationTag, e)
        null
    }
}
