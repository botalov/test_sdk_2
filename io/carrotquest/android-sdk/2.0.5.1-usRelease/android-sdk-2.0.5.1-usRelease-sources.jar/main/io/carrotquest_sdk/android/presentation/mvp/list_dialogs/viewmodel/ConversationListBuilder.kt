package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.viewmodel

import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ConversationListItem
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ConversationUiItem
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ListUiState

/**
 * Stateless builder: принимает готовый список [ConversationUiItem] (уже отсортированный
 * по lastUpdate) и возвращает [ListUiState]. Не зависит от Android-контекста и репозиториев —
 * поэтому легко покрывается юнит-тестами.
 */
internal object ConversationListBuilder {

    fun build(
        conversations: List<ConversationUiItem>,
        expandedGroupIds: Set<String>
    ): ListUiState {
        if (conversations.isEmpty()) return ListUiState.Empty

        val recent = conversations.filter { it.isRecent }
        val history = conversations.filter { !it.isRecent }

        val recentItems = recent.map { ConversationListItem.Single(it) }

        val historyItems = history
            .groupBy { it.lastAdminId ?: "no_operator_${it.id}" }
            .values
            .flatMap { group ->
                if (group.size == 1) {
                    listOf(ConversationListItem.Single(group.first()))
                } else {
                    val opId = group.first().lastAdminId!!
                    listOf(
                        ConversationListItem.Group(
                            operatorId = opId,
                            operatorName = group.first().adminName,
                            operatorAvatarUrl = group.first().adminAvatarUrl,
                            conversations = group,
                            isExpanded = expandedGroupIds.contains(opId)
                        )
                    )
                }
            }

        return ListUiState.Content(recentItems, historyItems)
    }
}
