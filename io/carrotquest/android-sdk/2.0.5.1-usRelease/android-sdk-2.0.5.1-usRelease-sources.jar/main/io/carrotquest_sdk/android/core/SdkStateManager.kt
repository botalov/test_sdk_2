package io.carrotquest_sdk.android.core

import io.carrotquest_sdk.android.core.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

internal object SdkStateManager {

    private const val TAG = "SdkStateManager"

    private val _state: MutableStateFlow<SdkState> = MutableStateFlow(SdkState.Idle)
    val state: StateFlow<SdkState> = _state.asStateFlow()

    private val _publicState: MutableStateFlow<CarrotState> = MutableStateFlow(CarrotState.Idle)
    val publicState: StateFlow<CarrotState> = _publicState.asStateFlow()

    /**
     * Эмитится когда SDK обнаружил, что refresh-токен протух/недействителен — клиент должен
     * вызвать [deInit] и заново [setup]. Не меняет state автоматически, т.к. мы не хотим
     * ломать инварианты state-машины из callback'а (interceptor работает в OkHttp-thread).
     */
    private val _sessionExpired: MutableSharedFlow<Unit> = MutableSharedFlow(
        replay = 0,
        extraBufferCapacity = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val sessionExpired: SharedFlow<Unit> = _sessionExpired.asSharedFlow()

    fun notifySessionExpired() {
        Log.e(TAG, "notifySessionExpired: refresh failed, client should deInit+setup")
        _sessionExpired.tryEmit(Unit)
    }

    @Volatile
    private var readyDeferred: CompletableDeferred<Unit> = CompletableDeferred()

    fun isInit(): Boolean = _state.value is SdkState.Ready
    fun isInitializing(): Boolean = _state.value is SdkState.Initializing

    /**
     * Атомарный check-and-set перехода в Initializing.
     * Возвращает true если переход состоялся, false — если SDK уже инициализируется или готов.
     * Защищает от гонки параллельных setup()-вызовов.
     */
    @Synchronized
    fun onInitStarted(): Boolean {
        val current = _state.value
        if (current is SdkState.Initializing || current is SdkState.Ready) {
            return false
        }
        _state.value = SdkState.Initializing
        _publicState.value = CarrotState.Initializing
        return true
    }

    @Synchronized
    fun onReady() {
        val current = _state.value
        if (current !is SdkState.Initializing) {
            Log.e(TAG, "onReady() ignored, unexpected state: $current")
            return
        }
        _state.value = SdkState.Ready
        _publicState.value = CarrotState.Ready
        readyDeferred.complete(Unit)
    }

    @Synchronized
    fun onFailed(error: Throwable) {
        val current = _state.value
        if (current !is SdkState.Initializing) {
            Log.e(TAG, "onFailed() ignored, unexpected state: $current")
            return
        }
        _state.value = SdkState.Failed(error)
        _publicState.value = CarrotState.Failed(error)
        readyDeferred.completeExceptionally(error)
        readyDeferred = CompletableDeferred()
    }

    @Synchronized
    fun onInitAborted() {
        if (_state.value is SdkState.Initializing) {
            _state.value = SdkState.Idle
            _publicState.value = CarrotState.Idle
        }
    }

    @Synchronized
    fun onDeInit() {
        if (!readyDeferred.isCompleted) readyDeferred.cancel()
        readyDeferred = CompletableDeferred()
        _state.value = SdkState.Idle
        _publicState.value = CarrotState.Idle
    }

    suspend fun awaitReady() {
        if (_state.value is SdkState.Ready) return
        readyDeferred.await()
    }
}
