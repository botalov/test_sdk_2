package io.carrotquest_sdk.android.domain.use_cases.conversation.files

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.db.files.SavedFile
import io.reactivex.Observable

fun Observable<String>.downloadFileUseCase(messageId: String, attachmentId: String): Observable<String> {
    return this.flatMap {
        val attachment = getAttachment(messageId, attachmentId)
        if (attachment == null) {
            return@flatMap Observable.error(Throwable("File not found"))
        }

        val url = attachment.url
        if (url == null) {
            return@flatMap Observable.error(Throwable("Url is null"))
        }
        val size = attachment.size
        if (size <= 0) {
            return@flatMap Observable.error(Throwable("Size is 0"))
        }

        return@flatMap CarrotInternal.getLibComponent().getCarrotService()
            .downloadF(messageId, attachment.id, url, size)
            .map { f ->

                val db = CarrotInternal.getLibComponent().getSdkDataBase()
                val savedFile = SavedFile(System.currentTimeMillis().toString())
                savedFile.localUri = f.absolutePath
                savedFile.url = url
                db.savedFileDao().insert(savedFile)

                return@map f.absolutePath
            }
    }
}