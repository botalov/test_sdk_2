package io.carrotquest_sdk.android.domain.entities.popup

data class PopUpMessageEntity(
        val id: String,
        val sourceBodyJson: String,
        val expirationTime: Long,
        val backgroundColor: String
)