package io.carrotquest_sdk.android.presentation.container

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asAndroidColorFilter
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.createBitmap
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import io.carrotquest_sdk.android.core.util.Log

@Composable
fun TiledPatternImage(
    url: String,
    modifier: Modifier = Modifier,
    scale: Float = 3f, // <-- Добавили параметр масштаба (1f = оригинальный размер)
    colorFilter: ColorFilter? = null, // <-- Добавили параметр цветового фильтра
) {
    val context = LocalContext.current
    var bitmapState by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(url) {
        try {
            val request = ImageRequest.Builder(context)
                .data(url)
                .size(coil.size.Size.ORIGINAL)
                .allowHardware(false)
                .build()

            val result = context.imageLoader.execute(request)

            if (result is SuccessResult) {
                bitmapState = result.drawable.toBitmapSafely()
            }
        } catch (e: Exception) {
            Log.e("TiledPatternImage", "Error loading pattern image: $e")
        }
    }

    // Пересоздаем Paint, если изменился битмап, масштаб или фильтр
    val nativePaint = remember(bitmapState, scale, colorFilter) {
        bitmapState?.let { bmp ->
            android.graphics.Paint().apply {
                val bitmapShader = android.graphics.BitmapShader(
                    bmp,
                    android.graphics.Shader.TileMode.REPEAT,
                    android.graphics.Shader.TileMode.REPEAT
                )

                // Применяем масштаб, если он отличается от 1.0
                if (scale != 1f) {
                    val matrix = android.graphics.Matrix()
                    // Растягиваем/сжимаем по осям X и Y пропорционально
                    matrix.setScale(scale, scale)
                    bitmapShader.setLocalMatrix(matrix)
                }

                shader = bitmapShader

                // Если передали цветовой фильтр - применяем его
                if (colorFilter != null) {
                    this.colorFilter = colorFilter.asAndroidColorFilter()
                }
            }
        }
    }

    Spacer(
        modifier = modifier.drawBehind {
            if (nativePaint != null) {
                drawIntoCanvas { canvas ->
                    canvas.nativeCanvas.drawRect(
                        0f, 0f, size.width, size.height, nativePaint
                    )
                }
            }
        }
    )
}

private fun Drawable.toBitmapSafely(): Bitmap {
    if (this is BitmapDrawable && this.bitmap != null) {
        return this.bitmap
    }
    val width = if (intrinsicWidth > 0) intrinsicWidth else 1
    val height = if (intrinsicHeight > 0) intrinsicHeight else 1
    val bitmap = createBitmap(width, height)
    val canvas = android.graphics.Canvas(bitmap)
    setBounds(0, 0, canvas.width, canvas.height)
    draw(canvas)
    return bitmap
}