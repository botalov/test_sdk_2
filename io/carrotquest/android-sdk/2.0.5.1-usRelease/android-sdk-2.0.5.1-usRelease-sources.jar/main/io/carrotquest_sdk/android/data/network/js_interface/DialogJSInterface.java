package io.carrotquest_sdk.android.data.network.js_interface;

import android.content.Context;
import android.webkit.JavascriptInterface;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView;

public class DialogJSInterface extends BaseJsInterface implements JSInterface {

    private static final String TAG = "DialogJSInterface";

    private Context context;
    private IJsPresenter presenter;

    public DialogJSInterface(Context context, IJsPresenter presenter, CarrotWebView webView) {
        super(webView);
        this.context = context;
        this.presenter = presenter;
    }

    /**
     * Нажатие на текст сообщения
     *
     * @param messageId Идентификатор сообщения
     */
    @JavascriptInterface
    public void clickMessage(final String messageId) {
        if (presenter != null) {
            presenter.onTapMessage(context, messageId);
            super.methodComplete("clickMessage");
        }
    }

    /**
     * Нажатие на ссылку в тексте сообщения
     *
     * @param messageId
     */
    @JavascriptInterface
    public void clickLinkOnMessage(final String messageId) {
        if (presenter != null) {
            //presenter.onTapMessage(context, messageId);
            super.methodComplete("clickLinkOnMessage");
        }
    }

    /**
     * Тап по прикрепленному к сообщению изображению
     *
     * @param url Идентификатор сообщения
     */
    @JavascriptInterface
    public void clickImage(final String url) {
        if (presenter != null) {
            presenter.onTapImage(url);
            super.methodComplete("clickImage");
        }
    }

    /**
     * Тап по ссылке, которая находится в тексте сообщения
     *
     * @param link Идентификатор сообщения
     */
    @JavascriptInterface
    public void clickLink(final String link) {
        if (presenter != null) {
            //presenter.onGoToLink(link);
            super.methodComplete("clickLink");
        }
    }

    /**
     * Тап на неудачно отправленное сообщение
     *
     * @param messageId Идентификатор сообщения
     */
    @JavascriptInterface
    public void clickErrorMessage(final String messageId) {
        if (presenter != null) {
            presenter.onTapErrorSendingMessage(context, messageId);
            super.methodComplete("clickErrorMessage");
        }
    }

    /**
     * Тап на отправляемое сообщение
     *
     * @param messageId Идентификатор сообщения
     */
    @JavascriptInterface
    public void clickSendingMessage(final String messageId) {
        if (presenter != null) {
            super.methodComplete("clickSendingMessage");
        }
    }

    /**
     * Отмена процесса отправки файла
     *
     * @param messageId Идентификатор сообщения
     */
//    @JavascriptInterface
//    public void cancelSendAttachMessage(final String messageId) {
//        if (presenter != null) {
//            //TODO как минимум, надо ереименовать метод. Еще нужно подумать как отменять отправку файла. Сейчас это даже дизайном не предусмотрено (картинки)
//            presenter.cancelDownloadFile(messageId, "");
//            super.methodComplete("cancelSendAttachMessage");
//        }
//    }

    @JavascriptInterface
    public void cancelDownloadFile(final String messageId, final String attachmentId) {
        if (presenter != null) {
            presenter.cancelDownloadFile(messageId, attachmentId);
            super.methodComplete("cancelDownloadFile");
        }
    }

    /**
     * Открытие прикрепленного файла, если он уже скачан на устройство
     *
     * @param messageId Идентификатор сообщения
     */
//    @JavascriptInterface
//    public void openAttachMessage(final String messageId) {
//        if (presenter != null) {
//            presenter.openAttachFile(messageId, "");
//            super.methodComplete("openAttachMessage");
//        }
//    }

    @JavascriptInterface
    public void openFile(final String messageId, final String attachmentId) {
        if (presenter != null) {
            presenter.openAttachFile(messageId, attachmentId);
            super.methodComplete("openFile");
        }
    }

    /**
     * Загрузка прикрепленного файла на устройство
     *
     * @param messageId Идентификатор сообщения
     */
//    @JavascriptInterface
//    public void downloadAttachMessage(final String messageId) {
//        if (presenter != null) {
//            presenter.onStartDownloadFile(String.valueOf(messageId), "");
//            super.methodComplete("downloadAttachMessage");
//        }
//    }

    @JavascriptInterface
    public void downloadFile(final String messageId, final String attachmentId) {
        if (presenter != null) {
            presenter.onStartDownloadFile(String.valueOf(messageId), String.valueOf(attachmentId));
            super.methodComplete("downloadFile");
        }
    }

    /**
     * Говорит о том, что надо загружать новые данные
     */
    @JavascriptInterface
    public void endList() {
        if (presenter != null) {
            presenter.paginationMessages();
            super.methodComplete("endList");
        }
    }


    /**
     * Ответ на автосообщение
     *
     * @param messageId Идентификатор сообщения
     * @param type      Тип (электропочта или телефон)
     * @param value     Значение, которое ввёл пользователь
     */
    @JavascriptInterface
    public void setContactDetails(final String messageId, final String type, final String value) {
        if (presenter != null) {
            presenter.setContactDetails(messageId, type, value);
            super.methodComplete("setContactDetails");
        }
    }


    /**
     * Тыкнули на оценку операторов
     *
     * @param messageId Идентификатор сообщения
     * @param value     Значение, на какую рожицу тыкнули (1, 3 или 5)
     */
    @JavascriptInterface
    public void sendEvaluationEmoji(final String messageId, final String value) {
        int vote = -1;
        try {
            vote = Integer.parseInt(value);
        }
        catch (Exception e){
            Log.e(TAG, value);
        }

        if (presenter != null && vote > 0) {
            presenter.sendVote(messageId, vote);
            super.methodComplete("sendEvaluationEmoji");
        }
    }


    /**
     * Отправить коммент к оценке оператора
     *
     * @param messageId Идентификатор сообщения
     * @param value     Оценка, которую ранее поставил пользователь
     * @param comment   Коммент, который ввёл пользователь
     */
    @JavascriptInterface
    public void sendVoteComment(final String messageId, final String value, final String comment) {
        int vote = -1;
        try {
            vote = Integer.parseInt(value);
        }
        catch (Exception e){
            Log.e(TAG, value);
        }
        if (presenter != null) {
            presenter.sendCommentVote(messageId, vote, comment);
            super.methodComplete("sendVoteComment");
        }
    }


    @JavascriptInterface
    public void openLink(final String url) {
        if(presenter != null) {
            try {
                String decodedUrl = URLDecoder.decode(url, "UTF-8");
                presenter.onGoToLink(decodedUrl, context);
            } catch (UnsupportedEncodingException e) {
                Log.e("DialogJSInterface", e);
            }
            super.methodComplete("openLink");
        }
    }

    /**
     * Утсанавливает свойство пользователя
     */
    @JavascriptInterface
    public void identify(final String props) {
        if(presenter != null) {
            presenter.setUserProperty(props);
            super.methodComplete("identify");
        }
    }

    @JavascriptInterface
    public void clickOnChooseDateCalendly(final String joinUrl, final String utm) {
        if(presenter != null) {
                presenter.onTapCalendlyButton(joinUrl, utm, context);
        }
    }

    @JavascriptInterface
    public void clickOnZoomButton(final String joinUrl, final String password) {
        if(presenter != null) {
            presenter.onTapZoomMeetingButton(joinUrl, context);
        }
    }


    @JavascriptInterface
    public void selectBotBrunch(final String messageId, final String branchId, final String branchLinkId, final String answerBody, final String href) {
        if(presenter != null) {
            presenter.onSelectBotBrunch(messageId, branchId, branchLinkId, answerBody, href, context);
        }
    }

    @JavascriptInterface
    public void onAddTextBotAction(final String messageId, final String branchId, final String branchLinkId, final String answerBody, final String replyType) {
        if(presenter != null) {
            presenter.onShowBotInput(messageId, branchId, branchLinkId, answerBody, context);
        }
    }

    @JavascriptInterface
    public void allowDataProcessing() {
        presenter.allowDataProcessing();
        super.methodComplete("allowDataProcessing");
    }

    @JavascriptInterface
    public void allowTrackContacts(String dataJson, String replyId) {
        presenter.allowTrackContacts(dataJson, replyId);
        super.methodComplete("allowTrackContacts");
    }
}

