package io.carrotquest_sdk.android.data.network.wss_responses

import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository

class ChatBotFinishedRtsMessage: IRtsMessage {
    private val tag = "ChatBotFinishedRtsMessage"

    @SerializedName(F.CONVERSATION)
    val conversationId: String = ""

    override fun process() {
        if(conversationId.isNotEmpty()) {
            val conversation = ConversationsRepository.getInstance().getConversationById(conversationId)
            if(conversation != null) {
                conversation.isChatBotFinished = true
                ConversationsRepository.getInstance().updateConversation(conversationId, conversation)
            }
        }
    }
}