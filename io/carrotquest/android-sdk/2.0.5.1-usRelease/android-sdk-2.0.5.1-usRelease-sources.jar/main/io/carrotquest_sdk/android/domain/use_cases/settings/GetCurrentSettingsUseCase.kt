package io.carrotquest_sdk.android.domain.use_cases.settings

import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.reactivex.Observable
import io.reactivex.subjects.BehaviorSubject

fun <T> Observable<T>.getSettings() : BehaviorSubject<SettingsEntity?> {
    val tag = "Observable.getCurrentUser()"
//    return Observable.defer {
//        SettingsRepository.getInstance().getSettings()
//    }
    return SettingsRepository.getInstance().getSettings()

}


fun getLastSettings(): SettingsEntity? = SettingsRepository.getInstance().getLastSettings()

fun getSettings(): SettingsEntity? = SettingsRepository.getInstance().getSettingsObject()