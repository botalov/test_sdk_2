package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.view

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ConversationListItem
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.ConversationUiItem
import io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model.PreviewIcon
import io.carrotquest_sdk.android.presentation.mvp.utils.toAnnotatedHtml

// ── Группа (стопка) ───────────────────────────────────────────────────────────

@Composable
internal fun ConversationGroupItem(
    group: ConversationListItem.Group,
    isDark: Boolean,
    accentColor: Color,
    onItemClick: (String) -> Unit,
    onToggle: () -> Unit
) {
    Column {
        // Главная карточка (верхняя в стопке / первая при раскрытии)
        ConversationCard(
            item = group.conversations.first(),
            isDark = isDark,
            accentColor = accentColor,
            onClick = if (group.isExpanded) {
                { onItemClick(group.conversations.first().id) }
            } else {
                onToggle
            }
        )

        // Остальные карточки — анимированно раскрываются
        group.conversations.drop(1).forEach { conversation ->
            AnimatedVisibility(
                visible = group.isExpanded,
                enter = expandVertically(spring(stiffness = Spring.StiffnessMediumLow)) +
                        slideInVertically(spring(stiffness = Spring.StiffnessMediumLow)) { -it / 2 } +
                        fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                ConversationCard(
                    item = conversation,
                    isDark = isDark,
                    accentColor = accentColor,
                    onClick = { onItemClick(conversation.id) }
                )
            }
        }

        // Полоски-превью карточек за стопкой (видны только в свёрнутом состоянии)
        AnimatedVisibility(
            visible = !group.isExpanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            StackPeekStrips(count = minOf(group.conversations.size - 1, 2), isDark = isDark)
        }

        // Кнопка "Свернуть" (видна только в раскрытом состоянии)
        AnimatedVisibility(
            visible = group.isExpanded,
            enter = expandVertically(spring(stiffness = Spring.StiffnessMediumLow)) + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            CollapseGroupButton(isDark = isDark, onClick = onToggle)
        }
    }
}

@Composable
private fun CollapseGroupButton(isDark: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(top = 4.dp, bottom = 4.dp)
            .height(30.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(SdkColors.background(isDark))
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClick
            ),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_cq_chevron_up),
            contentDescription = null,
            tint = SdkColors.title(isDark),
            modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = stringResource(R.string.list_collapse_group),
            color = SdkColors.title(isDark),
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

// Тонкие полоски, имитирующие края карточек позади стопки
@Composable
private fun StackPeekStrips(count: Int, isDark: Boolean) {
    val peekColor = SdkColors.divider(isDark)
    val shape = RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp)
    // Отступы берутся из SVG: основная карточка имеет 12dp padding,
    // средняя полоска — +12dp (итого 24dp), дальняя — +22.5dp (итого ~34dp)
    val horizontalPaddings = listOf(24.dp, 34.dp)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .offset(y = (-4).dp)  // перекрываем нижний padding основной карточки
    ) {
        repeat(count) { index ->
            val hPad = horizontalPaddings.getOrElse(index) { horizontalPaddings.last() }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = hPad)
                    .height(6.dp)
                    .border(1.dp, SdkColors.cardBorder(isDark), shape)
                    .clip(shape)
                    .background(peekColor)
            )
        }
    }
}

// ── Карточка диалога ──────────────────────────────────────────────────────────

@Composable
internal fun ConversationCard(item: ConversationUiItem, isDark: Boolean, accentColor: Color, onClick: () -> Unit) {
    val subColor = SdkColors.secondaryText(isDark)
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SdkColors.background(isDark)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.dp, SdkColors.cardBorder(isDark))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 12.dp, end = 12.dp, top = 18.dp, bottom = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AvatarImage(url = item.adminAvatarUrl, accentColor = accentColor, modifier = Modifier.size(40.dp))

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.adminName ?: "",
                    color = SdkColors.title(isDark),
                    fontSize = 15.sp,
                    lineHeight = 21.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (item.lastMessageText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (item.lastMessageIcon != PreviewIcon.NONE) {
                            Icon(
                                painter = painterResource(
                                    if (item.lastMessageIcon == PreviewIcon.IMAGE)
                                        R.drawable.ic_cq_photo
                                    else
                                        R.drawable.ic_cq_file
                                ),
                                contentDescription = null,
                                tint = subColor,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                        }

                        val previewAnnotated = buildAnnotatedString {
                            if (item.lastMessagePrefix != null) {
                                withStyle(SpanStyle(color = SdkColors.sectionLabel)) {
                                    append("${item.lastMessagePrefix}: ")
                                }
                            }
                            append(item.lastMessageText.toAnnotatedHtml())
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        // Удалённое сообщение показываем тем же приглушённым цветом,
                        // что и имя оператора-префикса, чтобы визуально отличить от
                        // обычного текста реплики.
                        val previewColor = if (item.isLastMessageDeleted) SdkColors.sectionLabel else subColor
                        Text(
                            text = previewAnnotated,
                            color = previewColor,
                            fontSize = 15.sp,
                            lineHeight = 18.75.sp,
                            maxLines = 2,
                            fontWeight = FontWeight(400),
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Top,
                modifier = Modifier.align(Alignment.Top)
            ) {
                if (item.lastMessageTime.isNotBlank()) {
                    Text(text = item.lastMessageTime, color = subColor, fontSize = 11.sp)
                }
                if (item.unreadCount > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(SdkColors.unreadBadge),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (item.unreadCount > 99) "99+" else item.unreadCount.toString(),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

// ── Аватар ────────────────────────────────────────────────────────────────────

@Composable
internal fun AvatarImage(url: String?, accentColor: Color, modifier: Modifier = Modifier) {
    val placeholder = painterResource(R.drawable.ic_grey_circle_placrholder)
    AsyncImage(
        model = ImageRequest.Builder(LocalContext.current)
            .data(url)
            .crossfade(true)
            .build(),
        contentDescription = null,
        modifier = modifier
            .clip(CircleShape)
            .background(accentColor),
        placeholder = placeholder,
        error = placeholder,
        fallback = placeholder,
    )
}
