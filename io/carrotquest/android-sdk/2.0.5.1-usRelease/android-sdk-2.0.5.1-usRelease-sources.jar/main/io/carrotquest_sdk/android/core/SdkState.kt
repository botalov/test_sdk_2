package io.carrotquest_sdk.android.core

internal sealed class SdkState {
    object Idle : SdkState()
    object Initializing : SdkState()
    object Ready : SdkState()
    data class Failed(val error: Throwable) : SdkState()
}
