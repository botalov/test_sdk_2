package io.carrotquest_sdk.android.presentation.mvp.dialog.view

import android.content.Context
import android.widget.ImageView
import androidx.fragment.app.FragmentManager
import io.carrotquest_sdk.android.presentation.mvp.base.IBaseView
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.OperatorStatus
import io.carrotquest_sdk.android.presentation.mvp.web_view.CarrotWebView

interface IDialogView : IBaseView {
    fun setupWebView(webView: CarrotWebView)
    fun loadUrl()
    fun initStartView(jsonScript: String)
    fun showMessage(messageJson: String)
    fun deleteMessage(messageJson: String)
    fun deleteAllMessages(js: String)
    fun updateMessage(messageJson: String)
    fun updateUnreadConversationsCount(count: Int)
    fun updateAdminsAvatars(avatars: Array<ImageView>)
    fun updateAdminName(adminName: String)
    fun updateAdminName(adminName: String, needResize: Boolean)
    fun updateAppName(appName: String)
    fun updateStatus(status: OperatorStatus)
    fun updateAppDescription(description: String, operatorsInOnline: Boolean)
    fun updateStatusCollapsedAppBar(operatorsInOnline: Boolean)
    fun updateAppColor(color: Int)
    fun showErrorNoInternet()
    fun showErrorAirplaneMode()
    fun showErrorSomething()
    fun showErrorFileNotFound()
    fun showErrorSendMessage()
    fun toBottomScroll()
    fun startDownloadFile(messageId: String, attachmentId: String)
    fun showSendButton()
    fun hideSendButton()
    fun showAttachFileButton()
    fun hideAttachFileButton()
    fun enableSendButton()
    fun disableSendButton()

    fun showPhonePrefix()
    fun hidePhonePrefix()

    fun enableInput()
    fun disableInput()
    fun hideInput()
    fun showInput(conversationId: String)
    fun clearInput()
    fun setInputMod(mod: InputMod)
    fun updateHint(hint: String?)
    fun updateMaxLengthInput(maxLength: Int?)

    fun scrollWebView(js: String)
    fun showToBottomButton()
    fun hideToBottomButton()
    fun collapseHeader(operatorsInOnline: Boolean)
    fun updateElevationHeader(elevation: Float)

    fun showDataSavedMessage()

    fun hideLoadError()
    fun hideLoading()

    fun startRoutingBot(jsonScript: String)
    fun addBrunch(jsonScript: String)
    fun openFilePicker()

    fun updatePhoneRegionFlag(flag: String)
    fun updatePhoneRegionPrefix(prefix: String)

    fun setKeyboardType(keyboardType: Int)

    fun getCurrentContext(): Context?
    fun getSupportFragmentManager(): FragmentManager?
    fun goToParentActivity()

    fun finish()
}