package io.carrotquest_sdk.android.domain.use_cases.agreements

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings

fun updateAppSettings(key: String, value: Boolean) {
    val settings = getSettings()

    if (settings != null) {
        val sourceDataString = settings.sourceData
        val jsonObject = JsonParser.parseString(sourceDataString) as JsonObject
        if (jsonObject.has("user")) {
            val userJsonObject = jsonObject.get("user") as JsonObject
            userJsonObject.addProperty(key, value)

            jsonObject.add("user", userJsonObject)

            val updatedSettings = SettingsEntity(
                userId = settings.userId,
                isShowVK = settings.isShowVK,
                textLinkVK = settings.textLinkVK,
                isShowViber = settings.isShowViber,
                textLinkViber = settings.textLinkViber,
                isShowFB = settings.isShowFB,
                textLinkFB = settings.textLinkFB,
                isShowTelegram = settings.isShowTelegram,
                textLinkTelegram = settings.textLinkTelegram,
                isShowInstagram = settings.isShowInstagram,
                textLinkInstagram = settings.textLinkInstagram,
                isShowWhatsapp = settings.isShowWhatsapp,
                textLinkWhatsapp = settings.textLinkWhatsapp,
                appColor = settings.appColor,
                welcomeMessage = settings.welcomeMessage,
                messengerAvatar = settings.messengerAvatar,
                showPoweredBy = settings.showPoweredBy,
                sourceData = jsonObject.toString(),
                appName = settings.appName,
                appId = settings.appId,
                statusOperators = settings.statusOperators,
                onlineMessage = settings.onlineMessage,
                offlineMessage = settings.offlineMessage,
                admins = settings.admins,
                theme = settings.theme,
                locale = settings.locale
            )

            SettingsRepository.getInstance().saveSettings(updatedSettings)

        }
    }
}