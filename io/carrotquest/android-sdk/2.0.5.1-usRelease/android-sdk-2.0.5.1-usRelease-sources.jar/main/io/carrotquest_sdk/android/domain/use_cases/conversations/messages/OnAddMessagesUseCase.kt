package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.TAG
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversation
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import java.sql.Timestamp
import java.util.concurrent.TimeUnit

fun <T> Observable<T>.onAddMessages() : Observable<ArrayList<MessageData>> {
    return Observable.defer {
        return@defer this.flatMap {
            MessagesRepository.getInstance().getAddedMessages()
        }

    }
}

fun <T> Observable<T>.onAddConversation() : Observable<ArrayList<MessageData>> {
    return Observable.defer {
        return@defer this.flatMap {
            MessagesRepository.getInstance().getAddedMessages()
                    .doOnNext { messages ->

                        for (m in messages) {
                            val d = Observable.just(true)
                                    .getConversation(m.conversation)
                                    .take(1)
                                    .filter { x -> x.value != null && x.value.id != null }
                                    .map { x -> x.value!! }
                                    .subscribe({ conversation ->

                                    }, { t ->
                                        Log.e(TAG, t)
                                    })
                        }
                    }
        }
    }
}

fun <T> Observable<T>.onAddExpirationMessages() : Observable<ArrayList<MessageData>> {
    return Observable.defer {
        return@defer this.flatMap {
            MessagesRepository.getInstance().getAddedMessages()
                .doOnNext { arrayMessages ->
                    if (arrayMessages.size == 1) {
                        val message = arrayMessages[0]
                        //Если у сообщения есть "протухание"
                        val expirationTime = message.expiraionTime
                        if (expirationTime != null) {
                            MessagesRepository.getInstance().addExpirationMessage(message.id)

                            val correctExpirationTime = expirationTime * 1000
                            val currentTime = Timestamp(System.currentTimeMillis()).time
                            val minExpirationTime = (30 * 1000).toLong()
                            //Считаем разницу между временем, в которое надо удалить сообщение и текущим времененм
                            val diff: Long =
                                when (correctExpirationTime - currentTime < minExpirationTime) {
                                    true -> minExpirationTime
                                    else -> correctExpirationTime - currentTime
                                }

                            Observable.just(true)
                                .subscribeOn(Schedulers.newThread())
                                .delay(diff, TimeUnit.MILLISECONDS)
                                .take(1)
                                .subscribe {
                                    MessagesRepository.getInstance().getExpirationMessages()
                                        .subscribe { expirationMessageIds ->
                                            if (expirationMessageIds.contains(message.id)) {
                                                val openedConversationId =
                                                    ConversationsRepository.getInstance()
                                                        .getOpenedConversationId()
                                                if (message.conversation != openedConversationId) {
                                                    MessagesRepository.getInstance()
                                                        .removeMessage(message.id)
                                                }
                                                MessagesRepository.getInstance()
                                                    .removeExpirationMessage(message.id)

                                                Observable.just(true)
                                                    .getConversation(message.conversation)
                                                    .take(1)
                                                    .subscribe {
                                                        if (it.value != null) {
                                                            val conversation = it.value
                                                            if (conversation.id != null && conversation.partsCount == 1 && conversation.partLast?.id == message.id) {
                                                                ConversationsRepository.getInstance()
                                                                    .removeConversation(conversation.id)
                                                            }
                                                        }
                                                    }
                                            }
                                        }
                                }
                        }
                    }
                }
        }
    }
}