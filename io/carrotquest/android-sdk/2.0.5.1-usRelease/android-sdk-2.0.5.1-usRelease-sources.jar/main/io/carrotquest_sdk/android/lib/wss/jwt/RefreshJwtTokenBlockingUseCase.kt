package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.CarrotLib

// Shared lock — serializes all callers (timer + HTTP 401 interceptor).
internal val refreshLock = Any()

/**
 * Синхронно обновляет JWT-токен. Безопасно при конкурентных вызовах:
 * если пока мы ждали lock другой поток уже обновил токен — возвращаем готовый.
 *
 * @param failedToken токен, с которым запрос получил 401 (null для timer-based refresh)
 */
internal fun refreshJwtTokenBlocking(failedToken: String? = null): String? {
    synchronized(refreshLock) {
        val current = getJwtToken()
        if (!failedToken.isNullOrEmpty() && current.isNotEmpty() && current != failedToken) {
            return current
        }
        return try {
            val carrotApi = CarrotLib.getLibComponents().carrotApi
            val response = carrotApi.refresh(!isActualRefreshToken())
                .take(1)
                .blockingFirst()
            if (response.meta.status == 200) {
                saveJwtToken(response.data.access)
                saveRefreshToken(response.data.refresh)
                response.data.access
            } else {
                Log.e("JWT", "refreshBlocking: status=${response.meta.status}")
                null
            }
        } catch (e: Exception) {
            Log.e("JWT", "refreshBlocking error: $e")
            null
        }
    }
}
