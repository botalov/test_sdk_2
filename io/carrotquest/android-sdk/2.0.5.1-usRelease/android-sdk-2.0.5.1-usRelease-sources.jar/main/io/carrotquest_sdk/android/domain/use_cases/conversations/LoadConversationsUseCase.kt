package io.carrotquest_sdk.android.domain.use_cases.conversations

import com.google.gson.Gson
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.json.JSONObject

const val TAG_LOAD_CONVERSATIONS = "loadConversations()"
fun Observable<UserEntity>.loadConversations() : Observable<ArrayList<DataConversation>> {
    return Observable.defer {
        return@defer this.flatMap {
            CarrotInternal.getService().carrotLib.getConservations(it.id)
                .subscribeOn(Schedulers.io())
                .doOnError { t ->
                    Log.e(TAG_LOAD_CONVERSATIONS, t)
                }
                .map { userConversations ->
                    val res = ArrayList<DataConversation>()
                    if (userConversations.conversations != null && userConversations.conversations.isNotEmpty()) {
                        res.addAll(userConversations.conversations)
                    }

                        if (userConversations.meta != null && userConversations.meta.nextAfter != null) {
                            ConversationsRepository.getInstance().setCurrentAfter(userConversations.meta.nextAfter)
                        }
                        return@map res
                    }
                    .doOnNext { conversations ->
                        for(c in conversations) {
                            try {
                                val jsonConvString = Gson().toJson(c)
                                if (jsonConvString != null) {
                                    c.sourceJsonData =
                                        JsonParser.parseString(jsonConvString).asJsonObject
                                }
                            } catch (e: Exception) {
                                Log.e(TAG_LOAD_CONVERSATIONS, e)
                            }
                        }
                        ConversationsRepository.getInstance().saveConversations(conversations)
                    }
                    .doOnError { t ->
                        Log.e(TAG_LOAD_CONVERSATIONS, t.toString())
                    }
        }
    }
}

fun Observable<UserEntity>.loadConversations(after: String) : Observable<ArrayList<DataConversation>> {
    return Observable.defer {
        return@defer this.flatMap {
            CarrotInternal.getService().carrotLib.getConservations(it.id, after)
                    .doOnError { t ->
                        Log.e(TAG_LOAD_CONVERSATIONS, t)
                    }
                    .map { userConversations ->
                        val res = ArrayList<DataConversation>()
                        if (userConversations.conversations != null && userConversations.conversations.isNotEmpty()) {
                            res.addAll(userConversations.conversations)
                        }

                        return@map res
                    }
                    .doOnNext { conversations ->
                        for(conversation in conversations) {
                            ConversationsRepository.getInstance().addConversation(conversation)
                        }
                    }
                    .doOnError { t ->
                        Log.e(TAG_LOAD_CONVERSATIONS, t.toString())
                    }
        }
    }
}

fun Observable<String>.loadConversation() : Observable<DataConversation?> {
    return Observable.defer {
        return@defer this.flatMap {
            if(it.isEmpty()) {
                //return@flatMap null
                throw Exception("Conversation id is null")
                //return@flatMap Observable.just(null)
            }

            CarrotInternal.getService().carrotLib.getConservation(it)
                .filter { response -> response.meta != null && response.data != null }
                .doOnError { t ->
                    Log.e(TAG_LOAD_CONVERSATIONS, t)
                }
                .onErrorReturn {
                    return@onErrorReturn null
                }
                .map { response ->
                    if (response.meta == null || (response.meta != null && response.meta.error == null)) {
                        val conversation = response.data
                        if (conversation != null) {
                            val jsonConvString = Gson().toJson(conversation)
                            if (jsonConvString != null) {
                                val jsonPartLast = JsonParser.parseString(jsonConvString)
                                if (jsonPartLast != null) {
                                    conversation.sourceJsonData = jsonPartLast.asJsonObject
                                    conversation.partLast.sourceJsonData =
                                        JSONObject(Gson().toJson(conversation.partLast))

                                    val conversationId = response.data.id
                                    if(conversationId != null) {
                                        ConversationsRepository.getInstance()
                                            .updateConversation(conversationId, conversation)
                                    }
                                }
                                if (conversation.partLast != null && conversation.partLast.actions != null) {
                                    val actions = ArrayList<ActionMessage>()
                                    conversation.partLast.actions.forEach { x ->
                                        x.messageId = conversation.partLast.id
                                        actions.add(x)
                                    }
                                    conversation.partLast.actions = actions
                                }
                            }
                        }
                        return@map conversation
                    } else {
                        return@map null
                    }
                }.onErrorReturn {
                    return@onErrorReturn null
                }
        }
    }
}