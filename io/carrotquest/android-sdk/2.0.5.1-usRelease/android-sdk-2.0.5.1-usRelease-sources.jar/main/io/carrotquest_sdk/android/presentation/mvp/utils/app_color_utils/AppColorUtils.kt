package io.carrotquest_sdk.android.presentation.mvp.utils.app_color_utils


import android.content.Context
import io.carrotquest_sdk.android.domain.use_cases.theme.SimpleTheme
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.round

private const val lightColor = "#ffffff"
private const val darkColor = "#333333"

object AppColorUtils {

    // --- Функции для расчета контрастности (взято из WCAG) ---
    /**
     * Конвертирует двухсимвольную HEX-строку в число Int.
     */
    private fun getRGB(c: String): Int {
        return c.toIntOrNull(16) ?: 0
    }

    /**
     * Вычисляет sRGB компоненту для расчета яркости.
     */
    private fun getsRGB(c: String): Double {
        var colorValue = getRGB(c) / 255.0
        colorValue = if (colorValue <= 0.03928) {
            colorValue / 12.92
        } else {
            ((colorValue + 0.055) / 1.055).pow(2.4)
        }
        return colorValue
    }

    /**
     * Рассчитывает относительную яркость (Luminance) цвета по стандарту WCAG.
     * L - Коэффициент светлости от 0 до 1.
     * @param c Цвет в HEX-формате (например, "#RRGGBB").
     */
    private fun getL(c: String): Double {
        val color = c.removePrefix("#")
        if (color.length != 6) return 0.0

        val r = getsRGB(color.substring(0, 2))
        val g = getsRGB(color.substring(2, 4))
        val b = getsRGB(color.substring(4, 6))

        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    /**
     * Рассчитывает коэффициент контрастности между двумя цветами.
     */
    private fun calcRatio(L1: Double, L2: Double): Double {
        return (max(L1, L2) + 0.05) / (min(L1, L2) + 0.05)
    }


// --- Публичные утилиты для работы с цветом ---

    /**
     * Осветляет или затемняет цвет.
     *
     * @param color Цвет в HEX-формате (например, "#RRGGBB").
     * @param percent Проценты, на сколько надо изменить цвет: положительное число осветляет, отрицательное — затемняет.
     * @return Цвет в HEX-формате.
     */
    fun lightenDarkenColor(color: String, percent: Int): String {
        val colorHex = color.removePrefix("#")
        if (colorHex.length != 6) return color

        val num = colorHex.toLong(16)
        val amt = round(2.55 * percent).toInt()

        val R = ((num shr 16) + amt).coerceIn(0, 255)
        val G = ((num shr 8 and 0x00FF) + amt).coerceIn(0, 255)
        val B = ((num and 0x0000FF) + amt).coerceIn(0, 255)

        return String.format("#%02x%02x%02x", R, G, B).removePrefix("#")
    }


    private fun changeAccentColor(accentColor: String, theme: SimpleTheme, context: Context): String {
        val isGoodContrast = isColorMatchWellWithTheme("#$accentColor", context)
        if(isGoodContrast) {
            return accentColor
        }

        val percent = if(theme == SimpleTheme.DARK) {
            5
        } else {
            -5
        }

        val c = lightenDarkenColor(accentColor, percent)
        return changeAccentColor(c, theme, context)
    }

    /**
     * Проверяет, является ли контраст между цветом и фоном темы достаточным.
     *
     * @param color Цвет для проверки.
     * @param context Контекст в SDK.
     * @param coolContrastRatio Пороговый коэффициент контрастности.
     * @return `true`, если контраст достаточный.
     */
    fun isColorMatchWellWithTheme(color: String, context: Context): Boolean {
        val theme = getThemeUseCase(context)
        val coolContrastRatio = if(theme == SimpleTheme.DARK) {
            5.10
        } else {
            1.95
        }

        val colorL = getL(color)

        val themeL = if (theme == SimpleTheme.DEFAULT) getL(lightColor) else getL(darkColor)
        val ratio = calcRatio(colorL, themeL)
        return ratio >= coolContrastRatio
    }

    private var cachedPalette: ColorPalette? = null

    fun getCorrectAccentColor(context: Context, baseColor: String): String {
        val theme = getThemeUseCase(context)
        val color = if(baseColor.startsWith("#")) {
            baseColor
        } else {
            "#$baseColor"
        }
        val isColorMatchWell = isColorMatchWellWithTheme(color, context)
        if(isColorMatchWell) {
            return baseColor
        }

        return (if(theme == SimpleTheme.DARK) {
            lightColor
        } else {
            darkColor
        }).removePrefix("#")
    }

    /**
     * Получает и рассчитывает пользовательскую цветовую палитру.
     * Результаты кэшируются, чтобы не выполнять расчеты повторно.
     *
     * @param context Контекст
     * @param messengerCollapsedColor Пользовательский цвет в HEX-формате без '#'.
     * @return Рассчитанная цветовая палитра [ColorPalette].
     */
    fun getColorPalette(context: Context, messengerCollapsedColor: String, forgetPreviousValue: Boolean = false): ColorPalette {
        // Возвращаем из кэша, если уже считали
        cachedPalette?.let {
            if (!forgetPreviousValue) {
                return it
            }
        }

        val theme = getThemeUseCase(context)

        val contractColor = changeAccentColor(messengerCollapsedColor, theme, context)

        val newPalette = ColorPalette(
            originalAccentColor = messengerCollapsedColor,
            contrastAccentColor = contractColor,
            theme = theme,
        )

        // Сохраняем в кэш и возвращаем
        cachedPalette = newPalette
        return newPalette
    }
}