package io.carrotquest_sdk.android.presentation.mvp.list_dialogs.model

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable

@Stable
sealed class ConversationListItem {
    @Immutable
    data class Single(val conversation: ConversationUiItem) : ConversationListItem()

    @Immutable
    data class Group(
        val operatorId: String,
        val operatorName: String?,
        val operatorAvatarUrl: String?,
        val conversations: List<ConversationUiItem>,   // первый — самый новый
        val isExpanded: Boolean
    ) : ConversationListItem()
}
