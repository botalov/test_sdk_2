package io.carrotquest_sdk.android.presentation.mvp.dialog.presenter

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.text.InputType
import android.text.TextUtils
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.result.ActivityResultLauncher
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.graphics.toColorInt
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop
import com.bumptech.glide.request.RequestOptions
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.Carrot
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.util.JsonUtil
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.files.download_files.DownloadManager
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.files.SavedFile
import io.carrotquest_sdk.android.data.network.js_interface.IJsPresenter
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.data.repositories.old.UserRepository
import io.carrotquest_sdk.android.domain.entities.Optional
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.agreements.TrackContacts
import io.carrotquest_sdk.android.domain.use_cases.agreements.allowDataProcessingUseCase
import io.carrotquest_sdk.android.domain.use_cases.agreements.allowTrackContactsUseCase
import io.carrotquest_sdk.android.domain.use_cases.bot.chooseRoutingBot
import io.carrotquest_sdk.android.domain.use_cases.bot.startRoutingBot
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.clearDraftMessageUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.saveDraftMessageUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.files.downloadFileUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.files.getAttachment
import io.carrotquest_sdk.android.domain.use_cases.conversations.TAG
import io.carrotquest_sdk.android.domain.use_cases.conversations.assignedConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.createConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.getLastConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.getNotPopupConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.getUnreadConversations
import io.carrotquest_sdk.android.domain.use_cases.conversations.loadConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.markConversationAsRead
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.createMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.createWelcomeMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getMessages
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.onAddBatch
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.onAddMessages
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.onRemoveMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.onUpdateMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.paginationMessages
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.removeWelcomeMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.saveMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.saveMessageWithAttachment
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.selectBotBrunch
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.sendMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.sendMessageWithAttachment
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateAutoReplay
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateAutoReplayLoading
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateAutoReplayLocal
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateConversationMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateStatusMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.onCreateConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.openConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.removeTypingIndicator
import io.carrotquest_sdk.android.domain.use_cases.conversations.updateOpenedConversationId
import io.carrotquest_sdk.android.domain.use_cases.countries.GetSavedCountryRegionUseCase
import io.carrotquest_sdk.android.domain.use_cases.countries.getCountryEntityByRegion
import io.carrotquest_sdk.android.domain.use_cases.settings.getLastSettings
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings
import io.carrotquest_sdk.android.domain.use_cases.theme.getTheme
import io.carrotquest_sdk.android.domain.use_cases.user.doneVoting
import io.carrotquest_sdk.android.domain.use_cases.user.doneVotingComment
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import io.carrotquest_sdk.android.domain.use_cases.user.sendVoteOperator
import io.carrotquest_sdk.android.domain.use_cases.user.setUserProperty
import io.carrotquest_sdk.android.domain.use_cases.user.wrongVoting
import io.carrotquest_sdk.android.lib.full_image_view.view.FullImageViewDialogFragment
import io.carrotquest_sdk.android.lib.managers.BackgroundManager
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageMetaData
import io.carrotquest_sdk.android.lib.utils.GraphicUtils
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.utils.loging.Log.Companion.e
import io.carrotquest_sdk.android.lib.utils.loging.LogToElk
import io.carrotquest_sdk.android.lib.utils.loging.MessageToElkType
import io.carrotquest_sdk.android.lib.wss.jwt.isActualJwtToken
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtToken
import io.carrotquest_sdk.android.models.UserProperty
import io.carrotquest_sdk.android.presentation.constans.StatusOperators
import io.carrotquest_sdk.android.presentation.entities.CountryEntity
import io.carrotquest_sdk.android.presentation.mvp.base.BasePresenter
import io.carrotquest_sdk.android.presentation.mvp.base.IBaseView
import io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.MessageActionsBottomSheetActivity
import io.carrotquest_sdk.android.presentation.mvp.calendly.view.CalendlyWidgetActivity
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.DialogViewModel
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.StateAppBar
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.DialogActivity
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.IDialogView
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.InputMod
import io.carrotquest_sdk.android.presentation.mvp.file_picker.FilePickerHelper
import io.carrotquest_sdk.android.presentation.container.SdkContainerActivity
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackClick
import io.carrotquest_sdk.android.presentation.mvp.utils.app_color_utils.AppColorUtils
import io.carrotquest_sdk.android.presentation.mvp.utils.generateUpdatedParams
import io.carrotquest_sdk.android.presentation.mvp.utils.jsonUtils.prepareJsonSettings
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.functions.Consumer
import io.reactivex.observers.DisposableObserver
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.UnsupportedEncodingException
import java.net.URLDecoder
import java.util.Date
import java.util.Locale
import java.util.Random
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class DialogPresenter : BasePresenter(), IJsPresenter {

    @set:Inject
    internal var db: CarrotSdkDB? = null
    @set:Inject
    internal var  userRepository: UserRepository? = null


    private val tag = "DialogPresenter"
    private var compositeDisposable = CompositeDisposable()
    private val viewModel = DialogViewModel.getInstance()

    private var isPagination = false

    private var isNewDialog = false

    private var currentAdmin: Admin? = null


    private val addedMessages = ArrayList<String>()

    private var selectRegionLauncher: ActivityResultLauncher<String>? = null

    private val mainInputType =
        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE

    fun onCreate() {
        try {
//            selectRegionLauncher =
//                (getViewInterface()?.getContext()).registerForActivityResult(SelectCountryContract()) { country ->
//                    if (country == null) {
//                        return@registerForActivityResult
//                    }
//
//                    setPhoneRegion(country)
//                }
        } catch (e: Exception) {
            Log.d(tag, "selectRegionLauncher error: $e")
        }

        loadMessages()
    }

    override fun attachView(view: IBaseView) {
        super.attachView(view)
        loadSettings()

        getViewInterface()?.let { dialogActivity ->
            val emptyAvatarImageView = createEmptyAdminImageView()
            val emptyAvList = arrayOf(emptyAvatarImageView)
            dialogActivity.updateAdminsAvatars(emptyAvList)

            val savedRegion = GetSavedCountryRegionUseCase().call()
            val savedCountry =
                getCountryEntityByRegion(savedRegion, PhoneNumberUtil.createInstance(dialogActivity.getCurrentContext()))
            setPhoneRegion(savedCountry)
        }
    }

    private var selectedCountry: CountryEntity? = null
    private fun setPhoneRegion(country: CountryEntity) {
        selectedCountry = country

        val flag = country.flag
        val prefix = "+${country.countryCode}"

        if (flag != null) {
            getViewInterface()?.updatePhoneRegionFlag(flag)
            getViewInterface()?.updatePhoneRegionPrefix(prefix)

            val currentConversationId = viewModel.getCurrentConversationId()
            if(currentConversationId.isNotEmpty()) {
                compositeDisposable.add(Observable.just(1).getConversation(currentConversationId)
                    .take(1)
                    .subscribe {
                        val conversation = it.value
                        if (conversation != null) {
                            updateInput(conversation)
                        }
                    })
            }
        }
    }

    private fun loadSettings() {
        val hasInternet =
            NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).hasConnect
        if (hasInternet) {
            compositeDisposable.add(Observable.just(true)
                .getSettings()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { settings ->
                        if (settings != null) {
                            val color = if(settings.originalAppColor == null) {
                                settings.appColor
                            } else {
                                AppColorUtils.getCorrectAccentColor(CarrotInternal.getLibComponent().contextSdk, settings.originalAppColor)
                            }

                            getViewInterface()?.updateAppColor(("#$color").toColorInt())
                            updateStatusOperators(settings)
                        }
                    },
                    { error -> Log.e(tag, error) }
                )
            )
        } else {
            val settings = getLastSettings()
            if (settings != null) {
//                val color = ("#" + settings.appColor).toColorInt()
//                getViewInterface()?.updateAppColor(color)
                val color = AppColorUtils.getCorrectAccentColor(CarrotInternal.getLibComponent().contextSdk, settings.originalAppColor!!)
                getViewInterface()?.updateAppColor(("#$color").toColorInt())
                updateStatusOperators(settings)
            }
        }
    }

    fun onCreateWebView(convId: String) {
        val hasInternet =
            NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).hasConnect

        if (hasInternet) {
            getConversation(convId)
        } else {

            if (NetworkManager.isAirplaneModeOn()) {
                getViewInterface()?.showErrorAirplaneMode()
            } else {
                getViewInterface()?.showErrorNoInternet()
            }

            compositeDisposable.dispose()
            compositeDisposable = CompositeDisposable()
        }
    }

    private fun getConversation(convId: String) {
        compositeDisposable.add(
            Observable.just(true)
                .getConversation(convId)
                .take(1)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe({ conversationOpt ->
                    getViewInterface()?.updateHint(null)

                    if (conversationOpt.value != null) {
                        val conversation = conversationOpt.value
                        updateInput(conversation)
                    }

                    getViewInterface()?.setInputMod(currentInputMod)
                }, { t ->
                    Log.e(TAG, t)
                })
        )
    }

    fun onDestroy() {
        selectedCountry = null
        viewModel.updateCurrentConversationId("")

        currentAdmin = null
        super.detachView()
        viewModel.updateCurrentStateAppBar(StateAppBar.EXPANDED)

        compositeDisposable.dispose()
        compositeDisposable = CompositeDisposable()
    }

//    override fun getView(): DialogActivity? {
//        return super.getView() as? DialogActivity
//    }
    
    fun getViewInterface(): IDialogView? {
        return if(super.getView() is IDialogView) {super.getView() as IDialogView} else null
    }

    fun onOpenDialog() {
        isNewDialog = false
        initSubscribes()

        getViewInterface()?.updateHint(null)
        getViewInterface()?.hidePhonePrefix()

        getViewInterface()?.updateMaxLengthInput(null)
        getViewInterface()?.setKeyboardType(mainInputType)
    }

    fun onOpenNewDialog() {
        isNewDialog = true
        initNewConversationSubscribes()
        viewModel.updateCurrentConversationId("")

    }

    private fun updateInput(conversation: DataConversation) {
        val conversationId = conversation.id
        if (conversationId == null) {
            return
        }

        var maxLength: Int? = null
        if (conversation.type != null && ConversationType.BLOCK_POPUP_SMALL.stringValue == conversation.type) {
            getViewInterface()?.hideInput()
        } else if (ConversationType.LEAD_BOT.stringValue == conversation.type
            || ConversationType.ROUTING_BOT.stringValue == conversation.type
        ) {
            val lastPart = conversation.partLast
            val isAllowUserReply = conversation.replyType == "text"

            if (isAllowUserReply) {
                if (lastPart.type == "reply_admin") {
                    currentInputMod = InputMod.NORMAL
                    getViewInterface()?.showInput(conversationId)
                    getViewInterface()?.updateHint(null)
                } else if (lastPart.actions != null && lastPart.actions.isNotEmpty() && "property_field" == lastPart.actions[0].type) {
                    currentInputMod = InputMod.BOT_INPUT
                    currentAction = lastPart.actions[0]
                    getViewInterface()?.showInput(conversationId)

                    val placeholder = lastPart.actions[0].placeholder
                    val hint: String = if (placeholder != null) {
                        if (placeholder.type == "custom") {
                            placeholder.value
                        } else {
                            when (placeholder.type) {
                                "phone", "phone_mask" -> {
                                    if (selectedCountry == null) {
                                        CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_phone_hint)
                                    } else {
                                        val exampleNumber =
                                            PhoneNumberUtil.createInstance(getViewInterface()?.getCurrentContext())
                                                .getExampleNumberForType(
                                                    selectedCountry!!.region.uppercase(),
                                                    PhoneNumberUtil.PhoneNumberType.MOBILE
                                                )
                                        maxLength =
                                            exampleNumber?.nationalNumber?.toString()?.length
                                        exampleNumber?.nationalNumber?.toString()
                                            ?: CarrotInternal.getLibComponent().contextSdk.getString(
                                                R.string.bot_answer_phone_hint
                                            )
                                    }
                                }

                                "email" -> {
                                    CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_email_hint)
                                }

                                "name" -> {
                                    CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_name_hint)
                                }

                                else -> {
                                    CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_hint)
                                }
                            }
                        }
                    } else {
                        when (lastPart.replyType) {
                            "phone" -> {
                                if (selectedCountry == null) {
                                    CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_phone_hint)
                                } else {
                                    val exampleNumber = PhoneNumberUtil.createInstance(getViewInterface()?.getCurrentContext())
                                        .getExampleNumberForType(
                                            selectedCountry!!.region.uppercase(),
                                            PhoneNumberUtil.PhoneNumberType.MOBILE
                                        )
                                    maxLength = exampleNumber?.nationalNumber?.toString()?.length
                                    exampleNumber?.nationalNumber?.toString()
                                        ?: CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_phone_hint)
                                }
                            }

                            "email" -> {
                                CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_email_hint)
                            }

                            "name" -> {
                                CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_name_hint)
                            }

                            else -> {
                                CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_hint)
                            }
                        }
                    }

                    val keyboardType = when (lastPart.replyType) {
                        "phone" -> {
                            InputType.TYPE_CLASS_PHONE
                        }

                        "email" -> {
                            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                        }


                        else -> {
                            mainInputType
                        }
                    }

                    if (keyboardType == InputType.TYPE_CLASS_PHONE) {
                        getViewInterface()?.showPhonePrefix()
                    } else {
                        getViewInterface()?.hidePhonePrefix()
                    }

                    getViewInterface()?.updateMaxLengthInput(maxLength)

                    getViewInterface()?.updateHint(hint)
                    getViewInterface()?.setKeyboardType(keyboardType)
                    getViewInterface()?.showSendButton()
                    getViewInterface()?.disableSendButton()
                } else if (currentInputMod != InputMod.BOT_INPUT) {
                    currentInputMod = InputMod.ALLOW_USER_REPLIES
                    getViewInterface()?.showInput(conversationId)
                    getViewInterface()?.updateHint(null)
                    getViewInterface()?.hidePhonePrefix()

                    getViewInterface()?.updateMaxLengthInput(null)
                    getViewInterface()?.setKeyboardType(mainInputType)
                }
            } else {
                if (lastPart.type == "reply_admin") {
                    currentInputMod = InputMod.NORMAL
                    getViewInterface()?.showInput(conversationId)
                    getViewInterface()?.updateHint(null)
                    getViewInterface()?.hidePhonePrefix()
                    getViewInterface()?.updateMaxLengthInput(null)
                } else if (lastPart.actions != null && lastPart.actions.isNotEmpty() && "property_field" == lastPart.actions[0].type) {
                    currentInputMod = InputMod.BOT_INPUT
                    currentAction = lastPart.actions[0]
                    getViewInterface()?.showInput(conversationId)

                    val placeholder = lastPart.actions[0].placeholder
                    val hint = if (placeholder != null) {
                        if (placeholder.type == "custom") {
                            placeholder.value
                        } else {
                            when (placeholder.type) {
                                "phone" -> {
                                    if (selectedCountry == null) {
                                        CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_phone_hint)
                                    } else {
                                        val exampleNumber =
                                            PhoneNumberUtil.createInstance(getViewInterface()?.getCurrentContext())
                                                .getExampleNumberForType(
                                                    selectedCountry!!.region.uppercase(),
                                                    PhoneNumberUtil.PhoneNumberType.MOBILE
                                                )
                                        maxLength =
                                            exampleNumber?.nationalNumber?.toString()?.length
                                        exampleNumber?.nationalNumber?.toString()
                                            ?: CarrotInternal.getLibComponent().contextSdk.getString(
                                                R.string.bot_answer_phone_hint
                                            )
                                    }
                                }

                                "email" -> {
                                    CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_email_hint)
                                }

                                "name" -> {
                                    CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_name_hint)
                                }

                                else -> {
                                    CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_hint)
                                }
                            }
                        }
                    } else {
                        when (lastPart.replyType) {
                            "phone" -> {
                                if (selectedCountry == null) {
                                    CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_phone_hint)
                                } else {
                                    val exampleNumber = PhoneNumberUtil.createInstance(getViewInterface()?.getCurrentContext())
                                        .getExampleNumberForType(
                                            selectedCountry!!.region.uppercase(),
                                            PhoneNumberUtil.PhoneNumberType.MOBILE
                                        )
                                    maxLength = exampleNumber?.nationalNumber?.toString()?.length
                                    exampleNumber?.nationalNumber?.toString()
                                        ?: CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_phone_hint)
                                }
                            }

                            "email" -> {
                                CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_email_hint)
                            }

                            "name" -> {
                                CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_name_hint)
                            }

                            else -> {
                                CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_hint)
                            }
                        }
                    }

                    val keyboardType = when (lastPart.replyType) {
                        "phone" -> {
                            InputType.TYPE_CLASS_PHONE
                        }

                        "email" -> {
                            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                        }


                        else -> {
                            mainInputType
                        }
                    }

                    if (keyboardType == InputType.TYPE_CLASS_PHONE) {
                        getViewInterface()?.showPhonePrefix()
                    } else {
                        getViewInterface()?.hidePhonePrefix()
                    }

                    getViewInterface()?.updateMaxLengthInput(maxLength)
                    getViewInterface()?.updateHint(hint)
                    getViewInterface()?.setKeyboardType(keyboardType)
                    getViewInterface()?.showSendButton()
                    getViewInterface()?.disableSendButton()
                } else if (conversation.isChatBotFinished) {
                    currentInputMod = InputMod.ALLOW_USER_REPLIES
                    getViewInterface()?.showInput(conversationId)
                    getViewInterface()?.updateHint(null)
                    getViewInterface()?.hidePhonePrefix()
                    getViewInterface()?.updateMaxLengthInput(null)
                    getViewInterface()?.setKeyboardType(mainInputType)
                } else {
                    getViewInterface()?.hideInput()
                    getViewInterface()?.hidePhonePrefix()
                    getViewInterface()?.updateMaxLengthInput(null)
                    getViewInterface()?.setKeyboardType(mainInputType)
                }
            }
        } else {
            getViewInterface()?.showInput(conversationId)
            getViewInterface()?.updateHint(null)
            getViewInterface()?.updateMaxLengthInput(null)
            getViewInterface()?.hidePhonePrefix()
            getViewInterface()?.setKeyboardType(mainInputType)
        }
    }


    private fun initNewConversationSubscribes() {
        if (!compositeDisposable.isDisposed) {
            compositeDisposable.dispose()
        }
        compositeDisposable = CompositeDisposable()

        val hasInternet =
            NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).hasConnect
        if (hasInternet) {
            commonSubscribes()
            compositeDisposable.add(
                Observable.just(true)
                    .getSettings()
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .take(1)
                    .subscribe({ settings ->
                        if (settings != null) {
                            updateHeader(null)

                            val jsonObject = JsonObject()
                            val joConnect =
                                prepareJsonSettings(
                                    JsonParser.parseString(settings.sourceData) as JsonObject,
                                    getViewInterface()?.getCurrentContext()
                                )
                            val providerName = when (BuildConfig.FLAVOR) {
                                "common" -> "Carrot quest"
                                "us" -> "Dashly"
                                else -> ""
                            }
                            if (providerName.isNotEmpty()) {
                                joConnect.addProperty("provider_name", providerName)
                            }
                            jsonObject.add("appSettings", joConnect)
                            val messagesArray = JsonArray()

                            jsonObject.add("unstructuredMessagesData", messagesArray)
                            val initJson = "javascript:window.webView.initDialogue($jsonObject)"

                            getViewInterface()?.initStartView(initJson)

                            compositeDisposable.add(
                                Single.just(true)
                                    .delay(100, TimeUnit.MILLISECONDS)
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribeOn(Schedulers.io())
                                    .subscribe(Consumer {
                                        getViewInterface()?.hideLoadError()
                                        getViewInterface()?.hideLoading()
                                        getViewInterface()?.enableInput()
                                    })
                            )

                            compositeDisposable.add(
                                Observable.just(settings)
                                    .createWelcomeMessage()
                                    .observeOn(AndroidSchedulers.mainThread())
                                    .subscribeOn(Schedulers.io())
                                    .take(1)
                                    .delay(1, TimeUnit.SECONDS)
                                    .subscribe({ optMessageData ->
                                        compositeDisposable.add(Observable.just(true)
                                            .chooseRoutingBot(viewModel.getCurrentConversationId())
                                            .observeOn(AndroidSchedulers.mainThread())
                                            .take(1)
                                            .doOnError { t ->
                                                Log.e(TAG, t)
                                            }
                                            .subscribe { chooseRoutingBotData ->
                                                val needStartRoutingBot =
                                                    chooseRoutingBotData?.bot != null && chooseRoutingBotData.found != false

                                                viewModel.setNeedStartRoutingBot(
                                                    needStartRoutingBot
                                                )

                                                if (!needStartRoutingBot) {
                                                    val mArray = JSONArray()
                                                    mArray.put(optMessageData.value?.sourceJsonData)

                                                    val arrayStr = mArray.toString()
                                                    val addMessagesJson =
                                                        "javascript:window.webView.addMessages($arrayStr)"
                                                    getViewInterface()?.showMessage(addMessagesJson)
                                                }
                                            }
                                        )
                                    }, { t ->
                                        Log.e(TAG, t)
                                    })
                            )
                        } else {
                            throw Exception()
                        }
                    }, {
                        getViewInterface()?.showErrorSomething()
                    })
            )
        }
    }

    private fun initSubscribes() {
        if (!compositeDisposable.isDisposed) {
            compositeDisposable.dispose()
        }
        compositeDisposable = CompositeDisposable()

        if (NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).hasConnect) {
            initDoneConversationSubscribes()
            NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)
                .addObserver({ hasInternet ->
                    if (hasInternet) {
                        loadMessages()
                    }
                }, { }, {})

            BackgroundManager.getInstance().addObserver({ isForeground ->
                if (isForeground) {
//                    Observable.just(true)
//                        .delay(2, TimeUnit.SECONDS)
//                        .take(1)
//                        .doOnComplete {
//                            loadMessages(needHardUpdate = true)
//                        }
//                        .subscribe()


                    //println("ISOPENPICKER = $isOpenPicker")
                    if(!isOpenPicker) {
                        loadMessages(needHardUpdate = true)
                    }
                    //loadMessages(needHardUpdate = false)
                }
            }, { }, {})
        } else {
            loadSettings()
            getViewInterface()?.showErrorNoInternet()
        }
    }

    private fun initDoneConversationSubscribes() {
        if (!compositeDisposable.isDisposed) {
            compositeDisposable.dispose()
        }

        compositeDisposable = CompositeDisposable()
        val conversationId = viewModel.getCurrentConversationId()
        compositeDisposable.add(Observable.just(true)
            .getConversation(conversationId)
            .take(1)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.io())
            .doOnError {
            }
            .doOnNext { it ->
                val conversation = it.value
                if (conversation == null) {
                    getViewInterface()?.showErrorSomething()
                } else {
                    if (conversation.type != ConversationType.BLOCK_POPUP_BIG.stringValue
                        && conversation.type != ConversationType.BLOCK_POPUP_SMALL.stringValue
                    ) {
                        compositeDisposable.add(
                            Observable.just(true)
                                .openConversation(conversationId)
                                .subscribe()
                        )
                    }
                }
            }
            .markConversationAsRead()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .take(1)
            .filter { x -> x.value != null }
            .map { x -> x.value!! }
            .doOnNext { conversation ->
                updateHeader(conversation.lastAdmin)
                compositeDisposable.add(
                    Observable.just(viewModel.getCurrentConversationId())
                        .loadConversation()
                        .take(1)
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribeOn(Schedulers.io())
                        .subscribe({ c ->
                            if (c != null && c.lastAdmin != null) {
                                updateHeader(c.lastAdmin)
                            }
                        }, {
                        })
                )
            }
            .doOnError {
                onOpenNewDialog()
            }
            .getMessages()
            .doOnNext { res ->
                val messages = res.value
                if (messages == null) {
                    getViewInterface()?.showErrorSomething()

                    return@doOnNext
                }

                compositeDisposable.add(
                    Observable.just(true)
                        .getSettings()
                        .observeOn(AndroidSchedulers.mainThread())
                        .take(1)
                        .subscribe({ settings ->
                            if (settings != null) {

                                val jsonObject = JsonObject()
                                val jsonParser = JsonParser()

                                val joConnect =
                                    prepareJsonSettings(
                                        jsonParser.parse(settings.sourceData) as JsonObject,
                                        getViewInterface()?.getCurrentContext()
                                    )
                                val providerName = when (BuildConfig.FLAVOR) {
                                    "common" -> "Carrot quest"
                                    "us" -> "Dashly"
                                    else -> ""
                                }
                                if (providerName.isNotEmpty()) {
                                    joConnect.addProperty("provider_name", providerName)
                                }

                                jsonObject.add("appSettings", joConnect)
                                jsonObject.add("unstructuredMessagesData", messages.sourceData)


                                val initJson = "javascript:window.webView.initDialogue($jsonObject)"
                                getViewInterface()?.initStartView(initJson)

                                compositeDisposable.add(
                                    Single.just(true)
                                        .delay(1, TimeUnit.SECONDS)
                                        .observeOn(AndroidSchedulers.mainThread())
                                        .subscribeOn(Schedulers.io())
                                        .subscribe(Consumer {
                                            getViewInterface()?.hideLoadError()
                                            getViewInterface()?.hideLoading()
                                            getViewInterface()?.enableInput()

                                        })
                                )
                            } else {
                                throw Exception()
                            }
                            commonSubscribes()
                        }, {
                            getViewInterface()?.showErrorSomething()
                        })
                )
            }
            .subscribe()
        )

    }

    private fun commonSubscribes() {
        getView()
        compositeDisposable.add(
            Observable.just(true)
                .assignedConversation(viewModel.getCurrentConversationId())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.io())
                .subscribe({ currentConversation ->
                    if (currentConversation != null) {
                        val admin = currentConversation.lastAdmin
                        if (admin != null) {
                            updateHeader(admin)
                        }
                    }

                }, { error ->
                    Log.e(tag, error)
                })
        )

        compositeDisposable.add(
            Observable.just(true)
                .onAddMessages()
                .subscribe({ messages ->
                    val messagesArray = JSONArray()

//                    val xMessages = ArrayList<MessageData>()
//                    messages.forEach { m ->
//                        if (!addedMessages.contains(m.id)) {
//                            xMessages.add(m)
//                        }
//                    }

                    messages.forEach { m ->
                        addedMessages.add(m.id)
                        addedMessages.add(m.randomId)
                    }

                    for (m in messages) {
                        val currentConvId = viewModel.getCurrentConversationId()
                        if ((currentConvId.isNotEmpty() && currentConvId == m.conversation)
                            || (currentConvId.isEmpty() && m.isFirst)
                        ) {
                            messagesArray.put(m.sourceJsonData)
                        }
                    }

                    val arrayStr = messagesArray.toString()
                    val addMessagesJson = "javascript:window.webView.addMessages($arrayStr)"
                    getViewInterface()?.showMessage(addMessagesJson)



                    compositeDisposable.add(Observable.just(true)
                        .getConversation(viewModel.getCurrentConversationId())
                        .observeOn(AndroidSchedulers.mainThread())
                        .doOnNext { conversationOpt ->
                            val conversation = conversationOpt.value
                            if (conversation != null) {
                                updateHeader(conversation.lastAdmin)
                            }
                        }
                        .markConversationAsRead()
                        .subscribeOn(Schedulers.io())
                        .take(1)
                        .subscribe())
                }, { t ->
                    Log.e(tag, t)
                })
        )

        compositeDisposable.add(
            Observable.just(true)
                .onAddBatch()
                .doOnDispose {
                    Log.d(tag, "onAddBrunch dispose")
                }
                .doOnComplete {
                    Log.d(tag, "onAddBrunch complete")
                }
                .subscribe({ addedBrunchStr ->
                    run {
                        //TODO тут наверное надо что-то переделать чотбы отправлять во вьюху нормальный json
                        val addMessagesJson =
                            "javascript:window.webView.addBatchedMessages($addedBrunchStr)"
                        getViewInterface()?.showMessage(addMessagesJson)

                        val json = JsonParser.parseString(addedBrunchStr)
                        if (json != null && json.isJsonObject && json.asJsonObject.has(F.PARTS)) {
                            val partsJson = json.asJsonObject.get(F.PARTS).asJsonArray
                            if (partsJson.size() == 1) {
                                Log.d(tag, "")
                            }
                            if (!partsJson.isJsonNull) {
                                for (p in partsJson) {
                                    val updateMessagesJson =
                                        "javascript:window.webView.updateMessageObject($p)"
                                    getViewInterface()?.updateMessage(updateMessagesJson)
                                }
                            }
                        }
                    }
                }, { t ->
                    Log.e(tag, t)
                })
        )

        compositeDisposable.add(
            Observable.just(true)
                .onUpdateMessage()
                .doOnDispose {
                    Log.d(tag, "dispose")
                }
                .doOnComplete {
                    Log.d(tag, "complete")
                }
                .subscribe({ updatedMessage ->
                    if (updatedMessage != null && (updatedMessage.conversation == viewModel.getCurrentConversationId() || viewModel.getCurrentConversationId()
                            .isEmpty()) && updatedMessage.type != "vote"
                    ) {
                        val messageId = updatedMessage.id
                        val params = generateUpdatedParams(updatedMessage)


                        addedMessages.add(messageId)
                        if (updatedMessage.type == "auto_reply") {
                            val jsUpdateMessageInputStatus =
                                "javascript:window.webView.updateMessageInputStatus(\"$messageId\", $params)"
                            getViewInterface()?.updateMessage(jsUpdateMessageInputStatus)
                        } else if (updatedMessage.attachments.isNullOrEmpty() || updatedMessage.isFirst) {
                            val jsUpdateMessage =
                                "javascript:window.webView.updateMessageObject(${updatedMessage.sourceJsonData.toString()})"
                            getViewInterface()?.updateMessage(jsUpdateMessage)
                        }
                    }

                }, { t ->
                    Log.e(tag, t)
                })
        )

        compositeDisposable.add(
            Observable.just(true)
                .onRemoveMessage()
                .subscribe({ removedMessage ->
                    if (removedMessage != null && (removedMessage.conversation == viewModel.getCurrentConversationId() || removedMessage.conversation == "")) {
                        val messageId = removedMessage.id

                        val jsDeleteMessage =
                            "javascript:window.webView.deleteMessage(\"$messageId\")"
                        getViewInterface()?.deleteMessage(jsDeleteMessage)
                    }
                }, { t ->
                    Log.e(tag, t)
                })
        )

        compositeDisposable.add(
            Observable.just(true)
                .getConversations()
                .getNotPopupConversations()
                //.getUnreadConversations()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ conversations ->
                    Observable.just(conversations)
                        .getUnreadConversations()
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .take(1)
                        .subscribe { unreadConversations ->
                            unreadConversations.removeAll { x -> x.id == viewModel.getCurrentConversationId() }
                            getViewInterface()?.updateUnreadConversationsCount(unreadConversations.size)
                        }

                    val currentConversation =
                        conversations.find { x -> x.id == viewModel.getCurrentConversationId() }
                    //&& currentConversation.isChatBotFinished
                    if (currentConversation != null) {
                        updateInput(currentConversation)
                    }

                }, {
                    Log.e(tag, it.toString())
                })
        )

        compositeDisposable.add(Observable.just(true)
            .chooseRoutingBot(viewModel.getCurrentConversationId())
            .observeOn(AndroidSchedulers.mainThread())
            .take(1)
            .doOnError { t ->
                Log.e(TAG, t)
            }
            .subscribe { data ->
                run {
                    val needStartRoutingBot = data?.found == true
                    viewModel.setNeedStartRoutingBot(needStartRoutingBot)
                    if (needStartRoutingBot) {
                        val botId = data?.bot?.id
                        if (botId != null) {
                            viewModel.setRoutingBotId(botId)
                        }
                        val jsResponse = Gson().toJson(data)

                        val jsScript =
                            "javascript:window.webView.addRoutingBotMessages($jsResponse)"
                        getViewInterface()?.startRoutingBot(jsScript)

                        if (data?.bot?.allow != true) {
                            getViewInterface()?.hideInput()
                        }

                        // Если у нас диалог с роутинг-ботом, то надо подписаться на сохранение нового диалога
                        compositeDisposable.add(
                            Observable.just(true).onCreateConversation()
                                .subscribeOn(Schedulers.io())
                                .observeOn(AndroidSchedulers.mainThread())
                                .take(1)
                                .subscribe({ c ->
                                    val cId = viewModel.getCurrentConversationId()
                                    if (cId == c.randomId) {
                                        viewModel.setNeedStartRoutingBot(false)
                                        viewModel.updateCurrentConversationId(c.id)
                                        commonSubscribes()
                                    }
                                }, { t ->
                                    Log.e(TAG, t)
                                })
                        )
                    }
                }
            })
    }

    fun onTapCloseButton() {
        compositeDisposable.add(
            Observable.just(true)
                .openConversation("")
                .subscribe()
        )
        compositeDisposable.dispose()
        compositeDisposable.clear()

        //getViewInterface()?.finish()
        getViewInterface()?.finish()
    }

    fun onTapGoToHistoryDialogsButton(startedFromNotification: Boolean) {
        compositeDisposable.dispose()
        compositeDisposable.clear()

        compositeDisposable.add(
            Observable.just(true)
                //.openConversation("")
                .getSettings()
                .take(1)
                .subscribe({ settings ->
                    val intent = Intent(getViewInterface()?.getCurrentContext(), SdkContainerActivity::class.java)

                    if (settings != null) {
                        intent.putExtra(
                            SdkContainerActivity.APP_COLOR,
                            Color.parseColor("#" + settings.appColor)
                        )
                    }
                    intent.putExtra(SdkContainerActivity.STARTED_FROM_NOTIFICATION, startedFromNotification)
                    getViewInterface()?.getCurrentContext()?.startActivity(intent)
                    compositeDisposable.dispose()
                    compositeDisposable.clear()
                    getViewInterface()?.finish()
                }, { t ->
                    Log.e(tag, t)
                })
        )
    }

    fun onTabToBottomScroll() {
        getViewInterface()?.toBottomScroll()
    }


    override fun onTapMessage(context: Context, messageId: String) {
        context.startActivity(MessageActionsBottomSheetActivity.intentForMessage(context, messageId))
    }

    override fun onTapImage(url: String) {
        val strFakeStart =
            getViewInterface()?.getCurrentContext()?.resources?.getString(R.string.fake_start_uri_for_image)
                ?: ""
        val trueUrl = when (url.contains(strFakeStart)) {
            true -> url.substring(strFakeStart.length)
            false -> url
        }

        if (db == null) {
            db = CarrotInternal.getLibComponent().sdkDataBase
        }
        val savedFile = db?.savedFileDao()?.getByURL(trueUrl)
        if (savedFile != null) {
            val fullViewImage = FullImageViewDialogFragment.newInstance(File(savedFile.localUri))
            getViewInterface()?.getSupportFragmentManager()?.let { fullViewImage.show(it, "fullViewImage") }
        } else {
            val fullViewImage = FullImageViewDialogFragment.newInstance(trueUrl)
            getViewInterface()?.getSupportFragmentManager()?.let { fullViewImage.show(it, "fullViewImage") }
        }
    }

    override fun onTapErrorSendingMessage(context: Context, messageId: String) {
        context.startActivity(MessageActionsBottomSheetActivity.intentForError(context, messageId))
    }

    override fun cancelDownloadFile(messageId: String, attachmentId: String) {
        DownloadManager.cancelDownloading(messageId)

        val params = HashMap<String, String>()
        params[ResponseFields.STATUS] = ""
        params[ResponseFields.ATTACHMENT_ID] = attachmentId
        val strParams = JsonUtil.createJsonParams(params)
        val jsUpdateMessageAttachment =
            "javascript:window.webView.updateMessageAttachment(\"$messageId\", $strParams)"
        getViewInterface()?.updateMessage(jsUpdateMessageAttachment)
    }

    override fun openAttachFile(messageId: String, attachmentId: String) {
        isOpenPicker = true


        val attachment = getAttachment(messageId, attachmentId)
        if(attachment == null) {
//            compositeDisposable.add(
//                Observable.just(true)
//                    .getConversation(viewModel.getCurrentConversationId())
//                    .take(1)
//                    .filter { x -> x.value != null }
//                    .map { x -> x.value!! }
//                    .getMessages().subscribe())


            return
        }

        val db = CarrotInternal.getLibComponent().sdkDataBase

        val strFakeStart =
            getViewInterface()?.getCurrentContext()?.resources?.getString(R.string.fake_start_uri_for_image)
                ?: ""
        val url =
            if (strFakeStart.isNotEmpty() && attachment.url.contains(
                    strFakeStart
                )
            ) {
                attachment.url.replace(strFakeStart, "")
            } else {
                attachment.url
            }

        val savedFile = db.savedFileDao().getByURL(url)
            ?: return


//                    val file = File(savedFile.localUri)
//                    if (!file.exists()) {
//                        getViewInterface()?.showErrorFileNotFound()
//                        onStartDownloadFile(messageId, attachmentId)
//                        return@subscribe
//                    }
//
//                    val myMime = MimeTypeMap.getSingleton()
//                    val mimeType = myMime.getMimeTypeFromExtension(fileExt(savedFile.localUri))
//
//
//                    if (file.exists()) {
//                        val newIntent = Intent(Intent.ACTION_VIEW)
//                        newIntent.flags = Intent.FLAG_ACTIVITY_NO_HISTORY
//                        newIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
//                        val builder = StrictMode.VmPolicy.Builder()
//                        StrictMode.setVmPolicy(builder.build())
//                        newIntent.setDataAndTypeAndNormalize(Uri.fromFile(file), mimeType)
//                        try {
//                            getViewInterface()?.startActivity(
//                                Intent.createChooser(
//                                    newIntent, ""
//                                )
//                            )
//                        } catch (e: ActivityNotFoundException) {
//                            Log.e(TAG, e.toString())
//                        }
        //}


        val filePath = savedFile.localUri
        val file = File(filePath)

        // 1. Проверяем, существует ли файл
        if (!file.exists()) {
            Log.e("CarrotSDK", "Файл не найден по пути: $filePath")
            // Тут можно показать тост или коллбек об ошибке
            return
        }

        // 2. Определяем MIME-тип (чтобы система знала, PDF это или картинка)
        val extension = MimeTypeMap.getFileExtensionFromUrl(filePath)
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension.lowercase())
            ?: "*/*" // Фолбек, если тип не определен

        try {
            // 3. Генерируем безопасный URI через FileProvider
            // Важно: authority должна совпадать с тем, что в манифесте!
            val ctx = getViewInterface()?.getCurrentContext() ?: return
            val authority = "${ctx.packageName}.io.carrotquest_sdk.android.GenericFileProvider"
            val contentUri: Uri = FileProvider.getUriForFile(
                ctx,
                authority,
                file
            )

            // 4. Создаем Intent на открытие
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, mimeType)
                // Эти флаги обязательны: они дают временный доступ чужому приложению к этому файлу
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NO_HISTORY
            }

            // 5. Запускаем через chooser (красивее и надежнее)
            val chooser = Intent.createChooser(intent, "Открыть файл")
            // Флаг NEW_TASK нужен, если вы запускаете это не из Activity, а из контекста Application
            // Если запускаете из Activity, можно убрать, но для SDK безопаснее оставить
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

            getViewInterface()?.getCurrentContext()?.startActivity(chooser)

        } catch (e: IllegalArgumentException) {
            // Это случится, если путь к файлу не описан в file_paths.xml
            Log.e("CarrotSDK", "Путь к файлу не настроен в FileProvider: $filePath: ${e.toString()}")
        } catch (e: Exception) {
            Log.e("CarrotSDK", "Не удалось открыть файл: ${e.toString()}")
        }



//                        val intent = Intent(Intent.ACTION_VIEW)
//                        val fileMimeType = attachment?.mimeType
//                        val fileURI = FileProvider.getUriForFile(getView()!!, getViewInterface()?.packageName + ".provider", file)
//                        intent.setDataAndType(fileURI, fileMimeType)
//                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
//                        try {
//                            getViewInterface()?.startActivity(intent)
//                        } catch (e: java.lang.Exception) {
//                            getViewInterface()?.showErrorFileNotFound()
//                            onStartDownloadFile(messageId)
//                        }
    }

    private fun updateVisual(messageId: String, attachmentId: String, status: String) {
        val params = HashMap<String, String>()
        params[ResponseFields.STATUS] = status
        params[ResponseFields.ATTACHMENT_ID] = attachmentId
        val strParams = JsonUtil.createJsonParams(params)
        val jsUpdateMessageAttachment =
            "javascript:window.webView.updateMessageAttachment(\"$messageId\", $strParams)"
        getViewInterface()?.updateMessage(jsUpdateMessageAttachment)
    }

    override fun onStartDownloadFile(messageId: String, attachmentId: String) {
        //Обновляем визуал в webView
        updateVisual(messageId, attachmentId, "loading")

        compositeDisposable.add(Observable.just("").downloadFileUseCase(messageId, attachmentId).subscribe(
            Consumer {
                //Обновляем визуал в webView
                updateVisual(messageId, attachmentId, "loaded")
            }, Consumer {
                //Обновляем визуал в webView
                updateVisual(messageId, attachmentId, "error")
            }))
    }

    override fun paginationMessages() {
        if (!isPagination) {
            isPagination = true
            compositeDisposable.add(Observable.just(true)
                .getConversation(viewModel.getCurrentConversationId())
                .map { x -> x.value!! }
                .paginationMessages()
                .observeOn(AndroidSchedulers.mainThread())
                .take(1)
                .subscribe({
                    isPagination = false
                }, {
                    getViewInterface()?.showErrorSomething()
                    isPagination = false
                })
            )
        }
    }

    override fun setContactDetails(messageId: String, type: String, value: String) {
        compositeDisposable.add(Observable.just(true)
            .getMessage(messageId)
            .map { x ->
                x.value!!.id
            }
            .updateAutoReplayLoading(false)
            .getCurrentUser()
            .map { x ->
                x.id
            }
            .setUserProperty(type, value)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .take(1)
            .subscribe({ res ->
                compositeDisposable.add(Observable.just(messageId)
                    .updateAutoReplay(messageId, res)
                    .doOnNext {
                        val stringUpdate =
                            "javascript:window.webView.updateMessageInputStatus(\"$messageId\", [{\"replied\":$res}, {\"loading\":false}])"
                        getViewInterface()?.updateMessage(stringUpdate)
                    }
                    .getMessage(messageId)
                    .doOnNext { mOpt ->
                        if (mOpt.value != null) {
                            val message = mOpt.value
                            if (message.messageMetaData != null) {
                                val meta = message.messageMetaData
                                meta?.replied = res
                                meta?.loading = false
                                message.messageMetaData = meta
                                compositeDisposable.add(
                                    Observable.just(messageId)
                                        .updateAutoReplayLocal(message)
                                        .take(1)
                                        .subscribe()
                                )

                            }
                        }
                    }
                    .observeOn(AndroidSchedulers.mainThread())
                    .take(1)
                    .subscribe())
            }, {
                compositeDisposable.add(Observable.just(messageId)
                    .getMessage(messageId)
                    .doOnNext {
                        compositeDisposable.add(
                            Observable.just(it.value?.id!!)
                                .updateStatusMessage(
                                    it,
                                    MessageStatus.WARNING.name.lowercase(Locale.getDefault())
                                )
                                .subscribe()
                        )
                    }
                    .take(1)
                    .subscribe())
            })
        )
    }

    override fun sendVote(messageId: String, vote: Int) {
        compositeDisposable.add(Observable.just(true)
            .doOnNext {
                val stringUpdate =
                    "javascript:window.webView.updateMessageInputStatus(\"$messageId\", [{\"loading\":true}])"
                getViewInterface()?.updateMessage(stringUpdate)
            }
            .sendVoteOperator(messageId, vote)
            .take(1)
            .subscribe({ res ->
                if (res) {
                    compositeDisposable.add(
                        Observable.just(true)
                            .doneVoting(messageId, vote)
                            .subscribe({
                                if (vote == 5) {
                                    val stringUpdate =
                                        "javascript:window.webView.updateMessageInputStatus(\"$messageId\", [{\"loading\":false}, {\"vote\":$vote}])"
                                    getViewInterface()?.updateMessage(stringUpdate)

                                    compositeDisposable.add(Observable.just(true)
                                        .getMessage(messageId)
                                        .subscribe { messageOpt ->
                                            if (messageOpt.value != null) {
                                                val message = messageOpt.value
                                                val jsUpdateMessage =
                                                    "javascript:window.webView.updateMessageObject(${message.sourceJsonData.toString()})"
                                                getViewInterface()?.updateMessage(jsUpdateMessage)
                                            }
                                        }
                                    )
                                } else {
                                    val stringUpdate =
                                        "javascript:window.webView.updateMessageInputStatus(\"$messageId\", [{\"loading\":false}])"
                                    getViewInterface()?.updateMessage(stringUpdate)
                                }
                            }, { t ->
                                Log.e(tag, t)
                            })
                    )
                } else {
                    compositeDisposable.add(
                        Observable.just(true)
                            .wrongVoting(messageId)
                            .subscribe()
                    )
                }
            }, {
                compositeDisposable.add(
                    Observable.just(true)
                        .wrongVoting(messageId)
                        .subscribe()
                )
            })
        )
    }

    override fun sendCommentVote(messageId: String, vote: Int, comment: String) {
        compositeDisposable.add(Observable.just(true)
            .doOnNext {
                val stringUpdate =
                    "javascript:window.webView.updateMessageInputStatus(\"$messageId\", [{\"loading\":true}])"
                getViewInterface()?.updateMessage(stringUpdate)
            }
            .sendVoteOperator(messageId, vote, comment)
            .take(1)
            .subscribe({ res ->
                if (res) {
                    compositeDisposable.add(Observable.just(true)
                        .doOnNext {
                            val stringUpdate =
                                "javascript:window.webView.updateMessageInputStatus(\"$messageId\", [{\"loading\":false}, {\"vote\":$vote}])"
                            getViewInterface()?.updateMessage(stringUpdate)
                        }
                        .doneVotingComment(messageId, vote)
                        .doOnNext {
                            compositeDisposable.add(Observable.just(true)
                                .getMessage(messageId)
                                .subscribe { messageOpt ->
                                    if (messageOpt.value != null) {
                                        val message = messageOpt.value
                                        val jsUpdateMessage =
                                            "javascript:window.webView.updateMessageObject(${message.sourceJsonData.toString()})"
                                        getViewInterface()?.updateMessage(jsUpdateMessage)
                                    }
                                }
                            )
                        }
                        .subscribe())
                } else {
                    compositeDisposable.add(
                        Observable.just(true)
                            .wrongVoting(messageId)
                            .subscribe()
                    )
                }
            }, {
                compositeDisposable.add(
                    Observable.just(true)
                        .wrongVoting(messageId)
                        .subscribe()
                )
            })
        )
    }

    override fun onGoToLink(link: String, context: Context) {
        if (viewModel.getCurrentConversationId().isNotEmpty()
            && viewModel.getCurrentConversationId() != "last_conversation"
        ) {
            trackClick(viewModel.getCurrentConversationId(), object : CarrotSDK.Callback<Boolean> {
                override fun onResponse(result: Boolean?) {
                }

                override fun onFailure(t: Throwable?) {
                }
            })
        }
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(link)
        context.startActivity(intent)
    }

    override fun onTapCalendlyButton(joinUrl: String, utm: String?, context: Context) {
        compositeDisposable.add(
            Observable.just(true)
                .openConversation("")
                .getSettings()
                .take(1)
                .subscribe({ settings ->
                    val intent = Intent(context, CalendlyWidgetActivity::class.java)
                    intent.putExtra(CalendlyWidgetActivity.JOIN_URL_ARG, joinUrl)
                    intent.putExtra(CalendlyWidgetActivity.UTM_ARG, utm)
                    if (settings != null) {
                        intent.putExtra(
                            CalendlyWidgetActivity.APP_COLOR,
                            Color.parseColor("#" + settings.appColor)
                        )
                    } else {
                        intent.putExtra(
                            CalendlyWidgetActivity.APP_COLOR,
                            Color.parseColor("#000000")
                        )
                    }
                    context.startActivity(intent)
                }, { error ->
                    Log.e(tag, error.toString())
                })
        )
    }

    fun onResume() {
        val conversationId = viewModel.getCurrentConversationId()
        updateOpenedConversationId(conversationId)

        compositeDisposable.add(Observable.just(1)
            .delay(1, TimeUnit.SECONDS)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.io())
            .take(1)
            .subscribe {
                val context = getViewInterface()?.getCurrentContext()
                val lastLoadTime = if(context != null) {
                    SharedPreferencesLib.getLong(context, "last_load_messages_time_key")
                } else {
                    0
                }

                val needHard = if(lastLoadTime == 0L) {
                    true
                } else {
                    val currentTime = Date()
                    val afterTenMinutes = currentTime.after(Date(lastLoadTime + (10 * 60 * 1000 )))
                    afterTenMinutes
                }
                if(!isOpenPicker) {
                    loadMessages(needHardUpdate = needHard)
                } else {
                    isOpenPicker = false
                }
            })
    }

    fun onPause() {
        removeTypingIndicator()
        updateOpenedConversationId("")
    }

    override fun onTapZoomMeetingButton(joinUrl: String, context: Context) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(joinUrl)
        context.startActivity(intent)
    }

    private var selectBotBrunchInProcess = false
    override fun onSelectBotBrunch(
        messageId: String,
        branchId: String,
        branchLinkId: String,
        answerBody: String,
        href: String,
        context: Context
    ) {
        if(selectBotBrunchInProcess) {
            return
        }

        selectBotBrunchInProcess = true
        if (viewModel.needStartRoutingBot()) {
            val botId = viewModel.getRoutingBotId()

            val convId = viewModel.getCurrentConversationId().ifEmpty { null }
            val randomId = if (convId.isNullOrEmpty()) {
                val tempRandomId = "routing_${System.currentTimeMillis() / 1000}"
                tempRandomId
            } else {
                convId
            }

            updateOpenedConversationId(randomId)
            viewModel.updateCurrentConversationId(randomId)

            compositeDisposable.add(Observable.just(messageId)
                .startRoutingBot(botId, branchId, answerBody, randomId, convId).subscribe(
                    {
                        viewModel.setNeedStartRoutingBot(false)

                        compositeDisposable.add(Observable.just(true)
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribeOn(Schedulers.io())
                            .delay(1, TimeUnit.SECONDS)
                            .take(1)
                            .subscribe {
                                selectBotBrunchInProcess = false
                            })

                    }, { t ->
                        Log.e(TAG, t)

                        selectBotBrunchInProcess = false
                    })
            )
        } else {
            compositeDisposable.add(
                Observable.just(messageId)
                    .getMessage(messageId)
                    .take(1)
                    .subscribe({ x ->
                        run {
                            val mess = x.value
                            if (mess != null) {
                                if (mess.messageMetaData.answerActionId == null) {
                                    compositeDisposable.add(
                                        Observable.just(true)
                                            .selectBotBrunch(messageId, branchId, answerBody)
                                            .subscribe({ isSuccessful ->
                                                selectBotBrunchInProcess = false
                                                if (!isSuccessful) {
                                                    //updateBotButtons(mess, null, null)
                                                }
                                            }, { error ->
                                                Log.e(tag, error.toString())
                                                selectBotBrunchInProcess = false
                                            })
                                    )
                                } else {
                                    selectBotBrunchInProcess = false
                                }
                            } else {
                                compositeDisposable.add(
                                    Observable.just(true)
                                        .selectBotBrunch(messageId, branchId, answerBody)
                                        .subscribe({ isSuccessful ->
                                            selectBotBrunchInProcess = false
                                            if (!isSuccessful) {
                                                //updateBotButtons(mess, null, null)
                                            }
                                        }, { error ->
                                            Log.e(tag, error.toString())
                                            getViewInterface()?.showErrorSomething()
                                            selectBotBrunchInProcess = false
                                        })
                                )
                            }
                        }
                    }, {
                        Log.e(tag, it.toString())
                        selectBotBrunchInProcess = false
                    })
            )
        }

        if (href != null && href.isNotEmpty() && href.lowercase() != "undefined") {
            try {
                val decodedUrl = URLDecoder.decode(href, "UTF-8")
                onGoToLink(decodedUrl, context)
            } catch (e: UnsupportedEncodingException) {
                //e.printStackTrace()
            }
        }
    }

    override fun onShowBotInput(
        messageId: String,
        branchId: String,
        branchLinkId: String,
        answerBody: String,
        context: Context
    ) {
        currentInputMod = InputMod.BOT_INPUT
        val action = ActionMessage()
        action.messageId = messageId
        action.body = answerBody
        action.id = branchId

        currentAction = action
        getViewInterface()?.showInput(viewModel.getCurrentConversationId())
//        val hint = if (currentAction == null || currentAction?.body.isNullOrEmpty()) {
//            CarrotInternal.getLibComponent().contextSdk.getString(R.string.bot_answer_hint)
//        } else {
//            currentAction?.body
//        }
        //getViewInterface()?.updateHint(hint)
        getViewInterface()?.showSendButton()
    }

    override fun allowDataProcessing() {
        allowDataProcessingUseCase()
    }

    override fun allowTrackContacts(dataJson: String, replyId: String) {
        val jsData = Gson().fromJson(dataJson, JsonObject::class.java)
        val email = if (jsData.has("email")) {
            jsData.get("email").asString
        } else {
            null
        }

        val phone = if (jsData.has("phone")) {
            jsData.get("phone").asString
        } else {
            null
        }

        val contacts = TrackContacts(
            email = email,
            phone = phone
        )

        allowTrackContactsUseCase(contacts, replyId)
    }

    private fun updateBotButtons(message: MessageData, branchId: String?, answerBody: String?) {
        val metaData =
            if (message.messageMetaData != null) message.messageMetaData else MessageMetaData()
        //metaData.answerTime = System.currentTimeMillis() / 1000
        metaData.answerActionId = branchId
        metaData.answerBody = answerBody
        message.messageMetaData = metaData

        val jsonSource =
            if (message.sourceJsonData != null) message.sourceJsonData else JSONObject()
        jsonSource.remove(F.META_DATA)
        jsonSource.put(F.META_DATA, JSONObject(Gson().toJson(metaData)))
        message.sourceJsonData = jsonSource

        MessagesRepository.getInstance().updateMessage(message)
    }

    private fun updateBotAnswerTime(message: MessageData) {
        val metaData = message.messageMetaData
        metaData.answerTime = System.currentTimeMillis() / 1000
        message.messageMetaData = metaData

        val jsonSource = message.sourceJsonData
        jsonSource.remove(F.META_DATA)
        jsonSource.put(F.META_DATA, JSONObject(Gson().toJson(metaData)))
        message.sourceJsonData = jsonSource

        MessagesRepository.getInstance().updateMessage(message)
    }

    fun onDownloadFile(messageId: String, attachmentId: String) {
        val startParams = HashMap<String, String>()
        startParams[ResponseFields.STATUS] = "0"
        startParams[ResponseFields.ATTACHMENT_ID] = attachmentId
        val strStartParams = JsonUtil.createJsonParams(startParams)
        val jsUpdateStartMessageAttachment =
            "javascript:window.webView.updateMessageAttachment(\"$messageId\", $strStartParams)"
        getViewInterface()?.updateMessage(jsUpdateStartMessageAttachment)

        try {
            compositeDisposable.add(
                Observable.just(true)
                .getMessage(messageId)
                .take(1)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnError {
                    Log.e(tag, it)
                }
                .subscribe({
                    if (it.value != null) {
                        val message = it.value
                        if (message.attachments == null || (message.attachments
                                ?: ArrayList()).isEmpty()
                        ) {
                            downloadErrorToRlk("Download file error: message.attachments is empty. mId = $messageId. m.atts = ${message.attachments}")
                            return@subscribe
                        }

                        val attachment =
                            message.attachments?.firstOrNull { a -> a.id == attachmentId }
                        if (attachment == null) {
                            return@subscribe
                        }

                        CarrotInternal.getService().downloadFile(
                            messageId,
                            attachment.url,
                            attachment.size,
                            object : DisposableObserver<Int>() {
                                override fun onNext(progress: Int) {
                                    updateProgressDownloadFile(
                                        messageId,
                                        attachmentId,
                                        progress
                                    )
                                }

                                override fun onError(e: Throwable) {
                                    Log.e(tag, e.toString())
                                    downloadErrorToRlk("Download file error: onError. $e")

                                    val params = HashMap<String, String>()
                                    params[ResponseFields.STATUS] = ""
                                    params[ResponseFields.ATTACHMENT_ID] = attachmentId
                                    val strParams = JsonUtil.createJsonParams(params)
                                    val jsUpdateMessageAttachment =
                                        "javascript:window.webView.updateMessageAttachment(\"$messageId\", $strParams)"
                                    getViewInterface()?.updateMessage(jsUpdateMessageAttachment)

                                }

                                override fun onComplete() {

                                }
                            })

                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        initDoneConversationSubscribes()
                    }
                }, { t ->
                    getViewInterface()?.showErrorFileNotFound()
                    onStartDownloadFile(messageId, attachmentId)
                    Log.e(tag, t)
                    downloadErrorToRlk("Download file error (1449): $t")
                })
            )
        } catch (e: Exception) {
            getViewInterface()?.showErrorFileNotFound()
            onStartDownloadFile(messageId, attachmentId)
            downloadErrorToRlk("Download file error (1454): $e")
        }
    }

    private fun downloadErrorToRlk(message: String) {
        compositeDisposable.add(
            Observable.just(true)
                .getSettings()
                .take(1)
                .subscribe({ settings ->
                    LogToElk.getInstance().write(
                        settings?.appId ?: "",
                        message,
                        MessageToElkType.RTS_MESSAGE,
                        HashMap()
                    )
                }, {})
        )
    }

    private fun updateProgressDownloadFile(messageId: String, attachmentId: String, progress: Int) {
        val params = HashMap<String, String>()
        params[ResponseFields.ATTACHMENT_ID] = attachmentId
        if (progress == 100) {
            params[ResponseFields.STATUS] =
                MessageStatus.LOADED.name.lowercase(Locale.getDefault())

            //Костыль
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                initDoneConversationSubscribes()
            }

        } else {
            params[ResponseFields.STATUS] = progress.toString()
        }

        val strParams = JsonUtil.createJsonParams(params)
        val jsUpdateMessageAttachment =
            "javascript:window.webView.updateMessageAttachment(\"$messageId\", $strParams)"
        getViewInterface()?.updateMessage(jsUpdateMessageAttachment)
    }

    private var isOpenPicker = false
    fun onOpenPicker(height: Int) {
        isOpenPicker = true
        getViewInterface()?.openFilePicker()
    }

    private fun createConversationByFile(file: File) {
        val date = (System.currentTimeMillis() / 1000).toString()
        val attachment = Attachment()
        attachment.id = date
        attachment.created = date
        attachment.filename = file.name
        attachment.size = file.length()
        val strFakeStart =
            getViewInterface()?.getCurrentContext()?.resources?.getString(R.string.fake_start_uri_for_image)
        attachment.url = strFakeStart + file.absolutePath
        attachment.type = ResponseFields.FILE_TYPE
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
            MimeTypeMap.getFileExtensionFromUrl(
                Uri.fromFile(file).toString()
            ).lowercase(Locale.getDefault())
        )
        attachment.mimeType = mimeType

        if (mimeType?.contains("image") == true) {
            attachment.type = "image"
        } else {
            attachment.type = ResponseFields.FILE_TYPE
        }

        val botId = viewModel.getRoutingBotId()
        if (botId.isNotEmpty()) {
            getViewInterface()?.deleteAllMessages("javascript:window.webView.interruptBot()")
        }

        compositeDisposable.add(
            Observable.just(true)
                .removeWelcomeMessage()
                .createMessage(attachment, "", true, MessageStatus.LOADING)
                .saveMessage()
                .take(1)
                .subscribe({ firstMessageOpt ->
                    compositeDisposable.dispose()
                    compositeDisposable = CompositeDisposable()
                    compositeDisposable.add(
                        Observable.just(true)
                            .saveMessage(firstMessageOpt)
                            .createConversation(file)
                            .take(1)
                            .subscribe({ nConversationId ->
                                if (!TextUtils.isEmpty(nConversationId)) {
                                    if (firstMessageOpt.value != null ) {//&& Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
                                        val savedFile =
                                            SavedFile(System.currentTimeMillis().toString())
                                        savedFile.localUri = file.absolutePath
                                        savedFile.url = firstMessageOpt.value.attachments[0].url
                                        if (db == null) {
                                            db = CarrotInternal.getLibComponent().sdkDataBase
                                        }
                                        db?.savedFileDao()?.insert(savedFile)
                                    }

                                    if (firstMessageOpt.value != null) {
                                        val messageData = firstMessageOpt.value
                                        val status =
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) "" else "loaded"
                                        val jsonSource =
                                            messageData.sourceJsonData
                                        if (jsonSource.has(F.ATTACHMENTS)) {
                                            val attachmentsJson =
                                                jsonSource.getJSONArray(F.ATTACHMENTS)
                                            val attJson = attachmentsJson.getJSONObject(0)
                                            attJson?.remove(F.STATUS)
                                            val status =
                                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) "" else "loaded"
                                            attJson.put(F.STATUS, status)

                                            val nAttachments = JSONArray()
                                            nAttachments.put(attJson)
                                            messageData.sourceJsonData.remove(F.ATTACHMENTS)
                                            messageData.sourceJsonData.put(
                                                F.ATTACHMENTS,
                                                nAttachments
                                            )
                                        }

                                        val jsUpdateMessage =
                                            "javascript:window.webView.updateMessageObject(${messageData.sourceJsonData.toString()})"
                                        getViewInterface()?.updateMessage(jsUpdateMessage)
                                    }

                                    viewModel.updateCurrentConversationId(nConversationId!!)
                                    compositeDisposable.add(Observable.just(nConversationId)
                                        .getConversation(nConversationId)
                                        .doOnNext {
                                            commonSubscribes()
                                        }
                                        .map { x -> x.value?.id!! }
                                        .updateStatusMessage(
                                            firstMessageOpt,
                                            MessageStatus.LOADED.name.lowercase(Locale.getDefault())
                                        )
                                        .updateConversationMessage(firstMessageOpt)
                                        .observeOn(AndroidSchedulers.mainThread())
                                        .take(1)
                                        .subscribe({
                                            getViewInterface()?.enableInput()
                                        }, {
                                            Log.e(tag, it)
                                        })
                                    )


                                } else {
                                    getViewInterface()?.showErrorSomething()
                                }
                            }, {
                                Log.e(tag, it)
                                getViewInterface()?.showErrorSomething()
                            })
                    )


                }, { t ->
                    Log.e(tag, t)
                })
        )
    }

    private fun isCorrectPhone(text: String, typeReply: String): Boolean {
        if(selectedCountry == null || typeReply != "phone") {
            return true
        }

        val phone = if (currentInputMod == InputMod.BOT_INPUT) {
            "+${selectedCountry?.countryCode}$text"
        } else {
            text
        }

        return PhoneNumberUtil.createInstance(getViewInterface()?.getCurrentContext())
            .isPossibleNumber(phone, selectedCountry!!.region.uppercase())
    }


    fun onInputText(text: String) {
        //Отправляем на сервер событие о том, что пользователь печатает
        val conversationId = viewModel.getCurrentConversationId()
        if (conversationId.isNotEmpty()) {
            CarrotInternal.getService().setTyping(conversationId, text)
        }

        saveDraftMessageUseCase(text, conversationId)

        compositeDisposable.add(Observable.just(1)
            .getConversation(viewModel.getCurrentConversationId())
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .take(1)
            .subscribe {
                val conversation = it.value
                val phoneIsCorrect = if (conversation != null && conversation.partLast != null && conversation.partLast.replyType != null) {
                    isCorrectPhone(text.trim(), conversation.partLast.replyType)
                } else {
                    true
                }

                if (!TextUtils.isEmpty(text.trim()) && phoneIsCorrect) {
                    getViewInterface()?.hideAttachFileButton()
                    getViewInterface()?.enableSendButton()
                    getViewInterface()?.showSendButton()
                } else {
                    if (currentInputMod == InputMod.BOT_INPUT) {
                        getViewInterface()?.disableSendButton()
                        getViewInterface()?.showSendButton()
                        getViewInterface()?.hideAttachFileButton()
                    } else {
                        getViewInterface()?.disableSendButton()
                        getViewInterface()?.showAttachFileButton()
                    }
                }
            }
        )
    }

    private var currentInputMod = InputMod.NORMAL
    private var currentAction: ActionMessage? = null

    fun onTapSendMessage(textMessage: String) {
        val conversationId = viewModel.getCurrentConversationId()
        if (currentInputMod == InputMod.BOT_INPUT && currentAction != null) {
            sendActionBot(currentAction!!, textMessage)
            currentInputMod = InputMod.NORMAL
        } else {
            if (!TextUtils.isEmpty(conversationId)) {
                sendNormalMessage(textMessage, conversationId)
            } else {
                createConversation(textMessage)
            }
        }

        collapseHeader()
    }

    fun onTapPhonePrefix(context: AppCompatActivity) {
        selectRegionLauncher?.launch("")
    }

    fun onChangeConversationId(conversationId: String) {
        viewModel.updateCurrentConversationId(conversationId)
        currentAction = null
        currentInputMod = InputMod.NORMAL
    }

    fun onChangeErrorStateWebView(isError: Boolean?) {
        when (isError) {
            true -> getViewInterface()?.disableInput()
            else -> {getViewInterface()?.enableInput()}
        }
    }

    fun onViewKeyboardShow(oldHeight: Int, newHeight: Int, barsHeight: Int) {
        val oldHeightN = oldHeight - barsHeight
        val newHeightN = newHeight - barsHeight
        val jsOnKeyboardShow = "javascript:window.webView.onKeyboardShow($oldHeightN, $newHeightN)"
        getViewInterface()?.scrollWebView(jsOnKeyboardShow)
    }

    fun onViewKeyboardHide(oldHeight: Int, newHeight: Int, barsHeight: Int) {
        val oldHeightN = oldHeight - barsHeight
        val newHeightN = newHeight - barsHeight
        val jsOnKeyboardHide = "javascript:window.webView.onKeyboardHide($oldHeightN, $newHeightN)"
        getViewInterface()?.scrollWebView(jsOnKeyboardHide)
    }

    fun onBackPressed(startedFromNotification: Boolean) {
        compositeDisposable.add(
            Observable.just(true)
                .openConversation("")
                .subscribe()
        )
        compositeDisposable.dispose()
        compositeDisposable.clear()

        if (startedFromNotification) {
            getViewInterface()?.goToParentActivity()
        } else {
            getViewInterface()?.finish()
        }
    }

    fun onScrollDialog(offsetY: Float, scrollY: Int) {
        if (offsetY > 200) {
            getViewInterface()?.showToBottomButton()
            if (viewModel.getCurrentStateAppBar() == StateAppBar.EXPANDED) {
                collapseHeader()
            }
        }
        if (offsetY < 200) {
            getViewInterface()?.hideToBottomButton()
        }

        when (scrollY) {
            0 -> getViewInterface()?.updateElevationHeader(0.0f)
            else -> getViewInterface()?.updateElevationHeader(16.0f)
        }
    }

    private fun sendActionBot(action: ActionMessage, answer: String) {
        fun upMessage(message: MessageData): MessageData {
            message.status =
                MessageStatus.LOADED.name.lowercase()
            val jsonSource = message.sourceJsonData
            if (jsonSource.has(F.STATUS)) {
                jsonSource.remove(F.STATUS)
            }
            jsonSource.put(
                F.STATUS,
                MessageStatus.LOADED.name.lowercase()
            )

            message.sourceJsonData = jsonSource
            MessagesRepository.getInstance().updateMessage(message)

            viewModel.getRoutingBotId()

            return message
        }

        compositeDisposable.add(Observable.just(1)
            .getConversation(viewModel.getCurrentConversationId())
            .take(1)
            .subscribe {
                val conversation = it.value
                if (conversation != null) {
                    val trueAnswer =
                        if (selectedCountry != null && conversation.partLast.replyType == "phone") {
                            "+${selectedCountry?.countryCode}$answer"
                        } else {
                            answer
                        }
                    //selectedCountry = null

                    clearDraftMessageUseCase(viewModel.getCurrentConversationId())
                    getViewInterface()?.clearInput()
                    getViewInterface()?.toBottomScroll()

                    compositeDisposable.add(
                        Observable.just(true)
                            .createMessage(
                                trueAnswer,
                                viewModel.getCurrentConversationId(),
                                isFirst = false,
                                status = MessageStatus.LOADING
                            )
                            .take(1)
                            .doOnNext {
                                val message = it.value
                                if (message != null) {
                                    val messagesArray = JSONArray()

                                    val messageJson = message.sourceJsonData
                                    if (messageJson.has(F.CREATED)) {
                                        messageJson.remove(F.CREATED)
                                        messageJson.put(
                                            F.CREATED,
                                            ((System.currentTimeMillis() / 1000) - 2).toString()
                                        )
                                    }

                                    if (viewModel.getCurrentConversationId() == message.conversation) {
                                        messagesArray.put(messageJson)
                                    }

                                    if (!addedMessages.contains(message.id)) {
                                        addedMessages.add(message.id)
                                        addedMessages.add(message.randomId)

                                        val arrayStr = messagesArray.toString()
                                        val jsScript =
                                            "javascript:window.webView.addMessages(${arrayStr})"
                                        //getViewInterface()?.showMessage(jsScript)
                                    }

                                    if (viewModel.needStartRoutingBot()) {
                                        val botId = viewModel.getRoutingBotId()
                                        val randomId =
                                            "routing_${System.currentTimeMillis() / 1000}"
                                        viewModel.updateCurrentConversationId(randomId)
                                        val convId = viewModel.getCurrentConversationId()
                                            .ifEmpty { null }
                                        compositeDisposable.add(Observable.just(action.messageId)
                                            .startRoutingBot(
                                                botId,
                                                action.id,
                                                action.body,
                                                randomId,
                                                convId
                                            ).subscribe(
                                                {
                                                    viewModel.setNeedStartRoutingBot(false)
                                                    val jsonSource = message.sourceJsonData
                                                    if (jsonSource.has(F.CREATED)) {
                                                        jsonSource.remove(F.CREATED)
                                                    }
                                                    message.sourceJsonData = jsonSource
                                                    val updatedMessage = upMessage(message)

                                                    val jsUpdateMessage =
                                                        "javascript:window.webView.updateMessageObject(${updatedMessage.sourceJsonData})"
                                                    getViewInterface()?.updateMessage(jsUpdateMessage)
                                                }, { t ->
                                                    Log.e(TAG, t)
                                                })
                                        )
                                    } else {
                                        compositeDisposable.add(
                                            Observable.just(true)
                                                .selectBotBrunch(
                                                    action.messageId,
                                                    action.id,
                                                    trueAnswer
                                                )
                                                .subscribe({
                                                    upMessage(message)
                                                }, { error ->
                                                    Log.e(tag, error.toString())
                                                })
                                        )
                                    }
                                }
                            }
                            .subscribe()
                    )
                }
            })
    }

    private fun sendNormalMessage(textMessage: String, conversationId: String) {
        clearDraftMessageUseCase(conversationId)
        getViewInterface()?.clearInput()
        getViewInterface()?.toBottomScroll()

        //Если у нас диалог с бототм и пользователь его прерывает, то надо удалить сообщения
        val botId = viewModel.getRoutingBotId()
        if (botId.isNotEmpty()) {
            getViewInterface()?.deleteAllMessages("javascript:window.webView.interruptBot()")
        }

        compositeDisposable.add(
            Observable.just(true)
                .createMessage(textMessage, viewModel.getCurrentConversationId())
                .map { x -> x.value!! }
                .sendMessage()
                .take(1)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({
                    getViewInterface()?.enableInput()

                    compositeDisposable.add(
                        Observable.just(true)
                            .getConversation(conversationId)
                            .take(1)
                            .filter { x -> x.value != null }
                            .map { x -> x.value!! }
                            .getMessages()
                            .onErrorReturn { Optional(null) }
                            .take(1)
                            .filter { m -> m.value != null }
                            .map { m -> m.value!! }
                            .subscribe({ messages ->
                                for (message in messages.data) {
                                    MessagesRepository.getInstance()
                                        .removeExpirationMessage(messageId = message.id)
                                }
                            }, { t ->
                                Log.e(tag, t)
                            })
                    )

                }, { t ->
                    Log.e(tag, t)
                    getViewInterface()?.enableInput()
                    getViewInterface()?.showErrorSendMessage()
                })
        )
    }

    private fun createConversation(textMessage: String) {
        clearDraftMessageUseCase("")
        getViewInterface()?.clearInput()
        getViewInterface()?.toBottomScroll()

        //Если у нас диалог с ботом и пользователь его прерывает, то надо удалить сообщения
        val botId = viewModel.getRoutingBotId()
        if (botId.isNotEmpty()) {
            getViewInterface()?.deleteAllMessages("javascript:window.webView.interruptBot()")
        }

        compositeDisposable.add(
            Observable.just(true)
                .removeWelcomeMessage()
                .createMessage(textMessage, "", true, MessageStatus.LOADING)
                .saveMessage()
                .take(1)
                .subscribe({ firstMessageOpt ->
                    compositeDisposable.dispose()
                    compositeDisposable = CompositeDisposable()
                    compositeDisposable.add(
                        Observable.just(true)
                            .createConversation(textMessage)
                            .take(1)
                            .subscribe({ nConversationId ->
                                if (!TextUtils.isEmpty(nConversationId)) {
                                    viewModel.updateCurrentConversationId(nConversationId!!)
                                    compositeDisposable.add(Observable.just(nConversationId)
                                        .getConversation(nConversationId)
                                        .doOnNext {
                                            commonSubscribes()
                                        }
                                        .map { x -> x.value?.id!! }
                                        .updateStatusMessage(
                                            firstMessageOpt,
                                            MessageStatus.LOADED.name.lowercase(Locale.getDefault())
                                        )
                                        .updateConversationMessage(firstMessageOpt)
                                        .observeOn(AndroidSchedulers.mainThread())
                                        .take(1)
                                        .subscribe({
                                            //commonSubscribes()
                                            getViewInterface()?.enableInput()
                                        }, {
                                            Log.e(tag, it.message)
                                        })
                                    )


                                } else {
                                    getViewInterface()?.showErrorSomething()
                                }
                            }, {
                                getViewInterface()?.showErrorSomething()
                            })
                    )


                }, { t ->
                    Log.e(tag, t)
                })
        )
    }

    private fun updateStatusOperators(settings: SettingsEntity) {
        when (settings.statusOperators) {
            StatusOperators.ONLINE -> {
                if (viewModel.getCurrentStateAppBar() == StateAppBar.COLLAPSED) {
                    getViewInterface()?.updateStatusCollapsedAppBar(true)
                } else {
                    getViewInterface()?.updateAppDescription(
                        settings.onlineMessage
                            ?: "", true
                    )
                }
            }

            StatusOperators.OFFLINE -> {
                if (viewModel.getCurrentStateAppBar() == StateAppBar.COLLAPSED) {
                    getViewInterface()?.updateStatusCollapsedAppBar(false)
                } else {
                    getViewInterface()?.updateAppDescription(
                        settings.offlineMessage
                            ?: "", false
                    )
                }
            }

            else -> {
                if (viewModel.getCurrentStateAppBar() == StateAppBar.COLLAPSED) {
                    getViewInterface()?.updateStatusCollapsedAppBar(false)
                } else {
                    getViewInterface()?.updateAppDescription("", false)
                }
            }
        }
    }

    private fun updateHeader(admin: Admin?) {
        if (currentAdmin?.id != admin?.id || admin == null || currentAdmin == null || currentAdmin?.avatar != admin.avatar) {
            val baseId = 1000
            currentAdmin = admin

            if (admin?.avatar != null && admin.type != "default_admin") {

                getViewInterface()?.updateAdminName(
                    admin.name
                        ?: "", viewModel.getCurrentStateAppBar() == StateAppBar.EXPANDED
                )
                if (viewModel.getCurrentStateAppBar() == StateAppBar.COLLAPSED) {
                    compositeDisposable.add(Observable.just(true)
                        .getSettings()
                        .observeOn(AndroidSchedulers.mainThread())
                        .take(1)
                        .subscribe(
                            { settings ->
                                if (settings?.appColor != null && settings.appColor.isNotEmpty()) {
//                                    val color = ("#" + settings.appColor).toColorInt()
//                                    getViewInterface()?.updateAppColor(color)
                                    val color = AppColorUtils.getCorrectAccentColor(CarrotInternal.getLibComponent().contextSdk, settings.originalAppColor!!)
                                    getViewInterface()?.updateAppColor(("#$color").toColorInt())
                                    updateStatusOperators(settings)
                                }
                            },
                            { error ->
                                Log.e(tag, error)
                            }
                        )
                    )
                } else {
                    compositeDisposable.add(Observable.just(true)
                        .getSettings()
                        .observeOn(AndroidSchedulers.mainThread())
                        .take(1)
                        .subscribe(
                            { settings ->
                                if (settings?.appColor != null && settings.appColor.isNotEmpty()) {
                                    val color = Color.parseColor("#" + settings.appColor)
                                    val imageView = createAdminImageView(
                                        admin.avatar!!,
                                        baseId,
                                        true,
                                        color
                                    )
                                    if (imageView != null) {
                                        val adminsAvatars = arrayOf(imageView)
                                        getViewInterface()?.updateAdminsAvatars(adminsAvatars)
                                    }
                                }
                            },
                            { error ->
                                Log.e(tag, error)
                            }
                        )
                    )
                }
            } else {
                compositeDisposable.add(
                    Observable.just(true)
                        .getSettings()
                        .take(1)
                        .subscribe({ settings ->
                            if (settings != null) {
                                val color = Color.parseColor("#" + settings.appColor)

                                getViewInterface()?.updateAdminName(
                                    settings.appName
                                        ?: "",
                                    viewModel.getCurrentStateAppBar() == StateAppBar.EXPANDED
                                )

                                val countAdmins =
                                    if (settings.admins.size > 3) 3 else settings.admins.size

                                val arr = ArrayList<ImageView>()
                                val indexes =
                                    (0 until settings.admins.size).shuffled().take(countAdmins)

                                for (x in 0 until countAdmins) {
                                    val imageView = createAdminImageView(
                                        settings.admins[indexes[x]].avatar!!,
                                        baseId + x,
                                        x == 0,
                                        color
                                    )
                                    if (imageView != null) {
                                        arr.add(imageView)
                                    }
                                }

                                getViewInterface()?.updateAdminsAvatars(Array(countAdmins) { x -> arr[x] })
                            }

                        }, {
                            Log.e(tag, it.toString())
                        })
                )
            }
        }
    }

    private fun createAdminImageView(
        avatar: String,
        viewId: Int,
        isFirst: Boolean,
        backColor: Int?
    ): ImageView? {
        if (getView() == null || getViewInterface()?.getCurrentContext() == null) {
            return null
        }

        var options = RequestOptions()
        val dp33 = GraphicUtils.dpToPx(getViewInterface()?.getCurrentContext(), 30f)
        val dp35 = GraphicUtils.dpToPx(getViewInterface()?.getCurrentContext(), 35f)
        options = options.centerCrop().transform(CircleCrop())
        options = options.override(dp33, dp33)
        options = options.placeholder(R.drawable.ic_grey_circle_placrholder)

        val imageView = ImageView(getViewInterface()?.getCurrentContext())
        imageView.id = viewId
        val params = LinearLayout.LayoutParams(dp35, dp35) as ViewGroup.MarginLayoutParams
        if (!isFirst) {
            params.setMargins(GraphicUtils.dpToPx(getViewInterface()?.getCurrentContext(), -10f), 0, 0, 0)
        }
        imageView.layoutParams = params

        if (backColor != null) {
            val shape = GradientDrawable()
            shape.shape = GradientDrawable.OVAL
            shape.setColor(backColor)
            imageView.background = shape

        } else {
            imageView.setBackgroundResource(R.drawable.cq_circle_white_bkg)
        }

        if (getViewInterface()?.getCurrentContext() != null) {
            Glide.with(getViewInterface()?.getCurrentContext()!!)
                .load(avatar)
                .apply(options)
                .into(imageView)
        }

        return imageView
    }

    private fun createAdminImageView(avatar: String, viewId: Int, isFirst: Boolean): ImageView? {
        return createAdminImageView(avatar, viewId, isFirst, null)
    }

    private fun createEmptyAdminImageView(): ImageView {
        var options = RequestOptions()
        val dp35 = GraphicUtils.dpToPx(getViewInterface()?.getCurrentContext(), 35f)
        options = options.centerCrop().transform(CircleCrop())
        options = options.override(dp35, dp35)

        val imageView = ImageView(getViewInterface()?.getCurrentContext())
        imageView.id = Random().nextInt()
        val params = LinearLayout.LayoutParams(dp35, dp35) as ViewGroup.MarginLayoutParams

        imageView.layoutParams = params
        imageView.setBackgroundResource(R.drawable.cq_circle_white_bkg)

        if (getViewInterface()?.getCurrentContext() != null) {
            Glide.with(getViewInterface()?.getCurrentContext()!!)
                .load(R.drawable.ic_grey_circle_placrholder)
                .apply(options)
                .into(imageView)
        }

        return imageView
    }

    private fun collapseHeader() {
        if (viewModel.getCurrentStateAppBar() == StateAppBar.EXPANDED) {
            compositeDisposable.add(
                Observable.just(true)
                    .getSettings()
                    .take(1)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .subscribe({ settings ->
                        viewModel.updateCurrentStateAppBar(StateAppBar.COLLAPSED)
                        if (settings != null) {
                            getViewInterface()?.collapseHeader(settings.statusOperators == StatusOperators.ONLINE)
                        } else {
                            getViewInterface()?.collapseHeader(false)
                        }
                    }, { error ->
                        Log.e(tag, error.toString())
                    })
            )
        }
    }

    private fun loadData() {
        compositeDisposable.add(Observable.just(true)
            .getLastConversation()
            .take(1)
            .subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnNext { optional ->
                if (optional != null) {
                    val conversation = optional.value
                    updateHeader(conversation?.lastAdmin)
                    if (conversation != null && conversation.id != "") {
                        onChangeConversationId(conversation.id)
                        onOpenDialog()
                    } else {
                        onOpenNewDialog()
                    }
                } else {
                    onOpenNewDialog()
                }
            }
            .doOnError {
                Log.e(tag, it)
            }
            .subscribe()
        )
    }



    private fun loadMessages(needHardUpdate: Boolean = false) {
        val context = getViewInterface()?.getCurrentContext()
        if (context != null) {
            SharedPreferencesLib.saveLong(context, "last_load_messages_time_key", Date().time)
        }

        val tokenIsActual = if(context != null) {
            isActualJwtToken(context)
        } else {
            true
        }

        if(!tokenIsActual) {
            val b = BehaviorSubject.create<String>()
            compositeDisposable.add(b
                .subscribeOn(Schedulers.io())
                .take(1)
                .subscribe({ token: String? ->
                    if(userRepository == null) {
                        userRepository = CarrotInternal.getLibComponent().getUserRepository()
                    }

                    val tempUser = userRepository?.getUser()
                    tempUser?.token = token
                    userRepository?.saveUser(tempUser)

                    runUpdateMessages(needHardUpdate)
                },
                    { throwable: Throwable ->
                        e(
                            "RetrofitModule",
                            "refresh token error: $throwable"
                        )
                    }))


            compositeDisposable.add(Observable.just(1)
                .delay(2, TimeUnit.SECONDS)
                .take(1)
                .subscribeOn(Schedulers.io())
                .subscribe {
                    refreshJwtToken(b)
                })
        } else {
            runUpdateMessages(needHardUpdate)
        }
    }

    private fun runUpdateMessages(needHardUpdate: Boolean) {
        val conversationId = viewModel.getCurrentConversationId()
        if (conversationId.isEmpty() || "last_conversation" == conversationId) {
            return
        }

        compositeDisposable.add(Observable.just(1)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeOn(Schedulers.io())
            .getConversation(conversationId)
            .filter { x -> x.value != null }
            .map { x -> x.value!! }
            .getMessages()
            .take(1)
            .subscribe { optional ->
                if (optional.value != null) {
                    val messages = ArrayList<MessageData>()
                    messages.addAll(optional.value.data)

                    try {
                        MessagesRepository.getInstance()
                            .addMessages(messages, hardUpdate = needHardUpdate)

//                        if(optional.value.meta.nextAfter != null) {
//                            paginationMessages()
//                        }

                    } catch (e: Exception) {

                    }
                }
            })
    }

    fun onOpenLastDialog() {
        val hasInternet =
            NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).hasConnect

        if (hasInternet) {
            compositeDisposable.add(Observable.just(true)
                .getLastConversation()
                .take(1)
                .subscribeOn(Schedulers.newThread())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnNext { optional ->
                    if (optional != null) {
                        val conversation = optional.value
                        updateHeader(conversation?.lastAdmin)
                        if (conversation != null && conversation.id != null && conversation.id != "") {
                            onChangeConversationId(conversation.id)
                            onOpenDialog()
                        } else {
                            onOpenNewDialog()
                        }
                    } else {
                        onOpenNewDialog()
                    }
                }
                .doOnError {
                    Log.e(tag, it)
                }
                .subscribe()
            )
        }
    }

    private fun openConversationById(conversationId: String) {
        compositeDisposable.add(
            Observable.just(true)
                .openConversation(conversationId)
                .subscribe()
        )
        //openConversation(conversationId)
    }


    override fun setUserProperty(props: String) {
        val json = JsonParser.parseString(URLDecoder.decode(props, "UTF-8")).asJsonObject
        var dataIsSending = false

        val keys = json.keySet()
        if (keys.isNotEmpty()) {
            keys.forEach { key ->
                val value = json[key].asString
                try {
                    Carrot.setUserProperty(UserProperty(key, value))
                    dataIsSending = true
                }catch (e: Exception) {
                    dataIsSending = false
                    Log.e(tag, e)
                }
            }
        }

        if (dataIsSending) {
            getViewInterface()?.showDataSavedMessage()
        }
    }


    private fun fileExt(url: String): String? {
        var url = url
        if (url.contains("?")) {
            url = url.substring(0, url.indexOf("?"))
        }
        return if (url.lastIndexOf(".") == -1) {
            null
        } else {
            var ext = url.substring(url.lastIndexOf(".") + 1)
            if (ext.contains("%")) {
                ext = ext.substring(0, ext.indexOf("%"))
            }
            if (ext.contains("/")) {
                ext = ext.substring(0, ext.indexOf("/"))
            }
            ext.lowercase(Locale.getDefault())
        }
    }

    fun onOpenFile(uri: Uri?) {
        val dialogActivity = getViewInterface()?.getCurrentContext() as? android.app.Activity
        if (dialogActivity != null) {
            val filePickerHelper = FilePickerHelper(dialogActivity)

            if (uri != null) {
                try {
                    val file = filePickerHelper.getFile(uri)
                    val path = file.absolutePath

                    val fileTypeIsCorrect = filePickerHelper.fileTypeIsCorrect(path)
                    if (!fileTypeIsCorrect) {
                        filePickerHelper.showFileTypeError()
                        return
                    }


                    val isCorrectSize =
                        file.length() in 1 until (FilePickerHelper.maxSize * 1024 * 1024)

                    if (isCorrectSize) {
                        compositeDisposable.add(
                            Observable.just(true)
                                .getConversation(viewModel.getCurrentConversationId())
                                .take(1)
                                .subscribe { conversationOpt ->
                                    if (conversationOpt.value != null) {
                                        sendMessageWithAttachment(
                                            file,
                                            (java.lang.Long.parseLong(conversationOpt.value.lastUpdate!!) + 1).toString()
                                        )
                                    } else {
                                        createConversationByFile(file)
                                    }
                                })

                    } else {
                        val isImage = filePickerHelper.fileIsImage(path)

                        if (isImage) {
                            filePickerHelper.showSizeError(
                                dialogActivity.getString(R.string.error_image_size_title),
                                dialogActivity.getString(R.string.error_image_size_message)
                            )
                        } else {
                            filePickerHelper.showSizeError(
                                dialogActivity.getString(R.string.error_file_size_title),
                                dialogActivity.getString(R.string.error_file_size_message)
                            )
                        }

                        return
                    }
                } catch (e: Exception) {
                    android.util.Log.e("SELECT_FILE ANDROID", e.toString())
                }
            } else {
                android.util.Log.d("PhotoPicker", "No media selected")
            }
        }

        Observable.just(true)
            .delay(2, TimeUnit.SECONDS)
            .take(1)
            .doOnComplete {
                isOpenPicker = false
            }
            .subscribe()
    }

    private fun sendMessageWithAttachment(file: File, date: String) {
        val attachment = Attachment()
        attachment.id = date
        attachment.created = date
        attachment.filename = file.name
        attachment.size = file.length()
        val strFakeStart =
            getViewInterface()?.getCurrentContext()?.resources?.getString(R.string.fake_start_uri_for_image)
                ?: ""
        attachment.url = strFakeStart + file.absolutePath

        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
            MimeTypeMap.getFileExtensionFromUrl(
                Uri.fromFile(file).toString()
            ).lowercase(Locale.getDefault())
        )
        attachment.mimeType = mimeType

        if (mimeType?.contains("image") == true) {
            attachment.type = "image"
        } else {
            attachment.type = ResponseFields.FILE_TYPE
        }

        //Если у нас диалог с бототм и пользователь его прерывает, то надо удалить сообщения
        val botId = viewModel.getRoutingBotId()
        if (botId.isNotEmpty()) {
            getViewInterface()?.deleteAllMessages("javascript:window.webView.interruptBot()")
        }

        var sendingRandomId = ""

        val sendFileSubscribeDisposable = Observable.just(true)
            .createMessage(
                attachment,
                viewModel.getCurrentConversationId(),
                isNewDialog,
                MessageStatus.LOADING
            )
            .saveMessageWithAttachment()
            .map { x -> x.value!! }
            .doOnNext { sendingMessage ->
                sendingRandomId = sendingMessage.randomId
            }
            .sendMessageWithAttachment(strFakeStart)
            .take(1)
            .subscribe({ messageData ->
                messageData.randomId = sendingRandomId

                val savedFile = SavedFile(System.currentTimeMillis().toString())
                savedFile.localUri = file.absolutePath
                savedFile.url = messageData.attachments[0].url
                if (db == null) {
                    db = CarrotInternal.getLibComponent().sdkDataBase
                }
                db?.savedFileDao()?.insert(savedFile)


                //Сначала обновляем ID в webView
                val jsUpdateId = JSONObject()
                val oldId = messageData.sourceJsonData.get(F.ID)
                jsUpdateId.put(F.ID, messageData.id)

                val jsUpdateMessageId =
                    "javascript:window.webView.updateMessage(\"$oldId\", [${jsUpdateId.toString()}])"

                getViewInterface()?.updateMessage(jsUpdateMessageId)


                val jsonSource = messageData.sourceJsonData
                messageData.sourceJsonData.remove(F.ID)
                messageData.sourceJsonData.put(F.ID, messageData.id)
                if (jsonSource.has(F.ATTACHMENTS) && jsonSource.getJSONArray(F.ATTACHMENTS) != null) {
                    val attachmentsJson = jsonSource.getJSONArray(F.ATTACHMENTS)
                    val attJson = attachmentsJson.getJSONObject(0)
                    attJson?.remove(F.STATUS)
                    val status = "loaded"
                    attJson.put(F.STATUS, status)

                    val nAttachments = JSONArray()
                    nAttachments.put(attJson)
                    messageData.sourceJsonData.remove(F.ATTACHMENTS)
                    messageData.sourceJsonData.put(F.ATTACHMENTS, nAttachments)
                }

                MessagesRepository.getInstance().updateMessage(messageData)

                val jsUpdateMessage =
                    "javascript:window.webView.updateMessageObject(${messageData.sourceJsonData.toString()})"
                getViewInterface()?.updateMessage(jsUpdateMessage)

                addedMessages.add(messageData.id)

                /*val strParams = JsonUtil.createJsonParams(params)
                val jsUpdateMessageAttachment = "javascript:window.webView.updateMessageAttachment(\"${it.id}\", $strParams)"
                getViewInterface()?.updateMessage(jsUpdateMessageAttachment)*/
            }, { t ->
                Log.e(tag, t)
            })

        collapseHeader()
    }
}
