package io.carrotquest_sdk.android.domain.use_cases.countries

import io.carrotquest_sdk.android.presentation.entities.CountryEntity
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import java.util.Locale

fun getCountryEntityByRegion(region: String, phoneNumberUtil: PhoneNumberUtil): CountryEntity {
    val countryCode = phoneNumberUtil.getCountryCodeForRegion(region.uppercase())
    val countryName =  Locale("", region).displayCountry

    return CountryEntity(
        name = countryName,
        flag = getEmoji(region),
        region = region,
        countryCode = countryCode,
    )
}