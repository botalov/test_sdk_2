package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.data.data_entities.popup.PopUpStatesModel
import io.carrotquest_sdk.android.data.db.popup.PopUpDbEntity
import io.carrotquest_sdk.android.data.network.wss_responses.PopUpMessage
import io.carrotquest_sdk.android.data.repositories.PopupRepository
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

fun Observable<PopUpMessage>.saveNewPopUp() : Observable<PopUpMessage> {
    return Observable.defer {
        this.flatMap {
            saveImages(it)
                    .take(1)
                    .subscribe()

            PopupRepository.savePopUp(PopUpDbEntity(
                    id = it.id,
                    state = PopUpStatesModel.PROCESS.name,
                    bodyJson =  it.sourceJson,
                    expirationTime = it.expirationTime,
                    backgroundColor = it.backgroundColor
            ))
            return@flatMap this
        }
    }
}


private fun saveImages(popUpMessage: PopUpMessage) : Observable<PopUpMessage> {
    return SettingsRepository.getInstance().getSettings()
            .flatMap {settings->
                return@flatMap Single.just(popUpMessage)
                        .saveImages(settings.appId)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .toObservable()
            }

}