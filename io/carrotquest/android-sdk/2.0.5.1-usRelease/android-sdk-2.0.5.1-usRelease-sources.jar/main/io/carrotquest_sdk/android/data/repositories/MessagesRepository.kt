package io.carrotquest_sdk.android.data.repositories

import android.os.Build
import android.text.Html
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.messages.ExpirationMessage
import io.carrotquest_sdk.android.domain.entities.Optional
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.addNewMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.onAddConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.onAddExpirationMessages
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.PublishSubject
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.Locale
import java.util.concurrent.TimeUnit

class MessagesRepository private constructor() {
    private var data = MessagesResponse()
    private var currentAfter = ""
    private var welcomeMessage: MessageData? = null

    // RxJava — kept for DialogPresenter compatibility
    private val messagesSubject: BehaviorSubject<MessagesResponse> = BehaviorSubject.create()
    private val addMessagesSubject: PublishSubject<ArrayList<MessageData>> = PublishSubject.create()
    private val updateMessageSubject: PublishSubject<Optional<MessageData>> = PublishSubject.create()
    private val removeMessageSubject: PublishSubject<Optional<MessageData>> = PublishSubject.create()
    private val addBatchSubject: PublishSubject<String> = PublishSubject.create()

    // Flow — modern API for Compose/Coroutines consumers
    private val _newMessagesFlow = MutableSharedFlow<List<MessageData>>(extraBufferCapacity = 16)
    val newMessagesFlow: SharedFlow<List<MessageData>> = _newMessagesFlow.asSharedFlow()

    private val _removedMessageFlow = MutableSharedFlow<MessageData?>(extraBufferCapacity = 16)
    val removedMessageFlow: SharedFlow<MessageData?> = _removedMessageFlow.asSharedFlow()

    private var endTypingDisposable: Disposable? = null
    private var typingObserverDisposable: Disposable? = null

    companion object {
        @Volatile
        private var instance: MessagesRepository? = null
        fun getInstance(): MessagesRepository {
            // Double-checked locking — после deInit() instance=null, и параллельный
            // re-init может попытаться создать его дважды.
            val existing = instance
            if (existing != null) return existing
            return synchronized(MessagesRepository::class.java) {
                val cur = instance
                if (cur != null) cur
                else {
                    val fresh = MessagesRepository()
                    instance = fresh

                    Observable.just(true)
                            .onAddExpirationMessages()
                            .onErrorReturn { ArrayList() }
                            .subscribe()

                    Observable.just(true)
                            .onAddConversation()
                            .onErrorReturn { ArrayList() }
                            .subscribe()

                    // Подписываемся на индикатор печати из CarrotService
                    fresh.initTypingObserver()
                    fresh
                }
            }
        }
    }

    private fun initTypingObserver() {
        // Disposable сохраняем — иначе при deInit() мы не сможем отписаться, а после
        // re-init подписка останется висеть на старом adminTypingObservable.
        typingObserverDisposable = CarrotInternal.getLibComponent().carrotService.adminTypingObservable()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({ message ->
                val currentOpenedId = ConversationsRepository.getInstance().getOpenedConversationId()
                if (message.conversation == currentOpenedId) {
                    addMessageTyping(message)

                    endTypingDisposable?.dispose()
                    endTypingDisposable = Observable.just(true)
                        .delay(message.duration.toLong(), TimeUnit.SECONDS)
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe { removeMessageTyping() }
                }
            }, {
                // error handling
            })
    }

    /**
     * Полный teardown для re-init сценария (Carrot.deInit() → setup()).
     * Diosposes подписок, обнуляет состояние, сбрасывает singleton, чтобы при следующем
     * getInstance() создался свежий instance, заново подписанный на новые Subject'ы
     * перезапущенного CarrotService.
     */
    fun deInit() {
        typingObserverDisposable?.dispose()
        typingObserverDisposable = null
        endTypingDisposable?.dispose()
        endTypingDisposable = null
        messageTyping = null

        // Завершаем подписчиков с onComplete — у них есть шанс корректно отреагировать.
        try { messagesSubject.onComplete() } catch (_: Throwable) {}
        try { addMessagesSubject.onComplete() } catch (_: Throwable) {}
        try { updateMessageSubject.onComplete() } catch (_: Throwable) {}
        try { removeMessageSubject.onComplete() } catch (_: Throwable) {}
        try { addBatchSubject.onComplete() } catch (_: Throwable) {}

        data = MessagesResponse()
        welcomeMessage = null
        currentAfter = ""

        synchronized(MessagesRepository::class.java) {
            instance = null
        }
    }


    fun getData(): Observable<MessagesResponse> {
        return messagesSubject
    }

    fun getDataSingle(): List<MessageData> {
        return this.data.data
    }

    fun setData(messages: MessagesResponse) {
        this.data = messages
        this.welcomeMessage = null
        messagesSubject.onNext(this.data)
    }

    fun getMessages() = this.data

    fun setCurrentAfter(after: String) {
        this.currentAfter = after
    }

    fun getCurrentAfter() = this.currentAfter

    fun findMessageById(messageId: String): MessageData? {
        return this.data.data.find { x -> x.id == messageId }
    }

    fun removeMessage(message: MessageData) {
        if (this.data.data != null) {
            this.data.data.remove(message)
        } else {
            this.data.data = ArrayList()
        }
        messagesSubject.onNext(this.data)
        removeMessageSubject.onNext(Optional(message))
        _removedMessageFlow.tryEmit(message)
    }

    fun removeMessage(messageId: String) {
        val message = this.data.data.find { x -> x.id == messageId }
        if (message != null) {
            removeMessageSubject.onNext(Optional(message))
            _removedMessageFlow.tryEmit(message)
        }
        this.data.data.remove(message)
        messagesSubject.onNext(this.data)
    }

    fun addMessage(message: MessageData) {
        if (this.data.data == null) {
            this.data.data = ArrayList()
        }
        this.data.data.add(message)
        val addMessages = ArrayList<MessageData>()
        addMessages.add(message)
        addMessagesSubject.onNext(addMessages)
        _newMessagesFlow.tryEmit(addMessages)
        messagesSubject.onNext(this.data)
    }

    private val lock = Any()
    fun addMessages(messages: ArrayList<MessageData>, hardUpdate: Boolean = false) {
        if (this.data.data == null) {
            this.data.data = ArrayList()
        }

        synchronized(lock) {
            val diffMessages = ArrayList<MessageData>()
            diffMessages.addAll(messages.filterNot { x ->
                this.data.data.map { a -> a.id }.contains(x.id)
            })

            this.data.data.addAll(diffMessages)
            if (hardUpdate) {
                val allMessages = ArrayList<MessageData>()
                allMessages.addAll(this.data.data)
                addMessagesSubject.onNext(allMessages)
                _newMessagesFlow.tryEmit(allMessages)
            } else {
                addMessagesSubject.onNext(diffMessages)
                _newMessagesFlow.tryEmit(diffMessages)
            }

            messagesSubject.onNext(this.data)
        }
    }

    fun addBatch(batch: String) {
        addBatchSubject.onNext(batch)
    }

    fun addWssMessage(message: MessageData) {
        Observable.just(true).addNewMessage(message)
                .take(1)
                .subscribe()
        val conversation = ConversationsRepository.getInstance().getConversationById(message.conversation)
        if (conversation != null && conversation.id != null) {
            val sourceConversation = conversation.sourceJsonData
            if (sourceConversation != null) {
                sourceConversation.remove(F.PARTS_COUNT)
                sourceConversation.addProperty(F.PARTS_COUNT, conversation.partsCount.toString())
                sourceConversation.remove(F.UNREAD_PARTS_COUNT)
                sourceConversation.addProperty(
                    F.UNREAD_PARTS_COUNT,
                    conversation.unreadPartsCount.toString()
                )
                sourceConversation.remove(F.LAST_UPDATE)
                sourceConversation.addProperty(F.LAST_UPDATE, conversation.lastUpdate)
                conversation.sourceJsonData = sourceConversation
            }

            val conversationId = conversation.id
            if (conversationId != null) {
                ConversationsRepository.getInstance()
                    .updateConversation(conversationId, conversation)
            }
        }

        var body = message.body
        if (message.type == ResponseFields.ARTICLE) {
            if (message.bodyJson != null && message.bodyJson.isJsonObject) {
                if (message.bodyJson.asJsonObject.has(F.NAME)) {
                    body = message.bodyJson.asJsonObject[F.NAME].asString
                }
            }
        } else if(message.type == ResponseFields.VOTE) {
            body = CarrotLib.getLibComponents().context.getString(R.string.plese_vote_operator)
        }

        body = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Html.fromHtml(body, Html.FROM_HTML_MODE_LEGACY).toString()
        } else {
            Html.fromHtml(body).toString()
        }

        if(message.attachments != null && message.attachments.isNotEmpty()) {
            val firstAttachment = message.attachments.first()
            val trueBody = message.body.ifEmpty {
                if (firstAttachment.mimeType.lowercase(Locale.getDefault()).contains("image")) {
                    CarrotLib.getLibComponents().context.getString(R.string.image_str)
                } else {
                    CarrotLib.getLibComponents().context.getString(R.string.file_str)
                }
            }

            val imageStr =  if (firstAttachment.mimeType.lowercase(Locale.getDefault()).contains("image")) {
                "🖼 "
            } else {
                "📎 "
            }

            body = imageStr + trueBody
        }

        val isFromBot = (message.type == "chat_bot_user" && !message.actions.isNullOrEmpty())
        if(!isFromBot) {
            val conversationType = conversation?.type
            PushNotificationHelper.getInstance().postNotification(message.id.toString(),
                    if (message.messageFrom == null) "" else message.messageFrom.name,
                    body, message.conversation.toString(), message.sentVia, conversationType, null, null)
        }

        replaceMessageTyping(message)
        updateMessage(message)
    }

    fun getAddedMessages(): Observable<ArrayList<MessageData>> {
        return addMessagesSubject
    }

    fun getUpdatedMessage(): Observable<Optional<MessageData>> {
        return updateMessageSubject
    }

    fun getRemovedMessage(): Observable<Optional<MessageData>> {
        return removeMessageSubject
    }

    fun getAddedBatch(): Observable<String> {
        return addBatchSubject
    }

    fun updateMessage(message: MessageData) {
        if(this.data == null || this.data.data == null) {
            return
        }
        val index = this.data.data.indexOfFirst { x ->
            x.id == message.id
                    || (x.randomId !=  null && x.randomId != "0" && x.randomId == message.randomId)
                    || (x.randomId !=  null && x.randomId != "0" &&x.id == message.randomId)
                    || (x.randomId !=  null && x.randomId != "0" &&x.randomId == message.id)
        }

        if (index >= 0) {
            this.data.data[index] = message
            messagesSubject.onNext(this.data)
            updateMessageSubject.onNext(Optional(message))
        }
    }

    private var messageTyping: MessageData? = null
    fun addMessageTyping(message: MessageData) {
        if (messageTyping == null && message.messageFrom != null) {
            messageTyping = message
            val addMessages = ArrayList<MessageData>()
            addMessages.add(message)
            addMessagesSubject.onNext(addMessages)
            _newMessagesFlow.tryEmit(addMessages)
        }
    }

    fun removeMessageTyping() {
        if(this.data.data != null) {
            this.data.data.remove(messageTyping)
            if (messageTyping != null) {
                removeMessageSubject.onNext(Optional(messageTyping))
                _removedMessageFlow.tryEmit(messageTyping)
                messageTyping = null
            }
            messagesSubject.onNext(this.data)
        }
    }

    fun replaceMessageTyping(message: MessageData) {
        if (this.data.data != null && messageTyping != null) {
            removeMessageTyping()
        }
        addMessage(message)
    }

    fun saveWelcomeMessage(message: MessageData?) {
        this.welcomeMessage = message
    }

    fun getWelcomeMessage(): MessageData? {
        return this.welcomeMessage
    }

    fun getExpirationMessages(): Observable<ArrayList<String>> {
        val db: CarrotSdkDB = SdkApp.getInstance().database
        val ids = ArrayList<String>()
        val tempArray = db.expirationMessageDao().all
        for (message in tempArray) {
            ids.add(message.id)
        }

        return Observable.just(ids)
    }

    fun addExpirationMessage(messageId: String) {
        val db: CarrotSdkDB = SdkApp.getInstance().database
        db.expirationMessageDao().insert(ExpirationMessage(messageId))
    }

    fun removeExpirationMessage(messageId: String) {
        val db: CarrotSdkDB = SdkApp.getInstance().database
        db.expirationMessageDao().remove(messageId)
    }
}
