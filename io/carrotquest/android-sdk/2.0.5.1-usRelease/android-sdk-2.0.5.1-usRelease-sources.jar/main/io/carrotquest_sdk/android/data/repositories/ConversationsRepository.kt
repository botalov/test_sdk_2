package io.carrotquest_sdk.android.data.repositories

import com.google.gson.Gson
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.reactivex.Observable
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.PublishSubject
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Collections

class ConversationsRepository private constructor() {
    private var currentAfter = ""

    private val conversations = Collections.synchronizedList(ArrayList<DataConversation>())

    // RxJava — kept for DialogPresenter compatibility
    private val conversationsSubject: BehaviorSubject<ArrayList<DataConversation>> = BehaviorSubject.createDefault(ArrayList(conversations))
    private val assignedConversationSubject = BehaviorSubject.create<DataConversation>()
    private val addConversationSubject: PublishSubject<DataConversation> = PublishSubject.create()

    private val unreadConversationsIDs = ArrayList<String>()
    private val unreadConversationsSubject: BehaviorSubject<ArrayList<String>> = BehaviorSubject.createDefault(unreadConversationsIDs)

    private var openedConversation: String = ""
    private var lastOpenedConversation: String = ""
    private val openedConversationIdSubject: BehaviorSubject<String> = BehaviorSubject.create()

    // Flow — modern API for Compose/Coroutines consumers
    private val _conversationsFlow = MutableStateFlow<List<DataConversation>>(emptyList())
    val conversationsFlow: StateFlow<List<DataConversation>> = _conversationsFlow.asStateFlow()

    private val _newConversationFlow = MutableSharedFlow<DataConversation>(extraBufferCapacity = 1)
    val newConversationFlow: SharedFlow<DataConversation> = _newConversationFlow.asSharedFlow()

    // Сигнал об изменении состояния списка. Нужен потому, что часть мутаторов меняет
    // существующий объект DataConversation in-place (см. ConversationReplyChangedMessage:
    // RTS приходит при удалении/редактировании сообщения и обновляет partLast у того же
    // объекта). После этого _conversationsFlow.value = ArrayList(this.conversations)
    // содержит ТЕ ЖЕ references → ArrayList.equals возвращает true → MutableStateFlow
    // не уведомляет подписчиков. Этот flow гарантирует уведомление в любом случае.
    private val _changeSignal = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val changeSignal: SharedFlow<Unit> = _changeSignal.asSharedFlow()

    private fun emitConversationsChanged(snapshot: ArrayList<DataConversation>) {
        conversationsSubject.onNext(snapshot)
        _conversationsFlow.value = snapshot
        _changeSignal.tryEmit(Unit)
    }

    // Singleton реализован в companion object внизу файла — там же deInit() обнуляет
    // ссылку для re-init сценария.

    fun getConversations(): Observable<ArrayList<DataConversation>> {
        return conversationsSubject
    }

    fun getConversationsSync(): ArrayList<DataConversation> {
        return ArrayList(this.conversations)
    }

    fun getConversationById(id: String): DataConversation? {
        return this.conversations.find { x->x.id != null && x.id == id }
    }

    private val lock = Any()
    fun saveConversations(data: ArrayList<DataConversation>) {
        if(data == null || data.isEmpty()) {
            return
        }
        synchronized(lock) {
            try {
                for (conversation in data) {
                    if (this.conversations.find { x -> x.id != null && x.id == conversation.id } == null) {
                        this.conversations.add(conversation)
                    }
                }

                emitConversationsChanged(ArrayList(this.conversations))
            } catch (e: Exception) {
                Log.e("saveConversations", e)
            }
        }
    }

    fun clearConversations() {
        synchronized(this.conversations) {
            this.conversations.clear()
            emitConversationsChanged(ArrayList(this.conversations))
        }
    }

    fun addConversation(conversation: DataConversation) {
        if (conversation == null) return
        synchronized(this.conversations) {
            if (this.conversations.find { it.id != null && it.id == conversation.id } != null) return
            val resAdd = this.conversations.add(conversation)
            if (resAdd) {
                this.addConversationSubject.onNext(conversation)
                _newConversationFlow.tryEmit(conversation)
                emitConversationsChanged(ArrayList(this.conversations))
            }
        }
    }

    fun updateLastAdmin(conversationId: String, admin: Admin?) {
        synchronized(this.conversations) {
            val conversation = this.conversations.find { it.id != null && it.id == conversationId }
                ?: return
            conversation.lastAdmin = admin
            emitConversationsChanged(ArrayList(this.conversations))
        }
    }

    fun updateInfoAboutConversation(conversation: DataConversation) {
        if(conversation.id != null) {
            this.updateConversation(conversation.id, conversation)
        }
    }

    fun removeConversation(id: String) {
        synchronized(this.conversations) {
            val resRemove = this.conversations.remove(this.conversations.find { it.id != null && it.id == id })
            if (resRemove) {
                emitConversationsChanged(ArrayList(this.conversations))
            }
        }
    }
    
    fun assignedConversation() : Observable<DataConversation> {
        return this.assignedConversationSubject
    }

    fun removeUnreadConversation(conversationId: String) {
        synchronized(this.conversations) {
            val c = this.conversations.find { x -> x.id == conversationId } ?: return
            val index = this.conversations.indexOf(c)
            c.unreadPartsCount = 0

            if(c.sourceJsonData != null) {
                val sJd = c.sourceJsonData
                if(sJd.has(F.UNREAD_PARTS_COUNT)) {
                    sJd.remove(F.UNREAD_PARTS_COUNT)
                    sJd.addProperty(F.UNREAD_PARTS_COUNT, 0)
                }
                c.sourceJsonData = sJd
            }

            this.conversations[index] = c
            emitConversationsChanged(ArrayList(this.conversations))
        }
    }

    fun saveOpenedConversation(id: String) {
        if(id.isNotEmpty()) {
            lastOpenedConversation = id
        }
        this.openedConversation = id
        openedConversationIdSubject.onNext(id)
    }

    fun getOpenedConversationId() : String {
        return openedConversation
    }

    fun getLastOpenedConversationId() : String {
        return lastOpenedConversation
    }

    fun updateConversation(conversationId: String, conversation: DataConversation) {
        synchronized(this.conversations) {
            val foundConversation = this.conversations.find { x -> x.id != null && x.id == conversationId }
                    ?: return

            // Merge-guard: часть WSS-событий и ответов API не включает last_admin,
            // из-за чего объект-апдейт приходит с lastAdmin=null и затирает оператора
            // в карточке. Если в новой версии оператора нет, а в старой был —
            // сохраняем старого (реальная смена оператора всегда приходит с данными).
            if (conversation.lastAdmin == null && foundConversation.lastAdmin != null) {
                conversation.lastAdmin = foundConversation.lastAdmin
                val src = conversation.sourceJsonData
                if (src != null) {
                    val hasValidAdmin = src.has(F.LAST_ADMIN)
                            && !src.get(F.LAST_ADMIN).isJsonNull
                            && src.get(F.LAST_ADMIN).isJsonObject
                    if (!hasValidAdmin) {
                        src.remove(F.LAST_ADMIN)
                        runCatching {
                            val adminJson = JsonParser.parseString(Gson().toJson(foundConversation.lastAdmin))
                            if (adminJson.isJsonObject) {
                                src.add(F.LAST_ADMIN, adminJson.asJsonObject)
                            }
                        }
                    }
                }
            }

            this.conversations.remove(foundConversation)
            this.conversations.add(0, conversation)

            emitConversationsChanged(ArrayList(this.conversations))

            if (foundConversation.lastAdmin?.id != conversation.lastAdmin?.id) {
                this.assignedConversationSubject.onNext(conversation)
            }

            if(foundConversation.randomId == openedConversation) {
                saveOpenedConversation(conversation.id)
            }
        }
    }
    
    fun assignedConversation(conversation: DataConversation) {
        updateConversation(conversation.id, conversation)
        assignedConversationSubject.onNext(conversation)
    }

    fun getAddedConversation(): Observable<DataConversation> {
        return addConversationSubject
    }

    fun setCurrentAfter(after: String) {
        this.currentAfter = after
    }

    fun getCurrentAfter() = this.currentAfter

    /**
     * Полный teardown для re-init сценария. Сбрасывает локальное состояние и завершает
     * Rx subjects, чтобы текущие подписчики корректно отреагировали. Singleton
     * обнуляется — при следующем getInstance() создаётся свежий с пустыми subject'ами.
     */
    fun deInit() {
        synchronized(this.conversations) {
            this.conversations.clear()
        }
        currentAfter = ""
        openedConversation = ""
        lastOpenedConversation = ""

        try { conversationsSubject.onComplete() } catch (_: Throwable) {}
        try { assignedConversationSubject.onComplete() } catch (_: Throwable) {}
        try { addConversationSubject.onComplete() } catch (_: Throwable) {}
        try { unreadConversationsSubject.onComplete() } catch (_: Throwable) {}
        try { openedConversationIdSubject.onComplete() } catch (_: Throwable) {}

        synchronized(ConversationsRepository::class.java) {
            holderRef = null
        }
    }

    companion object {
        @Volatile
        private var holderRef: ConversationsRepository? = null
        fun getInstance(): ConversationsRepository {
            val existing = holderRef
            if (existing != null) return existing
            return synchronized(ConversationsRepository::class.java) {
                val cur = holderRef
                if (cur != null) cur
                else {
                    val fresh = ConversationsRepository()
                    holderRef = fresh
                    fresh
                }
            }
        }
    }
}