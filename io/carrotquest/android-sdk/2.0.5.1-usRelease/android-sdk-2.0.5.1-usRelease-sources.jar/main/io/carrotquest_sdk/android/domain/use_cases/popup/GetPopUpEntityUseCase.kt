package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.domain.entities.Optional
import io.carrotquest_sdk.android.domain.entities.popup.PopUpMessageEntity
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers

fun <T> Observable<T>.getPopUpEntity(conversationId: String) : Observable<Optional<PopUpMessageEntity>> {
    return Observable.defer {
        return@defer this.flatMap {
            return@flatMap SdkApp
                .getInstance()
                .database
                .popUpDao()
                .getAllPopUps()
                .subscribeOn(Schedulers.io())
                .doOnNext {
                    Log.d("getAllPopUpsObservable()", "getAllPopUpsObservable().size = ${it?.size ?: 0}")
                }
                .toObservable()
                .map { dbEntities ->
                    val foundPopup = dbEntities.find { x->x.id == conversationId } ?: return@map Optional(null)
                    val entity = PopUpMessageEntity(
                        foundPopup.id,
                        foundPopup.bodyJson,
                        foundPopup.expirationTime,
                        foundPopup.backgroundColor
                    )

                    return@map Optional(entity)
                }
        }
    }
}