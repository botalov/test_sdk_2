package io.carrotquest_sdk.android.domain.use_cases.user

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.responses.user.UserResponse
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.reactivex.Observable

fun <T> Observable<T>.loadUserById(id: String) : Observable<UserEntity> {
    val tag = "loadUserByIdUseCase"

    return this
        .doOnError { e ->
            run {
                Log.e(tag, e)
            }
        }
        .flatMap {
            CarrotInternal
                .getService()
                .carrotLib
                .getUser(id)
        }
        .map {
            val res = UserEntity(
                it.id,
                it.token,
                it.hasConversations,
                it.isBanned,
                it.conversationsUnread
            )
            res
        }
}


fun <T> Observable<T>.loadUserProps(id: String) : Observable<Map<String, Any>> {
    val tag = "loadUserProps"

    return this
        .doOnError { e ->
            run {
                Log.e(tag, e)
            }
        }
        .flatMap {
           return@flatMap CarrotInternal
                .getService()
                .carrotLib
                .loadUser(id)
        }
        .onErrorReturn {
            Log.e(tag, "ERROR: $it")
            return@onErrorReturn UserResponse()
        }
        .map { userResponse->
            val res = HashMap<String, Any>()

            if(userResponse.data != null) {
                val data = userResponse.data
                res.putAll(data.props)
            }

            saveUserProps(res)

            res
        }
}


private fun saveUserProps(props: HashMap<String, Any>) {
    if(props.containsKey("\$sdk_push_notifications_subscribed")) {
        val value = props["\$sdk_push_notifications_subscribed"]
        if(value != null) {
            val v: Boolean? = if(value is Boolean) value else if(value is String) value.toBoolean() else null

            if(v != null) {
                val key = SharedPreferenceKeys.SDK_PUSH_NOTIFICATIONS_UNSUBSCRIBED
                SharedPreferencesLib.saveBoolean(CarrotLib.getLibComponents().context, key, !v)
            }
        }
    }

    if(props.containsKey("\$sdk_push_campaigns_subscribed")) {
        val value = props["\$sdk_push_campaigns_subscribed"]
        if(value != null) {
            val v: Boolean? = if(value is Boolean) value else if(value is String) value.toBoolean() else null

            if(v != null) {
                val key = SharedPreferenceKeys.SDK_PUSH_CAMPAIGNS_UNSUBSCRIBED
                SharedPreferencesLib.saveBoolean(CarrotLib.getLibComponents().context, key, !v)
            }
        }
    }
}


