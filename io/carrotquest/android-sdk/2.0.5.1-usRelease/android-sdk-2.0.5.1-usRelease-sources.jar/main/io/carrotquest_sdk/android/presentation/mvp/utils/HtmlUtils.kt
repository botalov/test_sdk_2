package io.carrotquest_sdk.android.presentation.mvp.utils

import android.graphics.Typeface
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.core.text.HtmlCompat

/**
 * Парсит строку как HTML и возвращает [AnnotatedString] с сохранёнными стилями
 * (жирный, курсив, подчёркнутый, зачёркнутый, цвет).
 * Безопасно вызывать на plain-text — без тегов возвращает строку как есть.
 */
/** Возвращает содержимое, если строка целиком обёрнута в один <p>...</p>, иначе null. */
private fun String.singleParagraphContent(): String? {
    val trimmed = trim()
    val open = "<p>"
    val close = "</p>"
    if (!trimmed.startsWith(open, ignoreCase = true)) return null
    if (!trimmed.endsWith(close, ignoreCase = true)) return null
    // Убеждаемся, что это ровно один <p> — нет других закрывающих </p> внутри
    val inner = trimmed.substring(open.length, trimmed.length - close.length)
    if (inner.contains("</p>", ignoreCase = true)) return null
    return inner
}

fun String.toAnnotatedHtml(): AnnotatedString {
    // Если весь текст обёрнут в один <p>...</p> — убираем тег без замены на переносы строк
    val input = singleParagraphContent() ?: this
    val spanned = HtmlCompat.fromHtml(input, HtmlCompat.FROM_HTML_MODE_COMPACT)
    return buildAnnotatedString {
        append(spanned.toString().trimEnd())
        spanned.getSpans(0, spanned.length, Any::class.java).forEach { span ->
            val start = spanned.getSpanStart(span)
            val end = spanned.getSpanEnd(span)
            if (start < 0 || end < 0 || start >= end) return@forEach
            when (span) {
                is StyleSpan -> when (span.style) {
                    Typeface.BOLD ->
                        addStyle(SpanStyle(fontWeight = FontWeight.Bold), start, end)
                    Typeface.ITALIC ->
                        addStyle(SpanStyle(fontStyle = FontStyle.Italic), start, end)
                    Typeface.BOLD_ITALIC ->
                        addStyle(SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic), start, end)
                }
                is UnderlineSpan ->
                    addStyle(SpanStyle(textDecoration = TextDecoration.Underline), start, end)
                is StrikethroughSpan ->
                    addStyle(SpanStyle(textDecoration = TextDecoration.LineThrough), start, end)
                is ForegroundColorSpan ->
                    addStyle(SpanStyle(color = Color(span.foregroundColor)), start, end)
            }
        }
    }
}
