package io.carrotquest_sdk.android.lib.network.responses.messages

import androidx.annotation.Keep
import com.google.gson.annotations.SerializedName
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Meta

/**
 * Ответ `POST /v3/attachments` — загрузка файла отдельно от сообщения (upload-on-select).
 * `data` имеет ту же форму, что [Attachment] (type/id/filename/mime_type/size/url/created),
 * поэтому переиспользуем модель. Этот объект потом сериализуется в поле `attachments_cached`
 * при отправке сообщения (см. отправку мультиаттачей).
 */
@Keep
class AttachmentUploadResponse {
    @SerializedName(F.META)
    var meta: Meta? = null

    @SerializedName(F.DATA)
    var data: Attachment? = null
}
