package io.carrotquest_sdk.android.core.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.io.File
import java.io.RandomAccessFile
import kotlin.concurrent.thread
import kotlin.math.abs

/**
 * Запись голосового сообщения в WAV (PCM 16-bit).
 *
 * `MediaRecorder` не умеет писать WAV, поэтому пишем сырой PCM через [AudioRecord] и сами
 * формируем RIFF/WAVE-заголовок (placeholder при старте → патчим размеры при стопе). Нормализованный
 * пик амплитуды на буфер отдаём через [amplitude] для живой волны в UI. Волну для превью/исходящего
 * бабла строит уже существующий WaveformExtractor (он парсит WAV).
 *
 * Разрешение RECORD_AUDIO должно быть выдано ДО вызова [start] — это ответственность вызывающего
 * (DialogFragment запрашивает рантайм). Класс без UI/Compose-зависимостей.
 *
 * Параметры по умолчанию: 16 kHz, моно, 16-bit — компромисс качество/размер для речи
 * (~1.9 МБ/мин → лимит вложений 10 МБ ≈ 5 минут).
 */
class VoiceRecorder(
    private val sampleRate: Int = 16_000,
    private val maxDurationMs: Long = 5 * 60_000L,
) {
    sealed interface RecordResult {
        /** Успех: готовый WAV-файл и его длительность. */
        data class Success(val file: File, val durationMs: Long) : RecordResult
        /** Запись короче минимального порога (случайный тап) — файл удалён. */
        data object TooShort : RecordResult
        /** Не удалось записать (нет данных/ошибка устройства) — файл удалён/пуст. */
        data class Failed(val cause: Throwable?) : RecordResult
    }

    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val encoding = AudioFormat.ENCODING_PCM_16BIT
    private val bytesPerSample = 2 // 16-bit mono
    private val byteRate = sampleRate * bytesPerSample

    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    @Volatile private var recording = false
    @Volatile private var bytesWritten = 0L
    @Volatile private var failure: Throwable? = null
    private var outFile: File? = null

    // extraBufferCapacity + tryEmit: эмиссия из потока записи без подвешивания (drop при переполнении).
    private val _amplitude = MutableSharedFlow<Float>(replay = 0, extraBufferCapacity = 16)
    /** Нормализованный пик [0..1] на каждый прочитанный буфер PCM — для живой волны. */
    val amplitude: SharedFlow<Float> = _amplitude.asSharedFlow()

    val isRecording: Boolean get() = recording

    /**
     * Начинает запись в [file] (перезаписывает). Возвращает true, если запись стартовала.
     * Требует уже выданного RECORD_AUDIO; при отсутствии доступа/ошибке устройства вернёт false.
     */
    @SuppressLint("MissingPermission") // RECORD_AUDIO проверяет вызывающий
    fun start(file: File): Boolean {
        if (recording) return false

        val minBuf = AudioRecord.getMinBufferSize(sampleRate, channelConfig, encoding)
        if (minBuf <= 0) return false
        val bufferSize = minBuf * 2

        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, channelConfig, encoding, bufferSize)
        } catch (t: Throwable) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }

        outFile = file
        bytesWritten = 0L
        failure = null
        recorder = rec
        recording = true

        val maxBytes = byteRate * (maxDurationMs / 1000)

        worker = thread(name = "cq-voice-rec") {
            val raf = RandomAccessFile(file, "rw")
            try {
                raf.setLength(0)
                writeWavHeaderPlaceholder(raf)
                rec.startRecording()
                val buffer = ByteArray(bufferSize)
                while (recording) {
                    val read = rec.read(buffer, 0, buffer.size)
                    when {
                        read > 0 -> {
                            raf.write(buffer, 0, read)
                            bytesWritten += read
                            _amplitude.tryEmit(peak(buffer, read))
                            if (bytesWritten >= maxBytes) recording = false
                        }
                        read < 0 -> { // ERROR_INVALID_OPERATION / ERROR_BAD_VALUE и т.п.
                            failure = IllegalStateException("AudioRecord.read returned $read")
                            recording = false
                        }
                    }
                }
            } catch (t: Throwable) {
                failure = t
            } finally {
                try { rec.stop() } catch (_: Throwable) {}
                rec.release()
                try { patchWavHeader(raf, bytesWritten) } catch (_: Throwable) {}
                try { raf.close() } catch (_: Throwable) {}
            }
        }
        return true
    }

    /**
     * Останавливает запись, финализирует WAV-заголовок и возвращает результат.
     * Блокирует до завершения потока записи (короткий join). Записи короче [minDurationMs]
     * считаются случайными — файл удаляется, возвращается [RecordResult.TooShort].
     */
    fun stop(minDurationMs: Long = 1_000): RecordResult {
        if (worker == null && recorder == null) return RecordResult.Failed(failure)
        recording = false
        joinWorker()
        val file = outFile
        val written = bytesWritten
        val err = failure
        reset()

        if (file == null || err != null || written <= 0L) {
            file?.delete()
            return RecordResult.Failed(err)
        }
        val durationMs = written * 1000L / byteRate
        return if (durationMs < minDurationMs) {
            file.delete()
            RecordResult.TooShort
        } else {
            RecordResult.Success(file, durationMs)
        }
    }

    /** Отменяет запись и удаляет файл (без результата). */
    fun cancel() {
        recording = false
        joinWorker()
        outFile?.delete()
        reset()
    }

    private fun joinWorker() {
        try { worker?.join(2_000) } catch (_: InterruptedException) {}
    }

    private fun reset() {
        worker = null
        recorder = null
        outFile = null
        bytesWritten = 0L
        failure = null
    }

    // Нормализованный пик буфера: max |sample| / 32768. Семплы — signed 16-bit little-endian.
    private fun peak(buffer: ByteArray, len: Int): Float {
        var max = 0
        var i = 0
        while (i + 1 < len) {
            val sample = (buffer[i].toInt() and 0xFF) or (buffer[i + 1].toInt() shl 8)
            val v = abs(sample)
            if (v > max) max = v
            i += 2
        }
        return (max / 32768f).coerceIn(0f, 1f)
    }

    // ── WAV (RIFF/WAVE) заголовок ────────────────────────────────────────────────
    // Пишем 44-байтный placeholder с нулевыми размерами, при стопе патчим chunkSize и dataSize.

    private fun writeWavHeaderPlaceholder(raf: RandomAccessFile) {
        raf.write(buildWavHeader(sampleRate, channels = 1, bitsPerSample = 16, dataSize = 0))
    }

    // Перезаписываем весь 44-байтный заголовок с реальным dataSize (проще и надёжнее точечного патча).
    private fun patchWavHeader(raf: RandomAccessFile, dataSize: Long) {
        raf.seek(0)
        raf.write(buildWavHeader(sampleRate, channels = 1, bitsPerSample = 16, dataSize = dataSize.toInt()))
    }
}

/**
 * Канонический 44-байтный RIFF/WAVE-заголовок для PCM. Чистая функция (без I/O) — покрыта тестом.
 * Все размеры little-endian.
 */
internal fun buildWavHeader(sampleRate: Int, channels: Int, bitsPerSample: Int, dataSize: Int): ByteArray {
    val bytesPerSample = bitsPerSample / 8
    val byteRate = sampleRate * channels * bytesPerSample
    val blockAlign = channels * bytesPerSample
    val h = ByteArray(44)
    fun le(offset: Int, value: Int, bytes: Int) {
        for (i in 0 until bytes) h[offset + i] = ((value shr (8 * i)) and 0xFF).toByte()
    }
    fun tag(offset: Int, s: String) {
        for (i in s.indices) h[offset + i] = s[i].code.toByte()
    }
    tag(0, "RIFF"); le(4, 36 + dataSize, 4); tag(8, "WAVE")
    tag(12, "fmt "); le(16, 16, 4)        // subchunk1 size = 16 (PCM)
    le(20, 1, 2)                          // audioFormat = 1 (PCM)
    le(22, channels, 2)
    le(24, sampleRate, 4)
    le(28, byteRate, 4)
    le(32, blockAlign, 2)
    le(34, bitsPerSample, 2)
    tag(36, "data"); le(40, dataSize, 4)
    return h
}
