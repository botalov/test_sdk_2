package io.carrotquest_sdk.android.domain.use_cases.agreements

import io.carrotquest_sdk.android.Callback

import android.os.Handler
import android.os.Looper
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.data.service.CarrotService
import io.carrotquest_sdk.android.lib.CarrotLib

/**
 * Создание свойства и события о разрешении сбора данных в чате.
 * onResult — итог сохранения (false: не ушло/бэкенд отверг) для реакции UI-слоя.
 */
fun allowDataProcessingUseCase(onResult: (Boolean) -> Unit = {}) {
    val userId = CarrotLib.getLibComponents().userRep.user.id ?: ""
    if(userId.isEmpty()) {
        SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, "UserConsent") {
            "consent data_processing skipped: empty userId"
        }
        onResult(false)
        return
    }

    CarrotService.getInstance().setUserConsentDataProcessing(true, userId, object: Callback<Boolean> {
        override fun onResponse(result: Boolean) {
            SdkLogger.log(
                if (result) SdkLogLevel.INFO else SdkLogLevel.WARN,
                SdkLogCategory.NETWORK, "UserConsent"
            ) {
                "consent data_processing result=$result"
            }
            if (result) {
                Handler(Looper.getMainLooper()).postDelayed({
                    updateAppSettings("data_processing_policy_is_allowed", true)
                }, 1000)

            }
            onResult(result)
        }

        override fun onFailure(t: Throwable) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, "UserConsent") {
                "consent data_processing failed: $t"
            }
            onResult(false)
        }
    })
}

