package io.carrotquest_sdk.android.core.main;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.carrotquest_sdk.android.core.Cancellable;
import io.carrotquest_sdk.android.core.SdkGlobalHandlers;
import io.carrotquest_sdk.android.core.logging.SdkDiagnostics;
import io.carrotquest_sdk.android.core.logging.SdkLogEntry;
import io.carrotquest_sdk.android.core.logging.SdkLogLevel;
import io.carrotquest_sdk.android.core.logging.SdkLogSink;
import io.carrotquest_sdk.android.core.logging.SdkLogger;
import io.carrotquest_sdk.android.core.SdkStateManager;
import io.carrotquest_sdk.android.core.auth.AuthManager;
import io.carrotquest_sdk.android.data.user.UserStateHolder;
import io.carrotquest_sdk.android.domain.use_cases.user.SaveAuthedUserIdUseCaseKt;
import io.carrotquest_sdk.android.lib.CarrotLib;
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager;
import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.models.UserProperty;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData;
import io.carrotquest_sdk.android.lib.utils.AndroidUtils;
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib;
import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.Callback;
import io.carrotquest_sdk.android.Carrot;
import io.carrotquest_sdk.android.application.SdkApp;
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys;
import io.carrotquest_sdk.android.core.exceptions.CarrotException;
import io.carrotquest_sdk.android.core.exceptions.CarrotRepositoryException;
import io.carrotquest_sdk.android.core.exceptions.CarrotUserException;
import io.carrotquest_sdk.android.core.util.ConversationUtilsKt;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.core.util.sentry.SentryCQ_SDK;
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository;
import io.carrotquest_sdk.android.data.service.CarrotService;
import io.carrotquest_sdk.android.di.CarrotServiceModule;
import io.carrotquest_sdk.android.di.ContextSdkModule;
import io.carrotquest_sdk.android.di.DaggerSdkLibComponent;
import io.carrotquest_sdk.android.di.DataBaseModule;
import io.carrotquest_sdk.android.di.GsonModule;
import io.carrotquest_sdk.android.di.NotificationHelperModule;
import io.carrotquest_sdk.android.di.SdkLibComponent;
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.GetErrorMessagesUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.SendErrorMessagesUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.conversations.ClearHistoryUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.conversations.GetConversationsUseCaseKt;
import io.carrotquest_sdk.android.domain.use_cases.triggers.TrackScreenUseCase;
import io.carrotquest_sdk.android.models.EventParams;
import io.carrotquest_sdk.android.models.Operation;
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.DialogViewModel;
import io.carrotquest_sdk.android.presentation.mvp.notifications.NotificationsConstants;
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper;
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.TrackHelperKt;

/**
 * Entry point to the SDK. All members are static; use the {@code Carrot} / {@code Dashly} facades.
 *
 * <h3>Error-handling contract</h3>
 * Protecting the host app from SDK-internal failures is the priority, so public methods <b>do not
 * throw</b> at the caller:
 * <ul>
 *   <li><b>Fire-and-forget</b> methods (e.g. {@code trackEvent}, {@code setUserProperty},
 *       {@code openChat}, push helpers) swallow internal errors and log them via the SDK logger.
 *       Raise the log level ({@link #setLogLevel}), attach a {@link #setLogSink} or read
 *       {@link #getDiagnostics()} to observe them.</li>
 *   <li><b>Async operations</b> ({@code setup}, {@code auth}, {@code hashedAuth}, {@code deInit})
 *       report success and failure through their {@link Callback}; if invoked without a callback,
 *       failures are logged instead.</li>
 *   <li><b>Sole exception:</b> {@link #getUnreadConversations()} throws {@link CarrotException} and
 *       must be called inside a try/catch.</li>
 * </ul>
 */
public class CarrotSDK {
    private static final String TAG = "CarrotSDK";
    private static final String VERSION = BuildConfig.VERSION_SDK_NAME;

    private static volatile CarrotService service;
    static SdkLibComponent libComponent;


    private static ThemeSdk mTheme = null;

    private static boolean isUseEuApi = false;


    protected CarrotSDK(Context context) {

        SdkLogger.attachLogStore(context.getApplicationContext());
        SdkApp.getInstance().initDataBase(context);
        libComponent = DaggerSdkLibComponent.builder()
                .gsonModule(new GsonModule())
                .carrotServiceModule(new CarrotServiceModule(context, app_id, isUseEuApi))
                .contextSdkModule(new ContextSdkModule(context))
                .dataBaseModule(new DataBaseModule(SdkApp.getInstance()))
                .build();
    }

    private static Callback<NetworkResponse> eventsObserver = new Callback<NetworkResponse>() {
        @Override
        public void onResponse(NetworkResponse networkResponse) {
            Log.d(TAG, String.valueOf(networkResponse.getData()));
        }

        @Override
        public void onFailure(Throwable t) {
            Log.e(TAG, t.toString());
        }
    };

    private static Callback<Boolean> userPropertyObserver = new Callback<Boolean>() {
        @Override
        public void onResponse(Boolean result) {
            Log.d(TAG, "Set UserProperty");
        }

        @Override
        public void onFailure(Throwable t) {
            Log.e(TAG, t.toString());
        }
    };

    // Внутреннее состояние SDK (init/auth/session) намеренно НЕ выставляется в публичный API:
    // flow токенов/восстановления сессии скрыт от клиента. Восстановление после протухших кредов
    // происходит автоматически (clearJwtTokens + token-less /connect). Внутренние потребители
    // читают SdkStateManager.publicState / AuthManager напрямую.

    private static String api_key;
    private static String app_id;

    private static String parentActivityClassNameImpl;

    public static String getApiKey() {
        return api_key;
    }

    public static String getAppId() {
        return app_id;
    }

    /**
     * Initializes the SDK and opens a connection, starting a new user session. This is the normal
     * entry point — call it once, typically from {@code Application.onCreate()}. The {@code apiKey}
     * also encodes the app id (the part before the {@code "-"}).
     *
     * <p>Configuration methods such as {@link #setNotificationIcon(int)} and
     * {@link #setParentActivityClassName(String)} take effect once the SDK is initialized; call
     * them after {@code setup(...)} (or after the callback reports success).
     *
     * @param callback notified with {@code true} on success, or {@code onFailure} on an invalid key
     */
    public static void setup(@NonNull Context context,  @NonNull String apiKey, Callback<Boolean> callback) {
        commonSetup(context, apiKey, callback, true);
    }

    /**
     * Same as {@link #setup(Context, String, Callback)}, but lets you route traffic through the EU
     * data centre.
     *
     * @param useEuServers {@code true} to use EU servers
     */
    public static void setup(@NonNull Context context, @NonNull String apiKey, boolean useEuServers, Callback<Boolean> callback) {
        isUseEuApi = useEuServers;
        commonSetup(context, apiKey, callback, true);
    }

    /**
     * Same as {@link #setup(Context, String, Callback)} — initializes the SDK and opens a
     * connection — but does <b>not</b> start a new user session, so this initialization is not
     * counted as a session for analytics. Use it when you want the SDK ready (e.g. to receive
     * messages) without registering a session until the user actually engages.
     */
    public static void setupWithoutStartSession(@NonNull Context context, @NonNull String apiKey, Callback<Boolean> callback) {
        commonSetup(context, apiKey, callback, false);
    }

    // Internal bootstrap: builds the SDK dependency graph (including the notification helper)
    // without contacting the backend. Used by push entry points that may run before setup().
    // Exposed to other packages via CarrotInternal.setupWithoutConnect(...).
    static void buildComponentsWithoutConnect(@NonNull Context context) {
        SdkGlobalHandlers.INSTANCE.ensureInstalled();
        try {
            SdkApp.getInstance().initDataBase(context);

            libComponent = DaggerSdkLibComponent.builder()
                    .gsonModule(new GsonModule())
                    .carrotServiceModule(new CarrotServiceModule(context, app_id, isUseEuApi))
                    .contextSdkModule(new ContextSdkModule(context))
                    .dataBaseModule(new DataBaseModule(SdkApp.getInstance()))
                    .notificationHelperModule(new NotificationHelperModule())
                    .build();
        }
        catch (Exception e){
            Log.d(TAG, e.toString());
        }
    }

    private static String getAppIdFromApiKey(String apiKey) {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            throw new IllegalArgumentException("API key cannot be null or empty.");
        }

        int separatorIndex = apiKey.indexOf("-");

        if (separatorIndex == -1) {
            throw new IllegalArgumentException("Invalid API key format: No '-' separator found.");
        }

        if (separatorIndex == 0) {
            throw new IllegalArgumentException("Invalid API key format: App ID part is missing.");
        }

        return apiKey.substring(0, separatorIndex);
    }

    private static boolean isValidApiKey(String apiKey) {
        if(apiKey == null) {
            return false;
        }

        if(apiKey.isEmpty()) {
            return false;
        }

        final String API_KEY_PATTERN = "^\\d+-[a-f0-9]{1,30}$";
        return apiKey.matches(API_KEY_PATTERN);
    }

    private static void commonSetup(@NonNull Context context, @NonNull String apiKey, Callback<Boolean> callback, boolean startSession) {
        // Ставим глобальные охранники от крэшей ещё до любой работы SDK — гарантирует,
        // что ошибки в последующей инициализации не уронят хост.
        SdkGlobalHandlers.INSTANCE.ensureInstalled();

        if(!isValidApiKey(apiKey)) {
            IllegalArgumentException error = new IllegalArgumentException("Invalid API key format: " + apiKey);
            // Per the public-API error contract: never throw at the caller — report through the
            // callback when present, otherwise log. Abort setup; continuing with an invalid key
            // would build a half-configured SDK.
            if (callback != null) callback.onFailure(error);
            else Log.e(TAG, error.toString());
            return;
        }

        String appId = null;
        try {
            appId = getAppIdFromApiKey(apiKey);
        } catch (IllegalArgumentException e) {
            Log.e(TAG, e);
        }

        api_key = apiKey;
        app_id = appId;

        // Новый setup — снимаем метку деинициализации: пуши снова разрешены (для этой сессии).
        SharedPreferencesLib.saveBoolean(context, SharedPreferenceKeys.SDK_DEINITIALIZED, false);

        //TODO: validate input fields
        //service = libComponent.getCarrotService();
        if (service == null) {
            new CarrotSDK(context);
            service = libComponent.getCarrotService();
        }

        //String sUserAgent = UserAgent.Companion.getInstance(context).getUserAgentString(Version.userAgent);
        SharedPreferencesLib.saveString(context, "api_key", apiKey);
        SharedPreferencesLib.saveString(context, "app_id", appId);

        UserStateHolder.INSTANCE.restoreFromPrefs(context);

        //Инициализация Sentry для мониторинга ошибок
        SentryCQ_SDK.init(context);
        if (SdkStateManager.INSTANCE.isInit() || SdkStateManager.INSTANCE.isInitializing()) {
            if (callback != null) callback.onResponse(true);
        } else {
            try {
                service.init(apiKey, callback, startSession);
            } catch (Exception e) {
                Log.e(TAG, "service init error: " + e.toString());
            }
        }


        //Отправляем события о прочтениях рассылок, если такие (неотправленные) есть
        TrackHelperKt.syncPendingDeliveredPushes(context);

        if (networkReconnectRunnable == null) {
            networkReconnectHandler = new android.os.Handler(android.os.Looper.getMainLooper());
            networkReconnectRunnable = () -> {
                networkReconnectRunnable = null;
                NetworkManager.getInstance(context).addObserver(isConnect -> {
                    Log.d(TAG, "setup(...) 5");
                    if (isConnect) {
                        if (!Carrot.isInit() && !SdkStateManager.INSTANCE.isInitializing()) {
                            commonSetup(context, apiKey, callback, startSession);
                        } else {
                            // SDK формально Ready, но сессия могла деградировать (креды вычищены
                            // интерсептором после мёртвого refresh): сбрасываем кулдаун recovery,
                            // взведённый офлайн-попыткой, и лечим сразу, не дожидаясь нового 401.
                            CarrotService.getInstance().onNetworkRestored();
                        }
                        List<MessageData> errorMessages = GetErrorMessagesUseCaseKt.getAllErrorMessages();
                        if (!errorMessages.isEmpty()) {
                            SendErrorMessagesUseCaseKt.sendErrorMessages(errorMessages);
                        }
                        Log.d(TAG, "setup(...) 6");
                    }
                });
            };
            networkReconnectHandler.postDelayed(networkReconnectRunnable, 3000);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.TIRAMISU)
    private static void checkNotificationPermission(Context context){
        int checkRes = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS);
        if(checkRes != PackageManager.PERMISSION_GRANTED && context instanceof Activity) {
            //requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            ActivityCompat.requestPermissions((Activity) context,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    1);
        }
    }

    public static void setUserProperty(String key, String value) {
        SdkGlobalHandlers.safeVoid("setUserProperty", () -> {
            checkInitialization();
            service.setUserProperty(java.util.Collections.singletonList(new UserProperty(key, value)));
        });
    }

    public static void setUserProperty(Operation op, String key, String value) {
        SdkGlobalHandlers.safeVoid("setUserProperty(op)", () -> {
            checkInitialization();
            service.setUserProperty(java.util.Collections.singletonList(new UserProperty(op, key, value)));
        });
    }

    public static void setUserProperty(io.carrotquest_sdk.android.models.UserProperty userProperty) {
        SdkGlobalHandlers.safeVoid("setUserProperty(obj)", () -> {
            checkInitialization();
            service.setUserProperty(java.util.Collections.singletonList(userProperty), userPropertyObserver);
        });
    }


    public static void setNotificationIcon(int notificationIconId) {
        // Тихий no-op вместо краша: конфигурационный метод, клиент может вызвать его
        // до setup() — пусть запомнится и применится позже самим NotificationHelper,
        // а если DI ещё не готов, просто молча пропускаем.
        SdkLibComponent c = libComponent;
        if (c == null) {
            Log.e(TAG, "setNotificationIcon: SDK not initialized yet, skipped");
            return;
        }
        c.getNotificationHelper().setNotificationIcon(notificationIconId);
    }

    public static void setParentActivityClassName(String parentActivityClassName) {
        parentActivityClassNameImpl = parentActivityClassName;
        SdkLibComponent c = libComponent;
        if (c == null) {
            Log.e(TAG, "setParentActivityClassName: SDK not initialized yet, stored in memory only");
            return;
        }
        SharedPreferencesLib.saveString(c.getContextSdk(), "cq_parent_activity_class_name", parentActivityClassName);
    }

    public static String getParentActivityClassName() {
        if(parentActivityClassNameImpl != null && !parentActivityClassNameImpl.isEmpty()) {
            return parentActivityClassNameImpl;
        }
        SdkLibComponent c = libComponent;
        if (c == null) {
            return null;
        }
        return SharedPreferencesLib.getString(c.getContextSdk(), "cq_parent_activity_class_name");
    }

    public static void setUserProperty(List<io.carrotquest_sdk.android.models.UserProperty> userProperties) {
        SdkGlobalHandlers.safeVoid("setUserProperty(list)", () -> {
            checkInitialization();
            service.setUserProperty(userProperties, userPropertyObserver);
        });
    }

    public static void auth(String id, String userAuthKey) {
        auth(id, userAuthKey, null);
    }

    public static void auth(String id, String userAuthKey, Callback<String> callback) {
        if (android.text.TextUtils.isEmpty(id) || android.text.TextUtils.isEmpty(userAuthKey)) {
            IllegalArgumentException err = new IllegalArgumentException("auth(): id and userAuthKey must not be empty");
            if (callback != null) callback.onFailure(err);
            else Log.e(TAG, err.toString());
            return;
        }
        if (!ensureInitialized(callback)) return;
        if (AuthManager.INSTANCE.isAuthenticating()) return;
        AuthManager.INSTANCE.onAuthenticating();
        service.authUser(id, userAuthKey, new Callback<User>() {
            @Override
            public void onResponse(User user) {
                AuthManager.INSTANCE.onAuthenticated(user.getId() != null ? user.getId() : "");
                if (callback != null) callback.onResponse(user.getId());
                if (user != null) {
                    DialogViewModel.Companion.getInstance().updateCurrentConversationId("");
                    DialogViewModel.Companion.getInstance().setNeedStartRoutingBot(false);
                    DialogViewModel.Companion.getInstance().setRoutingBotId("");
                    ClearHistoryUseCaseKt.clearHistory();
                }
            }

            @Override
            public void onFailure(Throwable e) {
                AuthManager.INSTANCE.onFailed(e);
                if (callback != null) callback.onFailure(e);
            }
        });
    }


    public static void hashedAuth(String id, String hash) {
        hashedAuth(id, hash, null);
    }

    public static void hashedAuth(String id, String hash, Callback<String> callback) {
        if (android.text.TextUtils.isEmpty(id) || android.text.TextUtils.isEmpty(hash)) {
            IllegalArgumentException err = new IllegalArgumentException("hashedAuth(): id and hash must not be empty");
            if (callback != null) callback.onFailure(err);
            else Log.e(TAG, err.toString());
            return;
        }
        if (!ensureInitialized(callback)) return;
        if (AuthManager.INSTANCE.isAuthenticating()) return;
        AuthManager.INSTANCE.onAuthenticating();
        service.hashedAuth(id, hash, new Callback<User>() {
            @Override
            public void onResponse(User user) {
                AuthManager.INSTANCE.onAuthenticated(user.getId() != null ? user.getId() : "");
                if (callback != null) callback.onResponse(user.getId());
                if (user != null) {
                    DialogViewModel.Companion.getInstance().updateCurrentConversationId("");
                    DialogViewModel.Companion.getInstance().setNeedStartRoutingBot(false);
                    DialogViewModel.Companion.getInstance().setRoutingBotId("");
                    ClearHistoryUseCaseKt.clearHistory();
                }
            }

            @Override
            public void onFailure(Throwable e) {
                AuthManager.INSTANCE.onFailed(e);
                if (callback != null) callback.onFailure(e);
            }
        });
    }

    public static boolean isInit() {
        if (service != null) {
            return service.isInit();
        }
        return false;
    }

    public static void deInit() {
        SdkGlobalHandlers.safeVoid("deInit", () -> deInitInternal(null));
    }

    private static void deInitInternal(Callback<Boolean> callback) {
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            SdkStateManager.INSTANCE.onDeInit();
            AuthManager.INSTANCE.onDeInit();

            DialogViewModel.Companion.getInstance().updateCurrentConversationId("");
            DialogViewModel.Companion.getInstance().setNeedStartRoutingBot(false);
            DialogViewModel.Companion.getInstance().setRoutingBotId("");
            ClearHistoryUseCaseKt.clearHistory();

            if (unreadConversationsCancellable != null) {
                unreadConversationsCancellable.cancel();
                unreadConversationsCancellable = null;
            }
            if (networkReconnectRunnable != null && networkReconnectHandler != null) {
                networkReconnectHandler.removeCallbacks(networkReconnectRunnable);
            }
            networkReconnectRunnable = null;

            SaveAuthedUserIdUseCaseKt.saveConnectedUserIdUseCase("", libComponent.getContextSdk());
            SaveAuthedUserIdUseCaseKt.saveAuthedUserIdUseCase("", "", libComponent.getContextSdk());

            // Помечаем SDK деинициализированным (persist) — пуш-энтрипоинт дропает уведомления
            // предыдущего юзера, пока не произойдёт новый setup. Снимается в commonSetup.
            SharedPreferencesLib.saveBoolean(libComponent.getContextSdk(), SharedPreferenceKeys.SDK_DEINITIALIZED, true);

            // Убираем уже показанные уведомления предыдущего юзера из шторки.
            try {
                libComponent.getNotificationHelper().clearAllNotifications();
            } catch (Throwable t) {
                Log.e(TAG, "clearAllNotifications on deInit failed: " + t);
            }

            if (service != null) {
                service.deInit(() -> {
                    if (callback != null) callback.onResponse(true);
                });
                service = null;
            } else {
                if (callback != null) callback.onResponse(true);
            }



        });
    }

    public static void deInit(Callback<Boolean> callback) {
        try {
            deInitInternal(callback);
        } catch (Exception e) {
            callback.onFailure(e);
        }
    }

    public static void trackEvent(String eventName) {
        SdkGlobalHandlers.safeVoid("trackEvent", () -> {
            checkInitialization();
            service.trackEvent(eventName, null, eventsObserver);
        });
    }

    /**
     * Tracks an event with parameters. Build {@code params} with {@link EventParams#builder()} —
     * the SDK serializes it to JSON internally (don't pass a hand-written JSON string).
     *
     * @param eventName event name
     * @param eventParams typed parameters; {@code null}/empty sends the event without params
     */
    public static void trackEvent(String eventName, EventParams eventParams) {
        SdkGlobalHandlers.safeVoid("trackEvent(params)", () -> {
            checkInitialization();
            String paramsJson = (eventParams == null || eventParams.isEmpty())
                    ? null
                    : new com.google.gson.Gson().toJson(eventParams.getParams());
            service.trackEvent(eventName, paramsJson, eventsObserver);
        });
    }

    public static void trackUtm(String url) {
        SdkGlobalHandlers.safeVoid("trackUtm(url)", () -> {
            if(url == null) {
                return;
            }

            TrackHelperKt.trackUtm(url);

        });
    }

    public static void openChat(Context context) {
        SdkGlobalHandlers.safeVoid("openChat", () -> {
            if (context != null) {
                Intent intent = new Intent(context, io.carrotquest_sdk.android.presentation.container.SdkContainerActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    /**
     * Hands an incoming push payload to the SDK, which builds and displays the notification.
     * Call this from your push message handler (e.g. FCM's {@code onMessageReceived} or Huawei
     * Push Kit's {@code onMessageReceived}) once {@link #isCarrotPush(Map)} confirms the message
     * was sent through the SDK. If the SDK has not been initialized yet it sets itself up (without
     * opening a connection) so the push can still be shown.
     *
     * @param pushData the push data payload as a key-value map (e.g. {@code RemoteMessage.getData()}
     *                 on FCM or {@code RemoteMessage.getDataOfMap()} on Huawei Push Kit)
     * @param context  any valid context (used to self-initialize the SDK when needed)
     */
    public static void sendPushNotification(Map<String, String> pushData, Context context) {
        SdkGlobalHandlers.safeVoid("sendPushNotification", () -> {
            if (Carrot.isInit()) {
                if (CarrotInternal.getLibComponent() != null) {
                    CarrotInternal.getLibComponent().getNotificationHelper().postNotification(pushData);
                }
            } else {
                buildComponentsWithoutConnect(context);
                try {
                    PushNotificationHelper.getInstance().postNotification(pushData);
                } catch (Exception e){
                    Log.e(TAG, new Exception("postNotification(...) error. Result = " + e.toString()));
                }
            }
        });
    }

    /**
     * Registers the device's push token with the SDK backend so it can deliver push
     * notifications to this device. Call it whenever a new token is issued (e.g. FCM's
     * {@code onNewToken} or Huawei Push Kit's token callback) and after a successful
     * authentication. The token is only sent while system notifications are enabled for the app.
     *
     * @param token the current push registration token (FCM or Huawei Push Kit)
     */
    public static void sendPushToken(String token) {
        try {
            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(CarrotInternal.getLibComponent().getContextSdk());
            if(notificationManager.areNotificationsEnabled()) {
                String deviceId = AndroidUtils.getInstallId(CarrotInternal.getLibComponent().getContextSdk());
                String userId = CarrotInternal.getLibComponent().getUserRepository().getUser().getId();
                service.sendPushToken(userId, token, deviceId);
            }
        } catch (Exception e) {
            Log.e(TAG, e);
        }
    }

    public static String getVersion() {
        return VERSION;
    }


    public static void setTheme(ThemeSdk theme) {
        mTheme = theme;
    }

    public static ThemeSdk getTheme() {
        return mTheme;
    }

    private static void checkInitialization() {
        if (service == null) {
            String textError = "Carrot is not init. Call setup(contex,apiKey) first.";
            Log.e(TAG, textError);
            throw new RuntimeException(textError);
        }
    }

    /**
     * Non-throwing init guard for async public methods. If the SDK is not initialized, reports the
     * failure through {@code callback.onFailure(...)} when a callback is present (otherwise logs)
     * and returns {@code false}. Keeps such methods compliant with the "never throw at the caller"
     * contract — unlike {@link #checkInitialization()}, which throws and is only used by the
     * documented throwing method {@link #getUnreadConversations()}.
     */
    private static boolean ensureInitialized(@Nullable Callback<?> callback) {
        if (service != null) return true;
        IllegalStateException error = new IllegalStateException("Carrot is not initialized. Call setup(...) first.");
        if (callback != null) callback.onFailure(error);
        else Log.e(TAG, error.toString());
        return false;
    }


    /**
     * Sets the SDK log level. Defaults to {@link SdkLogLevel#NONE} — the SDK logs nothing. Raise
     * it (e.g. to {@link SdkLogLevel#DEBUG}) to see key internal events in logcat. Replaces the
     * removed setDebug(boolean) (see MIGRATION_3.0.0).
     */
    public static void setLogLevel(SdkLogLevel level) {
        SdkLogger.setLevel(level);
    }

    /**
     * Registers a sink that receives the SDK's {@link SdkLogEntry} records — pipe them into your
     * own logger or crash reporter. Pass {@code null} to remove it. Independent of logcat output,
     * which stays on whenever the log level is above NONE. Only entries at or below the configured
     * {@link #setLogLevel(SdkLogLevel)} are delivered.
     */
    public static void setLogSink(@Nullable SdkLogSink sink) {
        SdkLogger.setSink(sink);
    }

    /**
     * Controls whether sensitive values (auth tokens, lead identifiers, e-mails) appear in logs in
     * full. Defaults to {@code false} — such values are masked. Enable only for local debugging.
     */
    public static void setLogIncludeSensitive(boolean include) {
        SdkLogger.setIncludeSensitive(include);
    }

    /**
     * Returns a point-in-time {@link SdkDiagnostics} snapshot (SDK version, init/auth state, lead
     * id, connectivity, theme, …) — handy to print or attach to a support ticket. Works regardless
     * of the log level; sensitive fields are masked unless {@link #setLogIncludeSensitive(boolean)}
     * is enabled.
     */
    @NonNull
    public static SdkDiagnostics getDiagnostics() {
        return SdkDiagnostics.capture();
    }


    // Rx убран (ветка remove_rx): подписка на непрочитанные → Kotlin observeUnreadConversationIds
    // (корутины, Cancellable); отложенный реконнект → Handler.postDelayed.
    private static io.carrotquest_sdk.android.core.Cancellable unreadConversationsCancellable;
    private static android.os.Handler networkReconnectHandler;
    private static Runnable networkReconnectRunnable;
    public static void setUnreadConversationsCallback(Callback<List<String>> callback) {
        unreadConversationsCancellable = GetConversationsUseCaseKt.observeUnreadConversationIds(callback);
    }

    /**
     * Returns the ids of conversations with unread messages. <b>This is the one public method that
     * throws</b> (an intentional exception to the SDK-wide "never throw at the caller" contract):
     * call it inside a try/catch. Requires the SDK to be initialized and authenticated.
     *
     * @throws CarrotException if the user/repository is unavailable (e.g. not yet authenticated)
     */
    public static List<String> getUnreadConversations() throws CarrotException {
        checkInitialization();

        if (CarrotInternal.getLibComponent().getUserRepository() == null) {
            throw new CarrotRepositoryException("User repository is empty");
        }

        if (CarrotInternal.getLibComponent().getUserRepository().getUser() == null) {
            throw new CarrotUserException("User not found");
        }

        ArrayList<DataConversation> convs = ConversationsRepository.Companion.getInstance().getConversationsSync();
        ArrayList<String> res = new ArrayList<>();

        for(DataConversation entity : convs) {
            if(ConversationUtilsKt.recipientTypeIsRight(entity.getRecipientType())
                    && entity.getUnreadPartsCount() > 0 && entity.getId() != null) {
                res.add(entity.getId());
            }
        }

        return res;
    }



//    public static String getPushActionUrl(RemoteMessage remoteMessage) {
//        return SdkGlobalHandlers.safeCall("getPushActionUrl", null, () -> {
//            if (remoteMessage == null) return null;
//            Map<String, String> data = remoteMessage.getData();
//            if (data == null) return null;
//            if (data.containsKey(NotificationsConstants.CQ_SDK_PUSH) && "false".equals(data.get(NotificationsConstants.CQ_SDK_PUSH))) {
//                if (data.containsKey(NotificationsConstants.CQ_SDK_PUSH_BODY_JSON)) {
//                    String bodyJsonStr = data.get(NotificationsConstants.CQ_SDK_PUSH_BODY_JSON);
//                    if (bodyJsonStr == null) {
//                        bodyJsonStr = "{}";
//                    }
//                    JsonElement bodyJsonJson = JsonParser.parseString(bodyJsonStr);
//                    if (bodyJsonJson != null && bodyJsonJson.isJsonObject()) {
//                        JsonObject bodyJsonJsonObject = bodyJsonJson.getAsJsonObject();
//                        if (bodyJsonJsonObject != null
//                                && bodyJsonJsonObject.has(NotificationsConstants.CQ_SDK_PUSH_CLICK_ACTION)) {
//                            JsonElement action = bodyJsonJsonObject.get(NotificationsConstants.CQ_SDK_PUSH_CLICK_ACTION);
//                            if (action != null && action.isJsonPrimitive()) {
//                                return action.getAsString();
//                            }
//                        }
//                    }
//                }
//            }
//            return null;
//        });
//    }

    /**
     * Returns {@code true} if the given push payload was sent through the SDK. Use it in your
     * push message handler (FCM or Huawei Push Kit) to decide whether to forward the message to
     * {@link #sendPushNotification(Map, Context)}; other pushes should be handled by your own code.
     *
     * @param pushData the push data payload as a key-value map (e.g. {@code RemoteMessage.getData()}
     *                 on FCM or {@code RemoteMessage.getDataOfMap()} on Huawei Push Kit)
     */
    public static boolean isCarrotPush(Map<String, String> pushData) {
        return SdkGlobalHandlers.safeCall("isCarrotPush(map)", false,
                () -> pushData != null && pushData.containsKey(NotificationsConstants.CQ_SDK_PUSH));
    }

    /**
     * Returns {@code true} if the push is an auto-message (a triggered campaign sent
     * automatically), as opposed to a manual message from an operator. Only meaningful for payloads
     * for which {@link #isCarrotPush(Map)} is {@code true}.
     *
     * @param pushData the push data payload as a key-value map (e.g. {@code RemoteMessage.getData()}
     *                 on FCM or {@code RemoteMessage.getDataOfMap()} on Huawei Push Kit)
     */
    public static boolean isAutoMessage(Map<String, String> pushData) {
        return SdkGlobalHandlers.safeCall("isAutoMessage(map)", false,
                () -> pushData != null && pushData.containsKey(NotificationsConstants.CQ_SDK_PUSH) && pushData.containsKey(NotificationsConstants.CQ_SDK_SENT_VIA)
                        && NotificationsConstants.CQ_SDK_AUTO_MESSAGE.equals(pushData.get(NotificationsConstants.CQ_SDK_SENT_VIA)));
    }

    /**
     * Opts the current user out of all push notifications from the SDK. The choice is stored
     * locally and synced to the backend as a user property, so it persists across sessions.
     * Requires the SDK to be initialized.
     */
    public static void pushNotificationsUnsubscribe() {
        SdkGlobalHandlers.safeVoid("pushNotificationsUnsubscribe", () -> {
            checkInitialization();
            setUserProperty("$sdk_push_notifications_subscribed", "false");

            String key = SharedPreferenceKeys.SDK_PUSH_NOTIFICATIONS_UNSUBSCRIBED;
            SharedPreferencesLib.saveBoolean(CarrotLib.getLibComponents().getContext(), key, true);
        });
    }

    /**
     * Opts the current user out of push campaigns (triggered auto-messages) only, while leaving
     * other push notifications enabled. The choice is stored locally and synced to the backend as a
     * user property. Requires the SDK to be initialized.
     */
    public static void pushCampaignsUnsubscribe() {
        SdkGlobalHandlers.safeVoid("pushCampaignsUnsubscribe", () -> {
            checkInitialization();
            setUserProperty("$sdk_push_campaigns_subscribed", "false");

            String key = SharedPreferenceKeys.SDK_PUSH_CAMPAIGNS_UNSUBSCRIBED;
            SharedPreferencesLib.saveBoolean(CarrotLib.getLibComponents().getContext(), key, true);
        });
    }

    public static boolean isUseEuApi() {
        return isUseEuApi;
    }

    public static void  setCloseChatCallback(Callback<Boolean> callback) {
        CarrotInternal.updateCloseChatCallback(callback);
    }

    public static void trackScreen(String screenName) {
        SdkGlobalHandlers.safeVoid("trackScreen", () -> {
            TrackScreenUseCase trackScreenUseCase = new TrackScreenUseCase();
            trackScreenUseCase.call(screenName);
        });
    }
}
