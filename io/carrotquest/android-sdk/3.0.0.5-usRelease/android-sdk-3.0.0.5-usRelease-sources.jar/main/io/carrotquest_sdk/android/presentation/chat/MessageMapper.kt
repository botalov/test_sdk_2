package io.carrotquest_sdk.android.presentation.chat

import android.webkit.URLUtil
import com.google.gson.JsonParser
import com.vdurmont.emoji.EmojiParser
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.use_cases.agreements.RequestedContactField
import io.carrotquest_sdk.android.domain.use_cases.agreements.buildConsentState
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object MessageMapper {

    private fun String.parseEmoji(): String = EmojiParser.parseToUnicode(this)

    // Список отсортирован по убыванию (новейшие первыми) для reverseLayout = true.
    // DateDivider вставляется ПОСЛЕ последнего (старейшего) сообщения каждого дня,
    // чтобы при визуальном рендеринге снизу вверх разделитель оказался над сообщениями дня.
    fun map(messages: List<MessageData>, db: CarrotSdkDB): List<ChatListItem> {
        val grouped = messages.groupBy { it.id ?: it.randomId }
        // Сортировка для reverseLayout=true (index 0 = низ экрана = новейшее): по created
        // убыванию, а внутри одной секунды (пак бота присылается одной секундой) — по id.
        // id сообщений — снежинки, монотонно растущие со временем, поэтому это надёжный
        // вторичный ключ. Порядок в repo НЕ используем: при bulk-загрузке истории с сервера
        // он обратный/произвольный, в отличие от живого append.
        // m.sortKey (если задан) имеет приоритет: оптимистичные исходящие получают
        // sortKey = maxId+1 (см. DialogPresenter.sendActionBot), чтобы внутри одной
        // секунды встать строго после текущего последнего сообщения и перед будущими
        // серверными (у тех снежинки больше). У серверных sortKey == null → берём id.
        fun sortKey(m: MessageData): Long =
            m.sortKey ?: m.id?.toLongOrNull() ?: m.randomId?.toLongOrNull() ?: 0L
        val sorted = grouped.values
            .mapNotNull { group -> group.firstOrNull { it.removed.isNullOrEmpty() } }
            .sortedWith(
                compareByDescending<MessageData> { it.created?.toLongOrNull() ?: 0L }
                    .thenByDescending { sortKey(it) }
            )

        val result = mutableListOf<ChatListItem>()
        var lastDayKey: String? = null
        var pendingDivider: ChatListItem.DateDivider? = null

        // Кнопки активны только у самого свежего сообщения (sorted[0]). Прошлые ветки уже
        // отвечены (пользователь продвинулся дальше) — их кнопки схлопываются.
        val newestKey = sorted.firstOrNull()?.let { it.id ?: it.randomId }

        for (msg in sorted) {
            val timestampMs = (msg.created?.toLongOrNull() ?: 0L) * 1000L
            val dateEntry = dateLabelFor(timestampMs)
            val currentDayKey = dateEntry?.first

            if (currentDayKey != lastDayKey) {
                // Сбросить накопленный разделитель предыдущего дня
                pendingDivider?.let { result += it }
                pendingDivider = dateEntry?.let { (_, label) -> ChatListItem.DateDivider(label) }
                lastDayKey = currentDayKey
            }

            val isNewest = (msg.id ?: msg.randomId) == newestKey
            result += toListItems(msg, db, isNewest)
        }
        // Разделитель самого старого дня — окажется в самом верху списка
        pendingDivider?.let { result += it }

        return result
    }

    private fun toListItems(msg: MessageData, db: CarrotSdkDB, isNewest: Boolean): List<ChatListItem> {
        // Диагностика: сообщения бота с полем ввода (property_field). Встроенная карточка ввода
        // рендерится только при msg.type == AUTO_REPLY (см. autoReplyItems); по этому логу видно,
        // с каким type/replyType реально приходит вопрос-телефон в падающем кейсе.
        if (msg.actions?.any { it.type == "property_field" } == true) {
            Log.d("CQ_BotInput", "map property_field msg: type=${msg.type} replyType=${msg.replyType} id=${msg.id} isNewest=$isNewest")
        }
        val items = when (msg.type) {
            ResponseFields.TYPING     -> listOf(TypingIndicator(msg))
            ResponseFields.VOTE       -> listOf(VoteCard(msg))
            ResponseFields.AUTO_REPLY -> autoReplyItems(msg, db, isNewest)
            ResponseFields.REPLY_USER -> {
                val outgoing = regularMessage(msg, Direction.OUTGOING, db)
                // Гард на полностью пустое сообщение (ни текста, ни вложений): такие
                // рождались из FailSendingMessage-записей без attach-меты (до v27) —
                // пустой исходящий бабл не рисуем.
                val content = outgoing.content as? MessageContent.TextContent
                if (content != null && content.body.isEmpty() && content.attachments.isEmpty()) {
                    emptyList()
                } else {
                    listOf(outgoing)
                }
            }
            ResponseFields.REPLY_ADMIN -> listOf(replyAdmin(msg, db))
            ResponseFields.ARTICLE -> listOf(articleMessage(msg))
            // Ответ пользователя боту + возможная следующая ветка с кнопками
            ResponseFields.CHAT_BOT_USER -> chatBotUserMessage(msg, db, isNewest)
            // Сообщение от бота к пользователю (следующая ветка с кнопками/текстом/полем ввода)
            ResponseFields.CHAT_BOT_ADMIN -> autoReplyItems(msg, db, isNewest)
            else -> {
                val actions = msg.actions ?: emptyList()
                when {
                    actions.any { it.type == "button" || it.type == "meet" } ->
                        botMessageWithOptions(msg, db, isNewest)
                    actions.any { it.type == "property_field" || it.type == "text" } ->
                        listOf(regularMessage(msg, Direction.INCOMING, db))
                    msg.direction == ResponseFields.ADMIN_2_USER ->
                        listOf(regularMessage(msg, Direction.INCOMING, db))
                    else -> listOf(unknownMessage(msg))
                }
            }
        }
        // Помечаем сообщения, порождённые ботом (для автоскролла: на бот-сообщение всегда к низу).
        // Централизованно, чтобы не тянуть флаг через каждый билдер.
        return if (isBotOrigin(msg)) {
            items.map { (it as? ChatListItem.Message)?.copy(isBot = true) ?: it }
        } else {
            items
        }
    }

    // Сообщение порождено ботом (а не оператором/пользователем): тип бота либо блок с actions.
    private fun isBotOrigin(msg: MessageData): Boolean = when (msg.type) {
        ResponseFields.AUTO_REPLY,
        ResponseFields.CHAT_BOT_ADMIN,
        ResponseFields.CHAT_BOT_USER,
        ResponseFields.VOTE,
        ResponseFields.ARTICLE -> true
        ResponseFields.REPLY_ADMIN, ResponseFields.REPLY_USER -> false
        else -> msg.actions?.any { it.type == "button" || it.type == "meet" || it.type == "property_field" } == true
    }

    // chat_bot_user: ответ пользователя (answerBody) + следующая ветка бота (actions)
    private fun chatBotUserMessage(msg: MessageData, db: CarrotSdkDB, isNewest: Boolean): List<ChatListItem> {
        val result = mutableListOf<ChatListItem>()

        // Исходящий бабл с ответом пользователя
        val answerBody = (msg.messageMetaData?.answerBody?.takeIf { it.isNotBlank() } ?: msg.body ?: "").parseEmoji()
        if (answerBody.isNotBlank()) {
            val attachments = msg.attachments?.mapNotNull { attachment(it, db) } ?: emptyList()
            result += ChatListItem.Message(
                id = msg.id ?: "",
                direction = Direction.OUTGOING,
                sender = null,
                timestampMs = timestampMs(msg),
                deliveryStatus = deliveryStatus(msg),
                content = MessageContent.TextContent(body = answerBody, attachments = attachments),
            )
        }

        // Следующая ветка: контентные блоки (текст и/или вложения) и кнопки от бота
        val actions = msg.actions ?: emptyList()
        val contentActions = botContentActions(actions)
        val buttonActions = actions.filter { it.type == "button" || it.type == "meet" }

        for (action in contentActions) {
            botContentMessage(msg, action, db)?.let { result += it }
        }

        // Группу кнопок показываем ТОЛЬКО пока ответ ещё не известен (answerBody пуст): активный
        // шаг — тапабельные кнопки, либо локально отвеченный — схлопнутый выбор. Как только пришёл
        // answerBody, ответ уже показан исходящим пузырём выше — повторная группа с выбранной
        // кнопкой дублировала бы его (баг дубля «Закрыть» после перезагрузки на resume).
        if (buttonActions.isNotEmpty() && answerBody.isBlank()) {
            // Кнопки активны только у самой свежей ветки; прошлые — уже отвечены.
            result += ChatListItem.BotOptionsGroup(
                messageId = msg.id ?: "",
                options = botOptions(buttonActions),
                isAnswered = !isNewest,
            )
        }

        // reverseLayout=true: меньший индекс → ниже визуально, поэтому группу переворачиваем
        return result.reversed()
    }

    // Ссылка, зашитая в кнопку бота, лежит в body_json экшена. Точный ключ зависит от
    // конфигурации, поэтому пробуем типичные варианты.
    private fun actionLink(action: ActionMessage): String? {
        val obj = action.bodyJson?.takeIf { it.isJsonObject }?.asJsonObject ?: return null
        for (key in listOf("url", "href", "target", "link", "target_url")) {
            val v = obj.get(key)?.takeIf { it.isJsonPrimitive }?.asString
            if (!v.isNullOrBlank() && v.lowercase() != "undefined") return v
        }
        return null
    }

    private fun botOptions(buttonActions: List<ActionMessage>): List<BotOption> =
        buttonActions.map {
            BotOption(
                id = it.id ?: "",
                branchId = it.nextBranchId,
                text = (it.body ?: "").parseEmoji(),
                link = actionLink(it),
            )
        }

    private fun TypingIndicator(msg: MessageData) = ChatListItem.TypingIndicator(
        name = msg.messageFrom?.name,
        avatarUrl = msg.messageFrom?.avatar?.takeIf { it.isNotBlank() } ?: defaultMessengerAvatar(),
    )

    private fun VoteCard(msg: MessageData): ChatListItem.VoteCard {
        val score = msg.messageMetaData?.vote
        return ChatListItem.VoteCard(
            messageId = msg.id ?: "",
            voteState = if (score != null) VoteState.Rated(score) else VoteState.Pending,
            questionText = (msg.body ?: "").parseEmoji(),
        )
    }

    private fun autoReplyItems(msg: MessageData, db: CarrotSdkDB, isNewest: Boolean): List<ChatListItem> {
        val actions = msg.actions
        return when {
            !actions.isNullOrEmpty() && actions.any { it.type == "button" || it.type == "meet" } ->
                botMessageWithOptions(msg, db, isNewest)
            msg.messageMetaData?.vote != null -> listOf(VoteCard(msg))
            !actions.isNullOrEmpty() && actions.any { it.type == "property_field" }
                    && msg.type == ResponseFields.AUTO_REPLY ->
                listOf(contactInputMessage(msg, actions.first { it.type == "property_field" }))
            !msg.replyType.isNullOrEmpty() && msg.type == ResponseFields.AUTO_REPLY ->
                listOf(replyTypeInputMessage(msg))
            // Бот-блоки с вложениями без кнопок: regularMessage мапит только msg.attachments,
            // а вложения лежат на action — иначе картинка/файл такого блока не покажется.
            !actions.isNullOrEmpty() && botContentActions(actions).any { !it.attachments.isNullOrEmpty() } ->
                botMessageWithOptions(msg, db, isNewest)
            else -> listOf(regularMessage(msg, Direction.INCOMING, db))
        }
    }

    // Тип запрашиваемого контакта для блока согласия. NAME/TEXT согласия на хранение контакта
    // не требуют (строку подписки не показываем), но согласие на обработку перс. данных может
    // показаться и для них (решает настройка data_processing_policy).
    private fun requestedFieldFor(inputType: ContactInputType): RequestedContactField = when (inputType) {
        ContactInputType.EMAIL -> RequestedContactField.EMAIL
        ContactInputType.PHONE -> RequestedContactField.PHONE
        ContactInputType.NAME, ContactInputType.TEXT -> RequestedContactField.NONE
    }

    // Блок согласия строим только пока ответа ещё нет (Idle): после отправки поле сменяется
    // «Спасибо», согласие уже не нужно. Чекбоксы стартуют неотмеченными (см. buildConsentState),
    // их состояние далее держит ChatViewModel (localConsentChecked).
    private fun consentFor(inputType: ContactInputType, state: ContactInputState) =
        if (state is ContactInputState.Idle)
            buildConsentState(requestedFieldFor(inputType)).takeIf { it.isVisible }
        else null

    private fun replyTypeInputMessage(msg: MessageData): ChatListItem.Message {
        val inputType = when (msg.replyType) {
            "email"              -> ContactInputType.EMAIL
            "phone", "phone_mask" -> ContactInputType.PHONE
            "name"               -> ContactInputType.NAME
            else                 -> ContactInputType.TEXT
        }
        val state = if (msg.messageMetaData?.replied == true)
            ContactInputState.Submitted(msg.messageMetaData?.answerBody ?: "")
        else
            ContactInputState.Idle
        return ChatListItem.Message(
            id = msg.id ?: "",
            direction = Direction.INCOMING,
            sender = sender(msg),
            timestampMs = timestampMs(msg),
            deliveryStatus = null,
            content = MessageContent.ContactInputContent(
                body = (msg.body ?: "").parseEmoji(),
                placeholder = null,
                inputType = inputType,
                state = state,
                consent = consentFor(inputType, state),
            ),
        )
    }

    private fun contactInputMessage(msg: MessageData, action: ActionMessage): ChatListItem.Message {
        val placeholderObj = action.placeholder
        val inputType = when (placeholderObj?.type) {
            "email"                -> ContactInputType.EMAIL
            "phone", "phone_mask"  -> ContactInputType.PHONE
            "name"                 -> ContactInputType.NAME
            else                   -> ContactInputType.TEXT
        }
        val placeholderText = if (placeholderObj?.type == "custom") placeholderObj.value else null
        val state = if (msg.messageMetaData?.replied == true)
            ContactInputState.Submitted(msg.messageMetaData?.answerBody ?: "")
        else
            ContactInputState.Idle
        return ChatListItem.Message(
            id = msg.id ?: "",
            direction = Direction.INCOMING,
            sender = sender(msg),
            timestampMs = timestampMs(msg),
            deliveryStatus = null,
            content = MessageContent.ContactInputContent(
                body = (msg.body ?: "").parseEmoji(),
                placeholder = placeholderText,
                inputType = inputType,
                state = state,
                consent = consentFor(inputType, state),
            ),
        )
    }

    private fun replyAdmin(msg: MessageData, db: CarrotSdkDB): ChatListItem {
        if (msg.hasKBLink == true) {
            val bodyUrl = msg.bodyJson
                ?.takeIf { it.isJsonObject }
                ?.asJsonObject?.get("url")
                ?.takeIf { !it.isJsonNull }
                ?.asString ?: ""
            // Welcome-сообщение создаётся без bodyJson (createWelcomeMessage), поэтому url пустой →
            // fallback на домашнюю страницу базы знаний, иначе кнопка «Открыть статью» мёртвая.
            // Серверные reply_admin KB-ссылки несут bodyJson.url и fallback не задевает.
            val url = bodyUrl.ifBlank { buildKbHomeUrl() }
            return ChatListItem.Message(
                id = msg.id ?: "",
                direction = Direction.INCOMING,
                sender = sender(msg),
                timestampMs = timestampMs(msg),
                deliveryStatus = null,
                content = MessageContent.ArticleLinkContent(
                    name = (msg.body ?: "").parseEmoji(),
                    shortDescription = null,
                    url = url,
                ),
            )
        }
        return regularMessage(msg, Direction.INCOMING, db)
    }

    private fun articleMessage(msg: MessageData): ChatListItem.Message {
        val bodyJson = msg.bodyJson?.takeIf { it.isJsonObject }?.asJsonObject
        val name = bodyJson?.get("name")?.takeIf { !it.isJsonNull }?.asString?.takeIf { it.isNotBlank() } ?: ""
        val shortDescription = bodyJson?.get("short_description")?.takeIf { !it.isJsonNull }?.asString?.takeIf { it.isNotBlank() }
        val articleId = msg.body?.trim() ?: ""
        return ChatListItem.Message(
            id = msg.id ?: "",
            direction = Direction.INCOMING,
            sender = sender(msg),
            timestampMs = timestampMs(msg),
            deliveryStatus = null,
            content = MessageContent.ArticleLinkContent(
                name = name,
                shortDescription = shortDescription,
                url = buildArticleUrl(articleId),
            ),
        )
    }

    // Домашняя страница базы знаний (knowledge_base_domain из настроек). "" — если домена нет.
    private fun buildKbHomeUrl(): String = normalizeKbHomeUrl(rawKbDomain())

    private fun buildArticleUrl(articleId: String): String = buildKbArticleUrl(rawKbDomain(), articleId)

    // Сырой knowledge_base_domain из sourceData настроек (без нормализации). null — если нет.
    private fun rawKbDomain(): String? = runCatching {
        val sourceData = SettingsRepository.getInstance().getLastSettings()?.sourceData ?: return@runCatching null
        val json = JsonParser.parseString(sourceData)?.takeIf { it.isJsonObject }?.asJsonObject ?: return@runCatching null
        json.get("knowledge_base_domain")?.takeIf { !it.isJsonNull }?.asString
    }.getOrNull()

    // Нормализация домена базы знаний в URL главной страницы (протокол + без хвостового '/').
    // Чистая (без синглтонов) — покрыта MessageMapperKbUrlTest.
    internal fun normalizeKbHomeUrl(rawDomain: String?): String {
        val raw = rawDomain?.takeIf { it.isNotBlank() } ?: return ""
        return when {
            raw.startsWith("http://") || raw.startsWith("https://") -> raw
            raw.startsWith("//") -> "https:$raw"
            else -> "https://$raw"
        }.trimEnd('/')
    }

    // URL конкретной статьи базы знаний. "" — если нет articleId или домена. Чистая — покрыта тестом.
    internal fun buildKbArticleUrl(rawDomain: String?, articleId: String): String {
        if (articleId.isBlank()) return ""
        val home = normalizeKbHomeUrl(rawDomain)
        return if (home.isBlank()) "" else "$home/article/$articleId"
    }

    // Контентные блоки бота: текст и/или вложения. Картинки/файлы/голос у бота приходят как
    // attachments на action (нередко с ПУСТЫМ body), поэтому фильтровать по непустому тексту
    // нельзя — иначе блок с картинкой пропадает (виден только после переоткрытия, когда сообщение
    // приходит обычным reply_admin с msg.attachments). Кнопки/поля ввода сюда не попадают.
    private fun botContentActions(actions: List<ActionMessage>): List<ActionMessage> =
        actions.filter {
            (it.type == "text" || !it.attachments.isNullOrEmpty()) &&
                it.type != "button" && it.type != "meet" && it.type != "property_field"
        }

    private fun botContentMessage(msg: MessageData, action: ActionMessage, db: CarrotSdkDB): ChatListItem.Message? {
        val body = action.body?.trim()?.parseEmoji().orEmpty()
        val attachments = action.attachments?.mapNotNull { attachment(it, db) } ?: emptyList()
        if (body.isEmpty() && attachments.isEmpty()) return null
        return ChatListItem.Message(
            // Префикс "bot_" уводит синтетический id контентного блока в отдельное пространство
            // имён — реальные message.id числовые (снежинки), поэтому коллизия исключена.
            id = "bot_${msg.id}_${action.id}",
            direction = Direction.INCOMING,
            sender = sender(msg),
            timestampMs = timestampMs(msg),
            deliveryStatus = null,
            content = MessageContent.TextContent(body = body, attachments = attachments),
        )
    }

    private fun botMessageWithOptions(msg: MessageData, db: CarrotSdkDB, isNewest: Boolean): List<ChatListItem> {
        val actions = msg.actions ?: emptyList()
        val contentActions = botContentActions(actions)
        val buttonActions = actions.filter { it.type == "button" || it.type == "meet" }

        val result = mutableListOf<ChatListItem>()

        // Несколько контентных блоков (текст и/или вложения) от бота идут перед кнопками
        for (action in contentActions) {
            botContentMessage(msg, action, db)?.let { result += it }
        }

        // Основной body/вложения сообщения (если нет отдельных контентных блоков)
        if (contentActions.isEmpty()) {
            val incoming = regularMessage(msg, Direction.INCOMING, db)
            val content = incoming.content as? MessageContent.TextContent
            if (content != null && (content.body.isNotBlank() || content.attachments.isNotEmpty())) {
                result += incoming
            }
        }

        if (buttonActions.isNotEmpty()) {
            // Активны кнопки только у самой свежей ветки; прошлые/отвеченные — схлопнуты.
            val isAnswered = msg.messageMetaData?.replied == true || !isNewest
            result += ChatListItem.BotOptionsGroup(
                messageId = msg.id ?: "",
                options = botOptions(buttonActions),
                isAnswered = isAnswered,
            )
        }

        // reverseLayout=true: меньший индекс → ниже визуально, поэтому группу переворачиваем
        return result.reversed()
    }

    private fun regularMessage(msg: MessageData, direction: Direction, db: CarrotSdkDB): ChatListItem.Message {
        val attachments = msg.attachments?.mapNotNull { attachment(it, db) } ?: emptyList()
        return ChatListItem.Message(
            id = msg.id ?: "",
            direction = direction,
            sender = if (direction == Direction.INCOMING) sender(msg) else null,
            timestampMs = timestampMs(msg),
            deliveryStatus = if (direction == Direction.OUTGOING) deliveryStatus(msg) else null,
            content = MessageContent.TextContent(body = (msg.body ?: "").parseEmoji(), attachments = attachments),
        )
    }

    private fun unknownMessage(msg: MessageData) = ChatListItem.Message(
        id = msg.id ?: "",
        direction = if (msg.direction == ResponseFields.ADMIN_2_USER) Direction.INCOMING else Direction.OUTGOING,
        sender = null,
        timestampMs = timestampMs(msg),
        deliveryStatus = null,
        content = MessageContent.UnknownContent(msg.type),
    )

    private fun isVoice(att: Attachment): Boolean =
        att.type == "voice" || att.mimeType?.startsWith("audio/") == true

    private fun attachment(att: Attachment, db: CarrotSdkDB): UiAttachment? {
        val url = att.url
        val mime = att.mimeType
        val saved = url?.let { db.savedFileDao().getByURL(it) }
        // Голосовое — отдельный тип вложения ("voice" / audio/*), рисуется плеером.
        // Локальную копию из SavedFile берём, ТОЛЬКО пока файл реально существует: доставленный
        // голос подчищается orphan-sweep'ом на старте SDK (cleanupVoiceFiles), и маппинг
        // начинает указывать на удалённый путь — на нём MediaPlayer молчал (плеер немой). Тогда
        // стримим серверный http-URL (=ключ маппинга). Сырой url (локальный путь только что
        // записанного/упавшего голоса) отдаём как есть — файл на диске, стримить нечего.
        if (isVoice(att)) {
            val localUri = saved?.localUri?.takeIf { File(it).exists() }
            val model = localUri ?: url ?: return dropAttachment(att)
            return UiAttachment.VoiceAttachment(url = model)
        }
        // Картинка — если mime image/* ИЛИ вложение помечено type="image". При старте диалога
        // отправкой картинки mime может оказаться не image/*, но type выставлен в "image"
        // (см. createConversationByFile/sendMessageWithAttachment) — иначе рисовалось бы как файл.
        // TIFF Android/Coil не декодирует — такое вложение рисуем файловой карточкой.
        val isTiff = mime == "image/tiff" || mime == "image/tif"
        val isImage = !isTiff && (mime?.startsWith("image/") == true || att.type == "image")
        if (isImage) {
            // Для рендера берём локальный файл, только пока он реально существует (только что
            // отправленная картинка хранит локальный путь в url, скачанная — в SavedFile.localUri),
            // иначе — серверный URL. Путь превращаем в file-URI через File.toURI(): он кодирует
            // спецсимволы в имени ('#', '%', пробелы), голая конкатенация "file://$path" их ломала.
            val localPath = (saved?.localUri ?: url?.takeIf { it.startsWith("/") })
                ?.takeIf { File(it).exists() }
            val remoteUrl = url?.takeIf { !it.startsWith("/") }
            return when {
                localPath != null -> UiAttachment.ImageAttachment(
                    url = File(localPath).toURI().toString(),
                    fallbackUrl = remoteUrl,
                )
                remoteUrl != null -> UiAttachment.ImageAttachment(url = remoteUrl)
                else              -> dropAttachment(att)
            }
        }
        if (url == null) return dropAttachment(att)
        return UiAttachment.FileAttachment(
            id = att.id ?: "",
            name = att.filename ?: att.id ?: "",
            mimeType = mime ?: "",
            size = att.size,
            url = url,
            downloadState = if (saved != null) DownloadState.Downloaded(saved.localUri)
                            else DownloadState.NotDownloaded,
        )
    }

    // Вложение без единого источника (нет ни живого локального файла, ни серверного URL)
    // отрисовать нечем — дропаем, но со следом в диагностике вместо молчаливой «дырки».
    private fun dropAttachment(att: Attachment): UiAttachment? {
        SdkLogger.log(
            SdkLogLevel.WARN, SdkLogCategory.GENERAL, "MessageMapper",
            "attachment dropped: no renderable source (id=${att.id}, type=${att.type}, mime=${att.mimeType})",
        )
        return null
    }

    private fun sender(msg: MessageData): Sender {
        val from = msg.messageFrom
        // У бот-веток (и прочих системных сообщений) avatar часто пустой → вместо серого
        // плейсхолдера подставляем дефолтный аватар мессенджера из настроек (как в welcome).
        val avatar = from?.avatar?.takeIf { it.isNotBlank() } ?: defaultMessengerAvatar()
        return Sender(name = from?.name, avatarUrl = avatar)
    }

    // Дефолтный аватар оператора = messengerAvatar из настроек: либо готовый URL, либо
    // имя файла относительно BASE_FILES_URL/avatars/ (логика как в createWelcomeMessage).
    private fun defaultMessengerAvatar(): String? = runCatching {
        val raw = SettingsRepository.getInstance().getSettingsObject()
            ?.messengerAvatar?.takeIf { it.isNotBlank() } ?: return@runCatching null
        if (URLUtil.isValidUrl(raw)) raw else BuildConfig.BASE_FILES_URL + "avatars/" + raw
    }.getOrNull()

    private fun timestampMs(msg: MessageData) = (msg.created?.toLongOrNull() ?: 0L) * 1000L

    // Локальные статусы исходящих сообщений (MessageStatus): "loaded" — доставлено серверу,
    // "warning" — ошибка отправки, "loading" — в процессе (индикатора пока нет).
    private fun deliveryStatus(msg: MessageData) = when (msg.status) {
        "loading"                     -> DeliveryStatus.SENDING
        "loaded", "sent", "delivered" -> DeliveryStatus.SENT
        "read"                        -> DeliveryStatus.READ
        "warning", "failed"           -> DeliveryStatus.FAILED
        else                          -> null
    }

    // Returns (dayKey for deduplication, DateLabel) or null if timestamp is 0.
    private fun dateLabelFor(timestampMs: Long): Pair<String, DateLabel>? {
        if (timestampMs == 0L) return null
        val cal = Calendar.getInstance().also { it.timeInMillis = timestampMs }
        val today = Calendar.getInstance()
        val yesterday = Calendar.getInstance().also { it.add(Calendar.DAY_OF_YEAR, -1) }
        val dayKey = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.DAY_OF_YEAR)}"
        val label = when {
            isSameDay(cal, today)     -> DateLabel.Today
            isSameDay(cal, yesterday) -> DateLabel.Yesterday
            cal.get(Calendar.YEAR) == today.get(Calendar.YEAR) ->
                DateLabel.Exact(SimpleDateFormat("d MMMM", Locale.getDefault()).format(cal.time))
            else ->
                DateLabel.Exact(SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(cal.time))
        }
        return dayKey to label
    }

    private fun isSameDay(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
        a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
}
