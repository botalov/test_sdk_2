package io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages

const val DRAFT_MESSAGES_KEY: String = "draft_message_for_"

// Драфт вложений: JSON-массив УЖЕ загруженных вложений (формат attachments_cached) по диалогу.
const val DRAFT_ATTACHMENTS_KEY: String = "draft_attachments_for_"