package io.carrotquest_sdk.android.presentation.chat.consent

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.LinkInteractionListener
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentKind
import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentLine
import io.carrotquest_sdk.android.domain.use_cases.agreements.ConsentUiState
import io.carrotquest_sdk.android.presentation.ui.SdkColors

// Тексты согласий пока хардкодим по-русски (локализация — открытый вопрос PBR, см. план задачи).
// Каждый вид согласия = префикс («Я даю согласие на …» / «Нажимая на кнопку, вы соглашаетесь на …»)
// + подчёркнутая ссылочная часть, ведущая на документ (политика / условия хранения).
private const val PREFIX_CHECKBOX = "Я даю согласие на "
private const val PREFIX_IMPLICIT = "Нажимая на кнопку, вы соглашаетесь на "

private fun linkPhrase(kind: ConsentKind): String = when (kind) {
    ConsentKind.DATA_PROCESSING -> "обработку персональных данных"
    ConsentKind.EMAIL_SUBSCRIPTION -> "получение email-рассылок"
    ConsentKind.PHONE_SUBSCRIPTION -> "обратный звонок"
}

/**
 * Блок согласия на обработку персональных данных / хранение контакта.
 * Показывается над полем ввода (нижний инпут) и внутри бабла контакт-формы.
 *
 * Общий Composable: 0..2 строки (обработка данных и/или подтверждение подписки), каждая — либо
 * обязательный чекбокс, либо неявный текст. Кнопку отправки гейтит вызывающая сторона по
 * [ConsentUiState.allRequiredChecked]; сам блок только рендерит и отдаёт события наружу.
 *
 * @param onToggle клик по чекбоксу строки данного вида (для неявных строк не вызывается).
 * @param onLinkClick клик по ссылке на документ (единое открытие через presenter, как в теле чата).
 */
@Composable
internal fun ConsentBlock(
    state: ConsentUiState,
    accentColor: Color,
    isDark: Boolean,
    onToggle: (ConsentKind) -> Unit,
    onLinkClick: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!state.isVisible) return
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        state.lines.forEach { line ->
            ConsentLineRow(
                line = line,
                accentColor = accentColor,
                isDark = isDark,
                onToggle = { onToggle(line.kind) },
                onLinkClick = onLinkClick,
            )
        }
    }
}

@Composable
private fun ConsentLineRow(
    line: ConsentLine,
    accentColor: Color,
    isDark: Boolean,
    onToggle: () -> Unit,
    onLinkClick: (String) -> Unit,
) {
    val textColor = SdkColors.secondaryText(isDark)
    val prefix = if (line.withCheckbox) PREFIX_CHECKBOX else PREFIX_IMPLICIT
    val text = remember(line.kind, line.url, textColor) {
        buildConsentText(prefix, linkPhrase(line.kind), line.url, textColor, onLinkClick)
    }

    Row(verticalAlignment = Alignment.Top) {
        if (line.withCheckbox) {
            ConsentCheckbox(
                checked = line.checked,
                accentColor = accentColor,
                isDark = isDark,
                onClick = onToggle,
            )
            Spacer(Modifier.width(10.dp))
        }
        Text(
            text = text,
            color = textColor,
            fontSize = 13.sp,
            lineHeight = 18.sp,
        )
    }
}

/**
 * «Префикс + подчёркнутая ссылочная часть». Ссылочная часть кликабельна, только если [url] задан;
 * иначе остаётся просто подчёркнутым текстом (без действия).
 */
private fun buildConsentText(
    prefix: String,
    linkPhrase: String,
    url: String?,
    textColor: Color,
    onLinkClick: (String) -> Unit,
): AnnotatedString = buildAnnotatedString {
    append(prefix)
    val start = length
    append(linkPhrase)
    val end = length
    if (url != null) {
        val styles = TextLinkStyles(SpanStyle(color = textColor, textDecoration = TextDecoration.Underline))
        val listener = LinkInteractionListener { link -> (link as? LinkAnnotation.Url)?.url?.let(onLinkClick) }
        addLink(LinkAnnotation.Url(url, styles, listener), start, end)
    } else {
        addStyle(SpanStyle(textDecoration = TextDecoration.Underline), start, end)
    }
}

/** Кастомный чекбокс (без MaterialTheme): скруглённый квадрат, галочка рисуется Canvas. */
@Composable
private fun ConsentCheckbox(
    checked: Boolean,
    accentColor: Color,
    isDark: Boolean,
    onClick: () -> Unit,
) {
    // По макету: 16×16, радиус 4, рамка 1px, фон белый (Text/White) в светлой теме.
    val shape = RoundedCornerShape(4.dp)
    val checkColor = SdkColors.onAccent(accentColor)
    val box = Modifier
        .size(16.dp)
        .clip(shape)
        .clickable(onClick = onClick)

    if (checked) {
        Canvas(box.background(accentColor)) {
            val w = size.width
            // Галочка одним path со скруглёнными концами и изгибом — как в макете (белая на акценте).
            val check = Path().apply {
                moveTo(w * 0.27f, w * 0.52f)
                lineTo(w * 0.42f, w * 0.67f)
                lineTo(w * 0.73f, w * 0.35f)
            }
            drawPath(
                path = check,
                color = checkColor,
                style = Stroke(width = w * 0.125f, cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
        }
    } else {
        // Пустой квадрат: белый фон + рамка Line/Gray 800.
        Canvas(
            box
                .background(SdkColors.contactInputBg(isDark))
                .border(1.dp, SdkColors.contactInputBorder(isDark), shape)
        ) {}
    }
}
