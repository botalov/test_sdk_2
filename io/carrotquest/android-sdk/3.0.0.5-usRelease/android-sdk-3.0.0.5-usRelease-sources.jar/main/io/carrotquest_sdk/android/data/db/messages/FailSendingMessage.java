package io.carrotquest_sdk.android.data.db.messages;


import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class FailSendingMessage {
    @NonNull
    @PrimaryKey
    public String id;
    public String randomId;
    public String conversationId;
    public String created;
    public String body;
    public String bodyJson;
    public Boolean read;
    public String type;
    public String sentVia;
    public Boolean first;
    public String direction;
    public String status;
    public String replyType;
    public String messageFrom;
    public String attachPath;
    public Boolean inSendingProcess;

    // Метаданные вложения для ресенда (v27): attachPath хранит ЛОКАЛЬНЫЙ путь файла,
    // а эти поля позволяют восстановить полноценный Attachment (голос — плеером, файл — с именем).
    public String attachType;
    public String attachMimeType;
    public String attachFilename;
    public Long attachSize;
    // Уже загруженные на сервер вложения (form-поле attachments_cached в исходном виде):
    // при ресенде не перегружаем файлы, шлём reply сразу с этим JSON.
    public String attachmentsCached;



    public FailSendingMessage(@NonNull String id) {
        this.id = id;
    }
}
