package io.carrotquest_sdk.android.data.db.messages;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface FailSendingMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(FailSendingMessage message);

//    @Query("SELECT * FROM failsendingmessage WHERE id = :identifier")
//    Single<FailSendingMessage> getById(String identifier);

    @Query("SELECT * FROM failsendingmessage WHERE conversationId = :conversationId AND inSendingProcess = 0")
    List<FailSendingMessage> getAllByConversationId(String conversationId);

    @Query("SELECT * FROM failsendingmessage WHERE inSendingProcess = 0")
    List<FailSendingMessage> getAll();

    @Query("DELETE FROM failsendingmessage WHERE id = :identifier")
    void remove(String identifier);

    @Query("UPDATE failsendingmessage SET inSendingProcess=:inProcess WHERE id = :messageId")
    void updateProcessStatus(String messageId, int inProcess);

    // Смерть процесса между стартом ресенда (inSendingProcess=1) и его финишем оставляла
    // запись невидимой для getAll/getAllByConversationId навсегда. Вызывается на старте SDK.
    @Query("UPDATE failsendingmessage SET inSendingProcess=0 WHERE inSendingProcess=1")
    void resetStuckSendingProcess();

    @Query("SELECT attachmentsCached FROM failsendingmessage WHERE id = :messageId")
    String getAttachmentsCached(String messageId);

    // Локальные пути файлов, ожидающих ресенда, — их нельзя удалять при cleanup хранилища голосовых.
    @Query("SELECT attachPath FROM failsendingmessage WHERE attachPath IS NOT NULL")
    List<String> getAllAttachPaths();
}