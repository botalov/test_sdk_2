package io.carrotquest_sdk.android.core.logging

import androidx.core.app.NotificationManagerCompat
import io.carrotquest_sdk.android.BuildConfig
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.auth.AuthManager
import io.carrotquest_sdk.android.core.auth.AuthState
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.wss.jwt.tokenStateSummary
import java.util.Locale

/**
 * A point-in-time snapshot of the SDK's state, useful for support and bug reports. Obtain it via
 * Carrot.getDiagnostics() (works regardless of the configured log level). Sensitive fields
 * ([userId], [authToken]) are masked unless Carrot.setLogIncludeSensitive(true) was called.
 *
 * Fields are best-effort: ones that are unavailable (e.g. before setup) come back null/unknown.
 */
data class SdkDiagnostics(
    val sdkVersion: String,
    val isInitialized: Boolean,
    val state: String,
    val isAuthed: Boolean,
    val userId: String?,
    val authToken: String?,
    val appId: String?,
    val isOnline: Boolean?,
    /**
     * Whether the host app is allowed to show notifications (app-level notifications toggle /
     * POST_NOTIFICATIONS runtime permission on Android 13+). null if unknown (e.g. before setup).
     */
    val pushNotificationsEnabled: Boolean?,
    val theme: String,
    val locale: String,
    /** Masked snapshot of persisted access/refresh tokens (ages + isActual verdict). Always safe. */
    val tokenState: String,
    /** Recent SDK log lines (INFO+), oldest first — useful for support. */
    val recentLogs: List<String>,
) {
    /** Human-readable multi-line dump, convenient to attach to a support ticket. */
    fun toFormattedString(): String = buildString {
        appendLine("SDK diagnostics")
        appendLine("  version:      $sdkVersion")
        appendLine("  initialized:  $isInitialized ($state)")
        appendLine("  authed:       $isAuthed (userId=${userId ?: "-"}, token=${authToken ?: "-"})")
        appendLine("  appId:        ${appId ?: "-"}")
        appendLine("  online:       ${isOnline ?: "unknown"}")
        appendLine("  push perm:    ${pushNotificationsEnabled ?: "unknown"}")
        appendLine("  theme/locale: $theme / $locale")
        appendLine("  tokens:       $tokenState")
        if (recentLogs.isNotEmpty()) {
            appendLine()
            appendLine("Recent logs (${recentLogs.size}):")
            recentLogs.forEach { appendLine("  $it") }
        }
    }.trimEnd()

    companion object {
        @JvmStatic
        fun capture(): SdkDiagnostics {
            val includeSensitive = SdkLogger.isIncludeSensitive()
            val initialized = runCatching { SdkStateManager.isInit() }.getOrDefault(false)
            val state = runCatching { SdkStateManager.state.value::class.simpleName ?: "?" }.getOrDefault("?")

            val auth = runCatching { AuthManager.state.value }.getOrNull()
            val userId = (auth as? AuthState.Authenticated)?.userId
            val token = runCatching { CarrotLib.getLibComponents().userRep.user.token }.getOrNull()

            // Контекстные поля берём только если SDK инициализирован — иначе SdkApp.getInstance()
            // создал бы Application раньше времени (нежелательный сайд-эффект для снапшота).
            val app = if (initialized) runCatching { SdkApp.getInstance() }.getOrNull() else null
            val online = app?.let { runCatching { NetworkManager.getInstance(it).isNetworkAvailable() }.getOrNull() }
            // Разрешение на уведомления не зависит от init SDK — нужен лишь контекст SDK (есть уже
            // после setup). Берём contextSdk из libComponent — тем же способом, что CarrotSDK при
            // показе пушей. Через app (SdkApp) НЕ гейтим: он null до isInit, из-за чего было unknown.
            val pushEnabled = runCatching {
                val ctx = CarrotInternal.getLibComponent()?.contextSdk ?: return@runCatching null
                NotificationManagerCompat.from(ctx).areNotificationsEnabled()
            }.getOrNull()
            val theme = app?.let { runCatching { getThemeUseCase(it).name }.getOrNull() } ?: "?"

            return SdkDiagnostics(
                sdkVersion = BuildConfig.VERSION_SDK_NAME,
                isInitialized = initialized,
                state = state,
                isAuthed = auth is AuthState.Authenticated,
                userId = userId?.let { Redactor.token(it, includeSensitive) },
                authToken = token?.takeIf { it.isNotEmpty() }?.let { Redactor.token(it, includeSensitive) },
                appId = runCatching { CarrotSDK.getAppId() }.getOrNull(),
                isOnline = online,
                pushNotificationsEnabled = pushEnabled,
                theme = theme,
                locale = runCatching { Locale.getDefault().toLanguageTag() }.getOrDefault("?"),
                // tokenStateSummary() уже маскирует токены — безопасно класть в снапшот всегда.
                tokenState = runCatching { tokenStateSummary() }.getOrDefault("?"),
                recentLogs = runCatching { SdkLogStore.snapshot() }.getOrDefault(emptyList()),
            )
        }
    }
}
