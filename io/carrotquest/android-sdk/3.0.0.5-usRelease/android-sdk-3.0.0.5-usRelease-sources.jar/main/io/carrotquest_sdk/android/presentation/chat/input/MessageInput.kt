package io.carrotquest_sdk.android.presentation.chat.input

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.ui.text.style.TextOverflow
import coil.compose.AsyncImage
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R import io.carrotquest_sdk.android.presentation.chat.consent.ConsentBlock
import io.carrotquest_sdk.android.presentation.chat.ContactInputType
import io.carrotquest_sdk.android.presentation.ui.SdkColors

private val ICON_GREY = Color(0xFF999999)

// Чипы вложений (по макету input_3/input_4): превью/пилюля 50dp, скругление 10, крестик 22dp.
private val CHIP_SIZE = 55.dp
private val CHIP_CORNER = RoundedCornerShape(10.dp)
private val CHIP_REMOVE_SIZE = 24.dp // по макету: Ø24 (fill 20 + рамка 2 с каждой стороны)
private val FILE_PILL_WIDTH = 168.dp
private val FILE_BADGE_SIZE = 30.dp

/**
 * Нижний бар ввода сообщения (Compose-замена View-бара bottom_bar).
 *
 * Состояние — [MessageInputState] из [MessageInputViewModel]; действия наружу — [MessageInputEvent].
 * Реальные side-effect'ы (отправка, typing, draft, picker, выбор страны) делает DialogFragment
 * через DialogPresenter; компонент чисто отображает состояние и эмитит события.
 *
 * Раскладка заложена под будущие фичи (см. дизайн ~/Documents/design/input):
 *  - между текстом и кнопками — слот ленты вложений (мультифайл), пока пуст;
 *  - трейлинг-слот [TrailingAction] переключаемый (сейчас только send; mic для записи голоса — позже).
 *
 * imePadding НЕ применяется здесь — его даёт контейнер SdkContainerScreen.
 */
@Composable
fun MessageInput(
    state: MessageInputState,
    accentColor: Color,
    isDark: Boolean,
    onEvent: (MessageInputEvent) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!state.visible) return

    val consent = state.consent?.takeIf { it.isVisible }

    Column(modifier = modifier.fillMaxWidth()) {
        if (consent != null) {
            // Согласие + инпут на ОДНОЙ серой подложке (как в макете): фон #F2F2F2/#4D4D4D
            // (SdkColors.background), рамка как у инпута (SdkColors.inputBorder), радиус 20. Внешние
            // отступы карточки = прежние отступы пилюли (16/10) → на экране инпут стоит там же.
            Column(
                modifier = Modifier
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 10.dp)
                    .fillMaxWidth()
                    .background(SdkColors.background(isDark), RoundedCornerShape(20.dp))
                    .border(1.dp, SdkColors.inputBorder(isDark), RoundedCornerShape(20.dp)),
            ) {
                // Согласие — «выступающая» верхняя часть подложки (со своими отступами).
                ConsentBlock(
                    state = consent,
                    accentColor = accentColor,
                    isDark = isDark,
                    onToggle = { onEvent(MessageInputEvent.ConsentToggled(it)) },
                    onLinkClick = { onEvent(MessageInputEvent.ConsentLinkTapped(it)) },
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 10.dp),
                )
                // Пилюля вровень с левым/правым/нижним краями подложки (нулевые отступы) — подложка
                // видна только сверху, «из-под» инпута.
                InputPill(state, accentColor, isDark, onEvent, Modifier.fillMaxWidth())
            }
        } else {
            InputPill(
                state = state,
                accentColor = accentColor,
                isDark = isDark,
                onEvent = onEvent,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 10.dp),
            )
        }
    }
}

/**
 * Пилюля ввода (текст/аттачи/голос/кнопки). Вынесена из [MessageInput], т.к. рисуется в двух
 * контекстах: standalone (со своими внешними отступами) и внутри серой подложки согласия.
 * [modifier] несёт внешнее позиционирование; фон пилюли/рамка/внутренние отступы — здесь.
 */
@Composable
private fun InputPill(
    state: MessageInputState,
    accentColor: Color,
    isDark: Boolean,
    onEvent: (MessageInputEvent) -> Unit,
    modifier: Modifier = Modifier,
) {
    val contentAlpha = if (state.enabled) 1f else 0.5f
    Box(
        modifier = modifier
            // Радиус по макету (~/Documents/design/input): контейнер-пилюля 42dp (rx=20). Высоту 42
            // держим внутренними 6/6 + полем (vertical=4) + кнопками 30dp — всё центрируется в 42.
            .background(SdkColors.pageBackground(isDark), RoundedCornerShape(20.dp))
            .border(1.dp, SdkColors.inputBorder(isDark), RoundedCornerShape(20.dp))
            .padding(start = 0.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
    ) {
        // verticalAlignment = Bottom: при многострочном тексте/ленте вложений кнопки прижаты к низу
        // (как в дизайне input_3/input_4); при одной строке — визуально по центру.
        Row(verticalAlignment = Alignment.Bottom) {
            if (state.voiceState == VoiceState.Idle) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 16.dp),
                    ) {
                        state.phonePrefix?.let { prefix ->
                            PhonePrefixBlock(
                                prefix = prefix,
                                isDark = isDark,
                                onClick = { onEvent(MessageInputEvent.PhonePrefixTapped) },
                            )
                        }
                        InputTextField(
                            state = state,
                            isDark = isDark,
                            onTextChanged = { onEvent(MessageInputEvent.TextChanged(it)) },
                            // vertical=4: строка текста ≈30dp (4+line22+4), как кнопки 30dp → всё
                            // центрируется в пилюле 42dp; при многострочном тексте растёт вверх.
                            modifier = Modifier
                                .weight(1f)
                                .padding(vertical = 4.dp),
                        )
                    }

                    // Лента вложений (мультиаттачи) — под текстом, как в дизайне input_3/input_4.
                    if (state.attachments.isNotEmpty()) {
                        AttachmentsLane(
                            attachments = state.attachments,
                            isDark = isDark,
                            accentColor = accentColor,
                            onRemove = { clientId -> onEvent(MessageInputEvent.RemoveAttachment(clientId)) },
                        )
                    }
                }

                if (state.attachVisible) {
                    IconActionButton(
                        iconRes = R.drawable.ic_cq_attach_file,
                        tint = ICON_GREY,
                        // При достижении лимита вложений attach блокируется (как в дизайне/требовании).
                        enabled = state.enabled && state.attachments.size < MAX_ATTACHMENTS,
                        contentDescription = null,
                        modifier = Modifier
                            .alpha(if (state.attachments.size < MAX_ATTACHMENTS) contentAlpha else 0.4f)
                            .padding(start = 6.dp),
                        onClick = { onEvent(MessageInputEvent.AttachTapped) },
                    )
                }
            } else {
                // Режим голоса: вместо поля ввода — корзина + стоп/плей + звуковая волна (по макету voices).
                VoiceControls(
                    voiceState = state.voiceState,
                    isDark = isDark,
                    accentColor = accentColor,
                    onEvent = onEvent,
                    modifier = Modifier.weight(1f),
                )
            }

            TrailingAction(
                state = state,
                accentColor = accentColor,
                onEvent = onEvent,
            )
        }
    }
}

/**
 * Правый слот действия:
 *  - пустое поле, нет вложений, обычный режим → кнопка записи голоса (mic);
 *  - идёт запись / превью голоса → кнопка отправки (всегда активна, шлёт голос — SendVoice);
 *  - иначе → обычная кнопка отправки (активна по sendEnabled, шлёт текст/вложения — SendTapped).
 */
@Composable
private fun TrailingAction(
    state: MessageInputState,
    accentColor: Color,
    onEvent: (MessageInputEvent) -> Unit,
) {
    val isVoiceActive = state.voiceState != VoiceState.Idle
    if (!state.sendVisible && !isVoiceActive) return

    val onAccent = SdkColors.onAccent(accentColor)
    val showMic = !isVoiceActive
            && state.inputType == ContactInputType.TEXT
            && state.text.isBlank()
            && state.attachments.isEmpty()

    if (showMic) {
        CircleSlotButton(
            background = Color.Transparent,
            onClick = { onEvent(MessageInputEvent.StartVoiceRecording) },
            modifier = Modifier.padding(start = 6.dp),
            // Кнопка mic неактивна, пока диалог не загрузился (как кнопки отправки/прикрепления).
            enabled = state.enabled,
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_cq_mic),
                contentDescription = null,
                tint = ICON_GREY,
                modifier = Modifier.size(18.dp),
            )
        }
        return
    }

    // Голосовая отправка гейтится согласием так же, как текстовая (sendEnabled уже включает
    // consentOk): без отмеченных обязательных чекбоксов голос отправить нельзя.
    val enabled = if (isVoiceActive) state.consentOk else state.sendEnabled
    Box(
        modifier = Modifier
            // start=6 — зазор от attach; правый/нижний инсеты даёт внутренний padding контейнера.
            .padding(start = 6.dp)
            .size(30.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(CircleShape)
            .background(accentColor)
            .clickable(
                enabled = enabled,
                onClick = {
                    onEvent(if (isVoiceActive) MessageInputEvent.SendVoice else MessageInputEvent.SendTapped)
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_cq_send_message),
            contentDescription = null,
            tint = onAccent,
            modifier = Modifier.size(18.dp),
        )
    }
}

// Размер круглых кнопок в баре (как кнопка отправки).
private val VOICE_BTN_SIZE = 30.dp

/**
 * Бар записи/превью голоса (по макету ~/Documents/design/input/voices):
 *  - слева корзина (отмена записи / удаление превью) + стоп (во время записи) / плей-пауза (превью);
 *  - центр — звуковая волна (живая при записи, статичная при превью);
 *  - в превью справа от волны — длительность mm:ss. Кнопка отправки — снаружи (TrailingAction).
 */
@Composable
private fun VoiceControls(
    voiceState: VoiceState,
    isDark: Boolean,
    accentColor: Color,
    onEvent: (MessageInputEvent) -> Unit,
    modifier: Modifier = Modifier,
) {
    val recording = voiceState is VoiceState.Recording
    val barColor = SdkColors.title(isDark)
    Row(
        modifier = modifier.padding(start = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Корзина — подложка #F2F2F2 (light) / #4D4D4D (dark).
        CircleSlotButton(
            background = SdkColors.background(isDark),
            onClick = {
                onEvent(
                    if (recording) MessageInputEvent.CancelVoiceRecording
                    else MessageInputEvent.DeleteVoicePreview
                )
            },
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_cq_trash),
                contentDescription = null,
                tint = ICON_GREY,
                modifier = Modifier.size(18.dp),
            )
        }

        if (recording) {
            // Стоп — подложка акцентного цвета.
            CircleSlotButton(
                background = accentColor,
                onClick = { onEvent(MessageInputEvent.StopVoiceRecording) },
                modifier = Modifier.padding(start = 6.dp),
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_cq_stop),
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(14.dp),
                )
            }
        } else {
            val preview = voiceState as VoiceState.Preview
            // Плей/пауза — подложка акцентного цвета.
            CircleSlotButton(
                background = accentColor,
                onClick = { onEvent(MessageInputEvent.PlayPreviewToggle) },
                modifier = Modifier.padding(start = 6.dp),
            ) {
                Icon(
                    // Во время воспроизведения — стоп (тап останавливает и перематывает в начало).
                    painter = painterResource(
                        if (preview.isPlaying) R.drawable.ic_cq_stop else R.drawable.ic_cq_play
                    ),
                    contentDescription = null,
                    tint = Color.White,
                    // Триангл play оптически смещён влево (центроид левее центра бокса) — сдвигаем вправо.
                    modifier = Modifier
                        .offset(x = if (preview.isPlaying) 0.dp else 1.5.dp)
                        .size(14.dp),
                )
            }
        }

        val amplitudes = when (voiceState) {
            is VoiceState.Recording -> voiceState.amplitudes
            is VoiceState.Preview -> voiceState.waveform
            VoiceState.Idle -> emptyList()
        }
        val preview = voiceState as? VoiceState.Preview
        VoiceWaveform(
            amplitudes = amplitudes,
            unplayedColor = barColor,
            // Превью: проигранная часть подсвечивается акцентом по прогрессу (анимация как в баббле).
            playedColor = accentColor,
            progress = preview?.progress ?: 0f,
            fillWidth = preview != null,
            modifier = Modifier
                .weight(1f)
                .height(24.dp)
                // 15dp от кнопки стоп/плей до волны и 15dp от волны до времени.
                .padding(start = 15.dp, end = 15.dp),
        )

        // Таймер: реальное время при записи / длительность в превью.
        val timerSec = when (voiceState) {
            is VoiceState.Recording -> voiceState.elapsedSec
            is VoiceState.Preview -> voiceState.durationSec
            VoiceState.Idle -> null
        }
        if (timerSec != null) {
            Text(
                text = formatMmSs(timerSec),
                color = barColor,
                fontSize = 14.sp,
                // 9dp + 6dp (start у кнопки отправки) = 15dp от времени до кнопки отправки.
                modifier = Modifier.padding(end = 9.dp),
            )
        }
    }
}

/** Круглый слот 30dp с произвольным содержимым (mic/stop/play/trash). */
@Composable
private fun CircleSlotButton(
    background: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier
            .size(VOICE_BTN_SIZE)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(CircleShape)
            .background(background)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
        content = { content() },
    )
}

/**
 * Звуковая волна: вертикальные скруглённые палочки (w=2, как в макете). Живая запись — новые пики
 * справа (скользящее окно); превью — палочки из WaveformExtractor. Если палочек больше, чем влезает,
 * показываем последние.
 */
@Composable
private fun VoiceWaveform(
    amplitudes: List<Float>,
    unplayedColor: Color,
    modifier: Modifier = Modifier,
    playedColor: Color = unplayedColor,
    progress: Float = 0f,
    // true (превью): распределяем все палочки по ширине + красим проигранные по progress (как в
    // баббле). false (запись): живой скролл фиксированным шагом, последние влезающие палочки.
    fillWidth: Boolean = false,
) {
    Canvas(modifier = modifier) {
        if (amplitudes.isEmpty()) return@Canvas
        val barWidth = 2.dp.toPx()
        val minH = 2.dp.toPx()
        val centerY = size.height / 2f

        if (fillWidth) {
            val n = amplitudes.size
            val gap = if (n > 1) ((size.width - barWidth * n) / (n - 1)).coerceAtLeast(0f) else 0f
            val step = barWidth + gap
            amplitudes.forEachIndexed { i, raw ->
                val h = (raw.coerceIn(0f, 1f) * size.height).coerceAtLeast(minH)
                val played = (i + 1).toFloat() / n <= progress
                drawRoundRect(
                    color = if (played) playedColor else unplayedColor,
                    topLeft = Offset(i * step, centerY - h / 2f),
                    size = Size(barWidth, h),
                    cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
                )
            }
        } else {
            val gap = 2.dp.toPx()
            val step = barWidth + gap
            val maxBars = (size.width / step).toInt().coerceAtLeast(1)
            val bars = amplitudes.takeLast(maxBars)
            bars.forEachIndexed { i, raw ->
                val h = (raw.coerceIn(0f, 1f) * size.height).coerceAtLeast(minH)
                drawRoundRect(
                    color = unplayedColor,
                    topLeft = Offset(i * step, centerY - h / 2f),
                    size = Size(barWidth, h),
                    cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f),
                )
            }
        }
    }
}

private fun formatMmSs(totalSec: Int): String {
    val m = totalSec / 60
    val s = totalSec % 60
    return "%d:%02d".format(m, s)
}

@Composable
private fun InputTextField(
    state: MessageInputState,
    isDark: Boolean,
    onTextChanged: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val singleLine = state.inputType == ContactInputType.EMAIL || state.inputType == ContactInputType.PHONE
    val keyboardType = when (state.inputType) {
        ContactInputType.EMAIL -> KeyboardType.Email
        ContactInputType.PHONE -> KeyboardType.Phone
        ContactInputType.NAME, ContactInputType.TEXT -> KeyboardType.Text
    }
    val capitalization = when (state.inputType) {
        ContactInputType.NAME -> KeyboardCapitalization.Words
        ContactInputType.TEXT -> KeyboardCapitalization.Sentences
        else -> KeyboardCapitalization.None
    }

    BasicTextField(
        value = state.text,
        onValueChange = { new ->
            // Лимит длины раньше задавался InputFilter.LengthFilter на EditText — повторяем здесь.
            val limited = state.maxLength?.let { if (new.length > it) new.take(it) else new } ?: new
            onTextChanged(limited)
        },
        enabled = state.enabled,
        modifier = modifier,
        textStyle = LocalTextStyle.current.copy(
            color = SdkColors.title(isDark),
            fontSize = 16.sp,
            lineHeight = 22.sp,
        ),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, capitalization = capitalization),
        cursorBrush = androidx.compose.ui.graphics.SolidColor(SdkColors.title(isDark)),
        maxLines = 6,
        singleLine = singleLine,
        decorationBox = { innerTextField ->
            Box(contentAlignment = Alignment.CenterStart) {
                if (state.text.isEmpty() && !state.hint.isNullOrEmpty()) {
                    Text(text = state.hint, color = ICON_GREY, fontSize = 16.sp)
                }
                innerTextField()
            }
        },
    )
}

@Composable
private fun PhonePrefixBlock(
    prefix: PhonePrefixUi,
    isDark: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier.clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        if (prefix.flag.isNotEmpty()) {
            Text(text = prefix.flag, fontSize = 16.sp)
        }
        Icon(
            painter = painterResource(R.drawable.ic_cq_arrow_down),
            contentDescription = null,
            tint = ICON_GREY,
            modifier = Modifier.size(16.dp),
        )
        if (prefix.code.isNotEmpty()) {
            Text(text = prefix.code, color = SdkColors.title(isDark), fontSize = 16.sp)
        }
    }
}

@Composable
private fun IconActionButton(
    iconRes: Int,
    tint: Color,
    enabled: Boolean,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier = modifier
            // 30dp — как send и как в макете (две круглые кнопки 30dp, центр по вертикали в 42dp).
            .size(30.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(18.dp),
        )
    }
}

// ── Лента вложений (мультиаттачи) ───────────────────────────────────────────────

@Composable
private fun AttachmentsLane(
    attachments: List<PendingAttachment>,
    isDark: Boolean,
    accentColor: Color,
    onRemove: (String) -> Unit,
) {
    // bottom=4: вместе с нижним padding пилюли (6) даёт визуальные 10dp под лентой; слева тоже 10dp.
    Box(modifier = Modifier.fillMaxWidth().padding(top = 5.dp, bottom = 4.dp)) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            // top — место для выступающего крестика; end — чтобы крестик последнего чипа не обрезался.
            contentPadding = PaddingValues(top = 6.dp, start = 10.dp, end = 22.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(attachments, key = { it.clientId }) { att ->
                AttachmentChip(att = att, isDark = isDark, accentColor = accentColor, onRemove = onRemove)
            }
        }

        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.horizontalGradient(
                        0.0f to SdkColors.pageBackground(isDark),
                        0.03f to SdkColors.pageBackground(isDark), // Удерживает плотный цвет
                        0.05f to Color.Transparent,                 // Резко падает в прозрачность
                        1.0f to Color.Transparent,
                    )
                ),
        )

        // Плавное затухание справа (как в макете input_3/4) вместо резкого обреза ленты.
        // matchParentSize (а НЕ fillMaxHeight): оверлей подгоняется под высоту ленты и не форсит её
        // рост — иначе при огромном max-height (Column с ChatScreen weight 1f) инпут растягивался на
        // весь экран. Затухание только в правой части — дробным градиентом по всей ширине.
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.horizontalGradient(
                        0.0f to Color.Transparent,
                        0.9f to Color.Transparent,
                        1.0f to SdkColors.pageBackground(isDark),
                    )
                ),
        )
    }
}

@Composable
private fun AttachmentChip(
    att: PendingAttachment,
    isDark: Boolean,
    accentColor: Color,
    onRemove: (String) -> Unit,
) {
    val uploading = att.uploadState == AttachmentUploadState.UPLOADING
    Box {
        when (att) {
            is PendingAttachment.ImageAttachment -> {
                Box(
                    modifier = Modifier
                        .size(CHIP_SIZE)
                        .clip(CHIP_CORNER)
                        .border(1.dp, hairline(isDark), CHIP_CORNER),
                ) {
                    AsyncImage(
                        model = att.localUri,
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .size(CHIP_SIZE)
                            .alpha(if (uploading) 0.3f else 1f),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    )
                    if (uploading) UploadOverlay(onCancel = { onRemove(att.clientId) })
                }
            }
            is PendingAttachment.FileAttachment -> {
                Box(
                    modifier = Modifier
                        .width(FILE_PILL_WIDTH)
                        .height(CHIP_SIZE)
                        .clip(CHIP_CORNER)
                        .background(SdkColors.background(isDark)),
                ) {
                    Row(
                        // fillMaxSize + CenterVertically: иконка и текст по центру пилюли, а не у
                        // верхней границы (было — контент прилипал к верху).
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 10.dp)
                            .alpha(if (uploading) 0.4f else 1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Box(
                            modifier = Modifier
                                .size(FILE_BADGE_SIZE)
                                .clip(CircleShape)
                                .background(accentColor),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_cq_attach_file),
                                contentDescription = null,
                                tint = SdkColors.onAccent(accentColor),
                                modifier = Modifier.size(16.dp),
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = att.name,
                                color = SdkColors.title(isDark),
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Spacer(Modifier.height(3.dp))
                            Text(
                                text = att.sizeLabel,
                                color = ICON_GREY,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    if (uploading) UploadOverlay(onCancel = { onRemove(att.clientId) })
                }
            }
        }

        // Крестик удаления — только у загруженного чипа (во время загрузки отмена — по индикатору).
        // В правом-верхнем углу с лёгким выносом наружу (как в макете); место под вынос даёт
        // contentPadding ленты (top/end), поэтому он не обрезается.
        if (!uploading) {
            RemoveBadge(
                isDark = isDark,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 6.dp, y = (-6).dp),
                onClick = { onRemove(att.clientId) },
            )
        }
    }
}

/** Полупрозрачная заглушка загрузки: тёмный круг + индетерминантный прогресс, кликабельна = отмена. */
@Composable
private fun UploadOverlay(onCancel: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .size(CHIP_SIZE),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Color(0xFF22252A).copy(alpha = 0.5f))
                .clickable(onClick = onCancel),
            contentAlignment = Alignment.Center,
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                color = Color.White,
                strokeWidth = 2.dp,
            )
        }
    }
}

@Composable
private fun RemoveBadge(isDark: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    // По макету: fill #4D4D4D(light)/#595959(dark), ободок = цвет фона страницы (white/#333333),
    // чтобы бейдж читался на любой теме (на dark #4D4D4D-fill раньше сливался с пилюлей).
    val fill = SdkColors.attachmentRemoveBadge(isDark)
    // Рисуем бейдж ДВУМЯ сплошными кругами, без модификатора border: внешний = цвет ободка,
    // поверх меньший = fill. Это убирает тонкую антиалиасинг-кромку, которую даёт стык
    // background+border на одной форме (известный артефакт Compose).
    Box(
        modifier = modifier
            .size(CHIP_REMOVE_SIZE)
            .background(SdkColors.pageBackground(isDark), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier = Modifier
                .size(CHIP_REMOVE_SIZE - 4.dp) // 2dp ободка с каждой стороны
                .background(fill, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            // Крестик рисуем Canvas'ом (жирный, со скруглёнными концами) — Icons.Filled.Close
            // выглядел тонким/мелким. Размер иконки 10dp по макету.
            Canvas(modifier = Modifier.size(10.dp)) {
                val w = size.width
                val sw = w * 0.2f
                drawLine(Color.White, Offset(w * 0.15f, w * 0.15f), Offset(w * 0.85f, w * 0.85f), sw, cap = StrokeCap.Round)
                drawLine(Color.White, Offset(w * 0.85f, w * 0.15f), Offset(w * 0.15f, w * 0.85f), sw, cap = StrokeCap.Round)
            }
        }
    }
}

private fun hairline(isDark: Boolean): Color =
    if (isDark) Color.White.copy(alpha = 0.1f) else Color.Black.copy(alpha = 0.1f)
