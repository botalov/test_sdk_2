package io.carrotquest_sdk.android.data.service

import io.carrotquest_sdk.android.Callback

import android.content.Context
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.messaging.FirebaseMessaging
import com.google.gson.Gson
import com.google.gson.JsonObject
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.auth.AuthManager
import io.carrotquest_sdk.android.core.connection.ConnectionManager
import io.carrotquest_sdk.android.core.connection.WssManager
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.init.InitCoordinator
import io.carrotquest_sdk.android.core.init.OperationQueue
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.util.huawei.isHuawei
import io.carrotquest_sdk.android.data.network.wss_responses.ConversationTypingResponse
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.data.repositories.old.UserRepository
import io.carrotquest_sdk.android.data.user.UserStateHolder
import io.carrotquest_sdk.android.domain.entities.UserEntity
import io.carrotquest_sdk.android.domain.use_cases.user.getAuthedUserIdUseCase
import io.carrotquest_sdk.android.domain.use_cases.user.getConnectedUserIdUseCase
import io.carrotquest_sdk.android.domain.use_cases.user.getUserAgent
import io.carrotquest_sdk.android.domain.use_cases.user.saveAuthedUserIdUseCase
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.models.User
import io.carrotquest_sdk.android.models.UserProperty
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import io.carrotquest_sdk.android.lib.utils.AndroidUtils
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.wss.jwt.JwtTokenRefreshService
import io.carrotquest_sdk.android.lib.wss.jwt.clearAllCreds
import io.carrotquest_sdk.android.lib.wss.jwt.getRefreshToken
import io.carrotquest_sdk.android.lib.wss.jwt.getJwtToken
import io.carrotquest_sdk.android.domain.use_cases.agreements.updateAppUserFlags
import io.carrotquest_sdk.android.lib.wss.jwt.clearJwtTokens
import io.carrotquest_sdk.android.lib.wss.jwt.isActualJwtToken
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtTokenBlocking
import io.carrotquest_sdk.android.lib.wss.jwt.saveJwtToken
import io.carrotquest_sdk.android.presentation.mvp.utils.isTablet
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.ResponseBody
import retrofit2.HttpException
import javax.inject.Inject

class CarrotService : ICarrotService {

    @JvmField
    @Inject
    var userRepository: UserRepository? = null

    @JvmField
    @Inject
    var gson: Gson? = null

    /** Идентификатор аппа */
    private var appId: String? = null
    private var isUseEuServers = false

    /** Общая библиотека для работы с API */
    @JvmField
    var carrotLib: CarrotLib

    // Скоуп всех асинхронных операций сервиса (раньше CompositeDisposable allDisposables +
    // отдельные Disposable). Отменяется в deInit через cancelChildren.
    private val serviceScope = CoroutineScope(SupervisorJob() + SdkDispatchers.io)

    // Отдельный скоуп для отписки push в deInit — НЕ отменяется teardown'ом (раньше это была
    // standalone-подписка, не добавленная в allDisposables; должна доработать до timeout).
    private val pushScope = CoroutineScope(SupervisorJob() + SdkDispatchers.io)

    private var authJob: Job? = null

    // typing-индикатор (раньше typingDisposable/typingDebounceDisposable + startTypingTime).
    @Volatile
    private var startTypingTime: Long? = null
    private var typingJob: Job? = null

    // Поток "оператор печатает" (RTS). PublishSubject → MutableSharedFlow (replay=0) (ветка remove_rx).
    // CarrotService пересоздаётся при re-init, поэтому отдельный onComplete/recreate не нужен.
    private val adminTypingFlow = MutableSharedFlow<ConversationTypingResponse>(extraBufferCapacity = 16)
    val adminTypingEvents: SharedFlow<ConversationTypingResponse> = adminTypingFlow.asSharedFlow()

    // appId nullable: Dagger-модуль может строить сервис до setup() SDK (напр. тап пуша при
    // закрытом приложении → PushTapActivity → trackClick → getService()), тогда appId == null.
    // В Java-оригинале параметр был nullable; Kotlin-порт сделал его non-null → NPE-краш.
    constructor(context: Context, appId: String?, useEuServers: Boolean) {
        this.appId = appId
        this.isUseEuServers = useEuServers
        CarrotInternal.getLibComponent().inject(this)
        instance = this
        carrotLib = CarrotLib(context, repo(), isUseEuServers)
    }

    constructor() {
        this.appId = CarrotSDK.getAppId()
        this.isUseEuServers = CarrotSDK.isUseEuApi()
        CarrotInternal.getLibComponent().inject(this)
        carrotLib = CarrotLib(CarrotInternal.getLibComponent().contextSdk, repo(), isUseEuServers)
    }

    private val contextSdk: Context get() = CarrotInternal.getLibComponent().contextSdk

    private fun repo(): UserRepository {
        var r = userRepository
        if (r == null) {
            r = CarrotInternal.getLibComponent().userRepository
            userRepository = r
        }
        return r!!
    }

    /**
     * Инициализация сервисов (вызов setup()).
     */
    override fun init(apiKey: String, callback: Callback<Boolean>?, startSession: Boolean) {
        try {
            repo().saveToken("")
        } catch (exSaveToken: Exception) {
            Log.e(TAG, "save token error: $exSaveToken")
        }
        InitCoordinator.connect(
            appId.orEmpty(), apiKey, carrotLib, repo(), startSession, callback,
            { initPushesService() }, { startRefreshTokenService() }
        )
    }

    override fun deInit() {
        deInit(null)
    }

    fun deInit(onComplete: Runnable?) {
        // Синхронный teardown — нет race window с последующим setup()
        SdkStateManager.onDeInit()
        AuthManager.onDeInit()
        InitCoordinator.abort()
        OperationQueue.cancelAll()
        ConnectionManager.reset()
        WssManager.stop()
        JwtTokenRefreshService.getInstance().stop()

        cancelServiceWork()

        // Сбрасываем репозитории — singleton'ы держали подписки на старый CarrotService
        // (typing-индикатор) и хранили stale-данные.
        try {
            MessagesRepository.getInstance().deInit()
        } catch (t: Throwable) {
            Log.e(TAG, "MessagesRepository.deInit failed: $t")
        }
        try {
            ConversationsRepository.getInstance().deInit()
        } catch (t: Throwable) {
            Log.e(TAG, "ConversationsRepository.deInit failed: $t")
        }

        // Захватываем userId И auth-токен ДО очистки локального состояния — иначе отписка ниже
        // уходит неаутентифицированной (интерсептор читает креды в момент отправки, а они уже
        // стёрты) и сервер не снимает привязку device↔user → пуши идут прежнему юзеру.
        val userId = UserStateHolder.currentId()
        val deviceId = AndroidUtils.getInstallId(contextSdk)
        val authToken = repo().user?.token?.takeIf { it.isNotEmpty() }
            ?: getJwtToken().takeIf { it.isNotEmpty() }
            ?: SharedPreferencesLib.getString(contextSdk, SharedPreferenceKeys.CARROT_TOKEN)

        // Персистим pending-отписку ДО очистки кред: если запрос не дойдёт (таймаут/офлайн/kill),
        // повторим на следующем старте (retryPendingPushUnsubscribe). Очистится при успехе.
        if (userId.isNotEmpty()) {
            SharedPreferencesLib.saveString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_USER_ID, userId)
            SharedPreferencesLib.saveString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_DEVICE_ID, deviceId)
            SharedPreferencesLib.saveString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_TOKEN, authToken ?: "")
        }

        // Синхронная очистка локального состояния — не зависит от успеха unsubscribe
        repo().saveUser(User())
        UserStateHolder.clear()
        // Чистим persisted JWT-креды (access/refresh/legacy CarrotToken). deInit уже сбрасывает
        // личность (saveUser(User()) + очистка authed/connected userId в CarrotSDK.deInitInternal),
        // но без этого шага access-токен переживал teardown → следующий /connect уходил token-BASED
        // и сервер восстанавливал ТОГО ЖЕ юзера (logout «не выходил»). Теперь reinit → token-less →
        // аноним. Регрессия после перевода модели на «сброс кред только при провале /refresh».
        clearJwtTokens(contextSdk)

        // Асинхронная отписка push с timeout — onComplete гарантированно стрельнёт.
        // pushScope не отменяется teardown'ом (раньше — standalone .subscribe вне allDisposables).
        pushScope.launch {
            if (userId.isNotEmpty()) {
                sendPushUnsubscribe(userId, deviceId, authToken)
            }
            // onComplete на main: раньше unsubscribePush имел .observeOn(mainThread). Колбэк делает
            // UI (Toast) и повторный setup() — на фоне это падало и re-setup не выполнялся.
            withContext(SdkDispatchers.main) { onComplete?.run() }
        }
    }

    /**
     * Отправляет отписку push-токена от юзера с ЯВНЫМ auth-токеном (креды к этому моменту уже
     * очищены deInit). При подтверждённом успехе (meta.error == null) снимает pending-запись;
     * иначе оставляет её для повтора на следующем старте. Провал логируется (раньше глотался молча).
     */
    private suspend fun sendPushUnsubscribe(userId: String, deviceId: String, authToken: String?) {
        try {
            val response = withTimeoutOrNull(UNSUBSCRIBE_PUSH_TIMEOUT_SECONDS * 1000) {
                carrotLib.deletePushTokenSuspend(userId, deviceId, "mobile", authToken)
            }
            val ok = response != null && response.meta?.error == null
            if (ok) {
                clearPendingPushUnsubscribe()
                SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG, "push unsubscribe confirmed for user=$userId")
            } else {
                SdkLogger.log(
                    SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG,
                    "push unsubscribe NOT confirmed (kept for retry): timeout=${response == null} error=${response?.meta?.error} hadToken=${!authToken.isNullOrEmpty()}",
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "push unsubscribe failed (kept for retry): $e")
        }
    }

    private fun clearPendingPushUnsubscribe() {
        SharedPreferencesLib.clearPreference(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_USER_ID)
        SharedPreferencesLib.clearPreference(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_DEVICE_ID)
        SharedPreferencesLib.clearPreference(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_TOKEN)
    }

    /**
     * Повтор незавершённой отписки на старте SDK: если прошлый deInit не смог подтвердить отписку
     * (таймаут/офлайн/kill процесса), запись сохранилась в prefs — досылаем её здесь. Идёт с
     * сохранённым токеном старого юзера, поэтому не зависит от текущих кред. Вызывается из init.
     */
    fun retryPendingPushUnsubscribe() {
        val userId = SharedPreferencesLib.getString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_USER_ID)
        if (userId.isNullOrEmpty()) return
        val deviceId = SharedPreferencesLib.getString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_DEVICE_ID)
        val token = SharedPreferencesLib.getString(contextSdk, SharedPreferenceKeys.PENDING_UNSUB_TOKEN)?.takeIf { it.isNotEmpty() }
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG, "retrying pending push unsubscribe for user=$userId")
        pushScope.launch {
            sendPushUnsubscribe(userId, deviceId.orEmpty(), token)
        }
    }

    // Cooldown между авто-восстановлениями сессии: серия 403 absent_scopes не должна плодить re-init.
    // elapsedRealtime, не wall clock: перевод часов не должен ломать/раздувать кулдаун.
    @Volatile
    private var lastSessionRecoveryMs = 0L

    // Триггер, пришедший в кулдаун, не дропаем, а коалесцируем в один отложенный повтор.
    @Volatile
    private var recoveryRetryScheduled = false

    /**
     * Авто-восстановление сессии при невосстановимом отказе авторизации: refresh отвергнут ИЛИ
     * 403 `absent_scopes` (токен валиден по времени, но без нужных scopes — refresh выдаёт новый
     * access с теми же scopes и не лечит). Чистим ВСЕ креды + обнуляем auth_token и переигрываем
     * init token-less: `/connect` поднимает свежую сессию с корректными scopes. Раньше это требовало
     * полной выгрузки приложения (только холодный старт чинил). Single-flight (@Synchronized) +
     * cooldown — чтобы шторм 403 не зациклил re-init. Вызывается из [SdkStateManager.notifySessionExpired].
     */
    @Synchronized
    fun recoverSession() {
        // Дешёвый guard (без диска) держим синхронным под @Synchronized, чтобы серия 403 не плодила
        // параллельные recovery. Саму работу (чтение prefs, сброс кред, re-init) уводим с вызывающего
        // потока — recoverSession часто зовётся с сетевого треда OkHttp (через интерсептор), а там
        // нельзя блокировать на дисковом I/O.
        // isInitializing — ПЕРВЫМ: пока идёт init/recovery, любые триггеры бессмысленны
        // (раньше проверка кулдауна стояла раньше и лог врал «cooldown» вместо «initializing»).
        if (SdkStateManager.isInitializing()) {
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "session recovery skipped (already initializing)")
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        val sinceLast = now - lastSessionRecoveryMs
        if (lastSessionRecoveryMs != 0L && sinceLast < SESSION_RECOVERY_COOLDOWN_MS) {
            // Коалесцируем в один отложенный повтор на момент истечения кулдауна: раньше триггер
            // просто дропался, и лечение ждало СЛЕДУЮЩЕГО 401 (иногда — вечного спиннера у юзера).
            if (!recoveryRetryScheduled) {
                recoveryRetryScheduled = true
                val delayMs = SESSION_RECOVERY_COOLDOWN_MS - sinceLast
                serviceScope.launch {
                    kotlinx.coroutines.delay(delayMs)
                    recoveryRetryScheduled = false
                    recoverSession()
                }
                SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "session recovery deferred ${delayMs}ms (cooldown)")
            } else {
                SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "session recovery skipped (cooldown, retry already scheduled)")
            }
            return
        }
        // Офлайн-попытка гарантированно провалится, но раньше сжигала весь 30с бюджет кулдауна —
        // первое лечение после реконнекта блокировалось. Не взводим кулдаун: network observer
        // (см. init-блок) запустит recovery, когда сеть реально появится.
        if (!NetworkManager.getInstance(contextSdk).isNetworkAvailable()) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG, "session recovery deferred: no network (cooldown NOT armed)")
            return
        }
        lastSessionRecoveryMs = now

        serviceScope.launch {
            runSessionRecovery()
        }
    }

    /**
     * Появилась сеть (вызывается network-observer'ом [CarrotSDK]): сбрасываем кулдаун recovery —
     * офлайн-попытки не должны блокировать первое лечение после реконнекта. Если сессия
     * деградировала (SDK Ready, но кредов нет — их вычистил интерсептор после мёртвого refresh),
     * network-observer её не лечит (гейт !isInit), а 401-триггер может прийти нескоро —
     * запускаем recovery сразу.
     */
    fun onNetworkRestored() {
        lastSessionRecoveryMs = 0L
        val noCreds = getRefreshToken(contextSdk).isNullOrEmpty() &&
            repo().user?.token.isNullOrEmpty()
        if (noCreds && SdkStateManager.isInit()) {
            SdkLogger.log(
                SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
                "network restored with empty creds while Ready — triggering session recovery",
            )
            recoverSession()
        }
    }

    private fun runSessionRecovery() {
        val apiKey = SharedPreferencesLib.getString(contextSdk, "api_key")
        if (apiKey.isNullOrEmpty()) {
            SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "session recovery aborted: no stored api_key")
            return
        }
        SdkLogger.log(
            SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG,
            "session recovery: clearing creds and re-initializing with token-less /connect",
        )

        // Token-less: чистим JWT/refresh И обнуляем user.token (=auth_token обычных запросов),
        // чтобы /connect пошёл анонимно и сервер выдал новую сессию с правильными scopes.
        clearAllCreds(repo(), contextSdk)

        // Лёгкий reset (НЕ полный deInit — репозитории/подписки чата не трогаем): сбрасываем
        // connect-ретраи и переводим state в Idle, чтобы InitCoordinator.onInitStarted прошёл.
        // RTS НЕ останавливаем здесь явно: init→initComplete→WssManager.start() сам сделает stop()+
        // start() со свежим токеном. (Лишний WssManager.stop() здесь дал бы преждевременный
        // NetworkManager.deInit, рубящий сетевые observers открытого диалога.)
        ConnectionManager.reset()
        SdkStateManager.onDeInit()

        init(apiKey, null, true)
    }

    override fun isInit(): Boolean = SdkStateManager.isInit()

    override fun authUser(id: String, userAuthKey: String) {
        authUser(id, userAuthKey, null)
    }

    override fun authUser(id: String, userAuthKey: String, callback: Callback<User>?) {
        authJob?.cancel()
        authJob = serviceScope.launch {
            OperationQueue.execute { performAuth(id, callback) { carrotLib.authSuspend(id, userAuthKey) } }
        }
    }

    override fun hashedAuth(id: String, hash: String, callback: Callback<User>?) {
        authJob?.cancel()
        authJob = serviceScope.launch {
            OperationQueue.execute { performAuth(id, callback) { carrotLib.hashedAuthSuspend(id, hash) } }
        }
    }

    override fun setUserProperty(userProperty: List<UserProperty>) {
        OperationQueue.enqueue { setUserPropertySimple(userProperty) }
    }

    fun setUserPropertySimple(userProperty: List<UserProperty>) {
        serviceScope.launch {
            try {
                carrotLib.setPropertySuspend(UserStateHolder.currentId(), userProperty)
                Log.d(TAG, "onNext setUserProperty")
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                Log.e(TAG, e)
            }
        }
    }

    override fun setUserProperty(userProperty: List<UserProperty>, callback: Callback<Boolean>) {
        val prefix = "Set user property: "
        serviceScope.launch {
            try {
                OperationQueue.execute { carrotLib.setPropertySuspend(UserStateHolder.currentId(), userProperty) }
                withContext(SdkDispatchers.main) { callback.onResponse(true) }
                Log.d(TAG, prefix + "onComplete")
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                Log.e(TAG, prefix + "error: " + e)
                withContext(SdkDispatchers.main) { callback.onFailure(e) }
            }
        }
    }

    override fun trackEvent(eventName: String, eventParams: String?, callback: Callback<NetworkResponse>) {
        OperationQueue.enqueue { trackEventSimple(eventName, eventParams, callback) }
    }

    fun trackEventSimple(eventName: String, eventParams: String?, callback: Callback<NetworkResponse>) {
        serviceScope.launch {
            try {
                val r = carrotLib.trackEventSuspend(UserStateHolder.currentId(), eventName, eventParams)
                withContext(SdkDispatchers.main) { callback.onResponse(r) }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                withContext(SdkDispatchers.main) { callback.onFailure(e) }
            }
        }
    }

    // getConversations×2 / getConversation observer-методы удалены (ветка remove_rx):
    // единственный потребитель (old/UserRepository.java) был закомментирован; чтение бесед
    // идёт через ConversationsRepository / use-case suspend.

    // Мёртвые observer-методы удалены (ветка remove_rx): startConversations×2/getMessage/
    // reply/replyFile — потребители используют carrotLib.*Suspend / use-case suspend напрямую.

    override fun trackClickByPush(conversationId: String, callback: Callback<Boolean>) {
        serviceScope.launch {
            try {
                carrotLib.trackInteractionSuspend(conversationId, "clicked")
                withContext(SdkDispatchers.main) { callback.onResponse(true) }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                Log.e(TAG, e.toString())
                withContext(SdkDispatchers.main) { callback.onFailure(e) }
            }
        }
    }

    // Мёртвые observer-методы удалены (ветка remove_rx): markConversationAsRead/voteOperator×2/
    // updateAutoReply — голосование и mark-read идут через use-case suspend (SendVoteOperatorUseCase,
    // markConversationAsRead suspend) напрямую.

    // downloadF/downloadFile(Observer) удалены — мёртвые (чат качает через FileDownloadRepository
    // на корутинах/OkHttp; downloadFileUseCase не вызывался). Download* остаётся только для
    // кэша картинок попапа (DownloadUtil.downloadFilesToCash).

    override fun setTyping(conversationId: String, messageBody: String) {
        if (!SdkStateManager.isInit()) return

        // Лидирующий throttle: пинг typing-индикатора на первом символе и далее не чаще раза
        // в TYPING_THROTTLE_MS, пока пользователь печатает.
        // Раньше здесь была вторая ветка через Observable.just(true).debounce(2s); из-за
        // just(true)+onComplete «дебаунс» эмитил немедленно (таймер не срабатывал) и слал
        // дубликат запроса на каждый символ. Ветка удалена (remove_rx ревью, L3) — поведение
        // изменено: backend получает пинг не чаще раза в 2с вместо одного на символ.
        val now = System.currentTimeMillis()
        if (now - (startTypingTime ?: 0L) < TYPING_THROTTLE_MS) return
        if (typingJob?.isActive == true) return

        startTypingTime = now
        typingJob = serviceScope.launch(SdkDispatchers.main) {
            try {
                carrotLib.setTypingSuspend(conversationId, messageBody)
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                Log.e(TAG, e.toString())
            }
        }
    }

    override fun getSaveUserId(): String = UserStateHolder.currentId()

    // Мёртвый observer-метод chooseRoutingBot удалён (ветка remove_rx) — бот идёт через
    // loadRoutingBot/chooseRoutingBotSuspend напрямую.

    private fun initPushesService() {
        try {
            // Досылаем незавершённую отписку прошлого юзера ДО подписки текущего — если прошлый
            // deInit не подтвердил её (таймаут/офлайн/kill). Идёт с сохранённым токеном.
            retryPendingPushUnsubscribe()

            if (isHuawei()) return

            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (!task.isSuccessful) {
                    SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "initPushesService: FCM token fetch failed: ${task.exception?.message}")
                    return@addOnCompleteListener
                }

                val notificationManager = NotificationManagerCompat.from(contextSdk)
                if (task.result != null && notificationManager.areNotificationsEnabled()) {
                    val token = task.result
                    val deviceId = AndroidUtils.getInstallId(contextSdk)
                    sendPushToken(UserStateHolder.currentId(), token, deviceId)
                }
            }
        } catch (eIllegalState: IllegalStateException) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "initPushesService: Firebase unavailable", eIllegalState)
        } catch (e: Exception) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.PUSH, TAG, "initPushesService failed", e)
        }
    }

    fun sendPushToken(userId: String, token: String?, deviceId: String) {
        if (token.isNullOrEmpty()) return
        serviceScope.launch {
            try {
                OperationQueue.execute {
                    val sUserAgent = getUserAgent()
                    val deviceType = if (isTablet(contextSdk)) "tablet" else "phone"
                    val device = if (isHuawei()) "Huawei [huawei_push] 1.0.0" else "Android"
                    val sdkVersion = CarrotSDK.getVersion()
                    val browser = "sdk " + (sdkVersion ?: "")
                    val res = carrotLib.sendPushTokenSuspend(userId, token, deviceId, "mobile", deviceType, device, browser, sUserAgent)
                    SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.PUSH, TAG, "push token sent to backend")
                }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.PUSH, TAG, "sendPushToken failed", e)
            }
        }
    }

    fun adminTyping(pair: ConversationTypingResponse) {
        adminTypingFlow.tryEmit(pair)
    }

    fun startRefreshTokenService() {
        // Переподключение сокетов при обновлении JWT обрабатывает сам JwtWssService.
        JwtTokenRefreshService.getInstance().start()
    }

    /**
     * Единая точка записи данных аутентифицированного юзера. Обёрнуто в try-блоки по каждой
     * записи, чтобы частичный сбой одного холдера не порушил остальные.
     */
    private fun persistAuthedUser(tempUser: User, authedId: String) {
        try {
            repo().saveUser(tempUser)
        } catch (e: Exception) {
            Log.e(TAG, "persistAuthedUser.userRepository: $e")
        }
        try {
            val userEntity = UserEntity(
                tempUser.id,
                tempUser.token,
                tempUser.hasConversations,
                tempUser.isBanned,
                tempUser.conversationsUnread
            )
            io.carrotquest_sdk.android.data.repositories.UserRepository.getInstance().saveUser(userEntity)
        } catch (e: Exception) {
            Log.e(TAG, "persistAuthedUser.kotlinRepo: $e")
        }
        try {
            saveAuthedUserIdUseCase(authedId, tempUser.id, contextSdk)
        } catch (e: Exception) {
            Log.e(TAG, "persistAuthedUser.saveAuthedId: $e")
        }
        try {
            saveJwtToken(tempUser.token, contextSdk)
        } catch (e: Exception) {
            Log.e(TAG, "persistAuthedUser.saveJwtToken: $e")
        }
    }

    /** Обновляет JWT-токен, если протух (под shared lock, на IO). */
    private suspend fun refreshTokenIfNeeded() {
        if (isActualJwtToken(contextSdk)) {
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "refreshTokenIfNeeded: access actual → no pre-auth refresh")
            return
        }
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "refreshTokenIfNeeded: access NOT actual → refreshing before auth")
        withContext(SdkDispatchers.io) {
            val newToken = refreshJwtTokenBlocking(null)
            if (newToken != null) {
                val u = repo().getUser()
                if (u != null) {
                    u.token = newToken
                    repo().saveUser(u)
                }
                SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "refreshTokenIfNeeded: refreshed access before auth (no new lead)")
            } else {
                // Сервер отверг refresh (не сеть — IOException пробрасывается из blocking) → оба
                // токена мертвы. Чистим протухшие persisted креды: дальнейший auth всё равно упадёт
                // 403, но persisted-состояние станет чистым, и на следующем /connect (перезапуск
                // приложения) сессия восстановится анонимом без переустановки.
                SdkLogger.log(
                    SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                    "refreshTokenIfNeeded: refresh dead (both tokens expired) → clearing creds, will fall back to anonymous on next /connect",
                )
                clearJwtTokens(contextSdk)
            }
        }
    }

    /**
     * Общее ядро авторизации (performAuth/performHashedAuth отличались только вызовом
     * carrotLib.auth vs hashedAuth — параметризовано authCall).
     */
    private suspend fun performAuth(
        id: String,
        getAuthUserObserver: Callback<User>?,
        authCall: suspend () -> io.carrotquest_sdk.android.lib.network.responses.auth.AuthResponse
    ) {
        if (!SdkStateManager.isInit()) return

        val connectedUserId = getConnectedUserIdUseCase(contextSdk)
        val authedUserIds = getAuthedUserIdUseCase(contextSdk)
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
            "performAuth: externalId=$id, connectedUserId=$connectedUserId, storedAuthedIds=$authedUserIds",
        )
        if (shouldSkipAuth(id, connectedUserId, authedUserIds)) {
            // Уже авторизованы тем же id и connect вернул того же пользователя — сеть не нужна.
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "performAuth: SKIP network auth — already authed (connectedUserId==authedUserId)")
            getAuthUserObserver?.let { obs ->
                val user = repo().getUser()
                withContext(SdkDispatchers.main) { obs.onResponse(user) }
            }
            return
        }

        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "performAuth: running network auth (will refresh access first if not actual)")
        try {
            refreshTokenIfNeeded()
            val response = authCall()
            withContext(SdkDispatchers.main) {
                val data = response.data
                if (data?.user != null) {
                    val tempUser = data.user
                    if (tempUser.token.isNullOrEmpty() && !data.authToken.isNullOrEmpty()) {
                        tempUser.token = data.authToken
                    }
                    persistAuthedUser(tempUser, id)

                    // Смена пользователя (аноним→authed): переносим флаги согласий из ответа app_auth
                    // в sourceData настроек. Без этого buildConsentState читал флаги предыдущего юзера
                    // (аноним, не давал согласие) → плашка согласия показывалась повторно.
                    val consentFlags = buildMap {
                        data.dataProcessingPolicyIsAllowed?.let { put("data_processing_policy_is_allowed", it) }
                        data.emailStorageIsAllowed?.let { put("email_storage_is_allowed", it) }
                        data.phoneStorageIsAllowed?.let { put("phone_storage_is_allowed", it) }
                    }
                    SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.NETWORK, "UserConsent") {
                        "auth: applying consent flags to settings=$consentFlags"
                    }
                    updateAppUserFlags(consentFlags)
                } else if (data != null && "not_need" == data.result) {
                    try {
                        saveAuthedUserIdUseCase(id, UserStateHolder.currentId(), contextSdk)
                    } catch (e: Exception) {
                        Log.e(TAG, e)
                    }
                }

                val user = repo().getUser()
                // Подгрузка бесед после auth (раньше — getConversations(observer)): отдельная
                // корутина, чтобы performAuth не ждал сеть и сразу шёл к initPushesService().
                serviceScope.launch {
                    try {
                        OperationQueue.execute { carrotLib.getConversationsSuspend(user.id) }
                        withContext(SdkDispatchers.main) {
                            getAuthUserObserver?.onResponse(user)
                            WssManager.start(appId.orEmpty(), user.id.orEmpty())
                        }
                    } catch (e: Throwable) {
                        withContext(SdkDispatchers.main) { getAuthUserObserver?.onFailure(e) }
                    }
                }

                initPushesService()
            }
        } catch (c: CancellationException) {
            throw c
        } catch (e: Throwable) {
            authError(e)
            withContext(SdkDispatchers.main) { getAuthUserObserver?.onFailure(e) }
        }
    }

    private fun authError(e: Throwable) {
        if (e is HttpException) {
            val code = e.code()
            try {
                val responseBody: ResponseBody? = e.response()?.errorBody()
                val body = responseBody?.string() ?: ""
                // Раньше тело 403/401 читалось и молча отбрасывалось — отсюда "логов почти нет".
                // Логируем реальную причину отказа сервера (invalid hash / token expired / forbidden и т.п.).
                // ВАЖНО: здесь токены НЕ чистим. К моменту authError TokenRefreshInterceptor уже пытался
                // обновить access по refresh-токену. Если refresh был жив — токены валидны, и 401/403
                // означают НЕ-токеновую причину (например, неверный hash). Чистить креды здесь нельзя:
                // это уничтожило бы валидный refresh и заставило бы зря создавать нового анонима.
                // Сброс кредов делается только там, где /refresh реально провалился (interceptor /
                // refreshTokenIfNeeded / ConnectionManager).
                SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "authError: HTTP $code body=$body")
            } catch (npe: NullPointerException) {
                Log.e(TAG, npe)
            } catch (e1: Exception) {
                Log.e(TAG, e1)
            }
        }
        Log.e(TAG, e)
    }

    /** Отмена всех асинхронных операций сервиса (раньше deInitDisposables). */
    private fun cancelServiceWork() {
        authJob?.cancel()
        typingJob?.cancel()
        serviceScope.coroutineContext.cancelChildren()
        // adminTypingFlow не требует сброса: CarrotService пересоздаётся при re-init, а подписчик
        // (MessagesRepository) отменяет свой collect в своём deInit.
    }

    override fun setUserConsentContact(contacts: String, userId: String, partId: String, callback: Callback<Boolean>) {
        serviceScope.launch {
            // Причину неуспеха фиксируем ЗДЕСЬ — выше по стеку доступен только Boolean, и
            // сбой user_consent был полностью молчаливым (согласие терялось без следа).
            // Значения контактов не логируем (PII) — только ключи.
            val contactKeys = runCatching {
                com.google.gson.JsonParser.parseString(contacts).asJsonObject.keySet().joinToString(",")
            }.getOrDefault("?")
            try {
                val r = carrotLib.setUserConsentContactSuspend(contacts, partId, userId)
                val error = r.meta?.error
                if (error != null) {
                    SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG) {
                        "user_consent contact rejected: error=$error status=${r.meta?.status} keys=$contactKeys partId=$partId"
                    }
                }
                withContext(SdkDispatchers.main) { callback.onResponse(error == null) }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG) {
                    "user_consent contact request failed: $e keys=$contactKeys partId=$partId"
                }
                withContext(SdkDispatchers.main) { callback.onResponse(false) }
            }
        }
    }

    override fun setUserConsentDataProcessing(dataProcessing: Boolean?, userId: String, callback: Callback<Boolean>) {
        serviceScope.launch {
            try {
                val r = carrotLib.setUserConsentDataProcessingSuspend(dataProcessing, userId)
                val error = r.meta?.error
                if (error != null) {
                    SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG) {
                        "user_consent data_processing rejected: error=$error status=${r.meta?.status}"
                    }
                }
                withContext(SdkDispatchers.main) { callback.onResponse(error == null) }
            } catch (c: CancellationException) {
                throw c
            } catch (e: Throwable) {
                SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.NETWORK, TAG) {
                    "user_consent data_processing request failed: $e"
                }
                withContext(SdkDispatchers.main) { callback.onResponse(false) }
            }
        }
    }

    companion object {
        private const val TAG = "CarrotService"
        private const val UNSUBSCRIBE_PUSH_TIMEOUT_SECONDS = 5L
        // Минимальный интервал между авто-восстановлениями сессии (см. recoverSession).
        private const val SESSION_RECOVERY_COOLDOWN_MS = 30_000L
        // Минимальный интервал между пингами typing-индикатора (лидирующий throttle).
        private const val TYPING_THROTTLE_MS = 2000L

        /**
         * Авторизацию по сети можно пропустить, если мы уже авторизованы тем же внешним id и
         * connect вернул того же пользователя, что сохранён как authed. Чистая функция — вынесена
         * из performAuth для тестируемости.
         *
         * @param id               внешний id, переданный в auth()
         * @param connectedUserId  carrot-id, полученный при последнем connect (может быть null)
         * @param authedUserIds    [authedExternalId, authedCarrotUserId] из хранилища (может быть null)
         */
        @JvmStatic
        internal fun shouldSkipAuth(id: String, connectedUserId: String?, authedUserIds: List<String>?): Boolean {
            if (authedUserIds != null && authedUserIds.size == 2) {
                val authedId = authedUserIds[0]
                val authedUserId = authedUserIds[1]
                return authedId == id && connectedUserId != null && connectedUserId == authedUserId
            }
            return false
        }

        private var instance: CarrotService? = null

        @JvmStatic
        fun getInstance(): CarrotService {
            return instance ?: CarrotService().also { instance = it }
        }
    }
}
