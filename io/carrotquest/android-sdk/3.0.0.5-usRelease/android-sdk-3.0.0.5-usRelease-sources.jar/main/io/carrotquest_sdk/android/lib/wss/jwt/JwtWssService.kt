package io.carrotquest_sdk.android.lib.wss.jwt

import android.content.Context
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.managers.BackgroundManager
import io.carrotquest_sdk.android.lib.managers.UserPresenceService
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.lib.wss.Channel
import io.carrotquest_sdk.android.lib.wss.IWssService
import io.carrotquest_sdk.android.lib.wss.WssMessageListener
import io.carrotquest_sdk.android.lib.wss.utils.CloseReason
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val tag = "JwtWssService"
// Базовая задержка перед авто-реконнектом после обрыва (сек) — backoff против флапа.
private const val RECONNECT_DELAY_SEC = 3L
// Потолок экспоненциального backoff (сек).
private const val MAX_RECONNECT_DELAY_SEC = 30L
// После стольких ПОДРЯД быстрых реконнектов считаем, что соединение зацикленно отвергается
// (обычно — невалидный токен/нехватка scopes), и вместо долбёжки тем же токеном триггерим
// пересоздание сессии (recovery перезапустит RTS со свежим токеном).
private const val MAX_RECONNECT_ATTEMPTS = 5
// Если прошлый реконнект был давнее этого окна (мс) — считаем обрыв НОВЫМ инцидентом, а не петлёй,
// и сбрасываем счётчик (одиночные обрывы за сессию не должны накапливаться до ложной эскалации).
private const val RECONNECT_RESET_WINDOW_MS = 60_000L
// Период проверки живости RTS-сокета (мс).
private const val LIVENESS_CHECK_INTERVAL_MS = 30_000L
// Если по «подключённому» сокету не было НИ ОДНОГО входящего фрейма дольше этого порога (мс) —
// считаем его «тихо умершим» и принудительно переподключаем. При keepalive-пинге (20с) сервер
// отвечает pong примерно каждые 20с, поэтому 70с молчания (≈3 пропущенных pong) — надёжный признак
// мёртвого канала, который сама библиотека не задетектила (half-open: запись ping не падает).
private const val LIVENESS_STALE_THRESHOLD_MS = 70_000L
class JwtWssService(private val context: Context, private val rtsHost: String): IWssService {
    private val backgroundManager = BackgroundManager.getInstance()
    private val networkManager = NetworkManager.getInstance(context)
    private val scope = CoroutineScope(SdkDispatchers.io + SupervisorJob())

    private val sockets = ArrayList<JwtClientWebSocket>()

    // Счётчик подряд идущих быстрых реконнектов (для backoff + эскалации в recovery).
    @Volatile
    private var reconnectAttempts = 0
    @Volatile
    private var lastReconnectMs = 0L

    init {
        backgroundManager.addObserver {
            changeStateSockets()
        }

        networkManager.addObserver {
            changeStateSockets()
        }

        // Подписываемся на обновление JWT токена.
        // Когда токен обновляется (обычно каждые 30 минут), нам нужно
        // переподключить сокеты, так как старое соединение авторизовано старым токеном.
        scope.launch {
            JwtTokenRefreshService.getInstance().updateJwtTokenFlow.collect {
                Log.d(tag, "JWT updated, reconnecting sockets...")
                reconnectSockets()
            }
        }

        // Watchdog живости: ловит «тихо умерший» сокет (подключён, но молча перестал доставлять —
        // half-open после простоя, либо любой другой повод). Сама библиотека такое не всегда
        // детектит, а пути реконнекта завязаны на isConnected/обрыв, поэтому нужен независимый
        // детектор по давности входящего трафика.
        scope.launch {
            while (true) {
                delay(LIVENESS_CHECK_INTERVAL_MS)
                if (!networkManager.hasConnect || !backgroundManager.lastStateIsForeground()) continue
                val now = System.currentTimeMillis()
                sockets.forEach { s ->
                    val last = s.lastInboundMs()
                    val ageSec = if (last > 0L) (now - last) / 1000 else -1
                    val connected = s.isConnected()
                    when {
                        connected && last > 0L && now - last > LIVENESS_STALE_THRESHOLD_MS -> {
                            SdkLogger.log(
                                SdkLogLevel.WARN, SdkLogCategory.REALTIME, tag,
                                "RTS liveness watchdog: no inbound for ${ageSec}s on ${s.getAppId()} (connected=$connected) — forcing reconnect"
                            )
                            // Принудительный stop→connect (как при рефреше токена): операции
                            // сериализованы внутри JwtClientWebSocket, поэтому безопасны.
                            s.stop(reason = CloseReason.NONE)
                            s.connect()
                        }
                        // Раннее предупреждение: входящие «стареют», но порог ещё не достигнут.
                        // Здоровые тики (pong ~каждые 20с) сюда не попадают и буфер не засоряют.
                        connected && last > 0L && now - last > LIVENESS_STALE_THRESHOLD_MS / 2 -> {
                            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.REALTIME, tag, "RTS liveness: inbound aging ${ageSec}s on ${s.getAppId()} (threshold ${LIVENESS_STALE_THRESHOLD_MS / 1000}s)")
                        }
                    }
                }
            }
        }
    }

    override fun startSocket(
        appId: String?,
        channels: MutableList<Channel>?,
        listener: WssMessageListener?
    ) {
        if (appId != null && !channels.isNullOrEmpty() && listener != null) {
            //connect
            val clientWebSocket = JwtClientWebSocket(
                appId,
                ArrayList(channels.toList()),
                rtsHost,
                listener
            )
            // Неожиданный обрыв соединения (простой/сеть) — переподнимаем сокет с backoff.
            clientWebSocket.onDisconnect = { scheduleReconnect(clientWebSocket) }
            clientWebSocket.connect()
            sockets.add(clientWebSocket)
        }
    }

    override fun stopSocket(appId: String?) {
        val filteredSockets = sockets.filter { s -> s.getAppId() == appId }

        if (filteredSockets.isNotEmpty()) {
            filteredSockets.forEach { s ->
                s.stop(reason = CloseReason.NONE)
                s.dispose() // окончательный снос — освобождаем выделенный поток сокета
            }
            //?
            sockets.removeAll(filteredSockets.toSet())
        }
    }

    override fun deInit() {
        scope.coroutineContext.cancelChildren()
        for (socket in sockets) {
            socket.stop(reason = CloseReason.DEINIT)
            socket.dispose() // окончательный снос — освобождаем выделенный поток сокета
        }

        NetworkManager.getInstance(context).deInit()
        BackgroundManager.getInstance().deInit()
    }

    private fun reconnectSockets() {
        val hasInternetConnect = networkManager.hasConnect
        val isForeground = backgroundManager.lastStateIsForeground()

        if (hasInternetConnect && isForeground) {
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.REALTIME, tag, "reconnectSockets (JWT updated): online=$hasInternetConnect foreground=$isForeground sockets=${sockets.size}")
            // Свежий токен — это здоровый реконнект, не петля: сбрасываем счётчик попыток.
            reconnectAttempts = 0
            sockets.forEach { s ->
                // Принудительно закрываем и открываем заново,
                // чтобы JwtClientWebSocket.connect() подхватил новый токен из репозитория.
                s.stop(reason = CloseReason.NONE)
                s.connect()
            }
        } else {
            // Реконнект погашен: после рефреша сокеты остались на СТАРОМ токене. Важный для разбора
            // случай — если RTS «не ожил» после рефреша, ищем эту строку.
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.REALTIME, tag, "reconnectSockets (JWT updated) SKIPPED: online=$hasInternetConnect foreground=$isForeground — sockets stay on old token until next foreground/online")
        }
    }

    // Переподключение после НЕожиданного обрыва (onDisconnect). Экспоненциальный backoff +
    // проверки foreground/online против флапа сети. Если сокет рвётся ПОДРЯД много раз быстро —
    // это не сетевой флап, а зацикленный отказ авторизации (невалидный токен/нехватка scopes:
    // сервер рвёт хендшейк → "ID is null" → реконнект тем же токеном → снова обрыв). В этом случае
    // НЕ долбим тем же токеном бесконечно, а триггерим пересоздание сессии — recovery перезапустит
    // RTS со свежим токеном (WssManager.stop()→start()), что отменит и эту петлю.
    private fun scheduleReconnect(socket: JwtClientWebSocket) {
        scope.launch {
            try {
                val now = System.currentTimeMillis()
                // Давний прошлый реконнект → это новый инцидент, не петля: сбрасываем счётчик.
                if (now - lastReconnectMs > RECONNECT_RESET_WINDOW_MS) reconnectAttempts = 0
                lastReconnectMs = now

                if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
                    SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.REALTIME, tag, "RTS reconnect loop (attempts=$reconnectAttempts) — likely invalid token/scopes, triggering session recovery")
                    reconnectAttempts = 0
                    SdkStateManager.notifySessionExpired()
                    return@launch
                }

                val attempt = reconnectAttempts
                reconnectAttempts++
                val backoffSec = minOf(RECONNECT_DELAY_SEC shl attempt, MAX_RECONNECT_DELAY_SEC)
                delay(backoffSec * 1000)

                val online = networkManager.hasConnect
                val foreground = backgroundManager.lastStateIsForeground()
                if (online && foreground && !socket.isConnected()) {
                    SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.REALTIME, tag, "RTS dropped — reconnecting socket ${socket.getAppId()} (attempt ${attempt + 1}, backoff ${backoffSec}s)")
                    socket.connect()
                }
            } catch (t: Throwable) {
                SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.REALTIME, tag, "RTS reconnect scheduling failed", t)
            }
        }
    }

    private fun changeStateSockets() {
        // hasConnect — прогретый ping'ом кэш; на старте или при заблокированном/медленном ping
        // он может быть холодным false при живой сети. Страхуемся синхронной системной проверкой,
        // чтобы не рвать живые сокеты по ложному оффлайну (ложный INTERNET_DISAPPEARED).
        val hasInternetConnect = networkManager.hasConnect || networkManager.isNetworkAvailable()
        val isForeground = backgroundManager.lastStateIsForeground()
        if(hasInternetConnect && isForeground) {
            // Сеть/foreground восстановлены — здоровое условие, сбрасываем счётчик попыток.
            reconnectAttempts = 0
            sockets.forEach { s ->
                if(!s.isConnected()) {
                    SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.CONNECTIVITY, tag, "changeStateSockets: online+foreground, socket ${s.getAppId()} not connected → reconnecting")
                    s.connect()
                }
                // Если isConnected()==true, реконнекта тут НЕ будет (так и задумано). Если при этом
                // канал на деле мёртв — поймает watchdog по давности входящих.
            }
            UserPresenceService.getInstance().run()
        } else {
            val closeReason = if(!isForeground) CloseReason.APP_TO_BACKGROUND else CloseReason.INTERNET_DISAPPEARED
            SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.CONNECTIVITY, tag, "changeStateSockets: online=$hasInternetConnect foreground=$isForeground → stopping sockets ($closeReason)")
            sockets.forEach { s ->
                if(s.isConnected()) {
                    s.stop(reason = closeReason)
                }
            }
            UserPresenceService.getInstance().stop()
        }
    }
}
