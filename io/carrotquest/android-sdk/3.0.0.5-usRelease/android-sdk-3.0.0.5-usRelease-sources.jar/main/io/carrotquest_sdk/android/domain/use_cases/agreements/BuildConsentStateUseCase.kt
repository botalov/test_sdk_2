package io.carrotquest_sdk.android.domain.use_cases.agreements

import com.google.gson.JsonObject
import com.google.gson.JsonParser
import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings

/**
 * Настройки согласий, разобранные из сырого JSON connect-ответа (SettingsEntity.sourceData).
 *
 * Поля настроек лежат в data.app.settings, флаги пользователя («уже дал согласие») — в data.user.
 * Все поля опциональны: бэкенд может их не прислать (старый сервер / согласия выключены).
 */
data class ConsentSettings(
    // data.app.settings
    val dataProcessingPolicy: Boolean = false,
    val dataProcessingPolicyWithCheckbox: Boolean = false,
    val dataProcessingPolicyUrl: String? = null,
    val messengerShowConfirmSubscription: Boolean = false,
    val messengerConfirmSubscriptionWithCheckbox: Boolean = false,
    val termsOfEmailStorageUrl: String? = null,
    val termsOfPhoneStorageUrl: String? = null,
    // data.user
    val dataProcessingPolicyIsAllowed: Boolean = false,
    val emailStorageIsAllowed: Boolean = false,
    val phoneStorageIsAllowed: Boolean = false,
)

private const val KEY_DATA_PROCESSING_POLICY = "data_processing_policy"
private const val KEY_DATA_PROCESSING_POLICY_WITH_CHECKBOX = "data_processing_policy_with_checkbox"
private const val KEY_DATA_PROCESSING_POLICY_URL = "data_processing_policy_url"
private const val KEY_MESSENGER_SHOW_CONFIRM_SUBSCRIPTION = "messenger_show_confirm_subscription"
private const val KEY_MESSENGER_CONFIRM_SUBSCRIPTION_WITH_CHECKBOX = "messenger_confirm_subscription_with_checkbox"
private const val KEY_TERMS_OF_EMAIL_STORAGE = "terms_of_email_storage"
private const val KEY_TERMS_OF_PHONE_STORAGE = "terms_of_phone_storage"

private const val KEY_DATA_PROCESSING_POLICY_IS_ALLOWED = "data_processing_policy_is_allowed"
private const val KEY_EMAIL_STORAGE_IS_ALLOWED = "email_storage_is_allowed"
private const val KEY_PHONE_STORAGE_IS_ALLOWED = "phone_storage_is_allowed"

/**
 * Разбирает настройки согласий из sourceData connect-ответа.
 * Устойчиво к отсутствию/невалидности JSON — в этом случае вернёт значения по умолчанию (всё выключено).
 */
fun parseConsentSettings(sourceData: String?): ConsentSettings {
    if (sourceData.isNullOrBlank()) return ConsentSettings()
    val root = runCatching { JsonParser.parseString(sourceData) as? JsonObject }.getOrNull()
        ?: return ConsentSettings()

    // Настройки согласий бэкенд может класть в data.app.settings (там messenger-конфиг) ИЛИ в
    // data.settings (так указано в задаче) — читаем из обоих (app.settings приоритетнее).
    val appSettings = root.optObject("app")?.optObject("settings")
    val topSettings = root.optObject("settings")
    val user = root.optObject("user")

    fun bool(key: String) = appSettings.optBool(key) || topSettings.optBool(key)
    fun str(key: String) = appSettings.optString(key) ?: topSettings.optString(key)

    return ConsentSettings(
        dataProcessingPolicy = bool(KEY_DATA_PROCESSING_POLICY),
        dataProcessingPolicyWithCheckbox = bool(KEY_DATA_PROCESSING_POLICY_WITH_CHECKBOX),
        dataProcessingPolicyUrl = str(KEY_DATA_PROCESSING_POLICY_URL),
        messengerShowConfirmSubscription = bool(KEY_MESSENGER_SHOW_CONFIRM_SUBSCRIPTION),
        messengerConfirmSubscriptionWithCheckbox = bool(KEY_MESSENGER_CONFIRM_SUBSCRIPTION_WITH_CHECKBOX),
        termsOfEmailStorageUrl = str(KEY_TERMS_OF_EMAIL_STORAGE),
        termsOfPhoneStorageUrl = str(KEY_TERMS_OF_PHONE_STORAGE),
        dataProcessingPolicyIsAllowed = user.optBool(KEY_DATA_PROCESSING_POLICY_IS_ALLOWED),
        emailStorageIsAllowed = user.optBool(KEY_EMAIL_STORAGE_IS_ALLOWED),
        phoneStorageIsAllowed = user.optBool(KEY_PHONE_STORAGE_IS_ALLOWED),
    )
}

/**
 * Строит состояние блока согласия для шага чата, запрашивающего поле [requestedField].
 *
 * Правила (синхронизированы с веб-чатом):
 * - Строка обработки перс. данных: показывается, если включена настройка и пользователь ещё не давал согласие.
 * - Строка хранения контакта: показывается только при запросе email/phone, если включено
 *   подтверждение подписки и по соответствующему контакту согласия ещё нет.
 * Уже данные согласия (флаги *_is_allowed) строку убирают, чтобы не спрашивать повторно.
 */
fun buildConsentState(settings: ConsentSettings, requestedField: RequestedContactField): ConsentUiState {
    val lines = mutableListOf<ConsentLine>()

    if (settings.dataProcessingPolicy && !settings.dataProcessingPolicyIsAllowed) {
        lines += ConsentLine(
            kind = ConsentKind.DATA_PROCESSING,
            withCheckbox = settings.dataProcessingPolicyWithCheckbox,
            checked = !settings.dataProcessingPolicyWithCheckbox,
            url = settings.dataProcessingPolicyUrl,
        )
    }

    if (settings.messengerShowConfirmSubscription) {
        val withCheckbox = settings.messengerConfirmSubscriptionWithCheckbox
        when (requestedField) {
            RequestedContactField.EMAIL -> if (!settings.emailStorageIsAllowed) {
                lines += ConsentLine(
                    kind = ConsentKind.EMAIL_SUBSCRIPTION,
                    withCheckbox = withCheckbox,
                    checked = !withCheckbox,
                    url = settings.termsOfEmailStorageUrl,
                )
            }
            RequestedContactField.PHONE -> if (!settings.phoneStorageIsAllowed) {
                lines += ConsentLine(
                    kind = ConsentKind.PHONE_SUBSCRIPTION,
                    withCheckbox = withCheckbox,
                    checked = !withCheckbox,
                    url = settings.termsOfPhoneStorageUrl,
                )
            }
            RequestedContactField.NONE -> Unit
        }
    }

    return ConsentUiState(lines)
}

/**
 * Удобная обёртка: читает актуальные настройки из кэша (SettingsRepository) и строит состояние.
 * Возвращает пустой ConsentUiState, если настроек ещё нет.
 */
fun buildConsentState(requestedField: RequestedContactField): ConsentUiState {
    val settings: SettingsEntity = getSettings() ?: return ConsentUiState()
    return buildConsentState(parseConsentSettings(settings.sourceData), requestedField)
}

private fun JsonObject?.optObject(key: String): JsonObject? =
    this?.takeIf { it.has(key) && it.get(key).isJsonObject }?.getAsJsonObject(key)

private fun JsonObject?.optBool(key: String): Boolean {
    val el = this?.takeIf { it.has(key) }?.get(key) ?: return false
    return runCatching { el.isJsonPrimitive && el.asJsonPrimitive.isBoolean && el.asBoolean }.getOrDefault(false)
}

private fun JsonObject?.optString(key: String): String? {
    val el = this?.takeIf { it.has(key) && !it.get(key).isJsonNull }?.get(key) ?: return null
    if (!el.isJsonPrimitive || !el.asJsonPrimitive.isString) return null
    return runCatching { el.asString }.getOrNull()?.takeIf { it.isNotBlank() }
}
