package io.carrotquest_sdk.android.domain.use_cases.agreements

/**
 * Тип запрашиваемых у пользователя персональных данных в текущем шаге чата.
 * От него зависит, какую строку согласия на хранение контакта показывать.
 */
enum class RequestedContactField { EMAIL, PHONE, NONE }

/**
 * Вид согласия. Определяет текст строки и то, каким use-case факт согласия сохраняется:
 * DATA_PROCESSING -> allowDataProcessingUseCase, *_SUBSCRIPTION -> allowTrackContactsUseCase.
 */
enum class ConsentKind { DATA_PROCESSING, EMAIL_SUBSCRIPTION, PHONE_SUBSCRIPTION }

/**
 * Одна строка блока согласия.
 *
 * @property withCheckbox true — обязательный чекбокс (блокирует отправку, пока не отмечен);
 *                        false — неявное согласие («Нажимая на кнопку, вы соглашаетесь…»), не блокирует.
 * @property checked      состояние чекбокса. Для неявной строки всегда true.
 * @property url          ссылка на документ (политика/условия хранения), может быть null.
 */
data class ConsentLine(
    val kind: ConsentKind,
    val withCheckbox: Boolean,
    val checked: Boolean,
    val url: String?,
)

/**
 * Состояние блока согласия для текущего шага чата. Содержит 0..2 строки
 * (обработка перс. данных и/или подтверждение хранения контакта).
 *
 * Пустой список строк означает, что блок показывать не нужно.
 */
data class ConsentUiState(
    val lines: List<ConsentLine> = emptyList(),
) {
    /** Есть ли что показывать. */
    val isVisible: Boolean get() = lines.isNotEmpty()

    /**
     * Гейт кнопки отправки: все обязательные (с чекбоксом) строки отмечены.
     * Неявные строки согласия отправку не блокируют.
     */
    val allRequiredChecked: Boolean get() = lines.none { it.withCheckbox && !it.checked }

    /** Переключить чекбокс строки данного вида (для неявных строк — no-op). */
    fun toggled(kind: ConsentKind): ConsentUiState = copy(
        lines = lines.map { line ->
            if (line.kind == kind && line.withCheckbox) line.copy(checked = !line.checked) else line
        }
    )
}