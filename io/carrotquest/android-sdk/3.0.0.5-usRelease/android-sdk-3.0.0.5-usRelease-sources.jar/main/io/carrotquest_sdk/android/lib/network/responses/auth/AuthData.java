package io.carrotquest_sdk.android.lib.network.responses.auth;

import androidx.annotation.Keep;

import com.google.gson.annotations.SerializedName;

import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.lib.network.responses.base.Data;

@Keep
public class AuthData extends Data {
    @SerializedName("auth_token")
    private String authToken;
    @SerializedName("user")
    private User user;

    @SerializedName("refresh")
    private String refreshToken;

    @SerializedName("result")
    private String result;

    // Флаги согласий пользователя из data.user ответа app_auth. Nullable: null = сервер не прислал
    // (не трогаем локальное значение). Нужны, чтобы после смены пользователя (аноним→authed)
    // обновить sourceData настроек — иначе плашка согласия показывалась повторно (флаги были от анонима).
    private Boolean dataProcessingPolicyIsAllowed;
    private Boolean emailStorageIsAllowed;
    private Boolean phoneStorageIsAllowed;

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Boolean getDataProcessingPolicyIsAllowed() {
        return dataProcessingPolicyIsAllowed;
    }

    public void setDataProcessingPolicyIsAllowed(Boolean value) {
        this.dataProcessingPolicyIsAllowed = value;
    }

    public Boolean getEmailStorageIsAllowed() {
        return emailStorageIsAllowed;
    }

    public void setEmailStorageIsAllowed(Boolean value) {
        this.emailStorageIsAllowed = value;
    }

    public Boolean getPhoneStorageIsAllowed() {
        return phoneStorageIsAllowed;
    }

    public void setPhoneStorageIsAllowed(Boolean value) {
        this.phoneStorageIsAllowed = value;
    }
}
