package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.domain.entities.popup.PopUpMessageEntity
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversationSuspend
import io.carrotquest_sdk.android.domain.use_cases.conversations.markConversationAsReadById
import io.carrotquest_sdk.android.domain.use_cases.conversations.popUpMessageFromConversation
import io.carrotquest_sdk.android.presentation.mvp.popup.view.PopupAlertDialog
import kotlinx.coroutines.withContext

/**
 * Re-shows a pop-up as an overlay when its conversation is tapped in the list, instead of opening
 * an empty chat (a pop-up has no chat messages, so the dialog body would be blank — bug #11).
 *
 * Content source (Variant B): use the cached [PopUpMessageEntity] from [PopUpDao] if present;
 * otherwise rebuild it from the conversation's last part (body_json) fetched via
 * [getConversationSuspend]. Unlike [showPopup], the pop-up is NOT deleted afterwards, so it can be
 * reopened repeatedly.
 */
suspend fun reshowPopup(conversationId: String) {
    val entity = getPopUpEntity(conversationId) ?: rebuildFromConversation(conversationId)
    if (entity == null) {
        Log.e("reshowPopup", "no pop-up content for conversation $conversationId")
        return
    }

    val activity = SdkApp.getInstance().currentActivity ?: return
    withContext(SdkDispatchers.main) {
        if (PopupAlertDialog.isShowing()) return@withContext
        val builder = PopupAlertDialog(activity, R.style.popUpStyle)
        builder.show().show()
        builder.setData(entity.id, entity.sourceBodyJson, entity.backgroundColor)
    }

    // Помечаем диалог прочитанным (как при обычном открытии). НЕ удаляем pop-up из БД —
    // в отличие от showPopup(), чтобы его можно было открывать повторно.
    try {
        markConversationAsReadById(conversationId)
    } catch (t: Throwable) {
        Log.e("reshowPopup/markRead", t)
    }
}

private suspend fun rebuildFromConversation(conversationId: String): PopUpMessageEntity? {
    val conversation = getConversationSuspend(conversationId) ?: return null
    val popUp = popUpMessageFromConversation(conversation) ?: return null
    return PopUpMessageEntity(
        popUp.id,
        popUp.sourceJson,
        popUp.expirationTime,
        popUp.backgroundColor,
    )
}
