package io.carrotquest_sdk.android.presentation.chat.input

/** Максимум вложений в одном сообщении (бэкенд-ограничение). При достижении — attach блокируется. */
const val MAX_ATTACHMENTS = 10

/**
 * Вложение, выбранное в инпуте и загружаемое/загруженное на бэкенд (upload-on-select), но ещё не
 * отправленное сообщением. Чисто UI-модель: [clientId] — стабильный ключ для матчинга чипа с
 * фоновой загрузкой (Job) и обновления состояния по id (список меняется асинхронно, индекс не
 * годится). Серверный ref (объект attachment из POST /attachments) держит презентер в своей
 * map clientId→Attachment — сюда lib-модель не тащим.
 *
 * Варианты названы [ImageAttachment]/[FileAttachment], чтобы не затенять java.io.File.
 */
sealed class PendingAttachment {
    abstract val clientId: String
    abstract val localUri: String
    abstract val uploadState: AttachmentUploadState

    abstract fun withUploadState(state: AttachmentUploadState): PendingAttachment

    data class ImageAttachment(
        override val clientId: String,
        override val localUri: String,
        override val uploadState: AttachmentUploadState = AttachmentUploadState.UPLOADING,
    ) : PendingAttachment() {
        override fun withUploadState(state: AttachmentUploadState) = copy(uploadState = state)
    }

    data class FileAttachment(
        override val clientId: String,
        override val localUri: String,
        val name: String,
        val sizeLabel: String,
        override val uploadState: AttachmentUploadState = AttachmentUploadState.UPLOADING,
    ) : PendingAttachment() {
        override fun withUploadState(state: AttachmentUploadState) = copy(uploadState = state)
    }
}

enum class AttachmentUploadState {
    PENDING,
    UPLOADING,
    UPLOADED,
    FAILED,
}
