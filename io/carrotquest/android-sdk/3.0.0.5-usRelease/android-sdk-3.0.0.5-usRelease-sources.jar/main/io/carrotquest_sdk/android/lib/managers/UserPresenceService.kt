package io.carrotquest_sdk.android.lib.managers

import android.util.Log
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.F
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class UserPresenceService private constructor() {

    private var isRun = false
    private val scope = CoroutineScope(SdkDispatchers.io + SupervisorJob())
    // Периодическая отправка ONLINE (раньше Observable.interval + disposable).
    private var presenceJob: Job? = null
    // Разовая отправка ONLINE при старте (раньше firstDisposable).
    private var firstJob: Job? = null

    companion object {
        private const val TAG = "UserPresenceService"
        private const val PRESENCE_INTERVAL_MS = 30_000L
        private var instance: UserPresenceService? = null
        fun getInstance(): UserPresenceService {
            if (instance == null) {
                instance = UserPresenceService()
            }
            return instance!!
        }
    }

    // Ошибка отправки presence некритична — раньше onErrorReturn(status=400) просто проглатывался.
    private suspend fun sendPresence(userId: String, presence: String) {
        // Кредов нет совсем (token-less после сброса сессии): запрос гарантированно словит 401 и
        // зря разгонит 401→recovery-каскад. Пропускаем тик — после успешного /connect креды
        // появятся, и следующий тик уйдёт как обычно.
        val hasCreds = !CarrotLib.getLibComponents().userRep.user.token.isNullOrEmpty() ||
            io.carrotquest_sdk.android.lib.wss.jwt.getRefreshToken() != null ||
            io.carrotquest_sdk.android.lib.wss.jwt.getJwtToken().isNotEmpty()
        if (!hasCreds) {
            Log.w(TAG, "presence skipped: no credentials (token-less session)")
            return
        }
        try {
            CarrotLib.getLibComponents().carrotApi.setPresence(userId, presence)
        } catch (c: CancellationException) {
            // Отмена корутины (stop()/повторный run() при reconnect/deInit отменяют in-flight
            // presence) — это НЕ ошибка. Пробрасываем, иначе ломаем структурную конкурентность и
            // зашумляем логи ERROR-ом JobCancellationException на каждом старте.
            throw c
        } catch (t: Throwable) {
            Log.e(TAG, "$t")
        }
    }

    fun run() {
        if (isRun) {
            stop()
        } else {
            sendEventAboutStop()
        }
        isRun = true

        val userId = CarrotLib.getLibComponents().userRep.user.id
        if (userId != null && userId.isNotEmpty()) {
            firstJob = scope.launch { sendPresence(userId, F.ONLINE_USER) }
        }
        presenceJob = scope.launch {
            while (isActive) {
                delay(PRESENCE_INTERVAL_MS)
                if (userId != null && userId.isNotEmpty()) {
                    sendPresence(userId, F.ONLINE_USER)
                }
            }
        }
    }

    private fun sendEventAboutStop() {
        val userId = CarrotLib.getLibComponents().userRep.user.id
        if (userId != null && userId.isNotEmpty()) {
            scope.launch { sendPresence(userId, F.OFFLINE_IDLE_USER) }
        }
    }

    fun stop() {
        isRun = false
        presenceJob?.cancel()
        presenceJob = null
        firstJob?.cancel()
        firstJob = null
    }
}
