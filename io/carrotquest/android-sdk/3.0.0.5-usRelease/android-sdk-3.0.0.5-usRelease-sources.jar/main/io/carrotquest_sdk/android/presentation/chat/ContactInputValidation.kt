package io.carrotquest_sdk.android.presentation.chat

import android.util.Patterns

/**
 * Единое правило «можно ли отправить» для всех мест свободного ввода контакта/сообщения:
 * инлайн-форма в теле чата (MessageBubble) и нижний бар ввода (MessageInput / бот property_field).
 * Раньше эта логика была продублирована (DialogFragment.changeEnabledSendButton и MessageBubble),
 * и правила телефона расходились (length > 5 против подсчёта цифр) — здесь они сведены к одному.
 *
 * @param allowed внешнее разрешение: для формы — !isSubmitting, для бара — гейт презентера
 *   (enableSendButton/disableSendButton; базовая phone-проверка через libphonenumber — раньше).
 */
fun computeSendEnabled(text: String, type: ContactInputType, allowed: Boolean): Boolean {
    if (!allowed) return false
    val trimmed = text.trim()
    return when (type) {
        ContactInputType.EMAIL -> Patterns.EMAIL_ADDRESS.matcher(trimmed).matches()
        ContactInputType.PHONE -> trimmed.count { it.isDigit() } >= 5
        ContactInputType.NAME, ContactInputType.TEXT -> trimmed.isNotEmpty()
    }
}