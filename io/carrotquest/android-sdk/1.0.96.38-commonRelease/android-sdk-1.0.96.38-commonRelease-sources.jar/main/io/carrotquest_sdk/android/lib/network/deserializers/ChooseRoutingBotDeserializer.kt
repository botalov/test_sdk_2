package io.carrotquest_sdk.android.lib.network.deserializers

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import com.google.gson.JsonParseException
import io.carrotquest_sdk.android.lib.models.Admin
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.bot.ChatBotData
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotData
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse
import io.carrotquest_sdk.android.lib.utils.json.GsonUtil
import java.lang.reflect.Type

private const val TAG = "ChRoutBotDeserializer"
class ChooseRoutingBotDeserializer : JsonDeserializer<ChooseRoutingBotResponse> {

    override fun deserialize(
        json: JsonElement,
        typeOfT: Type?,
        context: JsonDeserializationContext?
    ): ChooseRoutingBotResponse {
        Log.d("TEST_SETUP_LIB_BOT", "json = $json")
        val response = ChooseRoutingBotResponse()

        if (!(GsonUtil.jsonElementNotNull(json.asJsonObject, F.META) && GsonUtil.jsonElementNotNull(
                json.asJsonObject,
                F.DATA
            ))
        ) {
            throw JsonParseException("meta is null or dataJsonElement is null")
        }

        val metaJsonElement = json.asJsonObject[F.META]
        val dataJsonElement = json.asJsonObject[F.DATA]

        if (metaJsonElement == null || dataJsonElement == null) {
            throw JsonParseException("(metaJsonElement == null) = ${metaJsonElement == null}; (dataJsonElement == null) = ${dataJsonElement == null}")
        }

        try {
            val meta = Gson().fromJson(metaJsonElement, Meta::class.java)
            Log.i("TEST_SETUP_LIB_BOT", "meta.status = ${meta.status}")
            val data = ChooseRoutingBotData()

            data.found = dataJsonElement.asJsonObject[F.FOUND].asBoolean
            data.sender =
                Gson().fromJson(dataJsonElement.asJsonObject[F.MESSAGE_SENDER], Admin::class.java)
            data.bot =
                Gson().fromJson(dataJsonElement.asJsonObject[F.CHAT_BOT], ChatBotData::class.java)

            Log.i("TEST_SETUP_LIB_BOT", "data.found = ${data.found}")
            response.meta = meta
            response.data = data
        } catch (e: Exception) {
            Log.e(TAG, e.toString())
            return Gson().fromJson(json, ChooseRoutingBotResponse::class.java)
        }

        return response
    }
}