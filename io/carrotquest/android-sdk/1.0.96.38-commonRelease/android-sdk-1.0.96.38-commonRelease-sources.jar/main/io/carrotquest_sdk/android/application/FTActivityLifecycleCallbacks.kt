package io.carrotquest_sdk.android.application

import android.app.Activity
import android.app.Application
import android.os.Bundle
import io.carrotquest_sdk.android.core.util.Log
import io.reactivex.functions.Consumer
import io.reactivex.subjects.BehaviorSubject

class FTActivityLifecycleCallbacks : Application.ActivityLifecycleCallbacks{
    private var currentActivity: Activity? = null
    private val currentActivityBehaviorSubject : BehaviorSubject<Activity> = BehaviorSubject.create()

    fun getCurrentActivity() = currentActivity

    override fun onActivityPaused(activity: Activity) {
        this.currentActivity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        this.currentActivity = activity
        if(activity != null) {
            currentActivityBehaviorSubject.onNext(activity)
        }
    }

    override fun onActivityStarted(activity: Activity) {
        this.currentActivity = activity
    }

    override fun onActivityDestroyed(activity: Activity) {
        Log.d("TEST_LAGS", "onActivityDestroyed ${activity.localClassName}")
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
        Log.d("TEST_LAGS", "onActivitySaveInstanceState ${activity.localClassName}")
    }

    override fun onActivityStopped(activity: Activity) {
        Log.d("TEST_LAGS", "onActivityStopped ${activity.localClassName}")
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        this.currentActivity = activity
    }

    fun subscribeOnChangeCurrentActivity(onNext: Consumer<Activity>, onError: Consumer<Throwable>) = currentActivityBehaviorSubject.subscribe(onNext, onError)
}