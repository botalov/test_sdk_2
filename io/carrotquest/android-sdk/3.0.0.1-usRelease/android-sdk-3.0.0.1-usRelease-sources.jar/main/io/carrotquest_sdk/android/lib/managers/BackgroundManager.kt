package io.carrotquest_sdk.android.lib.managers

import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import io.carrotquest_sdk.android.core.Cancellable
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch

class BackgroundManager private constructor() : IStateManager {

    // BehaviorSubject<Boolean> → SharedFlow с replay=1: новый подписчик сразу
    // получает последнее известное foreground/background состояние (как BehaviorSubject).
    private val changeStateFlow = MutableSharedFlow<Boolean>(
        replay = 1,
        extraBufferCapacity = 4,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    private val scope = CoroutineScope(SupervisorJob() + SdkDispatchers.main)

    private val foregroundBackgroundListener = ForegroundBackgroundListener()

    @Volatile
    private var lastStateIsForeground = false

    override fun addObserver(observer: StateObserver): Cancellable {
        // Job живёт до deInit() (scope.cancel()) ИЛИ до Cancellable.cancel() от подписчика.
        val job = scope.launch(SdkDispatchers.main) {
            changeStateFlow.collect { observer.onChanged(it) }
        }
        // ProcessLifecycleOwner.addObserver обязан вызываться на главном потоке.
        // foregroundBackgroundListener — единый инстанс, повторный addObserver идемпотентен.
        if (Looper.myLooper() == Looper.getMainLooper()) {
            registerLifecycleObserver()
        } else {
            Handler(Looper.getMainLooper()).post { registerLifecycleObserver() }
        }
        return Cancellable { job.cancel() }
    }

    private fun registerLifecycleObserver() {
        try {
            ProcessLifecycleOwner.get().lifecycle.addObserver(foregroundBackgroundListener)
        } catch (e: Exception) {
            Log.e(TAG, "addObserver failed on main thread: $e")
        }
    }

    override fun deInit() {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            performDeInit()
        } else {
            Handler(Looper.getMainLooper()).post { performDeInit() }
        }
    }

    private fun performDeInit() {
        try {
            ProcessLifecycleOwner.get().lifecycle.removeObserver(foregroundBackgroundListener)
        } catch (e: Exception) {
            Log.e(TAG, "removeObserver failed: $e")
        }
        scope.cancel()
        instance = null
    }

    fun lastStateIsForeground(): Boolean = lastStateIsForeground

    private inner class ForegroundBackgroundListener : LifecycleEventObserver {
        override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    lastStateIsForeground = true
                    changeStateFlow.tryEmit(true)
                }
                Lifecycle.Event.ON_PAUSE -> {
                    lastStateIsForeground = false
                    changeStateFlow.tryEmit(false)
                }
                else -> {}
            }
        }
    }

    companion object {
        private const val TAG = "BackgroundManager"

        @Volatile
        private var instance: BackgroundManager? = null

        @JvmStatic
        fun getInstance(): BackgroundManager {
            return instance ?: BackgroundManager().also { instance = it }
        }
    }
}
