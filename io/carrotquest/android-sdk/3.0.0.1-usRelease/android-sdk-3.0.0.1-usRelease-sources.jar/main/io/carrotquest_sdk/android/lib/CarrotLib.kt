package io.carrotquest_sdk.android.lib

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.text.TextUtils
import android.util.Log
import android.webkit.MimeTypeMap
import androidx.fragment.app.FragmentManager
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.util.huawei.isHuawei
import io.carrotquest_sdk.android.lib.di.ApiModule
import io.carrotquest_sdk.android.lib.di.ContextModule
import io.carrotquest_sdk.android.lib.di.DaggerLibComponent
import io.carrotquest_sdk.android.lib.di.GsonModule
import io.carrotquest_sdk.android.lib.di.LibComponent
import io.carrotquest_sdk.android.lib.di.RepositoryModule
import io.carrotquest_sdk.android.lib.di.RetrofitModule
import io.carrotquest_sdk.android.lib.full_image_view.view.FullImageViewDialogFragment
import io.carrotquest_sdk.android.lib.models.User
import io.carrotquest_sdk.android.lib.models.UserConversations
import io.carrotquest_sdk.android.models.UserProperty
import io.carrotquest_sdk.android.lib.network.responses.PushSubResponse
import io.carrotquest_sdk.android.lib.network.responses.auth.AuthResponse
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotResponse
import io.carrotquest_sdk.android.lib.network.responses.connect.ConnectResponse
import io.carrotquest_sdk.android.lib.network.responses.conversation.ConversationResponse
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse
import io.carrotquest_sdk.android.lib.network.responses.messages.ReplyFileResponse
import io.carrotquest_sdk.android.lib.network.responses.reply.ReplyResponse
import io.carrotquest_sdk.android.lib.network.responses.start_conversation.StartConversationResponse
import io.carrotquest_sdk.android.lib.network.responses.triggers.TriggersResponse
import io.carrotquest_sdk.android.lib.network.responses.user.UserResponse
import io.carrotquest_sdk.android.lib.repositories.IUserRepository
import io.carrotquest_sdk.android.lib.utils.files.SaveImageCallback
import io.carrotquest_sdk.android.lib.utils.files.saveBitmapImageToGallery
import kotlinx.coroutines.CancellationException
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.UnsupportedEncodingException
import java.net.URLEncoder
import java.security.InvalidKeyException
import java.security.NoSuchAlgorithmException
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Обёртка над [CarrotApi]. Сетевой слой переведён на корутины (ветка remove_rx) — все методы
 * [CarrotApi] `suspend`, публичный API класса тоже `suspend` (Rx-мост apiCall и интерфейс
 * ICarrotLib удалены, у класса остались только прямые потребители suspend-вариантов).
 */
class CarrotLib(context: Context, userRepository: IUserRepository, isUseEuServers: Boolean) {

    private var useEuServers: Boolean = isUseEuServers
    private var carrotApi: CarrotApi

    init {
        libComponent = DaggerLibComponent.builder()
            .gsonModule(GsonModule(context))
            .apiModule(ApiModule())
            .contextModule(ContextModule(context))
            .retrofitModule(RetrofitModule(context, userRepository, useEuServers))
            .repositoryModule(RepositoryModule(userRepository))
            .build()
        carrotApi = libComponent!!.carrotApi
    }

    suspend fun connectSuspend(
        apiKey: String,
        browser: String,
        tokenType: String,
        referrer: String?,
        startSession: Boolean
    ): ConnectResponse {
        val deviceType = "phone"
        val os = "Android " + Build.VERSION.RELEASE + " (" + Build.VERSION.SDK_INT + ")"
        return if (referrer.isNullOrEmpty()) {
            carrotApi.connect(
                apiKey, startSession, false, false, browser, os, getDeviceName(), deviceType, tokenType
            )
        } else {
            carrotApi.connect(
                apiKey, true, false, false, browser, os, getDeviceName(), deviceType, tokenType, referrer
            )
        }
    }

    // ---- suspend-варианты (strangler, ветка remove_rx, Ф8). Вызывают carrotApi напрямую,
    // без Observable-моста apiCall. По мере миграции потребителей соответствующие Observable-методы
    // выше удаляются. Семантика onErrorReturnItem сохранена через try/catch.
    // Диспетчер — на стороне вызывающего (use-cases уже в withContext(IO)).

    suspend fun getUserSuspend(userId: String): User =
        carrotApi.getUser(userId, false)

    suspend fun loadUserSuspend(userId: String): UserResponse =
        carrotApi.loadUser(userId, false)

    suspend fun getConversationsSuspend(userId: String): UserConversations =
        try { carrotApi.getConversations(userId) } catch (e: CancellationException) { throw e } catch (e: Exception) { UserConversations() }

    suspend fun getConversationsSuspend(userId: String, after: String): UserConversations =
        try { carrotApi.getConversations(userId, after, false, "before") } catch (e: CancellationException) { throw e } catch (e: Exception) { UserConversations() }

    suspend fun getConversationSuspend(conversationId: String): ConversationResponse {
        if (conversationId.isEmpty() || !conversationId.matches(Regex("\\d+"))) {
            return ConversationResponse()
        }
        return try {
            carrotApi.getConversation(conversationId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, e.toString())
            ConversationResponse()
        }
    }

    suspend fun conversationPartsSuspend(messageId: String, metaData: JsonObject): NetworkResponse =
        carrotApi.conversationParts(messageId, metaData)

    suspend fun setPropertySuspend(userId: String, userProperty: List<UserProperty>?): NetworkResponse {
        val propertyJson: String
        if (userProperty.isNullOrEmpty()) {
            propertyJson = "[]"
        } else {
            val array = JsonArray()
            for (property in userProperty) {
                val jsonObject = JsonObject()
                jsonObject.addProperty("op", property.operation.wireValue)
                jsonObject.addProperty("key", property.key)
                jsonObject.addProperty("value", property.value)
                array.add(jsonObject)
            }
            propertyJson = array.toString()
        }
        return carrotApi.sendProps(userId, propertyJson)
    }

    suspend fun trackEventSuspend(userId: String, eventName: String, eventParams: String?): NetworkResponse =
        if (eventParams == null) carrotApi.trackEvent(userId, eventName)
        else carrotApi.trackEvent(userId, eventName, eventParams)

    suspend fun startConversationSuspend(userId: String, messageText: String): StartConversationResponse =
        carrotApi.startConversation(userId, messageText)

    suspend fun startConversationSuspend(userId: String, file: File): StartConversationResponse {
        val boundary = "*****".toRequestBody("multipart/form-data".toMediaTypeOrNull())
        val index = file.name.lastIndexOf('.') + 1
        val ext = file.name.substring(index).lowercase()
        var mimetype = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        if (mimetype == null) mimetype = "file/*"
        if (mimetype.lowercase().contains("tiff")) mimetype = "file/*"
        val requestFile = file.asRequestBody(mimetype.toMediaTypeOrNull())
        var filePart: MultipartBody.Part? = null
        try {
            filePart = MultipartBody.Part.createFormData("file", URLEncoder.encode(file.name, "utf-8"), requestFile)
        } catch (e: UnsupportedEncodingException) {
            Log.e("CarrotLib", "URLEncoder utf-8 failed", e)
        }
        val fileName = file.name.toRequestBody("multipart/form-data".toMediaTypeOrNull())
        return carrotApi.startConversationWithFile(userId, boundary, fileName, filePart!!)
    }

    suspend fun getMessagesSuspend(conversationId: String): MessagesResponse =
        try { carrotApi.getMessages(conversationId) } catch (e: CancellationException) { throw e } catch (e: Exception) { MessagesResponse() }

    suspend fun getMessagesSuspend(conversationId: String, after: String): MessagesResponse =
        try { carrotApi.getMessages(conversationId, after, false, "before") } catch (e: CancellationException) { throw e } catch (e: Exception) { MessagesResponse() }

    suspend fun replySuspend(conversationId: String, messageText: String, fromUser: Boolean, randomId: String): ReplyResponse =
        try { carrotApi.reply(conversationId, messageText, fromUser, randomId) } catch (e: CancellationException) { throw e } catch (e: Exception) { ReplyResponse() }

    suspend fun replyFileSuspend(conversationId: String, file: File, autoAssign: String?, randomId: String): ReplyFileResponse {
        val boundary = "*****".toRequestBody("multipart/form-data".toMediaTypeOrNull())
        val index = file.name.lastIndexOf('.') + 1
        val ext = file.name.substring(index).lowercase()
        var mimetype = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        if (mimetype == null) mimetype = "file/*"
        if (mimetype.lowercase().contains("tiff")) mimetype = "file/*"
        val requestFile = file.asRequestBody(mimetype.toMediaTypeOrNull())
        var filePart: MultipartBody.Part? = null
        try {
            filePart = MultipartBody.Part.createFormData("file", URLEncoder.encode(file.name, "utf-8"), requestFile)
        } catch (e: UnsupportedEncodingException) {
            Log.e(TAG, e.toString())
        }
        val randomIdPart = randomId.toRequestBody("multipart/form-data".toMediaTypeOrNull())
        val autoAssignPart = (autoAssign ?: "").toRequestBody("multipart/form-data".toMediaTypeOrNull())
        val fileName = file.name.toRequestBody("multipart/form-data".toMediaTypeOrNull())
        return carrotApi.replyFile(conversationId, boundary, filePart!!, randomIdPart, autoAssignPart, fileName)
    }

    suspend fun markReadSuspend(conversationId: String): NetworkResponse =
        carrotApi.markRead(conversationId)

    suspend fun trackInteractionSuspend(conversationId: String, type: String): NetworkResponse =
        carrotApi.trackinteraction(conversationId, type)

    suspend fun chooseRoutingBotSuspend(conversationId: String): ChooseRoutingBotResponse =
        carrotApi.chooseRoutingBot(conversationId)

    suspend fun setMetaDataSuspend(messageId: String, metaData: String): NetworkResponse =
        carrotApi.setMetaData(messageId, metaData)

    suspend fun startRoutingBotSuspend(
        botId: String,
        buttonActionId: String,
        buttonActionText: String,
        randomId: String?,
        conversationId: String?
    ): NetworkResponse =
        carrotApi.startRoutingBot(botId, buttonActionId, buttonActionText, randomId, conversationId)

    suspend fun startRoutingBotSuspend(
        botId: String,
        buttonActionId: String,
        buttonActionText: String,
        randomId: String?
    ): NetworkResponse =
        carrotApi.startRoutingBot(botId, buttonActionId, buttonActionText, randomId)

    suspend fun setTypingSuspend(conversationId: String, messageBody: String): NetworkResponse =
        try { carrotApi.setTyping(conversationId, messageBody, true) } catch (e: CancellationException) { throw e } catch (e: Exception) { NetworkResponse("typing error") }

    suspend fun sendPushTokenSuspend(
        userId: String, token: String, deviceId: String, type: String,
        deviceType: String, device: String, browser: String, userAgent: String
    ): PushSubResponse {
        val os = "Android " + Build.VERSION.RELEASE + " (" + Build.VERSION.SDK_INT + ")"
        return carrotApi.sendPushToken(userId, token, "mobile", deviceId, device, deviceType, os, browser, userAgent)
    }

    suspend fun deletePushTokenSuspend(userId: String, deviceId: String, type: String): PushSubResponse =
        try { carrotApi.deletePushToken(userId, deviceId, type) } catch (e: CancellationException) { throw e } catch (e: Exception) { PushSubResponse("deletePushToken error") }

    suspend fun setUserConsentContactSuspend(contacts: String, partId: String, userId: String): NetworkResponse =
        carrotApi.setUserConsentContact(contacts, partId, userId)

    suspend fun setUserConsentDataProcessingSuspend(dataProcessing: Boolean?, userId: String): NetworkResponse =
        carrotApi.setUserConsentDataProcessing(dataProcessing == true, userId)

    suspend fun authSuspend(userId: String, userAuthKey: String): AuthResponse {
        val hash = generateHashHmac(userId, userAuthKey)
        return carrotApi.auth(userId, hash, "sdk_user_android")
    }

    suspend fun hashedAuthSuspend(userId: String, hash: String): AuthResponse =
        carrotApi.auth(userId, hash, "sdk_user_android")

    suspend fun getTriggersSuspend(): TriggersResponse =
        carrotApi.getTriggers()

    suspend fun sendTriggerSuspend(triggerIds: List<String>): NetworkResponse =
        carrotApi.sendTrigger(triggerIds)

    suspend fun setPresenceCurrentScreenSuspend(presence: String, currentScreen: String): NetworkResponse =
        carrotApi.setPresenceCurrentScreen(presence, currentScreen)

    fun setIsUseEuServers(useEuServers: Boolean) {
        this.useEuServers = useEuServers
    }

    fun isUseEuServers(): Boolean = useEuServers

    /** Returns the consumer friendly device name */
    private fun getDeviceName(): String {
        return if (isHuawei()) {
            "Huawei [huawei_push] 1.0.0"
        } else {
            val manufacturer = Build.MANUFACTURER
            val model = Build.MODEL
            if (model.startsWith(manufacturer)) {
                capitalize(model)
            } else {
                capitalize(manufacturer) + " " + model
            }
        }
    }

    private fun capitalize(str: String): String {
        if (TextUtils.isEmpty(str)) {
            return str
        }
        val arr = str.toCharArray()
        var capitalizeNext = true

        val phrase = StringBuilder()
        for (c in arr) {
            if (capitalizeNext && Character.isLetter(c)) {
                phrase.append(Character.toUpperCase(c))
                capitalizeNext = false
                continue
            } else if (Character.isWhitespace(c)) {
                capitalizeNext = true
            }
            phrase.append(c)
        }

        return phrase.toString()
    }

    companion object {
        private const val TAG = "CarrotLib"
        private var libComponent: LibComponent? = null

        @JvmStatic
        fun generateHashHmac(str: String, secret: String): String {
            val sha256Hmac = Mac.getInstance("HmacSHA256")

            val secretKey = SecretKeySpec(secret.toByteArray(), "HmacSHA256")
            sha256Hmac.init(secretKey)

            val macData = sha256Hmac.doFinal(str.toByteArray())
            val result = StringBuilder()
            for (element in macData) {
                result.append(Integer.toString((element.toInt() and 0xff) + 0x100, 16).substring(1))
            }
            return result.toString()
        }

        @JvmStatic
        fun showFullImage(urlImage: String, fragmentManager: FragmentManager) {
            val fullViewImage = FullImageViewDialogFragment.newInstance(urlImage)
            fullViewImage.show(fragmentManager, "fullViewImage")
        }

        @JvmStatic
        fun showFullImage(file: File, fragmentManager: FragmentManager) {
            val fullViewImage = FullImageViewDialogFragment.newInstance(file)
            fullViewImage.show(fragmentManager, "fullViewImage")
        }

        @JvmStatic
        fun showFullImage(bitmap: Bitmap, fragmentManager: FragmentManager) {
            val fullViewImage = FullImageViewDialogFragment.newInstance(bitmap)
            fullViewImage.show(fragmentManager, "fullViewImage")
        }

        @JvmStatic
        fun saveImageToGallery(image: Drawable, contentResolver: ContentResolver, callback: SaveImageCallback) {
            if (image !is BitmapDrawable) {
                callback.fail()
                return
            }

            val bitmap = image.bitmap
            saveBitmapImageToGallery(bitmap, contentResolver, callback)
        }

        @JvmStatic
        fun getLibComponents(): LibComponent = libComponent
            ?: throw IllegalStateException("CarrotSDK is not initialized. Call CarrotSDK.setup(...) first.")
    }
}