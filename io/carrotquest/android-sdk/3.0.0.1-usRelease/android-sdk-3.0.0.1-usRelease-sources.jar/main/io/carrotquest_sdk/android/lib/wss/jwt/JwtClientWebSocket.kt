package io.carrotquest_sdk.android.lib.wss.jwt

import com.neovisionaries.ws.client.WebSocket
import com.neovisionaries.ws.client.WebSocketException
import com.neovisionaries.ws.client.WebSocketFactory
import io.carrotquest_sdk.android.domain.use_cases.user.getUserAgent
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.loging.Log.Companion.e
import io.carrotquest_sdk.android.lib.utils.loging.LogToElk
import io.carrotquest_sdk.android.lib.utils.loging.MessageToElkType
import io.carrotquest_sdk.android.lib.wss.Channel
import io.carrotquest_sdk.android.lib.wss.WssMessageListener
import io.carrotquest_sdk.android.lib.wss.utils.CloseReason
import io.carrotquest_sdk.android.lib.wss.utils.SocketListener
import io.carrotquest_sdk.android.lib.wss.utils.getRtsConnectUrl
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.URI
import java.net.URISyntaxException
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

private const val tag = "JwtClientWebSocket"
// Интервал ping для keepalive RTS-соединения (мс).
private const val PING_INTERVAL_MS = 20_000L

/**
 * Одно RTS-соединение поверх neovisionaries WebSocket.
 *
 * Потокобезопасность (фикс критичной гонки реконнекта): ВСЕ операции жизненного цикла —
 * [connect], [stop] и реакция на обрыв сокета — сериализуются на ОДНОМ выделенном потоке
 * ([lifecycleExecutor], single-thread, FIFO). Раньше `stop()` и `connect()` стартовали каждый
 * свой `Thread` и без синхронизации мутировали общие `webSocket` и `socketListener.listener`;
 * при back-to-back `stop()→connect()` (рефреш токена / смена видимости) «опоздавший» `stop()` мог
 * обнулить listener только что поднятого сокета → сокет «connected», но `onTextMessage` молча
 * ронял все фреймы (реалтайм мёртв при живом соединении). Теперь:
 *  - listener свой на КАЖДОЕ соединение (нет общего изменяемого поля);
 *  - доступ к `webSocket` только на [lifecycleExecutor];
 *  - generation-токен: колбэки устаревшего (заменённого/закрытого) сокета игнорируются.
 */
class JwtClientWebSocket(
    private val appId: String,
    private val channels: ArrayList<Channel>,
    private val rtsHost: String,
    private val listener: WssMessageListener
) {
    // Единственный поток для операций жизненного цикла — сериализует connect/stop/обрыв.
    private val lifecycleExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "cq-rts-$appId").apply { isDaemon = true }
    }

    @Volatile private var isConnected = false
    // true, пока соединение закрывается НАМЕРЕННО (stop) — чтобы не дёргать авто-реконнект.
    @Volatile private var manualClose = false
    // Вызывается при НЕожиданном обрыве (не из-за stop) — для авто-переподключения снаружи.
    var onDisconnect: (() -> Unit)? = null

    // Текущий сокет — читается/пишется ТОЛЬКО на lifecycleExecutor.
    private var webSocket: WebSocket? = null
    // Поколение соединения. Каждый connect()/закрытие увеличивает счётчик; колбэки сокета несут
    // своё поколение и игнорируются, если оно устарело (сокет уже заменён или закрыт).
    @Volatile private var generation = 0
    // Время последнего входящего фрейма (мс). По нему watchdog в JwtWssService отличает живой
    // сокет от «тихо умершего» (при keepalive сервер шлёт pong ~каждые 20с).
    @Volatile private var lastInboundMs = 0L

    // Скоуп для асинхронного refresh токена перед коннектом (ветка remove_rx, фаза 5).
    private var refreshScope = CoroutineScope(SdkDispatchers.io + SupervisorJob())

    fun isConnected(): Boolean = isConnected

    /** Время (мс, epoch) последнего входящего фрейма; 0 — фреймов ещё не было. */
    fun lastInboundMs(): Long = lastInboundMs

    // Постановка задачи на lifecycleExecutor, устойчивая к гонке с dispose() (после shutdown
    // execute бросает RejectedExecutionException — на сокете, который уже утилизируют, это норма).
    private fun safeExecute(block: () -> Unit) {
        try {
            lifecycleExecutor.execute(block)
        } catch (_: RejectedExecutionException) {
            // executor уже остановлен (dispose) — игнорируем.
        }
    }

    fun connect() {
        SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, tag, "connect requested", fields = mapOf("appId" to appId))
        safeExecute { doConnect() }
    }

    private fun doConnect() {
        manualClose = false

        val isActualJwtToken = isActualJwtToken()
        if (!isActualJwtToken) {
            SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, tag, "connect: access not actual → refreshing token first", fields = mapOf("appId" to appId))
            refreshScope.launch {
                val token = refreshJwtToken()
                if (!token.isNullOrEmpty()) {
                    val userRepository = CarrotLib.getLibComponents().userRep
                    val user = userRepository.user
                    user.token = token
                    userRepository.saveUser(user)
                    SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, tag, "connect: token refreshed → reconnecting", fields = mapOf("appId" to appId))
                    connect() // снова через executor — сериализованно
                } else {
                    SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.REALTIME, tag, "connect: token refresh returned empty → NOT connecting", fields = mapOf("appId" to appId))
                }
            }
            return
        }

        // Закрываем прошлый сокет (на этом же потоке — без гонки с возможным stop/реконнектом).
        closeCurrentSocket(intentional = true)

        val myGen = ++generation
        try {
            val jwtToken = getJwtToken()
            if (jwtToken.isEmpty()) {
                e(tag, "jwtToken is empty. rts service isn/'t connect")
                return
            }

            val url = getRtsConnectUrl(rtsHost, appId, channels, jwtToken)
            val userAgent = getUserAgent()

            // Свой listener на КАЖДОЕ соединение — никакого общего изменяемого состояния.
            // Колбэки несут поколение myGen и проходят через executor с проверкой актуальности.
            val socketListener = SocketListener(
                appId,
                onDisconnected = { onSocketDisconnected(myGen) },
                onInbound = { lastInboundMs = System.currentTimeMillis() },
            )
            socketListener.setListener(listener)

            val factory = WebSocketFactory()
            val socket = factory.createSocket(URI(url))
            socket.addHeader("Authorization", "Token $jwtToken")
            socket.addHeader("User-Agent", "Token $userAgent")
            socket.addListener(socketListener)
            // Keepalive: периодический ping держит соединение живым и заставляет библиотеку
            // детектить мёртвый сокет (нет pong → onDisconnected) — иначе простой убивает RTS молча.
            socket.pingInterval = PING_INTERVAL_MS

            socket.connect()
            webSocket = socket
            lastInboundMs = System.currentTimeMillis()
            isConnected = true
            SdkLogger.log(
                SdkLogLevel.INFO, SdkLogCategory.REALTIME, tag, "RTS connected",
                fields = mapOf("appId" to appId, "gen" to myGen.toString(), "channels" to channels.size.toString()),
            )

            LogToElk.getInstance()
                .write(appId, "Rts connect", MessageToElkType.RTS_CONNECT, HashMap())
        } catch (e: WebSocketException) {
            isConnected = false
            e(tag, "WebSocketException: $e")
            logConnectError("web_socket_exception", e.toString())
        } catch (e: IOException) {
            isConnected = false
            e(tag, "IOException: $e")
            logConnectError("io_exception", e.toString())
        } catch (e: URISyntaxException) {
            isConnected = false
            e(tag, "URISyntaxException: $e")
            logConnectError("uri_syntax_exception", e.toString())
        } catch (e: Exception) {
            isConnected = false
            e(tag, "Just exception: $e")
            logConnectError("exception", e.toString())
        }
    }

    private fun logConnectError(key: String, value: String) {
        val params = HashMap<String, Any>()
        params[key] = value
        LogToElk.getInstance()
            .write(appId, "Rts connect error", MessageToElkType.RTS_CONNECT, params)
    }

    // Реакция на обрыв сокета. Прогоняется через executor и сверяет поколение: колбэк от старого
    // (уже заменённого/закрытого) сокета игнорируется — иначе он бы инициировал лишний реконнект.
    private fun onSocketDisconnected(gen: Int) {
        safeExecute {
            if (gen != generation) {
                // Колбэк от старого (уже заменённого/закрытого) сокета — игнорируем, иначе он бы
                // инициировал лишний реконнект. Логируем, чтобы видеть такие случаи при разборе.
                SdkLogger.log(
                    SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, tag, "ignore disconnect from stale socket",
                    fields = mapOf("appId" to appId, "gen" to gen.toString(), "current" to generation.toString()),
                )
                return@safeExecute
            }
            isConnected = false
            val inboundAgeSec = if (lastInboundMs > 0L) (System.currentTimeMillis() - lastInboundMs) / 1000 else -1
            SdkLogger.log(
                if (manualClose) SdkLogLevel.DEBUG else SdkLogLevel.WARN,
                SdkLogCategory.REALTIME, tag,
                if (manualClose) "RTS closed" else "RTS disconnected (reconnecting)",
                fields = mapOf("appId" to appId, "gen" to gen.toString(), "manualClose" to manualClose.toString(), "inboundAgeSec" to inboundAgeSec.toString()),
            )
            if (!manualClose) onDisconnect?.invoke()
        }
    }

    // Закрывает текущий сокет. Увеличивает поколение, чтобы onDisconnected закрываемого сокета
    // был распознан как устаревший и не вызвал реконнект. Вызывать ТОЛЬКО на lifecycleExecutor.
    private fun closeCurrentSocket(intentional: Boolean) {
        generation++
        val sock = webSocket
        webSocket = null
        isConnected = false
        if (sock != null) {
            if (intentional) {
                SdkLogger.log(SdkLogLevel.DEBUG, SdkLogCategory.REALTIME, tag, "RTS closed", fields = mapOf("appId" to appId, "gen" to generation.toString()))
            }
            try {
                sock.disconnect()
            } catch (t: Throwable) {
                e(tag, "disconnect error: $t")
            }
        }
    }

    fun getAppId(): String = appId

    fun stop(reason: CloseReason) {
        manualClose = true
        safeExecute {
            // Отменяем in-flight refresh и пересоздаём скоуп — connect() может быть вызван снова.
            refreshScope.cancel()
            refreshScope = CoroutineScope(SdkDispatchers.io + SupervisorJob())
            closeCurrentSocket(intentional = true)
        }

        if (reason != CloseReason.NONE) {
            val params = java.util.HashMap<String, Any>()
            params["reason"] = reason.name.lowercase(Locale.getDefault())
            LogToElk.getInstance()
                .write(appId, "Rts disconnect", MessageToElkType.RTS_DISCONNECT, params)
        }
    }

    // Окончательная утилизация сокета (session teardown / deInit). Завершает executor: уже
    // поставленные задачи (включая close из stop()) отработают, новые отвергаются. После dispose()
    // объект не переиспользуется. Без этого выделенный поток сокета «висел» бы до конца жизни процесса.
    fun dispose() {
        lifecycleExecutor.shutdown()
    }
}
