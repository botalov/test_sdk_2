package io.carrotquest_sdk.android.presentation.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Context
import coil.compose.AsyncImage
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import kotlin.math.roundToInt

private val IMAGE_GAP = 10.dp
private val IMAGE_CORNER = 6.dp

// ── Image grid ────────────────────────────────────────────────────────────────

@Composable
fun MessageImages(
    images: List<UiAttachment.ImageAttachment>,
    modifier: Modifier = Modifier,
    onImageTapped: (String) -> Unit = {},
) {
    Box(modifier = modifier) {
        when (images.size) {
            0    -> {}
            1    -> OneImage(images[0], onImageTapped)
            2    -> TwoImages(images[0], images[1], onImageTapped)
            3    -> ThreeImages(images, onImageTapped)
            else -> MultiImages(images, onImageTapped)
        }
    }
}

@Composable
private fun OneImage(img: UiAttachment.ImageAttachment, onImageTapped: (String) -> Unit) {
    // Одиночное изображение показываем целиком (Fit), а не Crop, и БЕЗ fillMaxWidth: бокс
    // получает размер по интринсик-аспекту картинки в пределах ограничений (ширину сверху
    // ограничивает сам бабл maxBubbleWidth, высоту — heightIn). Тогда бабл обворачивает картинку
    // по её пропорциям: портрет → узкий бабл без широких пустых полей, landscape → широкий и
    // невысокий, квадрат → квадрат. Раньше fillMaxWidth × height(150) + Crop резал квадрат/портрет
    // по высоте, а после перехода на Fit с fillMaxWidth у портрета появлялись широкие поля.
    // Сетки 2/3/multi намеренно остаются на Crop (квадратные ячейки).
    BubbleImage(
        url = img.url,
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .heightIn(max = 220.dp)
            .widthIn(max = 260.dp),
        onClick = { onImageTapped(img.url) },
    )
}

@Composable
private fun TwoImages(
    a: UiAttachment.ImageAttachment,
    b: UiAttachment.ImageAttachment,
    onImageTapped: (String) -> Unit,
) {
    Row(horizontalArrangement = Arrangement.spacedBy(IMAGE_GAP)) {
        BubbleImage(a.url, modifier = Modifier.weight(1f).aspectRatio(1f), onClick = { onImageTapped(a.url) })
        BubbleImage(b.url, modifier = Modifier.weight(1f).aspectRatio(1f), onClick = { onImageTapped(b.url) })
    }
}

@Composable
private fun ThreeImages(imgs: List<UiAttachment.ImageAttachment>, onImageTapped: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(IMAGE_GAP)) {
        BubbleImage(imgs[0].url, modifier = Modifier.weight(1f).aspectRatio(1f), onClick = { onImageTapped(imgs[0].url) })
        BubbleImage(imgs[1].url, modifier = Modifier.weight(1f).aspectRatio(1f), onClick = { onImageTapped(imgs[1].url) })
        BubbleImage(imgs[2].url, modifier = Modifier.weight(1f).aspectRatio(1f), onClick = { onImageTapped(imgs[2].url) })
    }
}

@Composable
private fun MultiImages(imgs: List<UiAttachment.ImageAttachment>, onImageTapped: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(IMAGE_GAP)) {
        imgs.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(IMAGE_GAP)) {
                row.forEach { img ->
                    BubbleImage(
                        url = img.url,
                        modifier = Modifier.weight(1f).aspectRatio(1f),
                        onClick = { onImageTapped(img.url) },
                    )
                }
                repeat(4 - row.size) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun BubbleImage(
    url: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    onClick: () -> Unit = {},
) {
    AsyncImage(
        model = url,
        contentDescription = null,
        contentScale = contentScale,
        modifier = modifier
            .clip(RoundedCornerShape(IMAGE_CORNER))
            .clickable(onClick = onClick),
    )
}

// ── File card (outside bubble, standalone) ────────────────────────────────────

@Composable
fun FileCard(
    file: UiAttachment.FileAttachment,
    isDark: Boolean,
    accentColor: Color,
    isOutgoing: Boolean = false,
    // Растягивать на всю ширину бабла нужно только когда ширину задаёт что-то ещё (картинка):
    // одиночная файл-карточка должна обнимать контент, иначе бабл всегда раздувается до максимума.
    fillWidth: Boolean = false,
    onTap: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val downloadState by FileDownloadRepository
        .stateFor(file.id, file.downloadState)
        .collectAsState(initial = file.downloadState)

    val context = LocalContext.current
    val cardBg = SdkColors.fileCardBg(isDark, isOutgoing, accentColor)
    val iconTint      = SdkColors.onAccent(accentColor)
    val titleColor    = if (isOutgoing) Color.White else SdkColors.title(isDark)
    val subtitleColor = if (isOutgoing) SdkColors.secondaryOnAccent else SdkColors.secondaryText(isDark)

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .then(if (fillWidth) Modifier.fillMaxWidth() else Modifier)
            .clip(RoundedCornerShape(12.dp))
            .background(cardBg)
            .clickable(onClick = onTap)
            .padding(horizontal = 12.dp, vertical = 14.dp),
    ) {
        Box(
            modifier = Modifier.size(30.dp),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(accentColor),
            )
            // Захватываем конкретный Downloading в стабильный локал: progress-лямбда индикатора
            // вычисляется отложенно (draw-фаза), а downloadState — делегат collectAsState и может
            // флипнуться (Downloading→Downloaded/NotDownloaded) до перекомпозиции → каст
            // `as Downloading` в лямбде ронял ClassCastException на main. Локал фиксирует значение
            // этой композиции, в лямбде нет рантайм-каста.
            val downloading = downloadState as? DownloadState.Downloading
            if (downloading != null) {
                CircularProgressIndicator(
                    progress = { downloading.progress },
                    modifier = Modifier.size(30.dp),
                    strokeWidth = 2.5.dp,
                    color = iconTint,
                    trackColor = Color.Transparent,
                )
            }
            when (downloadState) {
                // Скрепка — кастомный вертикальный drawable из макета (ic_cq_file).
                is DownloadState.Downloaded -> Icon(
                    painter = painterResource(R.drawable.ic_cq_file),
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(16.dp),
                )
                is DownloadState.Downloading -> Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp),
                )
                is DownloadState.NotDownloaded -> Icon(
                    imageVector = Icons.Default.ArrowDownward,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
        Spacer(Modifier.width(10.dp))
        // С fillWidth — забираем остаток ширины (вес); без него — обнимаем контент, длинное имя
        // обрежется по максимуму бабла (Text maxLines=1 + ellipsis).
        Column(modifier = if (fillWidth) Modifier.weight(1f) else Modifier) {
            Text(
                text = file.name,
                color = titleColor,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val ext = file.name.substringAfterLast('.', "").uppercase().ifEmpty { null }
            val sizeStr = if (file.size > 0L) formatFileSize(file.size, context) else null
            val subtitle = listOfNotNull(ext, sizeStr).joinToString(" · ")
            if (subtitle.isNotEmpty()) {
                Text(
                    text = subtitle,
                    color = subtitleColor,
                    fontSize = 12.sp,
                )
            }
        }
    }
}

// Локализованный размер файла: байты/КБ — целые, МБ — с одним знаком (под макет «50 КБ»).
private fun formatFileSize(bytes: Long, context: Context): String = when {
    bytes < 1_024L         -> context.getString(R.string.file_size_b, bytes)
    bytes < 1_024L * 1_024 -> context.getString(R.string.file_size_kb, (bytes / 1_024.0).roundToInt())
    else                   -> context.getString(R.string.file_size_mb, "%.1f".format(bytes / (1_024.0 * 1_024)))
}
