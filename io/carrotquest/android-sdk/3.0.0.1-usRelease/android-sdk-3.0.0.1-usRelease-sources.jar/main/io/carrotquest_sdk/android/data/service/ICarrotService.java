package io.carrotquest_sdk.android.data.service;

import io.carrotquest_sdk.android.Callback;

import androidx.annotation.NonNull;

import java.util.List;

import io.carrotquest_sdk.android.lib.models.User;
import io.carrotquest_sdk.android.models.UserProperty;
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse;

public interface ICarrotService {
    void init(@NonNull String apiKey, Callback<Boolean> callback, boolean startSession);
    void deInit();
    boolean isInit();

    void authUser(String id, String userAuthKey);
    void authUser(String id, String userAuthKey, Callback<User> callback);

    void hashedAuth(String id, String hash, Callback<User> callback);

    void setUserProperty(List<UserProperty> userProperty);
    void setUserProperty(List<UserProperty> userProperty, Callback<Boolean> callback);

    void trackEvent(String eventName, String eventParams, Callback<NetworkResponse> callback);

    // Мёртвые observer-методы удалены (ветка remove_rx): startConversations/getMessage/reply/
    // replyFile/markConversationAsRead/voteOperator/updateAutoReply/chooseRoutingBot/
    // getConversations×2/getConversation — потребители перешли на carrotLib.*Suspend /
    // use-case suspend / ConversationsRepository напрямую.

    // downloadFile(Observer) удалён (мёртвый — потребителей нет); скачивание идёт через
    // CarrotService.downloadF (Observable<File>, Download*-кластер — отдельный заход).

    void setTyping(String conversationId, String messageBody);

    void trackClickByPush(String conversationId, Callback<Boolean> callback);

    String getSaveUserId();

    void setUserConsentContact(String contacts, String partId, String userId, Callback<Boolean> callback);
    void setUserConsentDataProcessing(Boolean dataProcessing, String userId, Callback<Boolean> callback);
}
