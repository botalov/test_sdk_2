package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.presentation.mvp.notifications.PushNotificationHelper

// suspend (ветка remove_rx) — Observable-ext убрана. Сохраняет открытый диалог + чистит пуши.
suspend fun openConversation(id: String?) {
    val mId = id ?: ""
    ConversationsRepository.getInstance().saveOpenedConversation(mId)
    PushNotificationHelper.getInstance().clearNotifications(mId)
}
