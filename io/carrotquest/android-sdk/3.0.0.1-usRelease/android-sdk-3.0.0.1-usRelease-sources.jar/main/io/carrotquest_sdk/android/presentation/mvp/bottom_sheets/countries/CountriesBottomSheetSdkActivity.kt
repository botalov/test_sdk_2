package io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.countries

import android.content.Intent
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.data.settings.SettingsManager
import io.carrotquest_sdk.android.domain.use_cases.countries.getCountryEntityByRegion
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.domain.use_cases.theme.getThemeUseCase
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.presentation.entities.CountryEntity
import io.carrotquest_sdk.android.presentation.mvp.utils.app_color_utils.AppColorUtils
import io.carrotquest_sdk.android.presentation.ui.SdkColors
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val ANIM_ENTER_MS = 300
private const val ANIM_EXIT_MS = 250

class CountriesBottomSheetSdkActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        overridePendingTransition(0, 0)

        val isDark = getThemeUseCase(this) == ThemeSdk.DARK

        val settings = SettingsRepository.getInstance().getSettingsObject()
        val rawColor = (settings?.originalAppColor ?: settings?.appColor)?.takeIf { it.isNotEmpty() }
            ?: SharedPreferencesLib.getString(this, SettingsManager.CACHED_ORIGINAL_APP_COLOR).takeIf { !it.isNullOrEmpty() }
            ?: SharedPreferencesLib.getString(this, SettingsManager.CACHED_APP_COLOR).takeIf { !it.isNullOrEmpty() }
        val normalizedColor = rawColor?.removePrefix("#")?.takeIf { it.isNotEmpty() }
        val accentColor = if (normalizedColor != null) {
            val contrastHex = AppColorUtils.getColorPalette(this, normalizedColor).contrastAccentColor
            Color("#$contrastHex".toColorInt())
        } else {
            Color(ContextCompat.getColor(this, R.color.colorButton))
        }

        setContent {
            CountriesSheet(
                isDark = isDark,
                accentColor = accentColor,
                onCountrySelected = { country ->
                    val intent = Intent().putExtra("SELECTED_COUNTRY", country)
                    setResult(RESULT_OK, intent)
                    finish()
                },
                onFinish = { finish() }
            )
        }
    }

    @Suppress("DEPRECATION")
    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }
}

@Composable
private fun CountriesSheet(
    isDark: Boolean,
    accentColor: Color,
    onCountrySelected: (CountryEntity) -> Unit,
    onFinish: () -> Unit
) {
    val context = LocalContext.current
    val surfaceColor = SdkColors.pageBackground(isDark)
    val textColor = SdkColors.title(isDark)
    val subColor = SdkColors.secondaryText(isDark)
    val dividerColor = SdkColors.divider(isDark)
    val scope = rememberCoroutineScope()

    var visible by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var allCountries by remember { mutableStateOf<List<CountryEntity>>(emptyList()) }

    LaunchedEffect(Unit) { visible = true }

    // Загружаем список стран асинхронно — PhoneNumberUtil тяжёлый
    LaunchedEffect(Unit) {
        allCountries = withContext(Dispatchers.IO) {
            val phoneNumberUtil = PhoneNumberUtil.createInstance(context)
            phoneNumberUtil.supportedRegions
                .map { region -> getCountryEntityByRegion(region, phoneNumberUtil) }
                .sortedBy { it.name }
        }
    }

    val filteredCountries = remember(allCountries, searchQuery) {
        if (searchQuery.isEmpty()) allCountries
        else allCountries.filter { country ->
            country.name.contains(searchQuery, ignoreCase = true) ||
                country.countryCode.toString().contains(searchQuery)
        }
    }

    val dismiss: () -> Unit = {
        scope.launch {
            visible = false
            delay(ANIM_EXIT_MS.toLong())
            onFinish()
        }
    }

    val selectAndDismiss: (CountryEntity) -> Unit = { country ->
        scope.launch {
            visible = false
            delay(ANIM_EXIT_MS.toLong())
            onCountrySelected(country)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Скрим — только fade
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(ANIM_ENTER_MS)),
            exit = fadeOut(tween(ANIM_EXIT_MS))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SdkColors.scrim)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = dismiss
                    )
            )
        }

        // Шторка — слайд снизу вверх
        AnimatedVisibility(
            visible = visible,
            enter = slideInVertically(tween(ANIM_ENTER_MS, easing = FastOutSlowInEasing)) { it } +
                    fadeIn(tween(ANIM_ENTER_MS)),
            exit = slideOutVertically(tween(ANIM_EXIT_MS, easing = FastOutSlowInEasing)) { it } +
                    fadeOut(tween(ANIM_EXIT_MS)),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.85f)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(surfaceColor)
                    .navigationBarsPadding()
                    .imePadding()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
            ) {
                // Drag handle
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(top = 12.dp, bottom = 4.dp)
                        .size(32.dp, 4.dp)
                        .clip(CircleShape)
                        .background(textColor.copy(alpha = 0.18f))
                )

                // Поле поиска
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    placeholder = {
                        Text(
                            text = stringResource(R.string.cq_search_hint),
                            color = subColor,
                            fontSize = 16.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_cq_search),
                            contentDescription = null,
                            tint = subColor,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accentColor,
                        unfocusedBorderColor = dividerColor,
                        focusedTextColor = textColor,
                        unfocusedTextColor = textColor,
                        cursorColor = accentColor,
                    ),
                    shape = RoundedCornerShape(12.dp)
                )

                HorizontalDivider(color = dividerColor)

                // Список стран
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(filteredCountries, key = { it.region }) { country ->
                        CountryItem(
                            country = country,
                            textColor = textColor,
                            subColor = subColor,
                            dividerColor = dividerColor,
                            onClick = { selectAndDismiss(country) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CountryItem(
    country: CountryEntity,
    textColor: Color,
    subColor: Color,
    dividerColor: Color,
    onClick: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = country.flag ?: "🏳",
                fontSize = 24.sp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = country.name,
                color = textColor,
                fontSize = 16.sp,
                modifier = Modifier.weight(1f)
            )
            if (country.countryCode > 0) {
                Text(
                    text = "+${country.countryCode}",
                    color = subColor,
                    fontSize = 16.sp
                )
            }
        }
        HorizontalDivider(
            modifier = Modifier.padding(start = 56.dp),
            color = dividerColor
        )
    }
}
