package io.carrotquest_sdk.android.core.coroutines

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers

/**
 * Централизованный поставщик корутинных диспетчеров. Введён в рамках миграции с RxJava
 * (ветка remove_rx): позволяет в тестах подменять диспетчеры на TestDispatcher вместо
 * жёстко зашитых Schedulers.io()/AndroidSchedulers.mainThread().
 *
 * В проде используется [Default]. В тестах присвой [SdkDispatchers.instance] свою реализацию.
 */
interface DispatcherProvider {
    val main: CoroutineDispatcher
    val io: CoroutineDispatcher
    val default: CoroutineDispatcher
    val unconfined: CoroutineDispatcher
}

internal object DefaultDispatcherProvider : DispatcherProvider {
    override val main: CoroutineDispatcher get() = Dispatchers.Main
    override val io: CoroutineDispatcher get() = Dispatchers.IO
    override val default: CoroutineDispatcher get() = Dispatchers.Default
    override val unconfined: CoroutineDispatcher get() = Dispatchers.Unconfined
}

object SdkDispatchers {
    @Volatile
    var instance: DispatcherProvider = DefaultDispatcherProvider

    val main: CoroutineDispatcher get() = instance.main
    val io: CoroutineDispatcher get() = instance.io
    val default: CoroutineDispatcher get() = instance.default
    val unconfined: CoroutineDispatcher get() = instance.unconfined
}