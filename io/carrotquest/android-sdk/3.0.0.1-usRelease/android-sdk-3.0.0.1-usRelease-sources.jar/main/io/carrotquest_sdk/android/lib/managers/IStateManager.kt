package io.carrotquest_sdk.android.lib.managers

import io.carrotquest_sdk.android.core.Cancellable

/**
 * Наблюдатель за булевым состоянием менеджера (есть/нет интернета, foreground/background).
 *
 * `fun interface` (SAM) — вызывается лямбдой как из Kotlin, так и из Java.
 * Пришёл на смену тройке Rx-колбэков (Consumer/Consumer/Action): error/complete-обработчики
 * в старом коде были рудиментом — Subject'ы никогда не emit'или onError, а onComplete
 * срабатывал только в deInit(). Во Flow-модели эти события не возникают, поэтому остался
 * единственный канал — изменение состояния.
 */
fun interface StateObserver {
    fun onChanged(state: Boolean)
}

interface IStateManager {
    /**
     * Добавить наблюдателя за состоянием. Возвращает [Cancellable] для отписки: подписчики с
     * собственным жизненным циклом (презентеры/Activity) ОБЯЗАНЫ вызвать [Cancellable.cancel] в
     * onDestroy, иначе collect живёт на скоупе менеджера до [deInit] и держит view (утечка).
     * Долгоживущим потребителям (на весь жизненный цикл SDK) возвращённый хэндл можно игнорировать.
     */
    fun addObserver(observer: StateObserver): Cancellable

    /**
     * Необходимо вызывать после завершения работы.
     */
    fun deInit()
}
