package io.carrotquest_sdk.android.domain.use_cases.bot

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse

/**
 * suspend-версия startRoutingBot (ветка remove_rx). Возвращает успех (meta.status == 200).
 * Заменила Observable-ext. Семантика 1:1:
 * - пустой actionId/Text → false;
 * - реальный conversationId (не "routing") → ошибка проглатывается (NetworkResponse(t) → false);
 * - иначе (новый/routing) → ошибка пробрасывается (как оригинал без onErrorReturn).
 */
suspend fun startRoutingBot(
    botId: String,
    answerActionId: String,
    answerActionText: String,
    randomId: String?,
    conversationId: String?
): Boolean {
    if (answerActionId.isEmpty() || answerActionText.isEmpty()) {
        return false
    }

    val carrotLib = CarrotInternal.getService().carrotLib
    return if (!conversationId.isNullOrEmpty() && !conversationId.contains("routing")) {
        val res = try {
            carrotLib.startRoutingBotSuspend(botId, answerActionId, answerActionText, randomId, conversationId)
        } catch (t: Throwable) {
            NetworkResponse("$t")
        }
        res.meta != null && res.meta?.status == 200
    } else {
        val res = carrotLib.startRoutingBotSuspend(botId, answerActionId, answerActionText, randomId)
        res.meta != null && res.meta?.status == 200
    }
}
