package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser

// Observable-ext getConversation удалена (ветка remove_rx, шаг 4 фазы 8.5) — все потребители
// (DialogPresenter, CreateConversation/CreateMessage/OnAddMessages) переведены на suspend.

// Возвращает DataConversation? (раньше Optional в Observable-ext). Логика 1:1: in-memory (repo)
// → подгрузка списка с сервера (getCurrentUser + loadConversations) → одиночная загрузка
// (reloadConversation).
suspend fun getConversationSuspend(conversationId: String): DataConversation? {
    ConversationsRepository.getInstance().getConversationById(conversationId)?.let { return it }

    val user = getCurrentUser()
    if (user != null) {
        loadConversations(user.id)
        ConversationsRepository.getInstance().getConversationById(conversationId)?.let { return it }
    }

    return reloadConversation(conversationId)
}
