package io.carrotquest_sdk.android.presentation.mvp.dialog.presenter

import io.carrotquest_sdk.android.Callback

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.text.InputType
import android.text.TextUtils
import android.webkit.MimeTypeMap
import androidx.core.graphics.toColorInt
import com.google.gson.JsonObject
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.core.constants.ConversationType
import io.carrotquest_sdk.android.core.Cancellable
import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.constants.MessageStatus
import io.carrotquest_sdk.android.core.constants.ResponseFields
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.db.files.SavedFile
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.data.repositories.old.UserRepository
import io.carrotquest_sdk.android.domain.entities.Optional
import io.carrotquest_sdk.android.domain.use_cases.bot.loadRoutingBot
import io.carrotquest_sdk.android.domain.use_cases.bot.startRoutingBot
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.clearDraftMessageUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversation.draft_messages.saveDraftMessageUseCase
import io.carrotquest_sdk.android.domain.use_cases.conversations.TAG
import io.carrotquest_sdk.android.domain.use_cases.conversations.createConversationSuspend
import io.carrotquest_sdk.android.domain.use_cases.conversations.getConversationSuspend
import io.carrotquest_sdk.android.domain.use_cases.conversations.conversationsFlow
import io.carrotquest_sdk.android.domain.use_cases.conversations.getLastConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.notPopup
import io.carrotquest_sdk.android.domain.use_cases.conversations.markConversationAsRead
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.createMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.createWelcomeMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.getMessages
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.paginationMessages
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.removeWelcomeMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.saveMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.selectBotBrunch
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.sendMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.sendMessageWithAttachment
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateAutoReplay
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateAutoReplayLoading
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateAutoReplayLocal
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateConversationMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.updateStatusMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.openConversation
import io.carrotquest_sdk.android.domain.use_cases.conversations.removeTypingIndicator
import io.carrotquest_sdk.android.domain.use_cases.conversations.updateOpenedConversationId
import io.carrotquest_sdk.android.domain.use_cases.countries.GetSavedCountryRegionUseCase
import io.carrotquest_sdk.android.domain.use_cases.countries.getCountryEntityByRegion
import io.carrotquest_sdk.android.domain.use_cases.settings.getLastSettings
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettings
import io.carrotquest_sdk.android.domain.use_cases.settings.getSettingsSuspend
import io.carrotquest_sdk.android.domain.use_cases.user.doneVoting
import io.carrotquest_sdk.android.domain.use_cases.user.doneVotingComment
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser
import io.carrotquest_sdk.android.domain.use_cases.user.sendVoteOperator
import io.carrotquest_sdk.android.domain.use_cases.user.setUserProperty
import io.carrotquest_sdk.android.domain.use_cases.user.wrongVoting
import io.carrotquest_sdk.android.lib.managers.BackgroundManager
import io.carrotquest_sdk.android.lib.managers.network.NetworkManager
import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.lib.utils.loging.Log.Companion.e
import io.carrotquest_sdk.android.lib.utils.loging.LogToElk
import io.carrotquest_sdk.android.lib.utils.loging.MessageToElkType
import io.carrotquest_sdk.android.lib.wss.jwt.isActualJwtToken
import io.carrotquest_sdk.android.lib.wss.jwt.refreshJwtToken
import io.carrotquest_sdk.android.presentation.constans.StatusOperators
import io.carrotquest_sdk.android.presentation.entities.CountryEntity
import io.carrotquest_sdk.android.presentation.mvp.base.BasePresenter
import io.carrotquest_sdk.android.presentation.mvp.base.IBaseView
import io.carrotquest_sdk.android.presentation.mvp.bottom_sheets.MessageActionsBottomSheetActivity
import io.carrotquest_sdk.android.presentation.mvp.dialog.model.DialogViewModel
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.IDialogView
import io.carrotquest_sdk.android.presentation.mvp.dialog.view.InputMod
import io.carrotquest_sdk.android.presentation.mvp.file_picker.FilePickerHelper
import io.carrotquest_sdk.android.presentation.mvp.notifications.tracking.trackClick
import io.carrotquest_sdk.android.presentation.mvp.utils.app_color_utils.AppColorUtils
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.UnsupportedEncodingException
import retrofit2.HttpException
import java.net.URLDecoder
import java.util.Date
import java.util.Locale
import javax.inject.Inject

// Таймаут ожидания готовности SDK (Ready) при загрузке сообщений после cold-start-offline:
// при возврате сети SDK переинициализируется, ждём сессию, затем грузим.
private const val AWAIT_READY_TIMEOUT_MS = 15_000L

class DialogPresenter : BasePresenter() {

    @set:Inject
    internal var db: CarrotSdkDB? = null
    @set:Inject
    internal var  userRepository: UserRepository? = null


    private val tag = "DialogPresenter"
    // Корутинная замена compositeDisposable (ветка remove_rx, фаза 7). На Main: колбэки во
    // вьюху безопасны; await не блокирует. Для разовых action-корутин (отправка, голосование и т.п.).
    private var presenterScope = CoroutineScope(SupervisorJob() + SdkDispatchers.main)
    // Отдельный скоуп для ДОЛГОЖИВУЩИХ подписок (commonSubscribes/init* потоки). Сбрасывается
    // при ре-ините/новом диалоге (resetSubscriptions) — это заменяет compositeDisposable.dispose()
    // и не отменяет разовые корутины из presenterScope.
    private var subscriptionsScope = CoroutineScope(SupervisorJob() + SdkDispatchers.main)
    private fun resetSubscriptions() {
        subscriptionsScope.cancel()
        subscriptionsScope = CoroutineScope(SupervisorJob() + SdkDispatchers.main)
    }

    // Подписки на менеджеры сети/фона. Их collect живёт на скоупе менеджера (до deInit SDK),
    // поэтому презентер ОБЯЗАН отписаться в onDestroy, иначе держит view (утечка на каждое
    // открытие чата). Раньше это был Rx Disposable под compositeDisposable.
    private var networkCancellable: Cancellable? = null
    private var backgroundCancellable: Cancellable? = null

    private val viewModel = DialogViewModel.getInstance()

    private var isPagination = false

    private var isNewDialog = false

    private val mainInputType =
        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_AUTO_COMPLETE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE

    fun onCreate() {
        loadMessages()
    }

    override fun attachView(view: IBaseView) {
        super.attachView(view)
        loadSettings()

        getViewInterface()?.let { dialogActivity ->
            val savedRegion = GetSavedCountryRegionUseCase().call()
            val savedCountry =
                getCountryEntityByRegion(savedRegion, PhoneNumberUtil.createInstance(dialogActivity.getCurrentContext()))
            setPhoneRegion(savedCountry)
        }
    }

    private var selectedCountry: CountryEntity? = null
    private fun setPhoneRegion(country: CountryEntity) {
        selectedCountry = country

        val flag = country.flag
        val prefix = "+${country.countryCode}"

        if (flag != null) {
            getViewInterface()?.updatePhoneRegionFlag(flag)
            getViewInterface()?.updatePhoneRegionPrefix(prefix)

            val currentConversationId = viewModel.getCurrentConversationId()
            if(currentConversationId.isNotEmpty()) {
                presenterScope.launch {
                    val conversation = getConversationSuspend(currentConversationId)
                    if (conversation != null) {
                        updateInput(conversation)
                    }
                }
            }
        }
    }

    private fun loadSettings() {
        val hasInternet =
            NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).hasConnect
        if (hasInternet) {
            presenterScope.launch {
                try {
                    val settings = getSettingsSuspend()
                    if (settings != null) {
                        val color = if(settings.originalAppColor == null) {
                            settings.appColor
                        } else {
                            AppColorUtils.getCorrectAccentColor(CarrotInternal.getLibComponent().contextSdk, settings.originalAppColor)
                        }
                        getViewInterface()?.updateAppColor(("#$color").toColorInt())
                    }
                } catch (error: Throwable) {
                    Log.e(tag, error)
                }
            }
        } else {
            val settings = getLastSettings()
            if (settings != null) {
                val color = AppColorUtils.getCorrectAccentColor(CarrotInternal.getLibComponent().contextSdk, settings.originalAppColor!!)
                getViewInterface()?.updateAppColor(("#$color").toColorInt())
            }
        }
    }

    fun onCreateWebView(convId: String) {
        // Сеть проверяем синхронно через ConnectivityManager (isNetworkAvailable),
        // а не через асинхронный кэш hasConnect: кэш врёт после Doze/долгого
        // background. Если сети физически нет — сразу показываем оверлей,
        // иначе вечный лоадер. Когда сеть вернётся, observer в initSubscribes
        // дёрнет loadMessages и обновит UI.
        val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)
        if (NetworkManager.isAirplaneModeOn()) {
            getViewInterface()?.showErrorAirplaneMode()
            resetSubscriptions()
            return
        }
        if (!networkManager.isNetworkAvailable()) {
            getViewInterface()?.showErrorNoInternet()
            return
        }
        // Немедленно синхронно восстанавливаем состояние UI из кеша (phone prefix и тип ввода),
        // не дожидаясь асинхронной цепочки getConversation. Это исключает мигание phone_prefix
        // при повторном входе в диалог: к моменту появления экрана UI уже в нужном состоянии.
        ConversationsRepository.getInstance().getConversationById(convId)?.let { updateInput(it) }
        loadConversationAndUpdateInput(convId)
    }

    private fun loadConversationAndUpdateInput(convId: String) {
        presenterScope.launch {
            try {
                val conversation = getConversationSuspend(convId)
                getViewInterface()?.updateHint(null)
                if (conversation != null) {
                    updateInput(conversation)
                }
                getViewInterface()?.setInputMod(currentInputMod)
            } catch (t: Throwable) {
                Log.e(TAG, t)
            }
        }
    }

    fun retry() {
        val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)
        when {
            NetworkManager.isAirplaneModeOn()        -> getViewInterface()?.showErrorAirplaneMode()
            !networkManager.isNetworkAvailable()     -> getViewInterface()?.showErrorNoInternet()
            else                                     -> loadMessages(needHardUpdate = true)
        }
    }

    // Backend-ошибку (HTTP, напр. 403) НЕ путаем с отсутствием сети: при живой сети показываем
    // «Что-то пошло не так» (GENERIC). Оверлей «нет интернета»/«авиарежим» — только когда сеть
    // реально недоступна (или это сетевой IOException). Иначе backend-403 маскировался под offline.
    //
    // hideLoading() вызываем ЗДЕСЬ (а не на каждом call-site): иначе следующий, кто добавит ветку
    // ошибки, забудет снять спиннер и вернёт «вечный лоадер поверх оверлоя ошибки».
    private fun showErrorForThrowable(t: Throwable?) {
        getViewInterface()?.hideLoading()
        val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)
        when {
            NetworkManager.isAirplaneModeOn()                  -> getViewInterface()?.showErrorAirplaneMode()
            t is HttpException                                 -> getViewInterface()?.showErrorSomething()
            !networkManager.isNetworkAvailable()               -> getViewInterface()?.showErrorNoInternet()
            t is IOException                                   -> getViewInterface()?.showErrorNoInternet()
            else                                               -> getViewInterface()?.showErrorSomething()
        }
    }

    fun onDestroy() {
        selectedCountry = null
        viewModel.updateCurrentConversationId("")

        super.detachView()

        // Отписка от менеджеров сети/фона — иначе их collect держит view до deInit SDK (утечка).
        networkCancellable?.cancel()
        networkCancellable = null
        backgroundCancellable?.cancel()
        backgroundCancellable = null

        presenterScope.cancel()
        presenterScope = CoroutineScope(SupervisorJob() + SdkDispatchers.main)
        subscriptionsScope.cancel()
        subscriptionsScope = CoroutineScope(SupervisorJob() + SdkDispatchers.main)
    }

    fun getViewInterface(): IDialogView? {
        return if(super.getView() is IDialogView) {super.getView() as IDialogView} else null
    }

    fun onOpenDialog() {
        isNewDialog = false
        initSubscribes()

        getViewInterface()?.updateHint(null)
        getViewInterface()?.updateMaxLengthInput(null)
        getViewInterface()?.setKeyboardType(mainInputType)
    }

    fun onOpenNewDialog() {
        isNewDialog = true
        initNewConversationSubscribes()
        viewModel.updateCurrentConversationId("")

    }

    private fun updateInput(conversation: DataConversation) {
        val conversationId = conversation.id
        if (conversationId == null) {
            return
        }

        if (conversation.type != null && ConversationType.BLOCK_POPUP_SMALL.stringValue == conversation.type) {
            getViewInterface()?.hideInput()
            return
        }

        val lastPart = conversation.partLast
        val isAllowUserReply = conversation.replyType == "text"
        // property_field может быть НЕ первым в actions (например, в part'е chat_bot_user, где бот
        // дозадаёт вопрос в рамках идущего диалога) — ищем по всему массиву, а не только actions[0].
        val botPropertyFieldAction = lastPart?.actions?.firstOrNull { it.type == "property_field" }

        val isBotConversation = ConversationType.LEAD_BOT.stringValue == conversation.type
                || ConversationType.ROUTING_BOT.stringValue == conversation.type

        Log.d(
            "CQ_BotInput",
            "updateInput convId=$conversationId convType=${conversation.type} isBot=$isBotConversation " +
                "lastPartType=${lastPart?.type} replyType=${lastPart?.replyType} " +
                "actions=[${lastPart?.actions?.joinToString(",") { it.type ?: "?" } ?: ""}] " +
                "allowUserReply=$isAllowUserReply hasPropertyField=${botPropertyFieldAction != null} " +
                "chatBotFinished=${conversation.isChatBotFinished} curMod=$currentInputMod"
        )

        // Бот-вопрос с полем ввода (property_field, напр. телефон) требует bot-input ДАЖЕ когда
        // conversation.type не помечен как бот: такой вопрос приходит в part'е chat_bot_user внутри
        // диалога с «обычным» типом (баг тестировщика — телефон-вопрос как chat_bot_user).
        if (!isBotConversation && botPropertyFieldAction == null) {
            // Обычный диалог — простой текстовый ввод.
            Log.d("CQ_BotInput", "updateInput branch=plain (not bot, no property_field) → NORMAL text")
            getViewInterface()?.showInput(conversationId)
            getViewInterface()?.updateHint(null)
            getViewInterface()?.updateMaxLengthInput(null)
            getViewInterface()?.hidePhonePrefix()
            getViewInterface()?.setKeyboardType(mainInputType)
            return
        }

        when {
            // property_field — самый приоритетный признак: всегда требует bot-input (телефон/почта/имя),
            // независимо от типа part'а (chat_bot_user/chat_bot_admin/auto_reply/reply_admin).
            botPropertyFieldAction != null -> {
                Log.d("CQ_BotInput", "updateInput branch=botPropertyField → applyBotPropertyFieldInput")
                // "phone_mask" трактуется как phone только при свободном текстовом ответе (replyType=="text").
                val phoneTypes = if (isAllowUserReply) setOf("phone", "phone_mask") else setOf("phone")
                applyBotPropertyFieldInput(conversationId, botPropertyFieldAction, lastPart.replyType, phoneTypes)
            }
            lastPart.type == "reply_admin" -> {
                Log.d("CQ_BotInput", "updateInput branch=reply_admin → NORMAL (allowUserReply=$isAllowUserReply)")
                currentInputMod = InputMod.NORMAL
                getViewInterface()?.showInput(conversationId)
                getViewInterface()?.updateHint(null)
                if (!isAllowUserReply) {
                    getViewInterface()?.hidePhonePrefix()
                    getViewInterface()?.updateMaxLengthInput(null)
                }
            }
            isAllowUserReply -> {
                Log.d("CQ_BotInput", "updateInput branch=isAllowUserReply (curMod=$currentInputMod, skip if BOT_INPUT)")
                if (currentInputMod != InputMod.BOT_INPUT) {
                    currentInputMod = InputMod.ALLOW_USER_REPLIES
                    getViewInterface()?.showInput(conversationId)
                    getViewInterface()?.updateHint(null)
                    getViewInterface()?.hidePhonePrefix()
                    getViewInterface()?.updateMaxLengthInput(null)
                    getViewInterface()?.setKeyboardType(mainInputType)
                }
            }
            conversation.isChatBotFinished -> {
                Log.d("CQ_BotInput", "updateInput branch=isChatBotFinished → ALLOW_USER_REPLIES")
                currentInputMod = InputMod.ALLOW_USER_REPLIES
                getViewInterface()?.showInput(conversationId)
                getViewInterface()?.updateHint(null)
                getViewInterface()?.hidePhonePrefix()
                getViewInterface()?.updateMaxLengthInput(null)
                getViewInterface()?.setKeyboardType(mainInputType)
            }
            else -> {
                Log.d("CQ_BotInput", "updateInput branch=else → hideInput")
                getViewInterface()?.hideInput()
                getViewInterface()?.hidePhonePrefix()
                getViewInterface()?.updateMaxLengthInput(null)
                getViewInterface()?.setKeyboardType(mainInputType)
            }
        }
    }

    // Настраивает поле ввода для бот-вопроса с property_field (phone/email/name/custom).
    private fun applyBotPropertyFieldInput(
        conversationId: String,
        action: ActionMessage,
        replyType: String?,
        phoneTypes: Set<String>
    ) {
        currentInputMod = InputMod.BOT_INPUT
        currentAction = action
        getViewInterface()?.showInput(conversationId)

        val (hint, maxLength) = botAnswerHint(action, replyType, phoneTypes)
        val keyboardType = keyboardTypeFor(replyType)

        Log.d("CQ_BotInput", "applyBotPropertyFieldInput replyType=$replyType actionType=${action.type} keyboardType=$keyboardType phonePrefix=${keyboardType == InputType.TYPE_CLASS_PHONE} hint=$hint")

        if (keyboardType == InputType.TYPE_CLASS_PHONE) {
            getViewInterface()?.showPhonePrefix()
        } else {
            getViewInterface()?.hidePhonePrefix()
        }
        getViewInterface()?.updateMaxLengthInput(maxLength)
        getViewInterface()?.updateHint(hint)
        getViewInterface()?.setKeyboardType(keyboardType)
        getViewInterface()?.showSendButton()
        getViewInterface()?.disableSendButton()
    }

    // hint + maxLength для бот-ввода. maxLength != null только для phone (длина примера номера).
    private fun botAnswerHint(
        action: ActionMessage,
        replyType: String?,
        phoneTypes: Set<String>
    ): Pair<String, Int?> {
        val ctx = CarrotInternal.getLibComponent().contextSdk
        val placeholder = action.placeholder
        if (placeholder != null) {
            if (placeholder.type == "custom") return placeholder.value to null
            return when (placeholder.type) {
                in phoneTypes -> phoneExampleHint()
                "email" -> ctx.getString(R.string.bot_answer_email_hint) to null
                "name" -> ctx.getString(R.string.bot_answer_name_hint) to null
                else -> ctx.getString(R.string.bot_answer_hint) to null
            }
        }
        return when (replyType) {
            "phone" -> phoneExampleHint()
            "email" -> ctx.getString(R.string.bot_answer_email_hint) to null
            "name" -> ctx.getString(R.string.bot_answer_name_hint) to null
            else -> ctx.getString(R.string.bot_answer_hint) to null
        }
    }

    // Подсказка-пример телефона для выбранной страны + длина (maxLength). Без страны — общий хинт.
    private fun phoneExampleHint(): Pair<String, Int?> {
        val ctx = CarrotInternal.getLibComponent().contextSdk
        val country = selectedCountry ?: return ctx.getString(R.string.bot_answer_phone_hint) to null
        val example = PhoneNumberUtil.createInstance(getViewInterface()?.getCurrentContext())
            .getExampleNumberForType(country.region.uppercase(), PhoneNumberUtil.PhoneNumberType.MOBILE)
            ?.nationalNumber?.toString()
        return (example ?: ctx.getString(R.string.bot_answer_phone_hint)) to example?.length
    }

    private fun keyboardTypeFor(replyType: String?): Int = when (replyType) {
        "phone" -> InputType.TYPE_CLASS_PHONE
        "email" -> InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        else -> mainInputType
    }


    private fun initNewConversationSubscribes() {
        resetSubscriptions()

        val hasInternet =
            NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).hasConnect
        if (hasInternet) {
            commonSubscribes()
            subscriptionsScope.launch {
                val settings = try {
                    getSettingsSuspend()
                } catch (e: Throwable) {
                    getViewInterface()?.showErrorSomething()
                    return@launch
                }
                if (settings == null) {
                    getViewInterface()?.showErrorSomething()
                    return@launch
                }

                // UI-reset через 100мс — параллельно welcome/routing-bot (как и было).
                launch {
                    delay(100)
                    getViewInterface()?.hideLoadError()
                    getViewInterface()?.hideLoading()
                    getViewInterface()?.enableInput()
                }

                // Welcome-сообщение (его эмиссия задерживалась на 1с), затем выбор routing-бота.
                launch {
                    try {
                        createWelcomeMessage(settings)
                        delay(1000)
                        val data = loadRoutingBot(viewModel.getCurrentConversationId())
                        val needStartRoutingBot = data?.bot != null && data.found != false
                        viewModel.setNeedStartRoutingBot(needStartRoutingBot)
                    } catch (t: Throwable) {
                        Log.e(TAG, t)
                    }
                }
            }
        }
    }

    private fun initSubscribes() {
        resetSubscriptions()

        // Observers регистрируем всегда — даже если сейчас сети нет. Иначе
        // chicken-and-egg: при оффлайн-старте мы бы не подписались на network
        // changes, и при появлении сети ничего бы не сработало (вечный лоадер
        // или непропадающий оверлей). Сетевое состояние проверяем синхронно
        // через ConnectivityManager (isNetworkAvailable) — это live-состояние,
        // не асинхронный кэш hasConnect (который может застревать в false
        // после долгого Doze).
        val networkManager = NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk)

        if (networkManager.isNetworkAvailable()) {
            initDoneConversationSubscribes()
        } else {
            // Сеть отключена физически — показываем оверлей сразу, чтобы не
            // висел лоадер. Настройки берём из кэша, чтобы шапка/цвета жили.
            loadSettings()
            getViewInterface()?.showErrorNoInternet()
        }

        // Перед повторной подпиской отменяем прежнюю, чтобы не плодить collect'ы.
        networkCancellable?.cancel()
        networkCancellable = networkManager.addObserver { hasInternet ->
            if (hasInternet) {
                // Сеть подтверждена ping'ом — снимаем оверлей "нет интернета"
                // (если он был показан при оффлайн-старте) и догружаем сообщения.
                getViewInterface()?.hideLoadError()
                loadMessages()
            } else {
                if (NetworkManager.isAirplaneModeOn()) {
                    getViewInterface()?.showErrorAirplaneMode()
                } else {
                    getViewInterface()?.showErrorNoInternet()
                }
            }
        }

        backgroundCancellable?.cancel()
        backgroundCancellable = BackgroundManager.getInstance().addObserver { isForeground ->
            if (isForeground) {
                //println("ISOPENPICKER = $isOpenPicker")
                if(!isOpenPicker) {
                    loadMessages(needHardUpdate = true)
                }
                //loadMessages(needHardUpdate = false)
            }
        }
    }

    private fun initDoneConversationSubscribes() {
        resetSubscriptions()
        val conversationId = viewModel.getCurrentConversationId()
        subscriptionsScope.launch {
            // 1. Грузим диалог (+ side-effect openConversation для не-popup), отмечаем прочитанным.
            val conversation = try {
                val c = getConversationSuspend(conversationId)
                if (c == null) {
                    showErrorForThrowable(null)
                } else if (c.type != ConversationType.BLOCK_POPUP_BIG.stringValue
                    && c.type != ConversationType.BLOCK_POPUP_SMALL.stringValue
                ) {
                    subscriptionsScope.launch {
                        openConversation(conversationId)
                    }
                }
                markConversationAsRead(c)
            } catch (e: Throwable) {
                onOpenNewDialog()
                return@launch
            } ?: return@launch

            // 2. Грузим сообщения диалога. На ошибке ВСЕГДА гасим лоадер (иначе вечный спиннер
            //    поверх оверлоя ошибки) и показываем ошибку с учётом её типа (backend vs offline).
            val messages = try {
                getMessages(conversation)
            } catch (t: Throwable) {
                showErrorForThrowable(t)
                return@launch
            }
            if (messages == null) {
                showErrorForThrowable(null)
                return@launch
            }

            // 3. Дожидаемся настроек, гасим лоадеры (с задержкой 1с, параллельно) и поднимаем подписки.
            val settings = try {
                getSettingsSuspend()
            } catch (e: Throwable) {
                showErrorForThrowable(e)
                return@launch
            }
            if (settings == null) {
                showErrorForThrowable(null)
                return@launch
            }
            launch {
                delay(1000)
                getViewInterface()?.hideLoadError()
                getViewInterface()?.hideLoading()
                getViewInterface()?.enableInput()
            }
            commonSubscribes()
        }
    }

    private fun commonSubscribes() {
        // Непрерывная подписка: на каждое добавление сообщений отмечаем диалог прочитанным.
        subscriptionsScope.launch {
            MessagesRepository.getInstance().newMessagesFlow.collect {
                try {
                    val conv = getConversationSuspend(viewModel.getCurrentConversationId())
                    markConversationAsRead(conv)
                } catch (t: Throwable) {
                    Log.e(tag, t)
                }
            }
        }

        // Непрерывная подписка на список диалогов: обновляем input текущего.
        subscriptionsScope.launch {
            conversationsFlow().map { it.notPopup() }.collect { conversations ->
                val curId = viewModel.getCurrentConversationId()
                val currentConversation = conversations.find { x -> x.id == curId }
                Log.d("CQ_BotInput", "conversationsFlow emit: size=${conversations.size} curId=$curId found=${currentConversation != null} lastPartType=${currentConversation?.partLast?.type}")
                if (currentConversation != null) {
                    updateInput(currentConversation)
                }
            }
        }

        // Разовый запрос routing-бота; при наличии — подписка на создание нового диалога.
        subscriptionsScope.launch {
            val data = try {
                loadRoutingBot(viewModel.getCurrentConversationId())
            } catch (t: Throwable) {
                Log.e(TAG, t)
                null
            }
            val needStartRoutingBot = data?.found == true
            viewModel.setNeedStartRoutingBot(needStartRoutingBot)
            if (needStartRoutingBot) {
                data?.bot?.id?.let { viewModel.setRoutingBotId(it) }
                if (data?.bot?.allow != true) {
                    getViewInterface()?.hideInput()
                }
                // Диалог с роутинг-ботом — ждём сохранения нового диалога, чтобы переключить
                // currentConversationId с временного randomId на реальный серверный id и поднять
                // подписки на сообщения (commonSubscribes). Новый диалог создаётся на сервере
                // (POST routing/start) ТОЛЬКО когда пользователь отвечает боту, а это происходит
                // в пользовательском темпе — часто сильно позже choose (человек сперва читает
                // первое сообщение). Раньше тут стоял жёсткий таймаут 5с: не успел ответить за 5с —
                // ожидание сдавалось, рекурсивный commonSubscribes() не вызывался → ответ бота не
                // подхватывался («ничего не приходит в ответ»). Поэтому ждём нужный диалог весь
                // lifecycle подписки (subscriptionsScope отменяется в onDestroy/resetSubscriptions).
                //
                // Ждём только пока диалога ещё нет (новый диалог, id пуст). При повторных вызовах
                // commonSubscribes (id уже известен) ждать нечего — иначе корутина повисла бы до
                // onDestroy. Матчим по randomId: к моменту эмиссии currentConversationId уже равен
                // сгенерированному randomId (см. onSelectBotBrunch), поэтому берём именно наш диалог,
                // а не первый попавшийся.
                if (viewModel.getCurrentConversationId().isEmpty()) {
                    try {
                        val repo = ConversationsRepository.getInstance()
                        val isOurNewConversation: (DataConversation) -> Boolean = {
                            val cur = viewModel.getCurrentConversationId()
                            cur.isNotEmpty() && cur == it.randomId
                        }
                        // newConversationFlow — SharedFlow(replay=0): эмиссия могла пройти до first().
                        // Подстрахуемся — сперва проверим уже сохранённые диалоги.
                        val c = repo.getConversationsSync().find(isOurNewConversation)
                            ?: repo.newConversationFlow.first(isOurNewConversation)
                        viewModel.setNeedStartRoutingBot(false)
                        viewModel.updateCurrentConversationId(c.id)
                        commonSubscribes()
                    } catch (e: CancellationException) {
                        throw e
                    } catch (t: Throwable) {
                        Log.e(TAG, t)
                    }
                }
            }
        }
    }

    fun onTapMessage(context: Context, messageId: String) {
        // Упавшее сообщение (status == "warning") → шторка с «Повторить»/«Удалить»,
        // обычное → шторка с «Копировать».
        val message = MessagesRepository.getInstance().findMessageById(messageId)
        val isFailed = message?.status == MessageStatus.WARNING.name.lowercase(Locale.getDefault())
        val intent = if (isFailed)
            MessageActionsBottomSheetActivity.intentForError(context, messageId)
        else
            MessageActionsBottomSheetActivity.intentForMessage(context, messageId)
        context.startActivity(intent)
    }

    fun paginationMessages() {
        if (MessagesRepository.getInstance().getCurrentAfter().isEmpty()) return
        if (!isPagination) {
            isPagination = true
            getViewInterface()?.showLoadingOlderMessages()
            presenterScope.launch {
                try {
                    val conversation = getConversationSuspend(viewModel.getCurrentConversationId())
                    if (conversation != null) paginationMessages(conversation)
                    isPagination = false
                    getViewInterface()?.hideLoadingOlderMessages()
                } catch (e: Throwable) {
                    getViewInterface()?.showErrorSomething()
                    isPagination = false
                    getViewInterface()?.hideLoadingOlderMessages()
                }
            }
        }
    }

    fun setContactDetails(messageId: String, type: String, value: String) {
        presenterScope.launch {
            val res = try {
                val message = getMessage(messageId) ?: return@launch
                updateAutoReplayLoading(message.id, false)
                val user = getCurrentUser() ?: return@launch
                setUserProperty(user.id, type, value)
            } catch (e: Throwable) {
                // Ошибка отправки контакта — помечаем сообщение как WARNING.
                val m = runCatching { getMessage(messageId) }.getOrNull()
                if (m?.id != null) {
                    runCatching {
                        updateStatusMessage(m, MessageStatus.WARNING.name.lowercase(Locale.getDefault()))
                    }
                }
                return@launch
            }

            updateAutoReplay(messageId, res)
            val message = getMessage(messageId)
            if (message?.messageMetaData != null) {
                val meta = message.messageMetaData
                meta?.replied = res
                meta?.loading = false
                message.messageMetaData = meta
                updateAutoReplayLocal(message)
            }
        }
    }

    fun sendVote(messageId: String, vote: Int) {
        presenterScope.launch {
            val res = try {
                sendVoteOperator(messageId, vote)
            } catch (e: Throwable) {
                wrongVoting(messageId)
                return@launch
            }
            if (res) {
                try {
                    doneVoting(messageId, vote)
                } catch (t: Throwable) {
                    Log.e(tag, t)
                }
            } else {
                wrongVoting(messageId)
            }
        }
    }

    fun sendCommentVote(messageId: String, vote: Int, comment: String) {
        presenterScope.launch {
            val res = try {
                sendVoteOperator(messageId, vote, comment)
            } catch (e: Throwable) {
                wrongVoting(messageId)
                return@launch
            }
            if (res) {
                doneVotingComment(messageId, vote)
            } else {
                wrongVoting(messageId)
            }
        }
    }

    fun onGoToLink(link: String, context: Context) {
        if (viewModel.getCurrentConversationId().isNotEmpty()
            && viewModel.getCurrentConversationId() != "last_conversation"
        ) {
            trackClick(viewModel.getCurrentConversationId(), object : Callback<Boolean> {
                override fun onResponse(result: Boolean?) {
                }

                override fun onFailure(t: Throwable?) {
                }
            })
        }
        // Ссылки без схемы (например, "google.com" из HTML <a href>) ACTION_VIEW не открывает —
        // достраиваем https://, иначе ловим ActivityNotFoundException.
        val uri = Uri.parse(link)
        val safeUri = if (uri.scheme.isNullOrEmpty()) Uri.parse("https://${link.trim()}") else uri
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = safeUri
        try {
            context.startActivity(intent)
        } catch (e: android.content.ActivityNotFoundException) {
            Log.e(tag, "No activity to open link: $safeUri")
        }
    }

    fun onResume() {
        // Перезапустить ping-цикл NetworkManager: если за ночь в Doze фоновый
        // retry исчерпал лимит и hasInternet застрял в false, тут флаг оживёт.
        NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).revalidate()

        val conversationId = viewModel.getCurrentConversationId()
        updateOpenedConversationId(conversationId)

        presenterScope.launch {
            delay(1000)
            val context = getViewInterface()?.getCurrentContext()
            val lastLoadTime = if(context != null) {
                SharedPreferencesLib.getLong(context, "last_load_messages_time_key")
            } else {
                0
            }

            val needHard = if(lastLoadTime == 0L) {
                true
            } else {
                Date().after(Date(lastLoadTime + (10 * 60 * 1000)))
            }
            if(!isOpenPicker) {
                loadMessages(needHardUpdate = needHard)
            } else {
                isOpenPicker = false
            }
        }
    }

    fun onPause() {
        removeTypingIndicator()
        updateOpenedConversationId("")
    }

    private var selectBotBrunchInProcess = false
    fun onSelectBotBrunch(
        messageId: String,
        branchId: String,
        branchLinkId: String,
        answerBody: String,
        href: String,
        context: Context
    ) {
        if(selectBotBrunchInProcess) {
            return
        }

        selectBotBrunchInProcess = true
        Log.d("CQ_BotInput", "onSelectBotBrunch msgId=$messageId branchId=$branchId answerBody='$answerBody' needStartRoutingBot=${viewModel.needStartRoutingBot()} convId=${viewModel.getCurrentConversationId()}")
        if (viewModel.needStartRoutingBot()) {
            val botId = viewModel.getRoutingBotId()

            val convId = viewModel.getCurrentConversationId().ifEmpty { null }
            val randomId = if (convId.isNullOrEmpty()) {
                "routing_${System.currentTimeMillis() / 1000}"
            } else {
                convId
            }

            updateOpenedConversationId(randomId)
            viewModel.updateCurrentConversationId(randomId)

            presenterScope.launch {
                try {
                    startRoutingBot(botId, branchId, answerBody, randomId, convId)
                    viewModel.setNeedStartRoutingBot(false)
                    delay(1000)
                    selectBotBrunchInProcess = false
                } catch (t: Throwable) {
                    Log.e(TAG, t)
                    selectBotBrunchInProcess = false
                }
            }
        } else {
            presenterScope.launch {
                try {
                    val mess = getMessage(messageId)
                    // mess есть и ветка уже выбрана (answerActionId != null) — ничего не делаем.
                    if (mess != null && mess.messageMetaData.answerActionId != null) {
                        selectBotBrunchInProcess = false
                    } else {
                        // showErrorSomething только когда сообщения нет в репозитории (как в оригинале).
                        val showErrorOnFail = mess == null
                        try {
                            selectBotBrunch(messageId, branchId, answerBody)
                        } catch (error: Throwable) {
                            Log.e(tag, error.toString())
                            if (showErrorOnFail) getViewInterface()?.showErrorSomething()
                        }
                        selectBotBrunchInProcess = false
                    }
                } catch (t: Throwable) {
                    Log.e(tag, t.toString())
                    selectBotBrunchInProcess = false
                }
            }
        }

        if (href != null && href.isNotEmpty() && href.lowercase() != "undefined") {
            try {
                val decodedUrl = URLDecoder.decode(href, "UTF-8")
                onGoToLink(decodedUrl, context)
            } catch (e: UnsupportedEncodingException) {
                //e.printStackTrace()
            }
        }
    }

    private var isOpenPicker = false
    fun onOpenPicker(height: Int) {
        isOpenPicker = true
        getViewInterface()?.openFilePicker()
    }

    private fun createConversationByFile(file: File) {
        val date = (System.currentTimeMillis() / 1000).toString()
        val attachment = Attachment()
        attachment.id = date
        attachment.created = date
        attachment.filename = file.name
        attachment.size = file.length()
        attachment.url = file.absolutePath
        attachment.type = ResponseFields.FILE_TYPE
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
            MimeTypeMap.getFileExtensionFromUrl(
                Uri.fromFile(file).toString()
            ).lowercase(Locale.getDefault())
        )
        attachment.mimeType = mimeType

        if (mimeType?.contains("image") == true) {
            attachment.type = "image"
        } else {
            attachment.type = ResponseFields.FILE_TYPE
        }

        presenterScope.launch {
            val firstMessage = try {
                removeWelcomeMessage()
                val m = createMessage(attachment, "", isFirst = true, status = MessageStatus.LOADING)
                saveMessage(m)
            } catch (t: Throwable) {
                Log.e(tag, t)
                return@launch
            }

            // Очищаем прежние подписки (commonSubscribes и пр.) перед стартом нового диалога.
            resetSubscriptions()

            try {
                saveMessage(firstMessage)
                val nConversationId = createConversationSuspend(file)
                if (!TextUtils.isEmpty(nConversationId)) {
                    run {
                        val savedFile = SavedFile(System.currentTimeMillis().toString())
                        savedFile.localUri = file.absolutePath
                        savedFile.url = firstMessage.attachments[0].url
                        if (db == null) {
                            db = CarrotInternal.getLibComponent().sdkDataBase
                        }
                        // Room-запись — на IO (presenterScope живёт на main; иначе дисковый I/O на UI-потоке).
                        withContext(SdkDispatchers.io) { db?.savedFileDao()?.insert(savedFile) }
                    }

                    run {
                        val jsonSource = firstMessage.sourceJsonData
                        if (jsonSource.has(F.ATTACHMENTS)) {
                            val attachmentsJson = jsonSource.getJSONArray(F.ATTACHMENTS)
                            val attJson = attachmentsJson.getJSONObject(0)
                            attJson?.remove(F.STATUS)
                            val status =
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) "" else "loaded"
                            attJson.put(F.STATUS, status)

                            val nAttachments = JSONArray()
                            nAttachments.put(attJson)
                            firstMessage.sourceJsonData.remove(F.ATTACHMENTS)
                            firstMessage.sourceJsonData.put(F.ATTACHMENTS, nAttachments)
                        }
                    }

                    viewModel.updateCurrentConversationId(nConversationId)
                    try {
                        val conv = getConversationSuspend(nConversationId)
                        commonSubscribes()
                        val convId = conv?.id!!
                        updateStatusMessage(firstMessage, MessageStatus.LOADED.name.lowercase(Locale.getDefault()))
                        updateConversationMessage(convId, firstMessage)
                        getViewInterface()?.enableInput()
                    } catch (t: Throwable) {
                        Log.e(tag, t)
                    }
                } else {
                    getViewInterface()?.showErrorSomething()
                }
            } catch (t: Throwable) {
                Log.e(tag, t)
                getViewInterface()?.showErrorSomething()
            }
        }
    }

    private fun isCorrectPhone(text: String, typeReply: String): Boolean {
        if(selectedCountry == null || typeReply != "phone") {
            return true
        }

        val phone = if (currentInputMod == InputMod.BOT_INPUT) {
            "+${selectedCountry?.countryCode}$text"
        } else {
            text
        }

        return PhoneNumberUtil.createInstance(getViewInterface()?.getCurrentContext())
            .isPossibleNumber(phone, selectedCountry!!.region.uppercase())
    }


    fun onInputText(text: String) {
        //Отправляем на сервер событие о том, что пользователь печатает
        val conversationId = viewModel.getCurrentConversationId()
        if (conversationId.isNotEmpty()) {
            CarrotInternal.getService().setTyping(conversationId, text)
        }

        saveDraftMessageUseCase(text, conversationId)

        presenterScope.launch {
            val conversation = getConversationSuspend(viewModel.getCurrentConversationId())
            val phoneIsCorrect = if (conversation?.partLast?.replyType != null) {
                isCorrectPhone(text.trim(), conversation.partLast.replyType)
            } else {
                true
            }

            if (!TextUtils.isEmpty(text.trim()) && phoneIsCorrect) {
                getViewInterface()?.hideAttachFileButton()
                getViewInterface()?.enableSendButton()
                getViewInterface()?.showSendButton()
            } else {
                if (currentInputMod == InputMod.BOT_INPUT) {
                    getViewInterface()?.disableSendButton()
                    getViewInterface()?.showSendButton()
                    getViewInterface()?.hideAttachFileButton()
                } else {
                    getViewInterface()?.disableSendButton()
                    getViewInterface()?.showAttachFileButton()
                }
            }
        }
    }

    private var currentInputMod = InputMod.NORMAL
    private var currentAction: ActionMessage? = null

    fun onTapSendMessage(textMessage: String) {
        val conversationId = viewModel.getCurrentConversationId()
        if (currentInputMod == InputMod.BOT_INPUT && currentAction != null) {
            sendActionBot(currentAction!!, textMessage)
            currentInputMod = InputMod.NORMAL
        } else {
            if (!TextUtils.isEmpty(conversationId)) {
                sendNormalMessage(textMessage, conversationId)
            } else {
                createConversation(textMessage)
            }
        }
    }

    fun onCountrySelected(country: CountryEntity) {
        setPhoneRegion(country)
    }

    fun onChangeConversationId(conversationId: String) {
        viewModel.updateCurrentConversationId(conversationId)
        currentAction = null
        currentInputMod = InputMod.NORMAL
    }

    private fun sendActionBot(action: ActionMessage, answer: String) {
        fun upMessage(message: MessageData): MessageData {
            message.status =
                MessageStatus.LOADED.name.lowercase()
            val jsonSource = message.sourceJsonData
            if (jsonSource.has(F.STATUS)) {
                jsonSource.remove(F.STATUS)
            }
            jsonSource.put(
                F.STATUS,
                MessageStatus.LOADED.name.lowercase()
            )

            message.sourceJsonData = jsonSource
            MessagesRepository.getInstance().updateMessage(message)

            viewModel.getRoutingBotId()

            return message
        }

        presenterScope.launch {
            val conversation = getConversationSuspend(viewModel.getCurrentConversationId()) ?: return@launch

            val trueAnswer =
                if (selectedCountry != null && conversation.partLast.replyType == "phone") {
                    "+${selectedCountry?.countryCode}$answer"
                } else {
                    answer
                }

            clearDraftMessageUseCase(viewModel.getCurrentConversationId())
            getViewInterface()?.clearInput()

            val message = createMessage(
                trueAnswer,
                viewModel.getCurrentConversationId(),
                isFirst = false,
                status = MessageStatus.LOADING
            )

            // Порядок сообщений. На устройствах со спешащими часами оптимистичный ответ
            // получал created с часов устройства и обгонял СЛЕДУЮЩИЙ вопрос бота (его серверный
            // created на 1-2 c меньше) → ответ уезжал ниже вопроса (chat сортируется по created).
            // Привязываем created к таймлайну сервера (created последнего сообщения), а тонкий
            // порядок внутри секунды задаём через sortKey = maxId+1: строго после текущего
            // последнего сообщения и перед будущими серверными (у тех снежинки больше).
            // Прежний код правил created в sourceJsonData на now-2, но сортировка использует
            // поле created, а не json, — поэтому не работал.
            val lastCreated = MessagesRepository.getInstance().getLastMessageCreatedSeconds()
            if (lastCreated > 0) {
                val anchored = lastCreated.toString()
                message.created = anchored
                message.sortKey = MessagesRepository.getInstance().getMaxMessageId() + 1
                val messageJson = message.sourceJsonData
                if (messageJson.has(F.CREATED)) {
                    messageJson.remove(F.CREATED)
                }
                messageJson.put(F.CREATED, anchored)
                message.sourceJsonData = messageJson
            }

            // Оптимистичная отрисовка: текстовый ответ боту (поле ввода в BOT_INPUT) кладём в
            // репозиторий сразу, как делает sendNormalMessage. Иначе сообщение появлялось только
            // после перезахода в диалог — upMessage()→updateMessage() это no-op, пока сообщения
            // нет в списке (MessagesRepository.updateMessage). Дедуп по id/randomId сработает,
            // когда тот же ответ придёт с бэкенда.
            MessagesRepository.getInstance().addMessage(message)

            if (viewModel.needStartRoutingBot()) {
                val botId = viewModel.getRoutingBotId()
                val randomId = "routing_${System.currentTimeMillis() / 1000}"
                viewModel.updateCurrentConversationId(randomId)
                val convId = viewModel.getCurrentConversationId().ifEmpty { null }
                try {
                    startRoutingBot(botId, action.id, action.body, randomId, convId)
                    viewModel.setNeedStartRoutingBot(false)
                    val jsonSource = message.sourceJsonData
                    if (jsonSource.has(F.CREATED)) {
                        jsonSource.remove(F.CREATED)
                    }
                    message.sourceJsonData = jsonSource
                    upMessage(message)
                } catch (t: Throwable) {
                    // Отмену корутины (закрытие диалога во время сетевого вызова) не глотаем
                    // и не логируем как ошибку — пробрасываем дальше.
                    if (t is CancellationException) throw t
                    Log.e(TAG, t)
                }
            } else {
                try {
                    selectBotBrunch(action.messageId, action.id, trueAnswer)
                    upMessage(message)
                } catch (error: Throwable) {
                    // Отмену корутины не глотаем — пробрасываем дальше.
                    if (error is CancellationException) throw error
                    Log.e(tag, error.toString())
                }
            }
        }
    }

    private fun sendNormalMessage(textMessage: String, conversationId: String) {
        clearDraftMessageUseCase(conversationId)
        getViewInterface()?.clearInput()

        presenterScope.launch {
            try {
                val newMessage = createMessage(textMessage, viewModel.getCurrentConversationId())
                sendMessage(newMessage)
                getViewInterface()?.enableInput()
            } catch (t: Throwable) {
                Log.e(tag, t)
                getViewInterface()?.enableInput()
                getViewInterface()?.showErrorSendMessage()
                return@launch
            }

            try {
                val conversation = getConversationSuspend(conversationId)
                val messages = if (conversation != null) getMessages(conversation) else null
                if (messages != null) {
                    for (message in messages.data) {
                        MessagesRepository.getInstance().removeExpirationMessage(messageId = message.id)
                    }
                }
            } catch (t: Throwable) {
                Log.e(tag, t)
            }
        }
    }

    private fun createConversation(textMessage: String) {
        clearDraftMessageUseCase("")
        getViewInterface()?.clearInput()

        presenterScope.launch {
            val firstMessage = try {
                removeWelcomeMessage()
                val m = createMessage(textMessage, "", isFirst = true, status = MessageStatus.LOADING)
                saveMessage(m)
            } catch (t: Throwable) {
                Log.e(tag, t)
                return@launch
            }

            // Очищаем прежние подписки (commonSubscribes и пр.) перед стартом нового диалога.
            resetSubscriptions()

            try {
                val nConversationId = createConversationSuspend(textMessage)
                if (!TextUtils.isEmpty(nConversationId)) {
                    viewModel.updateCurrentConversationId(nConversationId)
                    try {
                        val conv = getConversationSuspend(nConversationId)
                        commonSubscribes()
                        val convId = conv?.id!!
                        updateStatusMessage(firstMessage, MessageStatus.LOADED.name.lowercase(Locale.getDefault()))
                        updateConversationMessage(convId, firstMessage)
                        getViewInterface()?.enableInput()
                    } catch (t: Throwable) {
                        Log.e(tag, t.message)
                    }
                } else {
                    getViewInterface()?.showErrorSomething()
                }
            } catch (t: Throwable) {
                getViewInterface()?.showErrorSomething()
            }
        }
    }

    private fun loadMessages(needHardUpdate: Boolean = false) {
        val context = getViewInterface()?.getCurrentContext()
        if (context != null) {
            SharedPreferencesLib.saveLong(context, "last_load_messages_time_key", Date().time)
        }

        val tokenIsActual = if(context != null) {
            isActualJwtToken(context)
        } else {
            true
        }

        if(!tokenIsActual) {
            presenterScope.launch {
                val token = refreshJwtToken()
                if (token != null) {
                    if (userRepository == null) {
                        userRepository = CarrotInternal.getLibComponent().getUserRepository()
                    }
                    val tempUser = userRepository?.getUser()
                    tempUser?.token = token
                    userRepository?.saveUser(tempUser)

                    runUpdateMessages(needHardUpdate)
                } else {
                    e("RetrofitModule", "refresh token error")
                    // refresh не удался (нет валидной сессии) — пробуем общий путь: он дождётся
                    // Ready (SDK переинициализируется при сети) и в любом случае снимет спиннер.
                    runUpdateMessages(needHardUpdate)
                }
            }
        } else {
            runUpdateMessages(needHardUpdate)
        }
    }

    private fun runUpdateMessages(needHardUpdate: Boolean) {
        val conversationId = viewModel.getCurrentConversationId()
        if (conversationId.isEmpty() || "last_conversation" == conversationId) {
            return
        }

        presenterScope.launch {
            try {
                // Self-heal после cold-start-offline: если сессия ещё не установлена (init не дошёл
                // до Ready), getConversation/getMessages ушли бы без авторизации → null → вечный
                // спиннер. При возврате сети SDK сам переинициализируется (CarrotSDK networkReconnect
                // → commonSetup); дожидаемся Ready с таймаутом, затем грузим.
                if (!SdkStateManager.isInit()) {
                    withTimeoutOrNull(AWAIT_READY_TIMEOUT_MS) { SdkStateManager.awaitReady() }
                }

                val conversation = getConversationSuspend(conversationId)
                val response = if (conversation != null) getMessages(conversation) else null
                if (response != null) {
                    val messages = ArrayList<MessageData>()
                    messages.addAll(response.data)
                    MessagesRepository.getInstance()
                        .addMessages(messages, hardUpdate = needHardUpdate)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                Log.e(TAG, t)
            } finally {
                // Спиннер снимаем ВСЕГДА (раньше hideLoading звался только при response != null →
                // на cold-start-offline без сессии диалог висел в вечном спиннере). hideLoadError()
                // переводит UI в Loading, и кроме нас setReady() никто не зовёт.
                getViewInterface()?.hideLoading()
            }
        }
    }

    fun onOpenLastDialog() {
        val hasInternet =
            NetworkManager.getInstance(CarrotInternal.getLibComponent().contextSdk).hasConnect

        if (hasInternet) {
            presenterScope.launch {
                try {
                    val conversation = getLastConversation()
                    if (conversation != null && conversation.id != null && conversation.id != "") {
                        onChangeConversationId(conversation.id)
                        onOpenDialog()
                    } else {
                        onOpenNewDialog()
                    }
                } catch (t: Throwable) {
                    Log.e(tag, t)
                }
            }
        }
    }

    fun onOpenFile(uri: Uri?) {
        val dialogActivity = getViewInterface()?.getCurrentContext() as? android.app.Activity
        if (dialogActivity != null) {
            val filePickerHelper = FilePickerHelper(dialogActivity)

            if (uri != null) {
                try {
                    val file = filePickerHelper.getFile(uri)
                    val path = file.absolutePath

                    val fileTypeIsCorrect = filePickerHelper.fileTypeIsCorrect(path)
                    if (!fileTypeIsCorrect) {
                        filePickerHelper.showFileTypeError()
                        return
                    }


                    val isCorrectSize =
                        file.length() in 1 until (FilePickerHelper.maxSize * 1024 * 1024)

                    if (isCorrectSize) {
                        presenterScope.launch {
                            val conversation = getConversationSuspend(viewModel.getCurrentConversationId())
                            if (conversation != null) {
                                sendMessageWithAttachment(
                                    file,
                                    (java.lang.Long.parseLong(conversation.lastUpdate!!) + 1).toString()
                                )
                            } else {
                                createConversationByFile(file)
                            }
                        }
                    } else {
                        val isImage = filePickerHelper.fileIsImage(path)

                        if (isImage) {
                            filePickerHelper.showSizeError(
                                dialogActivity.getString(R.string.error_image_size_title),
                                dialogActivity.getString(R.string.error_image_size_message)
                            )
                        } else {
                            filePickerHelper.showSizeError(
                                dialogActivity.getString(R.string.error_file_size_title),
                                dialogActivity.getString(R.string.error_file_size_message)
                            )
                        }

                        return
                    }
                } catch (e: Exception) {
                    android.util.Log.e("SELECT_FILE ANDROID", e.toString())
                }
            } else {
                android.util.Log.d("PhotoPicker", "No media selected")
            }
        }

        presenterScope.launch {
            delay(2000)
            isOpenPicker = false
        }
    }

    private fun sendMessageWithAttachment(file: File, date: String) {
        val attachment = Attachment()
        attachment.id = date
        attachment.created = date
        attachment.filename = file.name
        attachment.size = file.length()
        attachment.url = file.absolutePath

        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
            MimeTypeMap.getFileExtensionFromUrl(
                Uri.fromFile(file).toString()
            ).lowercase(Locale.getDefault())
        )
        attachment.mimeType = mimeType

        if (mimeType?.contains("image") == true) {
            attachment.type = "image"
        } else {
            attachment.type = ResponseFields.FILE_TYPE
        }

        var sendingRandomId = ""

        presenterScope.launch {
            try {
                val toSend = createMessage(
                    attachment,
                    viewModel.getCurrentConversationId(),
                    isNewDialog,
                    MessageStatus.LOADING
                )
                saveMessage(toSend)
                sendingRandomId = toSend.randomId

                val messageData = sendMessageWithAttachment(toSend)

                messageData.randomId = sendingRandomId

                val savedFile = SavedFile(System.currentTimeMillis().toString())
                savedFile.localUri = file.absolutePath
                savedFile.url = messageData.attachments[0].url
                if (db == null) {
                    db = CarrotInternal.getLibComponent().sdkDataBase
                }
                // Room-запись — на IO (presenterScope живёт на main; иначе дисковый I/O на UI-потоке).
                withContext(SdkDispatchers.io) { db?.savedFileDao()?.insert(savedFile) }

                val jsonSource = messageData.sourceJsonData
                messageData.sourceJsonData.remove(F.ID)
                messageData.sourceJsonData.put(F.ID, messageData.id)
                if (jsonSource.has(F.ATTACHMENTS) && jsonSource.getJSONArray(F.ATTACHMENTS) != null) {
                    val attachmentsJson = jsonSource.getJSONArray(F.ATTACHMENTS)
                    val attJson = attachmentsJson.getJSONObject(0)
                    attJson?.remove(F.STATUS)
                    val status = "loaded"
                    attJson.put(F.STATUS, status)

                    val nAttachments = JSONArray()
                    nAttachments.put(attJson)
                    messageData.sourceJsonData.remove(F.ATTACHMENTS)
                    messageData.sourceJsonData.put(F.ATTACHMENTS, nAttachments)
                }

                MessagesRepository.getInstance().updateMessage(messageData)
            } catch (t: Throwable) {
                Log.e(tag, t)
            }
        }
    }
}
