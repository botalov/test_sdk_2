package io.carrotquest_sdk.android.core.main

/**
 * The app theme, selected by the integrator via `Carrot.setTheme(...)`. [LIGHT] and [DARK] are
 * explicit; [FROM_WEB] follows the theme configured in the web admin panel; [FROM_DEVICE] follows
 * the system dark-mode setting. The two "auto" modes are resolved to [LIGHT] or [DARK] internally
 * by `getThemeUseCase(...)` before rendering.
 */
enum class ThemeSdk {
    LIGHT,
    DARK,
    FROM_WEB,
    FROM_DEVICE,
}