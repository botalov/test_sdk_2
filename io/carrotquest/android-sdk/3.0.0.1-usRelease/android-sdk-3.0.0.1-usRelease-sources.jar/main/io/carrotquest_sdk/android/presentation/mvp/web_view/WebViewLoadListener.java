package io.carrotquest_sdk.android.presentation.mvp.web_view;

// Java-friendly колбэк "WebView загрузился" (раньше io.reactivex.Observer<Boolean>; ветка remove_rx).
public interface WebViewLoadListener {
    void onLoaded(boolean success);
}
