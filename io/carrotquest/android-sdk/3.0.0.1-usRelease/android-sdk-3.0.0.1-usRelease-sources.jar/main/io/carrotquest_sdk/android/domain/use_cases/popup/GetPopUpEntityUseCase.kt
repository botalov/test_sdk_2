package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.domain.entities.popup.PopUpMessageEntity
import kotlinx.coroutines.withContext

suspend fun getPopUpEntity(conversationId: String): PopUpMessageEntity? = withContext(SdkDispatchers.io) {
    val dbEntities = SdkApp
        .getInstance()
        .database
        .popUpDao()
        .getAllPopUpsSync()

    val foundPopup = dbEntities.firstOrNull { it.id == conversationId } ?: return@withContext null
    PopUpMessageEntity(
        foundPopup.id,
        foundPopup.bodyJson,
        foundPopup.expirationTime,
        foundPopup.backgroundColor
    )
}
