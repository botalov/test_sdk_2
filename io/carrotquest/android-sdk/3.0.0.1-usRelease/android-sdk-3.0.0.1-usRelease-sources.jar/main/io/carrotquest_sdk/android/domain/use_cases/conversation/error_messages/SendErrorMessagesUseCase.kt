package io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages

import com.google.gson.Gson
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData
import io.carrotquest_sdk.android.application.SdkApp
import io.carrotquest_sdk.android.data.db.CarrotSdkDB
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.sendMessage
import io.carrotquest_sdk.android.domain.use_cases.conversations.messages.sendMessageWithAttachment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject

// Скоуп fire-and-forget переотправки ошибочных сообщений (раньше Observable.subscribe на Schedulers.io).
private val errorMessagesScope = CoroutineScope(SdkDispatchers.io + SupervisorJob())

fun sendErrorMessages(messages: List<MessageData>) {
    val db: CarrotSdkDB = SdkApp.getInstance().database

    messages.forEach { message ->
        message.sourceJsonData = JSONObject(Gson().toJson(message))
        addMessageToConversation(message)

        db.failSendingMessageDao().updateProcessStatus(message.id, 1)

        // Раньше: Observable.just(message).sendMessage()/.sendMessageWithAttachment()
        // .doOnComplete{clear+update}.doOnError{updateStatus 0}.subscribe().
        // sendMessageWithAttachment не бросает (ошибку отдаёт значением) → всегда clear+update.
        // sendMessage бросает на сетевой ошибке → catch → updateStatus(0).
        errorMessagesScope.launch {
            try {
                if (message.attachments != null && message.attachments.isNotEmpty()) {
                    sendMessageWithAttachment(message)
                } else {
                    sendMessage(message)
                }
                clearErrorMessage(messageId = message.id)
                updateMessagesAtConversation(message.conversation)
            } catch (e: Throwable) {
                db.failSendingMessageDao().updateProcessStatus(message.id, 0)
            }
        }
    }
}

private fun addMessageToConversation(message: MessageData) {
    MessagesRepository.getInstance().addMessage(message)
}

private fun updateMessagesAtConversation(conversationId: String) {
    errorMessagesScope.launch {
        try {
            val response = CarrotLib.getLibComponents().carrotApi.getMessages(conversationId)
            val list = ArrayList<MessageData>()
            list.addAll(response.data)
            MessagesRepository.getInstance().addMessages(list)
        } catch (e: Throwable) {
            // мягкий фолбэк — обновление списка не критично
        }
    }
}