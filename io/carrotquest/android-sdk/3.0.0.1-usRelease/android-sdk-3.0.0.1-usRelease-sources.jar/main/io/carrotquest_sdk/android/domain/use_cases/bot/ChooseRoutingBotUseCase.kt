package io.carrotquest_sdk.android.domain.use_cases.bot

import io.carrotquest_sdk.android.lib.network.responses.bot.ChooseRoutingBotData
import io.carrotquest_sdk.android.core.main.CarrotInternal

/**
 * suspend-ядро (ветка remove_rx). Возвращает данные роутинг-бота для диалога;
 * при ошибке — пустой [ChooseRoutingBotData] (как раньше onErrorReturn).
 * Observable-ext chooseRoutingBot / getBotIdFromJson удалены (осиротели).
 */
suspend fun loadRoutingBot(conversationId: String): ChooseRoutingBotData? {
    val cId = if (conversationId == "last_conversation") "" else conversationId
    return try {
        CarrotInternal.getService().carrotLib.chooseRoutingBotSuspend(cId).data
    } catch (e: Exception) {
        ChooseRoutingBotData()
    }
}
