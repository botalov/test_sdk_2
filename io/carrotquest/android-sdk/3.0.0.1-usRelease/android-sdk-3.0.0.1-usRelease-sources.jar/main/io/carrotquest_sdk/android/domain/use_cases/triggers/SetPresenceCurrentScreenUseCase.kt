package io.carrotquest_sdk.android.domain.use_cases.triggers

import io.carrotquest_sdk.android.lib.network.F
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.domain.use_cases.user.getCurrentUser

class SetPresenceCurrentScreenUseCase {
    // Сначала убеждаемся, что юзер загружен (getCurrentUser suspend), затем отправляем presence.
    suspend fun call(screenName: String) {
        getCurrentUser() ?: return
        try {
            CarrotInternal.getService().carrotLib.setPresenceCurrentScreenSuspend(F.ONLINE_USER, screenName)
            Log.d("setPresenceCurrentScreen", "success")
        } catch (t: Throwable) {
            Log.e("setPresenceCurrentScreen", "error: $t")
        }
    }
}
