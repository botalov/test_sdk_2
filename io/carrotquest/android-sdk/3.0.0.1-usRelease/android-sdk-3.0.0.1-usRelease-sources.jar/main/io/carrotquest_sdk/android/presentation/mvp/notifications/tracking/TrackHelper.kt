package io.carrotquest_sdk.android.presentation.mvp.notifications.tracking

import io.carrotquest_sdk.android.Callback

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.google.gson.Gson
import io.carrotquest_sdk.android.lib.network.responses.base.NetworkResponse
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.core.utm.UTM
import io.carrotquest_sdk.android.core.utm.UtmUtil
import io.carrotquest_sdk.android.models.Operation
import io.carrotquest_sdk.android.models.UserProperty
import java.util.Locale
import java.util.concurrent.TimeUnit

fun trackClick(conversationId: String, callback: Callback<Boolean>) {
    if(CarrotInternal.getService() != null && CarrotInternal.getService().isInit) {
        callTrackClickByPush(conversationId, callback)
    } else {
        CarrotInternal.setupWithoutConnect(CarrotInternal.getLibComponent().contextSdk)
        callTrackClickByPush(conversationId, callback)
    }
}

private fun callTrackClickByPush(conversationId: String, callback: Callback<Boolean>) {
    CarrotInternal.getService().trackClickByPush(conversationId, callback)
}

fun trackUtm(link: String) {
    if(CarrotInternal.getService() != null && CarrotInternal.getService().isInit) {
        recordUtm(link)
    } else {
        CarrotInternal.setupWithoutConnect(CarrotInternal.getLibComponent().contextSdk)
        recordUtm(link)
    }
}

private fun recordUtm(link: String) {
    val utmString = link.substringAfter("?", "").substringBefore("#")
    if(utmString.isEmpty()) {
        return
    }

    val utmList = UtmUtil.getHashMapParamsFromQuery(utmString)
    trackEvents(utmList)
    setProps(utmList)
}

private fun trackEvents(utmList: HashMap<String, String>) {
    val filteredMap = utmList.filter { (k, _) -> k.lowercase() == UTM.SOURCE.value
            || k.lowercase() == UTM.CAMPAIGN.value
            || k.lowercase() == UTM.CONTENT.value
            || k.lowercase() == UTM.TERM.value
            || k.lowercase() == UTM.MEDIUM.value }
    val jsonStrForEvent = Gson().toJson(filteredMap)
    CarrotInternal.getService().trackEventSimple(
        "\$utm_hit",
        jsonStrForEvent,
        object : Callback<NetworkResponse> {
            override fun onResponse(result: NetworkResponse) {}
            override fun onFailure(t: Throwable) {}
        })

    // HashMap не гарантирует порядок ключей, поэтому ищем cq_event напрямую,
    // а cq_event_* собираем фильтрацией по всей мапе — без привязки к позиции.
    val eventName = utmList.entries
        .firstOrNull { (k, _) -> k.lowercase() == "cq_event" }?.value
    if (eventName != null) {
        val params = utmList
            .filter { (k, _) -> k.lowercase().startsWith("cq_event_") }
            .mapKeys { (k, _) -> k.lowercase().removePrefix("cq_event_") }

        CarrotInternal.getService().trackEventSimple(
            eventName,
            Gson().toJson(params),
            object : Callback<NetworkResponse> {
                override fun onResponse(result: NetworkResponse) {}
                override fun onFailure(t: Throwable) {}
            })
    }
}

private fun setProps(utmList: HashMap<String, String>) {
    val propsArray = ArrayList<UserProperty>()
    for (utmKey in utmList.keys) {
        val key = when (val utmKeyLowerCase = utmKey.lowercase(Locale.getDefault())) {
            UTM.SOURCE.value -> {
                "\$last_utm_source"
            }

            UTM.MEDIUM.value -> {
                "\$last_utm_medium"
            }

            UTM.CAMPAIGN.value -> {
                "\$last_utm_campaign"
            }

            UTM.TERM.value -> {
                "\$last_utm_term"
            }

            UTM.CONTENT.value -> {
                "\$last_utm_content"
            }

            else -> {
                if (utmKeyLowerCase.contains("cq_identify_")) {
                    utmKeyLowerCase.substringAfter("cq_identify_")
                } else {
                    ""
                }
            }
        }

        if (key.isNotEmpty()) {
            val value = utmList[utmKey] ?: continue
            propsArray.add(
                UserProperty(
                    Operation.UPDATE_OR_CREATE,
                    key,
                    value
                )
            )
        }
    }

    CarrotInternal.getService().setUserPropertySimple(propsArray)
}

fun trackDelivered(context: Context, conversationId: String) {
    Log.d("trackDelivered start", conversationId)
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    val workData = workDataOf("CONVERSATION_ID" to conversationId)

    val workRequest = OneTimeWorkRequestBuilder<PushDeliveryWorker>()
        .setConstraints(constraints)
        .setInputData(workData)
        .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
        .build()

    // Используем enqueueUniqueWork (REPLACE), чтобы не плодить дубликаты задач
    // для одного и того же пуша, если мы будем вызывать это при старте приложения
    WorkManager.getInstance(context).enqueueUniqueWork(
        "delivery_push_$conversationId",
        ExistingWorkPolicy.REPLACE,
        workRequest
    )
}

fun syncPendingDeliveredPushes(context: Context) {
    Log.d("syncPendingDeliveredPushes", "start")
    // Запускаем в отдельном потоке, чтобы не тормозить UI при чтении SharedPreferences
    Thread {
        val context = CarrotInternal.getLibComponent().contextSdk
        val pendingPushes = PushStorage.getPendingPushes(context)
        Log.d("syncPendingDeliveredPushes", pendingPushes.toString())
        for (conversationId in pendingPushes) {
            // Снова ставим их в очередь WorkManager
            trackDelivered(context, conversationId)
        }
    }.start()
}