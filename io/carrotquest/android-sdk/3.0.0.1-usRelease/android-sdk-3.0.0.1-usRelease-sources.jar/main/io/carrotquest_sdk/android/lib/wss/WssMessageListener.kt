package io.carrotquest_sdk.android.lib.wss

import io.carrotquest_sdk.android.lib.wss.response.WssResponse

/**
 * Колбэк-сток входящих RTS-сообщений (замена `io.reactivex.Observer<WssResponse>` в WSS-транспорте).
 *
 * Старый код тащил `List<Observer<WssResponse>>` через всю цепочку
 * IWssService → JwtWssService → JwtClientWebSocket → SocketListener, но реально передавался
 * ровно один observer, у которого использовался только `onNext` (onError/onComplete/onSubscribe —
 * пустышки). Свернули в один SAM-колбэк: `onMessage` дёргается на каждое входящее сообщение.
 *
 * `fun interface` — вызывается лямбдой из Kotlin и реализуется как обычный SAM-интерфейс из Java.
 */
fun interface WssMessageListener {
    fun onMessage(response: WssResponse)
}
