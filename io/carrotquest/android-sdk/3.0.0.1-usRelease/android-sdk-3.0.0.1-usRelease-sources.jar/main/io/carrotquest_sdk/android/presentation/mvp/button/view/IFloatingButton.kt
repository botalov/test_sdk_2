package io.carrotquest_sdk.android.presentation.mvp.button.view

import android.content.res.ColorStateList
import android.graphics.drawable.Drawable
import io.carrotquest_sdk.android.core.main.ThemeSdk
import io.carrotquest_sdk.android.presentation.mvp.base.IBaseView

interface IFloatingButton : IBaseView {
    fun initView()
    fun doVisible()
    fun doGone()
    fun show()
    fun hide()
    fun expand()
    fun collapse()
    fun showLastMessage()
    fun showLastMessageWithoutAvatar()
    fun hideLastMessage()
    fun updateTextLastMessage(text: String)
    fun updateLastAdminIcon(avatar: String)
    fun showUnreadCounter()
    fun hideUnreadCounter()
    fun updateUnreadCount(strCount: String)
    fun updateColor(colorFromSettings: ColorStateList)

    fun showFbButton()
    fun showVkButton()
    fun showTelegramButton()
    fun showViberButton()
    fun showInstagramButton()
    fun showWhatsappButton()

    fun showFbLabelButton()
    fun showVkLabelButton()
    fun showTelegramLabelButton()
    fun showViberLabelButton()
    fun showInstagramLabelButton()
    fun showWhatsappLabelButton()

    fun hideFbButton()
    fun hideVkButton()
    fun hideTelegramButton()
    fun hideViberButton()
    fun hideInstagramButton()
    fun hideWhatsappButton()

    fun hideFbLabelButton()
    fun hideVkLabelButton()
    fun hideTelegramLabelButton()
    fun hideViberLabelButton()
    fun hideInstagramLabelButton()
    fun hideWhatsappLabelButton()

    fun showOpenChatLabel()
    fun hideOpenChatLabel()

    fun updateIconOnFloatingButton(icon: Drawable?)
    fun setLocationFloatingButton(location: LocationFloatingButton)
    fun setMarginFloatingButton(margin: Float)
    fun updateMainBackgroundAlpha(alpha: Float)
    fun updateTheme(theme: ThemeSdk)
}