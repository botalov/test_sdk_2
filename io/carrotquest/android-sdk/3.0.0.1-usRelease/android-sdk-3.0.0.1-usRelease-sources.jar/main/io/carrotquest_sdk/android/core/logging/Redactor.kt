package io.carrotquest_sdk.android.core.logging

/**
 * Маскировка чувствительных значений для логов. По умолчанию секреты скрыты; при
 * includeSensitive=true (Carrot.setLogIncludeSensitive) возвращаются как есть — только для
 * локальной отладки. Чистые функции (без Android) — тестируются на JVM.
 */
internal object Redactor {

    /** Токен/ключ: при маскировке показываем только последние 4 символа («***abcd»). */
    fun token(value: String?, includeSensitive: Boolean): String {
        if (value.isNullOrEmpty()) return ""
        if (includeSensitive) return value
        return if (value.length <= 4) "***" else "***" + value.takeLast(4)
    }

    /** E-mail: при маскировке оставляем первый символ локальной части и домен («j***@x.com»). */
    fun email(value: String?, includeSensitive: Boolean): String {
        if (value.isNullOrEmpty()) return ""
        if (includeSensitive) return value
        val at = value.indexOf('@')
        if (at <= 0) return "***"
        return value.first() + "***" + value.substring(at)
    }
}
