package io.carrotquest_sdk.android.core.logging

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The SDK's single logging entry point. [getLevel] defaults to NONE — output is fully disabled
 * (the SDK writes nothing to logcat and incurs no overhead at the chatty levels). Enable it via
 * Carrot.setLogLevel(...). When enabled, every record is written to logcat and, if a sink was set
 * via Carrot.setLogSink(...), delivered to it as well.
 *
 * Independently of the output level, INFO-and-more-severe records are always kept in a small rolling
 * buffer ([SdkLogStore]) that persists to a private file, so Carrot.getDiagnostics() can include
 * recent history even when logcat output is off.
 */
object SdkLogger {

    // Уровень, начиная с которого записи попадают в персистентный буфер (независимо от output).
    private val CAPTURE_LEVEL = SdkLogLevel.INFO

    @Volatile
    private var level: SdkLogLevel = SdkLogLevel.NONE

    @Volatile
    private var includeSensitive: Boolean = false

    // Постоянный logcat-приёмник + один опциональный клиентский sink (см. setSink).
    private val logcatSink = LogcatSink()

    @Volatile
    private var clientSink: SdkLogSink? = null

    @JvmStatic
    fun setLevel(level: SdkLogLevel) {
        this.level = level
    }

    @JvmStatic
    fun getLevel(): SdkLogLevel = level

    /** Receiver of log entries set by the host app via Carrot.setLogSink; null removes it. */
    @JvmStatic
    fun setSink(sink: SdkLogSink?) {
        this.clientSink = sink
    }

    /** When true, sensitive values are logged in full instead of being masked (see [Redactor]). */
    @JvmStatic
    fun setIncludeSensitive(include: Boolean) {
        this.includeSensitive = include
    }

    @JvmStatic
    fun isIncludeSensitive(): Boolean = includeSensitive

    /** True if messages at level [l] are currently logged (use it to gate building expensive strings). */
    @JvmStatic
    fun isEnabled(l: SdkLogLevel): Boolean =
        l != SdkLogLevel.NONE && level != SdkLogLevel.NONE && l.ordinal <= level.ordinal

    /** Attaches the persistent rolling log buffer to the app's private storage (called once at setup). */
    @JvmStatic
    fun attachLogStore(context: Context) = SdkLogStore.attach(context)

    /** true, если запись уровня [l] должна попасть в персистентный буфер (INFO+), независимо от output. */
    @PublishedApi
    internal fun isCaptured(l: SdkLogLevel): Boolean =
        l != SdkLogLevel.NONE && l.ordinal <= CAPTURE_LEVEL.ordinal

    @JvmStatic
    @JvmOverloads
    fun log(
        level: SdkLogLevel,
        category: SdkLogCategory,
        tag: String,
        message: String,
        throwable: Throwable? = null,
        fields: Map<String, String> = emptyMap(),
    ) {
        if (!isEnabled(level) && !isCaptured(level)) return
        emit(SdkLogEntry(System.currentTimeMillis(), level, category, tag, message, fields, throwable))
    }

    /**
     * Lazy variant: [message] (and [fields]) are built only when the record is actually used (output
     * enabled or captured into the buffer). Prefer this at call sites that compose expensive strings.
     */
    inline fun log(
        level: SdkLogLevel,
        category: SdkLogCategory,
        tag: String,
        throwable: Throwable? = null,
        fields: Map<String, String> = emptyMap(),
        message: () -> String,
    ) {
        if (!isEnabled(level) && !isCaptured(level)) return
        emit(SdkLogEntry(System.currentTimeMillis(), level, category, tag, message(), fields, throwable))
    }

    @PublishedApi
    internal fun emit(entry: SdkLogEntry) {
        if (isCaptured(entry.level)) SdkLogStore.append(entry.toStoreLine())
        if (isEnabled(entry.level)) dispatch(entry)
    }

    private val timeFormat = ThreadLocal.withInitial { SimpleDateFormat("HH:mm:ss.SSS", Locale.US) }

    private fun SdkLogEntry.toStoreLine(): String {
        val time = timeFormat.get()!!.format(Date(timestampMs))
        val lvl = level.name.first()
        val cat = if (category != SdkLogCategory.GENERAL) "[${category.name}] " else ""
        val th = throwable?.let { " | ${it.javaClass.simpleName}: ${it.message}" } ?: ""
        return "$time $lvl $cat$tag: $message$th"
    }

    private fun dispatch(entry: SdkLogEntry) {
        try {
            logcatSink.onLog(entry)
        } catch (_: Throwable) {
        }
        clientSink?.let {
            try {
                it.onLog(entry)
            } catch (_: Throwable) {
            }
        }
    }

    // Короткие обёртки для категории GENERAL — на них переведены легаси-фасады Log.
    @JvmStatic
    @JvmOverloads
    fun e(tag: String, message: String, throwable: Throwable? = null) =
        log(SdkLogLevel.ERROR, SdkLogCategory.GENERAL, tag, message, throwable)

    @JvmStatic
    fun w(tag: String, message: String) = log(SdkLogLevel.WARN, SdkLogCategory.GENERAL, tag, message)

    @JvmStatic
    fun i(tag: String, message: String) = log(SdkLogLevel.INFO, SdkLogCategory.GENERAL, tag, message)

    @JvmStatic
    fun d(tag: String, message: String) = log(SdkLogLevel.DEBUG, SdkLogCategory.GENERAL, tag, message)

    @JvmStatic
    fun v(tag: String, message: String) = log(SdkLogLevel.VERBOSE, SdkLogCategory.GENERAL, tag, message)

    internal fun resetForTest() {
        level = SdkLogLevel.NONE
        includeSensitive = false
        clientSink = null
    }
}
