package io.carrotquest_sdk.android.presentation.container

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asAndroidColorFilter
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.createBitmap
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import io.carrotquest_sdk.android.core.util.Log
import kotlin.math.roundToInt

@Composable
fun TiledPatternImage(
    url: String,
    // Цвет подложки, поверх которой тайлится паттерн — нужен для авто-тинта по контрасту.
    accentColor: Color,
    modifier: Modifier = Modifier,
    scale: Float = 3f, // масштаб тайла (1f = оригинальный размер)
    // Явный фильтр от вызывающего; если не задан — вычисляем автоматически по контрасту с accent.
    colorFilter: ColorFilter? = null,
) {
    val context = LocalContext.current
    var bitmapState by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(url) {
        try {
            val request = ImageRequest.Builder(context)
                .data(url)
                .size(coil.size.Size.ORIGINAL)
                .allowHardware(false)
                .build()

            val result = context.imageLoader.execute(request)

            if (result is SuccessResult) {
                bitmapState = result.drawable.toBitmapSafely()
            }
        } catch (e: Exception) {
            Log.e("TiledPatternImage", "Error loading pattern image: $e")
        }
    }

    // Если вызывающий не задал фильтр — авто-тинт: одноцветный паттерн, плохо различимый на accent,
    // перекрашиваем в контрастный цвет (SrcIn сохраняет альфу/форму). Считаем один раз на (bitmap, accent).
    val effectiveFilter = remember(bitmapState, accentColor, colorFilter) {
        colorFilter ?: bitmapState?.let { bmp ->
            val pixels = IntArray(bmp.width * bmp.height)
            bmp.getPixels(pixels, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            patternTintArgb(pixels, accentColor.toArgb())?.let { tint ->
                ColorFilter.tint(Color(tint), BlendMode.SrcIn)
            }
        }
    }

    // Пересоздаем Paint, если изменился битмап, масштаб или фильтр
    val nativePaint = remember(bitmapState, scale, effectiveFilter) {
        bitmapState?.let { bmp ->
            android.graphics.Paint().apply {
                val bitmapShader = android.graphics.BitmapShader(
                    bmp,
                    android.graphics.Shader.TileMode.REPEAT,
                    android.graphics.Shader.TileMode.REPEAT
                )

                // Применяем масштаб, если он отличается от 1.0
                if (scale != 1f) {
                    val matrix = android.graphics.Matrix()
                    // Растягиваем/сжимаем по осям X и Y пропорционально
                    matrix.setScale(scale, scale)
                    bitmapShader.setLocalMatrix(matrix)
                }

                shader = bitmapShader

                // Применяем эффективный фильтр (явный или авто-тинт по контрасту), если он есть.
                if (effectiveFilter != null) {
                    this.colorFilter = effectiveFilter.asAndroidColorFilter()
                }
            }
        }
    }

    Spacer(
        modifier = modifier.drawBehind {
            if (nativePaint != null) {
                drawIntoCanvas { canvas ->
                    canvas.nativeCanvas.drawRect(
                        0f, 0f, size.width, size.height, nativePaint
                    )
                }
            }
        }
    )
}

// Порог контраста (WCAG-подобный, диапазон 1..21): ниже — паттерн почти сливается с accent,
// нужен тинт. Декор, не текст, поэтому порог низкий.
private const val PATTERN_CONTRAST_THRESHOLD = 1.5

/**
 * Возвращает ARGB-цвет тинта для одноцветного паттерна поверх [accentArgb] или null, если паттерн
 * пуст или уже достаточно контрастен. Чистая функция — без Compose/Android, тестируется на JVM.
 * [pixels] — ARGB-пиксели тайла (из Bitmap.getPixels).
 */
internal fun patternTintArgb(pixels: IntArray, accentArgb: Int): Int? {
    val ink = alphaWeightedColor(pixels) ?: return null
    if (contrastRatio(ink, accentArgb) >= PATTERN_CONTRAST_THRESHOLD) return null
    // Тинтуем в максимально контрастный к accent: тёмный на светлом accent, белый на тёмном
    // (порог 0.45 — как в SdkColors.onAccent для текста/иконок поверх accent).
    return if (relativeLuminance(accentArgb) > 0.45) 0xFF333333.toInt() else 0xFFFFFFFF.toInt()
}

/** Alpha-взвешенное среднее «краски» паттерна (ARGB, opaque) или null, если все пиксели прозрачны. */
internal fun alphaWeightedColor(pixels: IntArray): Int? {
    var aSum = 0.0; var r = 0.0; var g = 0.0; var b = 0.0
    for (p in pixels) {
        val a = (p ushr 24) and 0xFF
        if (a == 0) continue
        val af = a / 255.0
        r += ((p ushr 16) and 0xFF) * af
        g += ((p ushr 8) and 0xFF) * af
        b += (p and 0xFF) * af
        aSum += af
    }
    if (aSum <= 0.0) return null
    val rr = (r / aSum).roundToInt().coerceIn(0, 255)
    val gg = (g / aSum).roundToInt().coerceIn(0, 255)
    val bb = (b / aSum).roundToInt().coerceIn(0, 255)
    return (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
}

/** Относительная яркость по WCAG (совпадает с ColorUtils.calculateLuminance, но без Android-зависимости). */
internal fun relativeLuminance(argb: Int): Double {
    fun lin(c: Int): Double {
        val s = c / 255.0
        return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
    }
    val r = lin((argb ushr 16) and 0xFF)
    val g = lin((argb ushr 8) and 0xFF)
    val b = lin(argb and 0xFF)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b
}

/** Контраст по WCAG: (L1+0.05)/(L2+0.05), диапазон 1..21. */
internal fun contrastRatio(a: Int, b: Int): Double {
    val la = relativeLuminance(a)
    val lb = relativeLuminance(b)
    val hi = maxOf(la, lb)
    val lo = minOf(la, lb)
    return (hi + 0.05) / (lo + 0.05)
}

private fun Drawable.toBitmapSafely(): Bitmap {
    if (this is BitmapDrawable && this.bitmap != null) {
        return this.bitmap
    }
    val width = if (intrinsicWidth > 0) intrinsicWidth else 1
    val height = if (intrinsicHeight > 0) intrinsicHeight else 1
    val bitmap = createBitmap(width, height)
    val canvas = android.graphics.Canvas(bitmap)
    setBounds(0, 0, canvas.width, canvas.height)
    draw(canvas)
    return bitmap
}