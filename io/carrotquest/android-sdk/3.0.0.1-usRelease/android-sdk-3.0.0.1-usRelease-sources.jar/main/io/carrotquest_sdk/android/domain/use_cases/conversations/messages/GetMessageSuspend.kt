package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageData

/**
 * Suspend-версия getMessage (strangler, ветка remove_rx). Ищет сообщение по id в текущем
 * снимке MessagesRepository (как Observable-ext через getData().map{find}).
 * Заменила Observable-ext getMessage из GetMessageUseCase.kt.
 */
suspend fun getMessage(messageId: String): MessageData? =
    MessagesRepository.getInstance().findMessageById(messageId)
