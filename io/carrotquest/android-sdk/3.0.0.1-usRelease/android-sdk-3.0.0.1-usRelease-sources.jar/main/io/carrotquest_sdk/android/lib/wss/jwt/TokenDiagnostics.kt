package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.logging.Redactor
import java.util.Date

/**
 * Хелперы логирования токенов для диагностики у клиента. Токены НЕ светим целиком —
 * только маска (последние 4 символа + длина), чтобы лог можно было безопасно прислать в саппорт.
 */

internal fun maskToken(token: String?): String {
    if (token.isNullOrEmpty()) return "<empty>"
    // Ядро маскировки («***» + последние 4) — единое в [Redactor]; здесь добавляем длину,
    // чтобы по логу было видно пустой/обрезанный токен.
    return "${Redactor.token(token, includeSensitive = false)}(len=${token.length})"
}

/**
 * Человекочитаемая сводка состояния persisted-токенов: есть ли access/refresh, их возраст в секундах
 * и вердикт isActual. Используется в логах init/connect/auth, чтобы по логу клиента было видно,
 * почему SDK пошёл по тому или иному пути (refresh / token-less connect / прямой connect).
 */
internal fun tokenStateSummary(): String {
    val jwt = getJwtToken()
    val refresh = getRefreshToken()
    val now = Date().time
    val jwtAge = getLastUpdateJwtTokenTime().let { if (it <= 0) -1 else (now - it) / 1000 }
    val refreshAge = getLastUpdateRefreshToken().let { if (it <= 0) -1 else (now - it) / 1000 }
    return "access=${maskToken(jwt)}, accessAgeSec=$jwtAge, refresh=${maskToken(refresh)}, " +
            "refreshAgeSec=$refreshAge, isActualAccess=${runCatching { isActualJwtToken() }.getOrDefault(false)}, " +
            "isActualRefresh=${runCatching { isActualRefreshToken() }.getOrDefault(false)}"
}
