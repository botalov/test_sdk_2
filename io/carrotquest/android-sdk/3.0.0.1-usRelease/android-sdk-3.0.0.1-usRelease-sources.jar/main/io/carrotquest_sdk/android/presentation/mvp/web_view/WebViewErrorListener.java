package io.carrotquest_sdk.android.presentation.mvp.web_view;

// Java-friendly колбэк состояния ошибки WebView (раньше BehaviorSubject<Boolean>+Consumer; remove_rx).
public interface WebViewErrorListener {
    void onError(boolean hasError);
}
