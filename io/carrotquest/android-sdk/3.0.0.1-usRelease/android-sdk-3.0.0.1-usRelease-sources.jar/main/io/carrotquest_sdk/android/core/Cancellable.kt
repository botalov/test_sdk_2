package io.carrotquest_sdk.android.core

/**
 * Хэндл для отмены подписки на состояние SDK.
 *
 * Пришёл на смену `io.reactivex.disposables.Disposable` в публичном API SDK
 * (breaking change, major-версия — RxJava полностью убрана из contract'а).
 * `fun interface` (SAM) — из Java вызывается как `cancellable.cancel()`.
 */
fun interface Cancellable {
    fun cancel()
}
