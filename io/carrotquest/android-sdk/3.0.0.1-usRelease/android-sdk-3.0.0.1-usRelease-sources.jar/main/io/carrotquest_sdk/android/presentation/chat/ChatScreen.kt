package io.carrotquest_sdk.android.presentation.chat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.fragment.app.FragmentActivity
import io.carrotquest_sdk.android.R
import io.carrotquest_sdk.android.lib.full_image_view.view.FullImageViewDialogFragment
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.carrotquest_sdk.android.presentation.ui.LoadingContent
import io.carrotquest_sdk.android.presentation.ui.SdkColors

@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    accentColor: Color,
    isDark: Boolean,
    showPoweredBy: Boolean = false,
    appName: String = "",
    onEvent: (ChatEvent) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentOnEvent by rememberUpdatedState(onEvent)
    val handleEvent: (ChatEvent) -> Unit = remember(context, viewModel) {
        { event ->
            when (event) {
                is ChatEvent.ImageTapped -> {
                    val fm = (context as? FragmentActivity)?.supportFragmentManager
                    fm?.let { FullImageViewDialogFragment.newInstance(event.urls, event.initialIndex).show(it, "fullViewImage") }
                }
                is ChatEvent.FileTapped -> {
                    val file = viewModel.getFileAttachment(event.messageId, event.attachmentId)
                    val currentState = FileDownloadRepository.currentStateFor(
                        event.attachmentId, file?.downloadState ?: DownloadState.NotDownloaded,
                    )
                    when (currentState) {
                        is DownloadState.NotDownloaded -> file?.let {
                            FileDownloadRepository.download(scope, it.id, it.url, it.size)
                        }
                        is DownloadState.Downloading   -> FileDownloadRepository.cancel(event.attachmentId)
                        is DownloadState.Downloaded    ->
                            FileDownloadRepository.openFile(context, currentState.localPath, file?.mimeType ?: "")
                    }
                }
                else -> currentOnEvent(event)
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        when (val s = state) {
            is ChatScreenState.Loading -> LoadingContent(accentColor)
            is ChatScreenState.Error -> ChatErrorView(
                kind = s.kind,
                isDark = isDark,
                onRetry = { handleEvent(ChatEvent.Retry) },
            )
            is ChatScreenState.Content -> MessageList(
                items = s.items,
                accentColor = accentColor,
                isDark = isDark,
                isLoadingOlderMessages = s.isLoadingOlderMessages,
                canLoadOlderMessages = s.canLoadOlderMessages,
                showPoweredBy = showPoweredBy,
                appName = appName,
                onEvent = handleEvent,
            )
        }
    }
}

@Composable
fun ChatErrorView(
    kind: ErrorKind,
    isDark: Boolean,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val (title, message) = when (kind) {
        ErrorKind.NO_INTERNET  -> stringResource(R.string.chat_error_no_internet_title) to stringResource(R.string.chat_error_no_internet_message)
        ErrorKind.AIRPLANE_MODE -> stringResource(R.string.chat_error_airplane_title)   to stringResource(R.string.chat_error_airplane_message)
        ErrorKind.GENERIC      -> stringResource(R.string.chat_error_generic_title)     to stringResource(R.string.chat_error_generic_message)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = title,
            color = SdkColors.title(isDark),
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = message,
            color = SdkColors.secondaryText(isDark),
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = onRetry,
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SdkColors.title(isDark)),
        ) {
            Text(text = stringResource(R.string.chat_retry), color = SdkColors.background(isDark))
        }
    }
}


