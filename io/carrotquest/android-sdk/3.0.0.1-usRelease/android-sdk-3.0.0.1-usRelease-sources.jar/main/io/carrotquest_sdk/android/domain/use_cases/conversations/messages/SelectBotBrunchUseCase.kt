package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import io.carrotquest_sdk.android.lib.utils.loging.Log
import io.carrotquest_sdk.android.core.main.CarrotInternal
import org.json.JSONObject

/**
 * suspend-версия selectBotBrunch (ветка remove_rx). Возвращает успех (status == 200).
 * Семантика 1:1: ошибку логирует и пробрасывает (как doOnError без onErrorReturn);
 * потребители (DialogPresenter) оборачивают в try.
 */
suspend fun selectBotBrunch(messageId: String, actionId: String, actionBody: String): Boolean {
    val metaDataJson = JSONObject()
    metaDataJson.put("answer_action_id", actionId)
    metaDataJson.put("answer_body", actionBody)

    return try {
        CarrotInternal.getService().carrotLib
            .setMetaDataSuspend(messageId, metaDataJson.toString())
            .status == 200
    } catch (e: Throwable) {
        Log.Companion.e("", e)
        throw e
    }
}
