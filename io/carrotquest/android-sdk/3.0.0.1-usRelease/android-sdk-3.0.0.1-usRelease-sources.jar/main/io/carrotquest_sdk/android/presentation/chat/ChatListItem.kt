package io.carrotquest_sdk.android.presentation.chat

sealed class ChatListItem {

    data class DateDivider(val dateLabel: DateLabel) : ChatListItem()

    data class TypingIndicator(
        val name: String?,
        val avatarUrl: String?,
    ) : ChatListItem()

    data class Message(
        val id: String,
        val direction: Direction,
        val sender: Sender?,
        val timestampMs: Long,
        val deliveryStatus: DeliveryStatus?,
        val content: MessageContent,
        // Сообщение порождено ботом (auto_reply/chat_bot/article/блок с actions), а не оператором.
        // Используется автоскроллом: на сообщение бота всегда скроллим к низу.
        val isBot: Boolean = false,
    ) : ChatListItem()

    data class BotOptionsGroup(
        val messageId: String,
        val options: List<BotOption>,
        val isAnswered: Boolean,
        val selectedOptionId: String? = null,
    ) : ChatListItem()

    data class VoteCard(
        val messageId: String,
        val voteState: VoteState,
        val questionText: String = "",
    ) : ChatListItem()
}

enum class Direction { INCOMING, OUTGOING }

data class Sender(
    val name: String?,
    val avatarUrl: String?,
)

enum class DeliveryStatus { SENDING, SENT, READ, FAILED }

data class BotOption(
    val id: String,
    val branchId: String?,
    val text: String,
    // Ссылка, зашитая в кнопку бота (если есть): открывается при выборе ветки.
    val link: String? = null,
)

sealed class DateLabel {
    data object Today : DateLabel()
    data object Yesterday : DateLabel()
    data class Exact(val formatted: String) : DateLabel()
}

sealed class VoteState {
    data object Pending : VoteState()
    data object Loading : VoteState()
    data class Rated(val score: Int) : VoteState()
}
