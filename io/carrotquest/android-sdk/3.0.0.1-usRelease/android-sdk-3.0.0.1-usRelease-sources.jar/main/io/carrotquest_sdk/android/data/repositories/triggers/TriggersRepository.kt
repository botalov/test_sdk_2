package io.carrotquest_sdk.android.data.repositories.triggers

import io.carrotquest_sdk.android.lib.network.responses.base.Meta
import io.carrotquest_sdk.android.lib.network.responses.triggers.TriggersResponse
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.data.db.triggers.TriggerDbEntity
import kotlinx.coroutines.flow.Flow

class TriggersRepository {

    companion object {
        private var instance: TriggersRepository? = null
        fun getInstance(): TriggersRepository {
            if (instance == null) {
                instance = TriggersRepository()
            }
            return instance!!
        }
    }

    suspend fun loadTriggers(): Boolean {
        val response = try {
            CarrotInternal.getService().carrotLib.getTriggersSuspend()
        } catch (e: Throwable) {
            // Раньше onErrorReturn: подменяли ответ статусом 600.
            TriggersResponse().apply {
                setMeta(Meta().apply {
                    status = 600
                    error = e.toString()
                })
            }
        }

        if (response.getMeta()?.status == 200) {
            val data = response.getData()
            if (data != null) {
                val trDao = CarrotInternal.getLibComponent().sdkDataBase.triggerDao()
                trDao.deleteAll()

                val dbList = data
                    .filter { t -> t.getKind() == 7 }
                    .map { t ->
                        try {
                            TriggerDbEntity(
                                id = t.getId() ?: "",
                                kind = t.getKind() ?: -1,
                                url = t.getUrl() ?: "",
                                comparison = t.getComparison() ?: "",
                            )
                        } catch (e: Throwable) {
                            TriggerDbEntity(id = "", kind = 0, url = "", comparison = "")
                        }
                    }

                trDao.insert(dbList)
            }
        }

        return response.getMeta()?.status == 200
    }

    fun getTriggers(): Flow<List<TriggerDbEntity>> {
        // triggerDao().getAll() возвращает Flow (room-ktx). Потребитель (GetTriggersUseCase)
        // переведён на suspend one-shot (.first()), мост asFlowable больше не нужен.
        return CarrotInternal.getLibComponent().sdkDataBase.triggerDao().getAll()
    }
}