package io.carrotquest_sdk.android.core

internal sealed class CarrotState {
    object Idle : CarrotState()
    object Initializing : CarrotState()
    object Ready : CarrotState()
    data class Failed(val error: Throwable) : CarrotState()
}
