package io.carrotquest_sdk.android.core.util.files.download_files;

import android.os.Environment;
import androidx.annotation.NonNull;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import io.carrotquest_sdk.android.BuildConfig;
import io.carrotquest_sdk.android.lib.network.F;
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse;
import io.carrotquest_sdk.android.core.main.CarrotInternal;
import io.carrotquest_sdk.android.core.util.Log;
import io.carrotquest_sdk.android.data.db.CarrotSdkDB;
import io.carrotquest_sdk.android.data.db.files.SavedFile;
import okhttp3.OkHttpClient;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * Скачивание файлов. Rx убран (ветка remove_rx): остался только кэш картинок попапа
 * (downloadFilesToCash) — блокирующий, вызывается с IO-потока. Прогресс-скачивание и
 * downloadF(Observable) удалены как мёртвые (чат качает через FileDownloadRepository).
 */
public class DownloadUtil {
    private static final String TAG = "DownloadUtil";
    public static final String BASE_URL = BuildConfig.BASE_FILES_URL;

    /**
     * Блокирующе скачивает картинки попапа в кэш. Вызывать с фонового потока
     * (раньше — Observable на Schedulers.io, fire-and-forget из saveImages).
     */
    public static void downloadFilesToCash(ArrayList<String> urls, String baseUrl) {
        DownloadAPI api = new DownloadAPI(baseUrl);
        for (String url : urls) {
            if (url != null && !url.isEmpty()) {
                String fileNameUrl = url.substring(baseUrl.length());
                String fileName = fileNameUrl.substring(fileNameUrl.lastIndexOf('/') + 1);

                File folder = new File(CarrotInternal.getLibComponent().getContextSdk().getExternalFilesDir(null), "cq_sdk_cache");

                if (!folder.exists() && !folder.mkdirs()) {
                    Log.e(TAG, "Failed to create directory: " + folder.getAbsolutePath());
                    continue;
                }

                fileName = getFreeName(folder, fileName);
                File outputFile = new File(folder, fileName);

                try {
                    if (outputFile.createNewFile()) {
                        String path = api.downloadFile(url, outputFile);
                        if (path != null) {
                            Log.d(TAG, "cached image = " + path);
                        }
                    }
                } catch (IOException e) {
                    Log.e(TAG, e);
                }
            }
        }
    }

    private static File getDownloadDirectory() {
        File dir = CarrotInternal.getLibComponent().getContextSdk().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir == null) {
            dir = new File(CarrotInternal.getLibComponent().getContextSdk().getFilesDir(), Environment.DIRECTORY_DOWNLOADS);
        }
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

    public static String getFreeName(String fileName) {
        return getFreeName(getDownloadDirectory(), fileName);
    }

    public static String getFreeName(File directory, String fileName) {
        File file = new File(directory, fileName);
        if (!file.exists()) {
            return fileName;
        }

        String[] parts = stripExtension(fileName);
        String name = parts[0];
        String ext = parts[1];

        int suffix = 1;
        while (new File(directory, name + " (" + suffix + ")" + ext).exists()) {
            suffix++;
        }
        return name + " (" + suffix + ")" + ext;
    }

    private static String[] stripExtension(String str) {
        if (str == null) return new String[]{"", ""};
        int pos = str.lastIndexOf(".");
        if (pos == -1) return new String[]{str, ""};
        return new String[]{str.substring(0, pos), str.substring(pos)};
    }

    private static class DownloadAPI {
        private static final String TAG = "DownloadAPI";
        private static final int DEFAULT_TIMEOUT = 15;
        private final Retrofit retrofit;

        DownloadAPI(String baseUrl) {
            OkHttpClient client = new OkHttpClient.Builder()
                    .retryOnConnectionFailure(true)
                    .connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)
                    .build();

            // Без addCallAdapterFactory — дефолтный Call<T> (ветка remove_rx, RxJava2CallAdapter убран).
            retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(client)
                    .build();
        }

        /** Блокирующе скачивает url в file. Возвращает абсолютный путь или null при ошибке. */
        String downloadFile(@NonNull String url, final File file) {
            try {
                Response<ResponseBody> response = retrofit.create(DownloadService.class).download(url).execute();
                if (!response.isSuccessful() || response.body() == null) {
                    if (file.exists()) file.delete();
                    cleanUpDatabase(url);
                    return null;
                }
                try (InputStream stream = response.body().byteStream()) {
                    saveFile(stream, file);
                }
                return file.getAbsolutePath();
            } catch (Exception e) {
                Log.e(TAG, e.toString());
                if (file.exists()) file.delete();
                cleanUpDatabase(url);
                return null;
            }
        }

        private void cleanUpDatabase(String url) {
            CarrotSdkDB db = CarrotInternal.getLibComponent().getSdkDataBase();
            SavedFile savedFile = db.savedFileDao().getByURL(BASE_URL + url);
            if (savedFile != null) {
                db.savedFileDao().delete(savedFile.url);
            }
        }

        private void saveFile(InputStream stream, File file) {
            try {
                File parent = file.getParentFile();
                if (parent != null && !parent.exists()) {
                    parent.mkdirs();
                }

                if (!file.exists() && !file.createNewFile()) {
                    Log.e(TAG, "File not saved: " + file.getAbsolutePath());
                    return;
                }

                try (OutputStream output = new FileOutputStream(file)) {
                    byte[] buffer = new byte[8 * 1024];
                    int read;
                    while ((read = stream.read(buffer)) != -1) {
                        output.write(buffer, 0, read);
                    }
                    output.flush();
                } finally {
                    stream.close();
                }
            } catch (IOException e) {
                Log.e(TAG, e);
            }
        }
    }

    public static MessagesResponse replaceFilesLocalUrl(MessagesResponse response) {
        if (response == null || response.getData() == null) return response;

        CarrotSdkDB db = CarrotInternal.getLibComponent().getSdkDataBase();
        for (int i = 0; i < response.getData().size(); i++) {
            if (response.getData().get(i).getAttachments() == null) continue;

            for (int j = 0; j < response.getData().get(i).getAttachments().size(); j++) {
                String url = response.getData().get(i).getAttachments().get(j).getUrl();
                SavedFile savedFile = db.savedFileDao().getByURL(url);

                if (savedFile != null && new File(savedFile.localUri).exists() &&
                    !response.getData().get(i).getAttachments().get(j).getMimeType().contains("image")) {

                    response.getData().get(i).getAttachments().get(j).setUrl(savedFile.localUri);
                    response.getData().get(i).getAttachments().get(j).setType("loaded");
                    response.getData().get(i).getAttachments().get(j).setStatus("loaded");

                    response = replaceFileLocalUrlInSource(response, savedFile);
                }
            }
        }
        return response;
    }

    public static MessagesResponse replaceFileLocalUrlInSource(MessagesResponse response, SavedFile savedFile) {
        if (response == null || response.getSourceData() == null || !response.getSourceData().isJsonArray()) {
            return response;
        }

        JsonArray jsonArray = response.getSourceData().getAsJsonArray();
        for (JsonElement jsonMessage : jsonArray) {
            if (jsonMessage.isJsonObject()) {
                JsonElement attachments = jsonMessage.getAsJsonObject().get(F.ATTACHMENTS);
                if (attachments != null && attachments.isJsonArray()) {
                    for (JsonElement attachment : attachments.getAsJsonArray()) {
                        if (attachment.isJsonObject() && attachment.getAsJsonObject().has(F.URL) &&
                            savedFile.url.equals(attachment.getAsJsonObject().get(F.URL).getAsString())) {

                            attachment.getAsJsonObject().addProperty(F.URL, savedFile.localUri);
                            attachment.getAsJsonObject().addProperty(F.TYPE, "loaded");
                            attachment.getAsJsonObject().addProperty(F.STATUS, "loaded");
                        }
                    }
                }
            }
        }
        return response;
    }
}
