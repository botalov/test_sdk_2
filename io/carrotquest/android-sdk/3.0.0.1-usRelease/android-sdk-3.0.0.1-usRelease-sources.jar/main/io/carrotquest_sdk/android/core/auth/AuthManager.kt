package io.carrotquest_sdk.android.core.auth

import io.carrotquest_sdk.android.Callback

import io.carrotquest_sdk.android.core.logging.Redactor
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.main.CarrotSDK
import io.carrotquest_sdk.android.lib.models.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

internal object AuthManager {

    private const val TAG = "AuthManager"

    private val _state: MutableStateFlow<AuthState> = MutableStateFlow(AuthState.Idle)
    val state: StateFlow<AuthState> = _state.asStateFlow()

    fun isAuthenticating(): Boolean = _state.value is AuthState.Authenticating

    @Synchronized
    fun onAuthenticating() {
        val current = _state.value
        if (current is AuthState.Authenticating) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG, "onAuthenticating() ignored: already authenticating")
            return
        }
        _state.value = AuthState.Authenticating
        SdkLogger.log(SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "authenticating user")
    }

    @Synchronized
    fun onAuthenticated(userId: String) {
        val current = _state.value
        if (current !is AuthState.Authenticating) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG, "onAuthenticated() ignored, unexpected state: $current")
            return
        }
        _state.value = AuthState.Authenticated(userId)
        SdkLogger.log(
            SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG, "user authenticated",
            fields = mapOf("userId" to Redactor.token(userId, SdkLogger.isIncludeSensitive())),
        )
    }

    @Synchronized
    fun onFailed(error: Throwable) {
        val current = _state.value
        if (current !is AuthState.Authenticating) {
            SdkLogger.log(SdkLogLevel.WARN, SdkLogCategory.AUTH, TAG, "onFailed() ignored, unexpected state: $current")
            return
        }
        SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "auth failed", throwable = error)
        _state.value = AuthState.Failed(error)
    }

    @Synchronized
    fun onDeInit() {
        _state.value = AuthState.Idle
    }

    suspend fun auth(id: String, userAuthKey: String): Result<String> {
        onAuthenticating()
        return suspendCancellableCoroutine { cont ->
            val service = CarrotInternal.getService()
            if (service == null) {
                val error = IllegalStateException("SDK not initialized. Call setup() first.")
                onFailed(error)
                cont.resume(Result.failure(error))
                return@suspendCancellableCoroutine
            }
            service.authUser(id, userAuthKey, object : Callback<User> {
                override fun onResponse(result: User) {
                    val userId = result.id ?: ""
                    onAuthenticated(userId)
                    if (!cont.isCompleted) cont.resume(Result.success(userId))
                }

                override fun onFailure(t: Throwable) {
                    onFailed(t)
                    if (!cont.isCompleted) cont.resume(Result.failure(t))
                }
            })
        }
    }

    suspend fun hashedAuth(id: String, hash: String): Result<String> {
        onAuthenticating()
        return suspendCancellableCoroutine { cont ->
            val service = CarrotInternal.getService()
            if (service == null) {
                val error = IllegalStateException("SDK not initialized. Call setup() first.")
                onFailed(error)
                cont.resume(Result.failure(error))
                return@suspendCancellableCoroutine
            }
            service.hashedAuth(id, hash, object : Callback<User> {
                override fun onResponse(result: User) {
                    val userId = result.id ?: ""
                    onAuthenticated(userId)
                    if (!cont.isCompleted) cont.resume(Result.success(userId))
                }

                override fun onFailure(t: Throwable) {
                    onFailed(t)
                    if (!cont.isCompleted) cont.resume(Result.failure(t))
                }
            })
        }
    }
}
