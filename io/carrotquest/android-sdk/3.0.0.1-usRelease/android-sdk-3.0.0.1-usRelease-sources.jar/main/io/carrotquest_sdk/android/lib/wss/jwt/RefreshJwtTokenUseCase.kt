package io.carrotquest_sdk.android.lib.wss.jwt

import io.carrotquest_sdk.android.core.SdkStateManager
import io.carrotquest_sdk.android.core.logging.SdkLogCategory
import io.carrotquest_sdk.android.core.logging.SdkLogLevel
import io.carrotquest_sdk.android.core.logging.SdkLogger
import io.carrotquest_sdk.android.lib.CarrotLib

private const val TAG = "TokenFlow"

/**
 * Асинхронный refresh JWT-токена (ветка remove_rx, фаза 5: Rx → suspend).
 * При успехе (status 200) — сохраняет новые access+refresh в SharedPrefs и ВОЗВРАЩАЕТ новый access.
 * При не-200 / ошибке — возвращает null (не бросаем — общий поток токена не должен рваться).
 * При 4xx — серверный отказ (протухший refresh): notifySessionExpired() (клиент должен deInit()+setup()).
 *
 * Для синхронного пути (HTTP interceptor / ConnectionManager) используй [refreshJwtTokenBlocking].
 */
suspend fun refreshJwtToken(): String? {
    val carrotApi = CarrotLib.getLibComponents().carrotApi
    val needUpdateRefreshToken = !isActualRefreshToken()
    SdkLogger.log(
        SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
        "refreshJwtToken(async): requesting /refresh (updateRefreshToken=$needUpdateRefreshToken). State: ${tokenStateSummary()}",
    )
    return try {
        val response = carrotApi.refresh(needUpdateRefreshToken)
        if (response.meta.status == 200) {
            val token = response.data.access
            saveJwtToken(token)
            saveRefreshToken(response.data.refresh)
            SdkLogger.log(
                SdkLogLevel.INFO, SdkLogCategory.AUTH, TAG,
                "refreshJwtToken(async): SUCCESS, new access=${maskToken(token)}",
            )
            token
        } else {
            SdkLogger.log(
                SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG,
                "refresh non-200: status=${response.meta.status}, error=${response.meta.error}",
            )
            if (response.meta.status in 400..499) {
                SdkStateManager.notifySessionExpired()
            }
            null
        }
    } catch (e: Exception) {
        // Сетевая ошибка (IOException), TimeoutException и т.д. — логируем, токен не трогаем.
        SdkLogger.log(SdkLogLevel.ERROR, SdkLogCategory.AUTH, TAG, "refreshJwtToken(async): error $e", throwable = e)
        null
    }
}