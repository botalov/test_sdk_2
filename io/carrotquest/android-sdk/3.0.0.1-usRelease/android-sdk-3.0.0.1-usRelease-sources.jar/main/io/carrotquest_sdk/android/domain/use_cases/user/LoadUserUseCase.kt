package io.carrotquest_sdk.android.domain.use_cases.user

import io.carrotquest_sdk.android.lib.CarrotLib
import io.carrotquest_sdk.android.lib.utils.SharedPreferencesLib
import io.carrotquest_sdk.android.core.constants.SharedPreferenceKeys
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// loadUserById (Observable-ext) удалён — единственный потребитель (getCurrentUser Observable-ext)
// удалён; есть suspend getCurrentUser (GetCurrentUserSuspend.kt) + getUserSuspend.

// suspend-версия (ветка remove_rx). Заменила Observable-ext loadUserProps. Ошибка → пустая
// мапа (как onErrorReturn UserResponse()). Сохраняет push-флаги в SharedPreferences.
suspend fun loadUserProps(id: String): Map<String, Any> = withContext(Dispatchers.IO) {
    val tag = "loadUserProps"
    val res = HashMap<String, Any>()
    try {
        val userResponse = CarrotInternal.getService().carrotLib.loadUserSuspend(id)
        if (userResponse.data != null) {
            res.putAll(userResponse.data.props)
        }
    } catch (e: Exception) {
        Log.e(tag, "ERROR: $e")
    }
    saveUserProps(res)
    res
}


private fun saveUserProps(props: HashMap<String, Any>) {
    if(props.containsKey("\$sdk_push_notifications_subscribed")) {
        val value = props["\$sdk_push_notifications_subscribed"]
        if(value != null) {
            val v: Boolean? = if(value is Boolean) value else if(value is String) value.toBoolean() else null

            if(v != null) {
                val key = SharedPreferenceKeys.SDK_PUSH_NOTIFICATIONS_UNSUBSCRIBED
                SharedPreferencesLib.saveBoolean(CarrotLib.getLibComponents().context, key, !v)
            }
        }
    }

    if(props.containsKey("\$sdk_push_campaigns_subscribed")) {
        val value = props["\$sdk_push_campaigns_subscribed"]
        if(value != null) {
            val v: Boolean? = if(value is Boolean) value else if(value is String) value.toBoolean() else null

            if(v != null) {
                val key = SharedPreferenceKeys.SDK_PUSH_CAMPAIGNS_UNSUBSCRIBED
                SharedPreferencesLib.saveBoolean(CarrotLib.getLibComponents().context, key, !v)
            }
        }
    }
}


