package io.carrotquest_sdk.android.core.logging

/**
 * Receiver of the SDK's logs. Implement it to consume log events — for example, to pipe them into
 * your own logger or crash reporter. Invoked on the caller's thread, so keep it fast and do not
 * throw (a thrown exception is swallowed by the SDK so it cannot crash the host app).
 */
fun interface SdkLogSink {
    fun onLog(entry: SdkLogEntry)
}
