package io.carrotquest_sdk.android.domain.use_cases.settings

import io.carrotquest_sdk.android.data.repositories.SettingsRepository
import io.carrotquest_sdk.android.domain.entities.SettingsEntity

// Observable-ext getSettings удалена (ветка remove_rx) — все потребители на getSettingsSuspend
// (suspend) / getSettings()/getLastSettings() (sync).

fun getLastSettings(): SettingsEntity? = SettingsRepository.getInstance().getLastSettings()

fun getSettings(): SettingsEntity? = SettingsRepository.getInstance().getSettingsObject()

// suspend-версия: ждёт первую (реплеенную) эмиссию настроек (как awaitFirstOrNull на
// never-completing Observable).
suspend fun getSettingsSuspend(): SettingsEntity? = SettingsRepository.getInstance().awaitSettings()
