package io.carrotquest_sdk.android.domain.use_cases.popup

import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.db.popup.PopUpDbEntity
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.domain.entities.popup.PopUpMessageEntity
import kotlinx.coroutines.withContext
import java.util.Locale

suspend fun saveState(popUp: PopUpMessageEntity, isShowed: Boolean) = withContext(SdkDispatchers.io) {
    if (isShowed) {
        try {
            val db = CarrotInternal.getLibComponent()?.sdkDataBase
            db?.popUpDao()?.deleteById(popUp.id)
        } catch (e: Exception) {
            Log.e("saveState(). Remove raw.", e)
        }
    } else {
        try {
            val db = CarrotInternal.getLibComponent()?.sdkDataBase
            db?.popUpDao()?.insert(PopUpDbEntity(
                    id = popUp.id,
                    state = StatePopUp.FAILED_SHOWED.name.lowercase(Locale.getDefault()),
                    bodyJson = popUp.sourceBodyJson,
                    expirationTime = popUp.expirationTime,
                    backgroundColor = popUp.backgroundColor
            ))
        } catch (e: Exception) {
            Log.e("saveState(). Add raw.", e)
        }
    }
}