package io.carrotquest_sdk.android.data.db.messages

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ClosedMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(message: ClosedMessage)

    // Раньше возвращал Single<ClosedMessage> (room-rxjava2): пустой результат -> onError.
    // Теперь suspend с nullable: пустой результат -> null (ветка remove_rx, фаза 2).
    @Query("SELECT * FROM closedmessage WHERE id = :identifier")
    suspend fun getById(identifier: String): ClosedMessage?

    @Query("SELECT * FROM closedmessage")
    fun getAll(): List<ClosedMessage>

    @Query("DELETE FROM closedmessage WHERE id NOT IN (SELECT id from closedmessage ORDER BY id DESC LIMIT 20)")
    fun clear()
}