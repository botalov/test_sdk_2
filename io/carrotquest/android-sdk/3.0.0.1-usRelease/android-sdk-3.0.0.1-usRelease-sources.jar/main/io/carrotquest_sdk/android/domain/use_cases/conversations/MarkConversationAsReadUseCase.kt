package io.carrotquest_sdk.android.domain.use_cases.conversations

import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.Log
import io.carrotquest_sdk.android.data.repositories.ConversationsRepository

private const val markReadTag = "markConversationAsRead()"

// suspend-версии (strangler, ветка remove_rx). Отмечают диалог прочитанным + убирают unread.
// Ошибку глотаем (раньше onErrorReturn/doOnError), conversation/id возвращаем как passthrough.
suspend fun markConversationAsRead(conversation: DataConversation?): DataConversation? {
    val id = conversation?.id ?: return conversation
    try {
        val response = CarrotInternal.getService().carrotLib.markReadSuspend(id)
        if (response.status == 200) {
            ConversationsRepository.getInstance().removeUnreadConversation(id)
        }
    } catch (error: Throwable) {
        Log.e(markReadTag, error)
    }
    return conversation
}

suspend fun markConversationAsReadById(conversationId: String): String {
    try {
        val response = CarrotInternal.getService().carrotLib.markReadSuspend(conversationId)
        if (response.status == 200) {
            ConversationsRepository.getInstance().removeUnreadConversation(conversationId)
        }
    } catch (error: Throwable) {
        Log.e(markReadTag, error)
    }
    return conversationId
}