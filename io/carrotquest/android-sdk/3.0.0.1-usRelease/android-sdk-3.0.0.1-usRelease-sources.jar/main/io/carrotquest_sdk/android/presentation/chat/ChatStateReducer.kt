package io.carrotquest_sdk.android.presentation.chat

/**
 * Чистая reducer-логика: накладывает оптимистичные локальные состояния (ответы боту, голос,
 * форма контактов) поверх элементов, построенных [MessageMapper], и добавляет typing-индикатор.
 *
 * Вынесено из ChatViewModel.rebuildList ради детерминированного юнит-тестирования: функция не
 * зависит от корутин/синглтонов/БД. Подтверждённые сервером оверрайды возвращаются отдельными
 * множествами — вызывающий код удаляет их из локальных map-ов (побочный эффект снаружи).
 */
internal object ChatStateReducer {

    data class OverrideResult(
        val items: List<ChatListItem>,
        // id → серверный Rated, которым нужно ЗАМЕНИТЬ локальный Loading-оверрайд (пин на сессию,
        // см. ниже). Вызывающий сохраняет это в localVoteStates, а не удаляет оверрайд.
        val voteUpgrades: Map<String, VoteState.Rated>,
        val confirmedContactIds: Set<String>,
    )

    fun applyLocalOverrides(
        mapped: List<ChatListItem>,
        botAnswers: Map<String, String>,
        voteStates: Map<String, VoteState>,
        contactStates: Map<String, ContactInputState>,
        typing: ChatListItem.TypingIndicator?,
    ): OverrideResult {
        // Выбранная в этой сессии опция бота — применяем ВСЕГДА (даже если маппер уже пометил
        // группу isAnswered=true), иначе selectedOptionId теряется и выбранный чип исчезает.
        val withBotAnswers = if (botAnswers.isEmpty()) mapped else mapped.map { item ->
            if (item is ChatListItem.BotOptionsGroup) {
                val selectedId = botAnswers[item.messageId]
                if (selectedId != null) item.copy(isAnswered = true, selectedOptionId = selectedId) else item
            } else item
        }

        // Локальное состояние голоса. Когда сервер подтвердил Rated, пока ждали (Loading), НЕ снимаем
        // оверрайд, а ПИНим его как Rated на всю сессию (voteUpgrades). Причина: серверная копия
        // vote-сообщения нестабильна — последующий reload/WSS-обновление часто приходит БЕЗ оценки
        // (vote не персистится в читаемом messageMetaData.vote / гонка с getMessages), и если снять
        // оверрайд, карточка откатывается к выбору эмодзи (баг оценки оператора). Запиненный Rated
        // переживает такие откаты. Pending намеренно держит поле комментария открытым.
        val voteUpgrades = mutableMapOf<String, VoteState.Rated>()
        val withVoteOverrides = if (voteStates.isEmpty()) withBotAnswers else withBotAnswers.map { item ->
            if (item is ChatListItem.VoteCard) {
                val local = voteStates[item.messageId]
                val serverRated = item.voteState as? VoteState.Rated
                when {
                    local is VoteState.Loading && serverRated != null -> {
                        voteUpgrades[item.messageId] = serverRated // пин Rated на сессию
                        item
                    }
                    local != null -> item.copy(voteState = local)
                    else -> item
                }
            } else item
        }

        // Локальное состояние формы контактов: когда сервер присылает replied=true → маппер вернёт
        // Submitted → снимаем локальный оверрайд.
        val confirmedContactIds = mutableSetOf<String>()
        val withContactOverrides = if (contactStates.isEmpty()) withVoteOverrides else withVoteOverrides.map { item ->
            if (item is ChatListItem.Message) {
                val content = item.content as? MessageContent.ContactInputContent
                val local = contactStates[item.id]
                when {
                    local != null && content?.state is ContactInputState.Submitted -> { confirmedContactIds += item.id; item }
                    local != null && content != null -> item.copy(content = content.copy(state = local))
                    else -> item
                }
            } else item
        }

        // Typing-индикатор всегда в начале списка (reverseLayout=true → визуально снизу).
        val withTyping = typing?.let { listOf(it) + withContactOverrides } ?: withContactOverrides
        return OverrideResult(withTyping, voteUpgrades, confirmedContactIds)
    }
}
