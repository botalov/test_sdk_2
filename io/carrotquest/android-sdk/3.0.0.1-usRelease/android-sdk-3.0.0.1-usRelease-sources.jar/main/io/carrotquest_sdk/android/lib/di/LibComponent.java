package io.carrotquest_sdk.android.lib.di;

import android.content.Context;
import io.carrotquest_sdk.android.lib.CarrotApi;
import io.carrotquest_sdk.android.lib.di.ApiModule;
import io.carrotquest_sdk.android.lib.di.ContextModule;
import io.carrotquest_sdk.android.lib.di.GsonModule;
import io.carrotquest_sdk.android.lib.di.RepositoryModule;
import io.carrotquest_sdk.android.lib.repositories.IUserRepository;
import com.google.gson.Gson;
import dagger.Component;

import javax.inject.Singleton;

@Singleton
@Component(modules = {ContextModule.class, GsonModule.class, RepositoryModule.class, io.carrotquest_sdk.android.lib.di.ApiModule.class})
public interface LibComponent {
    CarrotApi getCarrotApi();
    Context getContext();
    Gson getGson();
    IUserRepository getUserRep();

    void inject(ApiModule apiModule);
    void inject(RepositoryModule repositoryModule);

}