package io.carrotquest_sdk.android.presentation.chat

sealed class MessageContent {

    data class TextContent(
        val body: String,
        val attachments: List<UiAttachment> = emptyList(),
    ) : MessageContent()

    data class ContactInputContent(
        val body: String,
        val placeholder: String?,
        val inputType: ContactInputType,
        val state: ContactInputState = ContactInputState.Idle,
    ) : MessageContent()

    data class ArticleLinkContent(
        val name: String,
        val shortDescription: String?,
        val url: String,
    ) : MessageContent()

    data class UnknownContent(val rawType: String?) : MessageContent()
}

enum class ContactInputType { EMAIL, PHONE, NAME, TEXT }

sealed class ContactInputState {
    data object Idle : ContactInputState()
    data object Submitting : ContactInputState()
    data class Submitted(val value: String) : ContactInputState()
}

sealed class UiAttachment {

    data class ImageAttachment(
        val url: String,
        val thumbnailUrl: String? = null,
    ) : UiAttachment()

    data class FileAttachment(
        val id: String,
        val name: String,
        val mimeType: String,
        val size: Long,
        // Серверный URL файла для скачивания. Хранится в модели, чтобы не резолвить его через
        // MessagesRepository по messageId (у бот-блоков id синтетический, а вложение лежит на
        // action, а не на message — там lookup не находит файл).
        val url: String,
        val downloadState: DownloadState = DownloadState.NotDownloaded,
    ) : UiAttachment()

    // Голосовое сообщение — отдельный вид вложения, рисуется плеером (а не карточкой файла),
    // но живёт в общем списке attachments наравне с файлами.
    data class VoiceAttachment(
        // Локальный путь (если файл уже скачан) или http-URL для стриминга через MediaPlayer.
        val url: String,
        // Длительность в секундах. 0 = неизвестна (в attachment её нет) — берётся из плеера.
        val durationSeconds: Int = 0,
    ) : UiAttachment()
}

sealed class DownloadState {
    data object NotDownloaded : DownloadState()
    data class Downloading(val progress: Float) : DownloadState()
    data class Downloaded(val localPath: String) : DownloadState()
}
