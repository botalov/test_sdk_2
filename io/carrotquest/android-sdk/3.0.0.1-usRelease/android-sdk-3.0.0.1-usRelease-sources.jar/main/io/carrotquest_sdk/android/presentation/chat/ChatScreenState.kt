package io.carrotquest_sdk.android.presentation.chat

sealed class ChatScreenState {
    data object Loading : ChatScreenState()
    data class Error(val kind: ErrorKind) : ChatScreenState()
    data class Content(
        val items: List<ChatListItem> = emptyList(),
        val isLoadingOlderMessages: Boolean = false,
        val canLoadOlderMessages: Boolean = true,
    ) : ChatScreenState()
}

enum class ErrorKind {
    NO_INTERNET,
    AIRPLANE_MODE,
    GENERIC,
}
