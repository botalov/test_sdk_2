package io.carrotquest_sdk.android.domain.entities

import io.carrotquest_sdk.android.lib.network.responses.messages.Attachment
import io.carrotquest_sdk.android.lib.network.responses.messages.MessageMetaData

data class MessageEntity(
    val id: String,
    val actions: List<ActionEntity>? = null,
    val created: String? = null,
    val conversation: String? = null,
    val body: String? = null,
    val bodyJson: String? = null,
    val read: Boolean? = null,
    val type: String? = null,
    val sentVia: String? = null,
    val first: Boolean? = null,
    val direction: String? = null,
    val status: String? = null,
    val replyType: String? = null,
    val randomId: String? = null,
    val messageFrom: AdminEntity? = null,
    val attachments: List<Attachment>? = null,
    val messageMetaData: MessageMetaData? = null,
    val expirationTime: Long? = null,
)