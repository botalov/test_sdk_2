package io.carrotquest_sdk.android.presentation.mvp.dialog.view;

import android.content.Context;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.util.AttributeSet;

public class RootContainerForKeyboard extends ConstraintLayout {

    // Java-friendly колбэк изменения высоты (раньше — Rx Observer<Pair>; ветка remove_rx).
    public interface OnSizeChangedListener {
        void onSizeChanged(int oldHeight, int newHeight);
    }

    private OnSizeChangedListener sizeListener;

    public void setSizeListener(OnSizeChangedListener listener) {
        this.sizeListener = listener;
    }

    public RootContainerForKeyboard(Context context) {
        super(context);
    }

    public RootContainerForKeyboard(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public RootContainerForKeyboard(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    protected void onSizeChanged(int w, int h, int oldW, int oldH) {
        super.onSizeChanged(w, h, oldW, oldH);
        if (sizeListener != null) {
            sizeListener.onSizeChanged(oldH, h);
        }
    }
}
