package io.carrotquest_sdk.android.data.repositories

import io.carrotquest_sdk.android.domain.entities.SettingsEntity
import io.carrotquest_sdk.android.domain.use_cases.countries.GetDefaultRegionUseCase
import io.carrotquest_sdk.android.domain.use_cases.countries.SaveCountryRegionUseCase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.first

class SettingsRepository {
    // Заменяет BehaviorSubject.create() (ветка remove_rx, фаза 4): replay=1 реплеит последние
    // настройки новым подписчикам и не эмитит до первого saveSettings — как BehaviorSubject.create().
    private val currentSettingsFlow = MutableSharedFlow<SettingsEntity>(replay = 1, extraBufferCapacity = 1)

    private var settings: SettingsEntity? = null

    companion object {
        @Volatile
        private var instance : SettingsRepository? = null
        // double-checked locking — как в ConversationsRepository/MessagesRepository:
        // без него гонка могла создать два инстанса (saveSettings в один, чтение из другого).
        fun getInstance(): SettingsRepository {
            return instance ?: synchronized(this) {
                instance ?: SettingsRepository().also { instance = it }
            }
        }
    }

    // Непрерывный поток настроек (раньше Observable-мост getSettings(); remove_rx).
    // Реплеит последние настройки новому подписчику (replay=1), не эмитит до первого saveSettings.
    fun settingsChangesFlow(): Flow<SettingsEntity> = currentSettingsFlow.asSharedFlow()

    // suspend-эквивалент getSettings().awaitFirstOrNull(): ждёт первую (реплеенную) эмиссию.
    // currentSettingsFlow никогда не завершается, поэтому возвращает только реальные настройки
    // (как awaitFirstOrNull на never-completing Observable — null фактически не приходит).
    suspend fun awaitSettings() : SettingsEntity = currentSettingsFlow.first()

    fun getLastSettings() : SettingsEntity? {
        return currentSettingsFlow.replayCache.firstOrNull()
    }

    fun saveSettings(settings: SettingsEntity) {
        this.settings = settings
        currentSettingsFlow.tryEmit(settings)

        //save current country
        val locale = settings.locale
        if(locale.isNotEmpty()) {
            val region = GetDefaultRegionUseCase().call(locale)
            SaveCountryRegionUseCase().call(region)
        }
    }

    fun getSettingsObject() = this.settings
}