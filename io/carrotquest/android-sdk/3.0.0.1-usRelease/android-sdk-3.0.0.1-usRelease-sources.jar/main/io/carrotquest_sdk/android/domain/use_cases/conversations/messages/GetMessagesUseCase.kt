package io.carrotquest_sdk.android.domain.use_cases.conversations.messages

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import io.carrotquest_sdk.android.core.coroutines.SdkDispatchers
import io.carrotquest_sdk.android.core.main.CarrotInternal
import io.carrotquest_sdk.android.core.util.files.download_files.DownloadUtil
import kotlinx.coroutines.withContext
import io.carrotquest_sdk.android.data.repositories.MessagesRepository
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.getErrorMessages
import io.carrotquest_sdk.android.domain.use_cases.conversation.error_messages.sendErrorMessages
import io.carrotquest_sdk.android.lib.network.responses.conversation.DataConversation
import io.carrotquest_sdk.android.lib.network.responses.messages.ActionMessage
import io.carrotquest_sdk.android.lib.network.responses.messages.MessagesResponse
import io.carrotquest_sdk.android.lib.utils.loging.Log

private const val tag = "getMessagesUseCase"

// История с сервера не возвращает actions бот-сообщений — восстанавливаем их из кэша
// (BotActionsDao), куда они попали при живом приёме по WSS. Сопоставление по messageId.
private fun restoreBotActions(resp: MessagesResponse) {
    val messages = resp.data ?: return
    val dao = try {
        CarrotInternal.getLibComponent().sdkDataBase.botActionsDao()
    } catch (e: Exception) {
        return
    }
    val listType = object : TypeToken<ArrayList<ActionMessage>>() {}.type
    for (m in messages) {
        if (!m.actions.isNullOrEmpty()) continue
        val id = m.id ?: continue
        val saved = dao.getById(id) ?: continue
        try {
            m.actions = Gson().fromJson(saved.actionsJson, listType)
        } catch (e: Exception) {
            // битый кэш — пропускаем
        }
    }
}

// suspend-версия (strangler, ветка remove_rx). Возвращает MessagesResponse? (раньше Optional в Observable).
// null = нет id / ответ без meta / ошибка в meta (как раньше Optional(null)).
suspend fun getMessages(conversation: DataConversation): MessagesResponse? {
    val id = conversation.id ?: return null

    val messageResponse = CarrotInternal.getService().carrotLib.getMessagesSuspend(id)
    if (messageResponse.meta == null) {
        Log.e(tag, "Error Get messages: messageResponse.meta is NULL")
        return null
    }
    if (messageResponse.meta.error != null) {
        Log.e(tag, "Error Get messages: ${messageResponse.meta.error}")
        return null
    }

    messageResponse.meta.nextAfter?.let { MessagesRepository.getInstance().setCurrentAfter(it) }

    // Файловый ввод-вывод (replaceFilesLocalUrl) и блокирующие Room-запросы (restoreBotActions,
    // getErrorMessages) — на IO: вызыватели идут на SdkDispatchers.main, иначе это блок UI-потока
    // (не падало лишь из-за allowMainThreadQueries).
    return withContext(SdkDispatchers.io) {
        val resp = DownloadUtil.replaceFilesLocalUrl(messageResponse)
        restoreBotActions(resp)

        val errorMessages = getErrorMessages(id)
        if (errorMessages.isNotEmpty()) {
            sendErrorMessages(errorMessages)
        }

        MessagesRepository.getInstance().setData(resp)
        resp
    }
}