package io.carrotquest_sdk.android.data.db.popup

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PopUpDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(file: PopUpDbEntity)

//    @Query("SELECT * FROM popupdbentity WHERE id = :id")
//    fun getById(id: String): PopUpDbEntity?

    @Query("SELECT * FROM popupdbentity")
    fun getAllPopUps(): Flow<List<PopUpDbEntity>>

    @Query("SELECT * FROM popupdbentity")
    fun getAllPopUpsSync(): List<PopUpDbEntity>

    @Query("DELETE FROM popupdbentity WHERE id=:id")
    fun deleteById(id: String)
}