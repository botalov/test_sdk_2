package io.carrotquest_sdk.android.data.db.messages

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ReadMessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(message: ReadMessage)

    // suspend + nullable вместо Single<ReadMessage> (room-rxjava2): пустой результат -> null.
    @Query("SELECT * FROM readmessage WHERE id = :idxxx")
    suspend fun getById(idxxx: String): ReadMessage?
}