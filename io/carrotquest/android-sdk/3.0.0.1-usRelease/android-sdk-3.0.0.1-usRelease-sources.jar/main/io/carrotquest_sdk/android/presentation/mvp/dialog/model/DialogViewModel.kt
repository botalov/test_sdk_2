package io.carrotquest_sdk.android.presentation.mvp.dialog.model


class DialogViewModel {
    companion object {
        private var instance: DialogViewModel? = null
        fun getInstance(): DialogViewModel {
            if (instance == null) {
                instance = DialogViewModel()
            }
            return instance!!
        }
    }

    // @Volatile: пишется/читается с разных диспатчеров (Main и IO) — как ChatViewModel.conversationId.
    @Volatile private var currentConversationId: String = ""
    private var needStartRoutingBot = false
    private var botId: String = ""

    fun updateCurrentConversationId(id: String) {
        this.currentConversationId = id
    }

    fun getCurrentConversationId() = this.currentConversationId

    fun needStartRoutingBot() = this.needStartRoutingBot

    fun setNeedStartRoutingBot(needStartRoutingBot: Boolean) {
        println("start_routing_bot setNeedStartRoutingBot $needStartRoutingBot")
        this.needStartRoutingBot = needStartRoutingBot
    }

    fun setRoutingBotId(botId: String) {
        this.botId = botId
    }

    fun getRoutingBotId() = this.botId
}